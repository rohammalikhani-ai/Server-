# DESIGN PRINCIPLES (Non-Negotiable)

These rules govern every future prompt/session working on this
project. If a proposed change would violate one of these, stop and
flag it rather than implementing it.

1. **Modular architecture.** No giant Main/God file. Every file has
   one clear job.
2. **Clear ownership.** Every module owns a clear responsibility and
   exposes clear interfaces/contracts — see `ARCHITECTURE.md`.
3. **Core vs. platform separation.** Core Game Logic stays separated
   from Minecraft/Fabric/Geyser implementation. `core/` and
   `modules/` never import platform-specific types.
4. **Adapters around external dependencies.** Mature ready-made
   mods/plugins/libraries/frameworks are welcome, but no important
   game system becomes permanently coupled to one external
   dependency — wrap it in `integrations/` behind a `core/contracts`
   interface.
5. **Investigate before adopting.** Before implementing a major
   subsystem, inspect available tools for license, compatibility,
   maintenance status, and Java/Bedrock/Geyser implications. Record
   the decision in `docs/decisions/`.
6. **One Game Logic, Multiple Client Presentations.** Java and
   Bedrock may render differently while sharing authoritative game
   rules/state.
7. **Story phasing / personal visibility.** Two players can share a
   location but see different entities/objects/states based on
   quest/faction/reputation/event conditions.
8. **Future-proof, not over-engineered.** Create clean extension
   points/interfaces now; do not implement systems the prototype
   doesn't need yet.
9. **Server-side authority.** AI/client input never directly controls
   Gold, Items, Ownership, Trades, Permissions, Damage, or
   Progression. Everything routes through server-side validation.
10. **Prefer events/interfaces/services over hard-coded coupling.**
    Cross-module communication goes through `core/events` or
    `core/contracts`, never direct calls into another module's
    internals.
11. **Understandable by humans and AI.** Every important module
    should be readable and reasoned-about by both a human developer
    and an AI assistant picking up the next task — clear names,
    documented contracts, no cleverness for its own sake.
