rootProject.name = "castel-slayer"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
        maven("https://repo.papermc.io/repository/maven-public/") {
            name = "paperMc"
        }
    }
}

include(":core")

// Existing Java modules. Their directories (modules/<name>/) are unchanged; each has
// its own build.gradle.kts that points Gradle at the existing internal/ + public/ layout.
include(":modules:character")
include(":modules:progression")
include(":modules:inventory")
include(":modules:equipment")
include(":modules:combat")

// Application layer: composes one active character's module state and drives the join/quit
// lifecycle. Paper-free; see docs/decisions/0004-application-runtime-layer.md.
include(":application:runtime")

include(":platform:java")
