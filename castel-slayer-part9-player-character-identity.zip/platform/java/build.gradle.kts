plugins {
    java
    id("com.gradleup.shadow") version "8.3.5"
}

// Main sources keep the standard src/main/java + src/main/resources layout. Tests live
// outside the project under tests/platform/java (mirroring the tests/ convention used
// everywhere else) and use the shared tests/support harness — see the root build file.
sourceSets {
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/platform/java"), rootProject.file("tests/support")))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    // Core is compiled into the shaded plugin jar (it isn't present on a vanilla
    // Paper server); Paper's own API is provided by the server at runtime.
    implementation(project(":core"))
    // The application layer (sessions/runtime) and the one module whose concrete services the
    // composition root constructs. Inventory/equipment/progression arrive via :application:runtime.
    implementation(project(":application:runtime"))
    implementation(project(":modules:character"))
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

tasks.processResources {
    val props = mapOf("version" to project.version)
    inputs.properties(props)
    filesMatching("plugin.yml") {
        expand(props)
    }
}

tasks.shadowJar {
    archiveClassifier.set("")
}

// The shaded jar (with :core's classes bundled) is the actual deployable artifact,
// not the plain jar the `java` plugin produces by default.
tasks.build {
    dependsOn(tasks.shadowJar)
}
