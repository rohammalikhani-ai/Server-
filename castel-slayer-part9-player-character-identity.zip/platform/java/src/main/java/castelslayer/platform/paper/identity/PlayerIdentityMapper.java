package castelslayer.platform.paper.identity;

import core.domain.ClientEdition;
import core.domain.PlayerId;
import core.domain.PlayerIdentity;
import org.bukkit.entity.Player;

/**
 * Translates a Bukkit {@link Player} into the platform-neutral identity types Core
 * understands. This is the one place in {@code platform/java} that reads
 * {@code Player#getUniqueId()}/{@code #getName()} for identity purposes — everything
 * downstream (listeners, future presenters) works with {@link PlayerId} /
 * {@link PlayerIdentity}, never a raw Bukkit type
 * ({@code core.contracts.IPlatformPresenter}'s Javadoc assumes exactly this split).
 *
 * <p><b>{@code PlayerId} is not a {@code character.contracts.CharacterId}.</b> This
 * mapper produces only the account-level identity a Minecraft session carries — the
 * Minecraft UUID. Which character that player plays is decided by the application layer
 * ({@code castelslayer.application.session.CharacterSelector}, backed by
 * {@code character.contracts.ICharacterDirectory}), never here and never by assuming
 * UUID-equals-CharacterId.
 */
public final class PlayerIdentityMapper {

    private PlayerIdentityMapper() {
    }

    /** The platform-neutral, account-level identity of {@code player}. */
    public static PlayerId toPlayerId(Player player) {
        return PlayerId.of(player.getUniqueId());
    }

    /** {@code player}'s identity facts as Core understands them: id, display name, edition. */
    public static PlayerIdentity toPlayerIdentity(Player player) {
        // Every connection this adapter sees is a native Java Edition client; a
        // Bedrock player would arrive through a bridge (e.g. Geyser/Floodgate) that
        // is out of scope this phase (see the task brief's FORBIDDEN list). Adding
        // real edition detection is the one line that needs to change here when that
        // bridge exists — nothing downstream should need to change, since
        // DESIGN_PRINCIPLES rule 6 already forbids branching game logic on edition.
        return new PlayerIdentity(toPlayerId(player), player.getName(), ClientEdition.JAVA);
    }
}
