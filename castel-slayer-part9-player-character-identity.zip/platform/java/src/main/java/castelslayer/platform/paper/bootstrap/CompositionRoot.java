package castelslayer.platform.paper.bootstrap;

import castelslayer.application.runtime.CharacterRuntimeDefaults;
import castelslayer.application.runtime.CharacterRuntimeFactory;
import castelslayer.application.runtime.CharacterRuntimeService;
import castelslayer.application.session.DirectoryCharacterSelector;
import castelslayer.application.session.PlayerSessionLifecycle;
import castelslayer.application.session.PlayerSessionService;
import castelslayer.application.session.SessionManager;
import castelslayer.application.session.SessionOutcomeListener;
import character.services.CharacterDirectoryService;
import character.services.CharacterFactory;
import character.services.CharacterLifecycleService;
import core.contracts.IEventBus;
import core.contracts.IPersistenceGateway;
import core.services.InMemoryPersistenceGateway;
import core.services.InProcessEventBus;
import java.time.Clock;
import java.util.Objects;

/**
 * The composition root for the Paper platform (see {@code ARCHITECTURE.md} →
 * "Composition Root"; location decided in
 * {@code docs/decisions/0003-paper-platform-and-composition-root.md}). This is the only place in
 * the codebase allowed to know about concrete service types: it builds them with plain Java
 * (no DI framework), and hands them out as contracts or application services.
 *
 * <pre>
 *   EventBus ─────────────────────────────┐
 *   IPersistenceGateway (in-memory, dev)  │
 *        └─► CharacterDirectory ─► CharacterLifecycle
 *        └─► CharacterRuntimeService (+ CharacterRuntimeFactory)
 *   SessionManager ─► PlayerSessionService ─► PlayerSessionLifecycle ── subscribes to ──► EventBus
 * </pre>
 *
 * <p><b>Persistence is the development in-memory gateway</b>: it is deterministic and dependency-free,
 * but everything is lost when the server stops. Replace the one line that creates it when a real
 * gateway exists; nothing else changes, because every consumer sees only
 * {@link IPersistenceGateway}. {@code IConfigProvider} is still not wired — no production
 * implementation exists.
 *
 * <p>No business logic lives here: it only constructs, connects and returns.
 */
public final class CompositionRoot {

    private CompositionRoot() {
    }

    /** Assembles the runtime with outcome reporting switched off (tests, headless use). */
    public static CoreRuntime bootstrap() {
        return bootstrap(SessionOutcomeListener.NONE);
    }

    /**
     * Assembles the runtime.
     *
     * @param outcomes receives the result of every event-driven join/quit (the event bus swallows
     *                 handler failures, so this is how the platform layer can log them)
     */
    public static CoreRuntime bootstrap(SessionOutcomeListener outcomes) {
        Objects.requireNonNull(outcomes, "outcomes");
        Clock clock = Clock.systemUTC();

        IEventBus eventBus = new InProcessEventBus();
        IPersistenceGateway persistence = new InMemoryPersistenceGateway();

        CharacterDirectoryService directory = new CharacterDirectoryService(persistence);
        CharacterLifecycleService lifecycle =
                new CharacterLifecycleService(directory, new CharacterFactory(eventBus, clock), eventBus, clock);

        CharacterRuntimeService runtimes = new CharacterRuntimeService(
                directory, persistence, new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard()));

        SessionManager sessions = new SessionManager();
        PlayerSessionService sessionService =
                new PlayerSessionService(sessions, new DirectoryCharacterSelector(directory), runtimes);
        PlayerSessionLifecycle sessionLifecycle = new PlayerSessionLifecycle(eventBus, sessionService, outcomes);

        return new CoreRuntime(eventBus, directory, lifecycle, sessions, sessionService, sessionLifecycle);
    }
}
