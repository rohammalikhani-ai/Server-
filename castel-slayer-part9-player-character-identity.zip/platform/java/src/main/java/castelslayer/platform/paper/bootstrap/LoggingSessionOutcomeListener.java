package castelslayer.platform.paper.bootstrap;

import castelslayer.application.session.SessionJoinResult;
import castelslayer.application.session.SessionOutcomeListener;
import castelslayer.application.session.SessionQuitResult;
import core.domain.PlayerId;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Reports session outcomes to a {@link Logger} (a plugin's {@code getLogger()}). Uses only the
 * JDK logger, so it is testable without Bukkit. Routine outcomes are {@code INFO}/{@code FINE};
 * anything that risks losing or blocking a player's data is {@code WARNING}/{@code SEVERE}.
 */
public final class LoggingSessionOutcomeListener implements SessionOutcomeListener {

    private final Logger logger;

    public LoggingSessionOutcomeListener(Logger logger) {
        this.logger = Objects.requireNonNull(logger, "logger");
    }

    @Override
    public void onJoin(PlayerId playerId, SessionJoinResult result) {
        if (result instanceof SessionJoinResult.Joined joined) {
            logger.info("Player " + playerId + " is now playing character " + joined.session().characterId());
        } else if (result instanceof SessionJoinResult.AlreadyActive) {
            logger.fine("Player " + playerId + " already has an active session");
        } else if (result instanceof SessionJoinResult.NoCharacter) {
            logger.info("Player " + playerId + " has no character to play");
        } else if (result instanceof SessionJoinResult.CharacterInUse inUse) {
            logger.warning("Character " + inUse.characterId() + " is already active for player " + inUse.activeFor());
        } else if (result instanceof SessionJoinResult.LoadRejected rejected) {
            logger.warning("Could not activate a character for player " + playerId + ": " + rejected.reason());
        }
    }

    @Override
    public void onQuit(PlayerId playerId, SessionQuitResult result) {
        if (result instanceof SessionQuitResult.Saved saved) {
            logger.info("Saved character " + saved.session().characterId() + " for player " + playerId);
        } else if (result instanceof SessionQuitResult.SaveFailed failed) {
            logger.log(Level.SEVERE, "FAILED to save character " + failed.session().characterId()
                    + " for player " + playerId + "; its state was not stored", failed.cause());
        }
    }
}
