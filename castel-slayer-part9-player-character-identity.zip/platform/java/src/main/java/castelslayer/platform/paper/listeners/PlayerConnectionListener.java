package castelslayer.platform.paper.listeners;

import castelslayer.platform.paper.identity.PlayerIdentityMapper;
import core.contracts.IEventBus;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.PlayerJoinedWorld;
import core.events.PlayerLeftWorld;
import java.time.Instant;
import java.util.Objects;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Translates Bukkit's player connection lifecycle into Core-level events. Never
 * exposes a Bukkit {@code Event} type to Core, directly or indirectly — Core must
 * never import {@code org.bukkit.*}/{@code io.papermc.*} (see the task brief's EVENT
 * TRANSLATION rule and {@code core.contracts.IPlatformPresenter}'s Javadoc). This
 * listener only publishes; it never mutates gameplay state itself
 * (DESIGN_PRINCIPLES rule 9). Loading a character, activating its runtime and saving it on quit
 * all happen in {@code :application:runtime}'s {@code PlayerSessionLifecycle}, which reacts to the
 * events published here — this class holds no character, persistence or gameplay logic.
 */
public final class PlayerConnectionListener implements Listener {

    private final IEventBus eventBus;

    public PlayerConnectionListener(IEventBus eventBus) {
        this.eventBus = Objects.requireNonNull(eventBus, "eventBus");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        PlayerId playerId = PlayerIdentityMapper.toPlayerId(event.getPlayer());
        WorldId worldId = WorldId.of(event.getPlayer().getWorld().getName());
        eventBus.publish(new PlayerJoinedWorld(playerId, worldId, Instant.now()));
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        PlayerId playerId = PlayerIdentityMapper.toPlayerId(event.getPlayer());
        WorldId worldId = WorldId.of(event.getPlayer().getWorld().getName());
        eventBus.publish(new PlayerLeftWorld(playerId, worldId, Instant.now()));
    }
}
