/**
 * Intentionally empty. Reserved for command registration once a real command is
 * designed — {@code DEVELOPMENT_RULES.md}: "never create a manager/service/class for
 * a feature that isn't being built yet." This phase's task brief explicitly forbids
 * inventing commands; see
 * {@code docs/decisions/0003-paper-platform-and-composition-root.md}.
 */
package castelslayer.platform.paper.commands;
