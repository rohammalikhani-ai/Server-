package castelslayer.platform.paper.bootstrap;

import castelslayer.application.session.PlayerSessionLifecycle;
import castelslayer.application.session.PlayerSessionService;
import castelslayer.application.session.SessionManager;
import castelslayer.application.session.SessionQuitResult;
import character.contracts.ICharacterDirectory;
import character.contracts.ICharacterLifecycle;
import core.contracts.IEventBus;
import java.util.List;
import java.util.Objects;

/**
 * The handle to everything {@link CompositionRoot#bootstrap()} assembled, exposed as contracts
 * and application services rather than concrete module types. Holds no logic of its own except
 * {@link #shutdown()}, which releases the event wiring and saves every still-active session.
 */
public final class CoreRuntime {

    private final IEventBus eventBus;
    private final ICharacterDirectory characterDirectory;
    private final ICharacterLifecycle characterLifecycle;
    private final SessionManager sessions;
    private final PlayerSessionService sessionService;
    private final PlayerSessionLifecycle sessionLifecycle;

    public CoreRuntime(IEventBus eventBus, ICharacterDirectory characterDirectory,
                       ICharacterLifecycle characterLifecycle, SessionManager sessions,
                       PlayerSessionService sessionService, PlayerSessionLifecycle sessionLifecycle) {
        this.eventBus = Objects.requireNonNull(eventBus, "eventBus");
        this.characterDirectory = Objects.requireNonNull(characterDirectory, "characterDirectory");
        this.characterLifecycle = Objects.requireNonNull(characterLifecycle, "characterLifecycle");
        this.sessions = Objects.requireNonNull(sessions, "sessions");
        this.sessionService = Objects.requireNonNull(sessionService, "sessionService");
        this.sessionLifecycle = Objects.requireNonNull(sessionLifecycle, "sessionLifecycle");
    }

    public IEventBus eventBus() {
        return eventBus;
    }

    public ICharacterDirectory characterDirectory() {
        return characterDirectory;
    }

    public ICharacterLifecycle characterLifecycle() {
        return characterLifecycle;
    }

    public SessionManager sessions() {
        return sessions;
    }

    public PlayerSessionService sessionService() {
        return sessionService;
    }

    /**
     * Stops reacting to player events, then quits (saves and releases) every active session.
     * Returns one result per session so the caller can report any {@code SaveFailed}.
     */
    public List<SessionQuitResult> shutdown() {
        sessionLifecycle.close();
        return sessionService.quitAll();
    }
}
