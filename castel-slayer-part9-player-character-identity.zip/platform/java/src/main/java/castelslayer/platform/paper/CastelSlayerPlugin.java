package castelslayer.platform.paper;

import castelslayer.platform.paper.bootstrap.CompositionRoot;
import castelslayer.platform.paper.bootstrap.CoreRuntime;
import castelslayer.platform.paper.bootstrap.LoggingSessionOutcomeListener;
import castelslayer.platform.paper.listeners.PlayerConnectionListener;
import castelslayer.application.session.SessionQuitResult;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * The Paper plugin entrypoint. Deliberately thin: its only job is to run the
 * composition root once and register the platform listeners it produces (see
 * {@code ARCHITECTURE.md} → "Composition Root" and
 * {@code docs/decisions/0003-paper-platform-and-composition-root.md}). No gameplay,
 * commands, or persistence logic belongs here or anywhere in this module yet.
 */
public final class CastelSlayerPlugin extends JavaPlugin {

    private CoreRuntime coreRuntime;

    @Override
    public void onEnable() {
        coreRuntime = CompositionRoot.bootstrap(new LoggingSessionOutcomeListener(getLogger()));

        getServer().getPluginManager().registerEvents(
                new PlayerConnectionListener(coreRuntime.eventBus()), this);

        getLogger().info("Castel Slayer platform foundation enabled (no gameplay systems yet).");
        getLogger().warning("Character data uses the in-memory development store: it is NOT kept across restarts.");
    }

    @Override
    public void onDisable() {
        if (coreRuntime != null) {
            for (SessionQuitResult result : coreRuntime.shutdown()) {
                if (result instanceof SessionQuitResult.SaveFailed failed) {
                    getLogger().severe("Character " + failed.session().characterId() + " was not saved on shutdown");
                }
            }
        }
        coreRuntime = null;
    }
}
