package castelslayer.application.runtime;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import character.contracts.ICharacterDirectory;
import core.contracts.PersistenceException;
import core.domain.PlayerId;
import java.util.Optional;
import support.Test;
import static support.Assertions.*;

/** CharacterRuntimeService: load outcomes are distinguishable; save then load round-trips per character. */
public class CharacterRuntimeServiceTest {

    @Test
    public void unknownCharacterIsNotFoundNotAFailure() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterId unknown = CharacterId.random();

        CharacterLoadResult result = f.runtimeService.load(unknown);

        assertEquals(new CharacterLoadResult.NotFound(unknown), result, "A missing character is NotFound");
    }

    @Test
    public void retiredCharacterIsNotActive() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        f.lifecycle.retire(a.id());

        assertEquals(new CharacterLoadResult.NotActive(a.id()), f.runtimeService.load(a.id()),
                "A retired character exists but cannot be played");
    }

    @Test
    public void storageFailureIsFailedNotNotFound() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        f.gateway.failReads = true;

        CharacterLoadResult result = f.runtimeService.load(a.id());

        assertTrue(result instanceof CharacterLoadResult.Failed,
                "An unreadable store must not look like a missing character (was " + result + ")");
        assertTrue(((CharacterLoadResult.Failed) result).cause() instanceof PersistenceException,
                "The original exception is preserved");
    }

    @Test
    public void corruptSavedStateIsFailed() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        // A saved envelope whose inventory is fine but is stored under a key it does not belong to.
        CharacterSummary b = f.createCharacter(PlayerId.random(), "Bram");
        CharacterRuntimeSnapshot ofB = f.runtimeFactory.snapshotOf(f.loadedRuntime(b));
        f.gateway.save(CharacterRuntimeService.COLLECTION, a.id().toString(), ofB);

        CharacterLoadResult result = f.runtimeService.load(a.id());

        assertTrue(result instanceof CharacterLoadResult.Failed, "B's state under A's key is corrupt, not loadable");
    }

    @Test
    public void directoryAnsweringWithAnotherCharacterNeverYieldsARuntimeForIt() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterSummary b = f.createCharacter(PlayerId.random(), "Bram");
        // A faulty directory (corrupt record, buggy adapter) that answers "find A" with B's summary.
        ICharacterDirectory confused = new ICharacterDirectory() {
            @Override
            public Optional<CharacterSummary> findById(CharacterId id) {
                return Optional.of(b);
            }

            @Override
            public Optional<CharacterSummary> findActiveForPlayer(PlayerId ownerId) {
                return Optional.empty();
            }
        };
        CharacterRuntimeService service = new CharacterRuntimeService(confused, f.gateway, f.runtimeFactory);

        CharacterLoadResult result = service.load(a.id());

        assertFalse(result instanceof CharacterLoadResult.Loaded,
                "Asking for A must never hand back a runtime for B (was " + result + ")");
        assertTrue(result instanceof CharacterLoadResult.Failed, "A mismatched directory answer is a load failure");
        assertEquals(a.id(), ((CharacterLoadResult.Failed) result).characterId(), "The failure names the character that was asked for");
    }

    @Test
    public void loadedRuntimeAlwaysBelongsToTheRequestedCharacter() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterSummary b = f.createCharacter(PlayerId.random(), "Bram");
        f.runtimeService.save(f.loadedRuntime(b));

        CharacterRuntime forA = f.loadedRuntime(a);
        CharacterRuntime forB = f.loadedRuntime(b);

        assertEquals(a.id(), forA.characterId(), "load(A) yields a runtime identified as A");
        assertEquals(a.id(), forA.progression().characterId(), "load(A): progression is A's");
        assertEquals(a.id(), forA.inventory().ownerId(), "load(A): inventory is A's");
        assertEquals(a.id(), forA.equipment().ownerId(), "load(A): equipment is A's");
        assertEquals(b.id(), forB.characterId(), "load(B) yields a runtime identified as B");
        assertEquals(b.id(), forB.inventory().ownerId(), "load(B): inventory is B's");
    }

    @Test
    public void characterWithNoSavedStateLoadsWithDefaults() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");

        CharacterRuntime runtime = f.loadedRuntime(a);

        assertEquals(a.id(), runtime.characterId(), "Runtime is for A");
        assertEquals(1, runtime.progression().progression().level(), "Never-saved state starts from defaults");
    }

    @Test
    public void saveThenLoadReturnsEquivalentState() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterRuntime runtime = f.loadedRuntime(a);
        RuntimeFixture.giveStateA(runtime);

        f.runtimeService.save(runtime);
        CharacterRuntime reloaded = f.loadedRuntime(a);

        assertEquals(f.runtimeFactory.snapshotOf(runtime), f.runtimeFactory.snapshotOf(reloaded), "Saved state equals loaded state");
        assertTrue(reloaded != runtime, "Loading builds a new runtime, not the live one");
    }

    @Test
    public void savedRuntimeIsNotAffectedByLaterChangesToTheLiveOne() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterRuntime runtime = f.loadedRuntime(a);
        RuntimeFixture.giveStateA(runtime);
        f.runtimeService.save(runtime);

        runtime.inventory().removeItem(RuntimeFixture.POTION, 12);

        assertEquals(12L, f.loadedRuntime(a).inventory().countOf(RuntimeFixture.POTION),
                "The store holds an immutable snapshot, not the live inventory");
    }

    @Test
    public void multipleCharactersStayIsolatedInTheStore() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterSummary b = f.createCharacter(PlayerId.random(), "Bram");
        CharacterRuntime ra = f.loadedRuntime(a);
        CharacterRuntime rb = f.loadedRuntime(b);
        RuntimeFixture.giveStateA(ra);
        RuntimeFixture.giveStateB(rb);
        f.runtimeService.save(ra);
        f.runtimeService.save(rb);

        CharacterRuntime loadedA = f.loadedRuntime(a);
        CharacterRuntime loadedB = f.loadedRuntime(b);

        assertEquals(12L, loadedA.inventory().countOf(RuntimeFixture.POTION), "A keeps A's potions");
        assertEquals(0L, loadedA.inventory().countOf(RuntimeFixture.ARROW), "A has none of B's arrows");
        assertEquals(30L, loadedB.inventory().countOf(RuntimeFixture.ARROW), "B keeps B's arrows");
        assertEquals(0L, loadedB.inventory().countOf(RuntimeFixture.POTION), "B has none of A's potions");
        assertTrue(loadedA.equipment().isEquipped(RuntimeFixture.sword().id()), "A wears A's sword");
        assertTrue(loadedB.equipment().isEquipped(RuntimeFixture.staff().id()), "B wields B's staff");
    }

    @Test
    public void writeFailureIsReportedNotSwallowed() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterRuntime runtime = f.loadedRuntime(f.createCharacter(PlayerId.random(), "Aria"));
        f.gateway.failWrites = true;

        assertThrows(PersistenceException.class, () -> f.runtimeService.save(runtime),
                "The caller must know the state was not stored");
    }

    @Test
    public void nullArgumentsAreRejected() {
        RuntimeFixture f = new RuntimeFixture();
        assertThrows(NullPointerException.class, () -> f.runtimeService.load(null), "id");
        assertThrows(NullPointerException.class, () -> f.runtimeService.save(null), "runtime");
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntimeService(null, f.gateway, f.runtimeFactory), "directory");
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntimeService(f.directory, null, f.runtimeFactory), "persistence");
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntimeService(f.directory, f.gateway, null), "factory");
    }
}
