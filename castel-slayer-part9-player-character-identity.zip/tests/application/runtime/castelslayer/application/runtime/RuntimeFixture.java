package castelslayer.application.runtime;

import castelslayer.application.session.DirectoryCharacterSelector;
import castelslayer.application.session.PlayerSessionService;
import castelslayer.application.session.SessionManager;
import character.contracts.CharacterSummary;
import character.services.CharacterDirectoryService;
import character.services.CharacterFactory;
import character.services.CharacterLifecycleService;
import core.contracts.IEventBus;
import core.domain.PlayerId;
import core.services.InMemoryPersistenceGateway;
import core.services.InProcessEventBus;
import equipment.domain.EquipmentSlot;
import equipment.domain.ItemCategory;
import equipment.domain.ItemDefinition;
import inventory.contracts.ItemId;
import inventory.domain.Item;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Objects;
import progression.services.DefaultProgressionCurve;
import progression.services.LevelingService;

/**
 * Plain-Java wiring of the whole runtime foundation for tests: real event bus, real in-memory
 * persistence, real character services and the application layer on top — no Paper, no mocks.
 * Build a NEW fixture inside every test method ({@code support.TestRunner} reuses one test-class
 * instance, so a shared field would leak state between tests).
 */
public final class RuntimeFixture {

    public static final Clock CLOCK = Clock.fixed(Instant.parse("2026-03-01T00:00:00Z"), ZoneOffset.UTC);

    public final IEventBus eventBus = new InProcessEventBus();
    public final FailingGateway gateway = new FailingGateway(new InMemoryPersistenceGateway());
    public final CharacterDirectoryService directory = new CharacterDirectoryService(gateway);
    public final CharacterLifecycleService lifecycle =
            new CharacterLifecycleService(directory, new CharacterFactory(eventBus, CLOCK), eventBus, CLOCK);
    public final CharacterRuntimeFactory runtimeFactory = new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard());
    public final CharacterRuntimeService runtimeService = new CharacterRuntimeService(directory, gateway, runtimeFactory);
    public final SessionManager sessions = new SessionManager();
    public final PlayerSessionService sessionService =
            new PlayerSessionService(sessions, new DirectoryCharacterSelector(directory), runtimeService);

    public CharacterSummary createCharacter(PlayerId owner, String name) {
        return lifecycle.create(owner, name);
    }

    public CharacterRuntime loadedRuntime(CharacterSummary character) {
        CharacterLoadResult result = runtimeService.load(character.id());
        Objects.requireNonNull(result);
        if (result instanceof CharacterLoadResult.Loaded loaded) {
            return loaded.runtime();
        }
        throw new AssertionError("expected Loaded but was " + result);
    }

    public static final ItemId POTION = new ItemId("potion");
    public static final ItemId ARROW = new ItemId("arrow");

    public static ItemDefinition sword() {
        return new ItemDefinition(new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
    }

    public static ItemDefinition staff() {
        return new ItemDefinition(new ItemId("oak_staff"), "Oak Staff", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
    }

    public static ItemDefinition helmet() {
        return new ItemDefinition(new ItemId("iron_helmet"), "Iron Helmet", ItemCategory.ARMOR, EquipmentSlot.HEAD);
    }

    /** Character "A": 450 XP, 12 potions, a sword and a helmet. */
    public static void giveStateA(CharacterRuntime runtime) {
        new LevelingService(new DefaultProgressionCurve(), CLOCK).gainXp(runtime.progression(), 450);
        runtime.inventory().addItem(new Item(POTION, 10), 12);
        runtime.equipment().equip(sword(), EquipmentSlot.MAIN_HAND);
        runtime.equipment().equip(helmet(), EquipmentSlot.HEAD);
    }

    /** Character "B": no XP, 30 arrows, only a staff. */
    public static void giveStateB(CharacterRuntime runtime) {
        runtime.inventory().addItem(new Item(ARROW, 64), 30);
        runtime.equipment().equip(staff(), EquipmentSlot.MAIN_HAND);
    }
}
