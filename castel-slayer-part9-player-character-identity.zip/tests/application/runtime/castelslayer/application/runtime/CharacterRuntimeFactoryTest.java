package castelslayer.application.runtime;

import character.contracts.CharacterSummary;
import core.domain.PlayerId;
import support.Test;
import static support.Assertions.*;

import java.util.Map;
import progression.domain.AttributeType;

/** CharacterRuntimeFactory: fresh runtimes, restore-from-snapshot, and snapshot extraction. */
public class CharacterRuntimeFactoryTest {

    private static CharacterSummary character(String name) {
        return new CharacterSummary(character.contracts.CharacterId.random(), PlayerId.random(), name, true);
    }

    @Test
    public void createNewBuildsDefaultStateOwnedByTheCharacter() {
        CharacterRuntimeFactory factory = new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard());
        CharacterSummary a = character("A");

        CharacterRuntime runtime = factory.createNew(a);

        assertEquals(a.id(), runtime.characterId(), "Runtime is for the given character");
        assertEquals(1, runtime.progression().progression().level(), "A new character starts at level 1");
        assertEquals(5, runtime.progression().attributes().baseValue(AttributeType.STRENGTH), "Default attributes come from the defaults");
        assertEquals(20, runtime.inventory().capacity(), "Default inventory capacity");
        assertEquals(0, runtime.equipment().equippedCount(), "Nothing is equipped");
    }

    @Test
    public void everyCreatedRuntimeHasItsOwnState() {
        CharacterRuntimeFactory factory = new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard());
        CharacterRuntime a = factory.createNew(character("A"));
        CharacterRuntime b = factory.createNew(character("B"));

        RuntimeFixture.giveStateA(a);

        assertEquals(0L, b.inventory().countOf(RuntimeFixture.POTION), "Changing A's inventory never changes B's");
        assertEquals(0, b.equipment().equippedCount(), "Changing A's equipment never changes B's");
        assertEquals(1, b.progression().progression().level(), "Changing A's progression never changes B's");
    }

    @Test
    public void snapshotThenRestoreRebuildsEquivalentState() {
        CharacterRuntimeFactory factory = new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard());
        CharacterSummary a = character("A");
        CharacterRuntime original = factory.createNew(a);
        RuntimeFixture.giveStateA(original);

        CharacterRuntimeSnapshot snapshot = factory.snapshotOf(original);
        CharacterRuntime restored = factory.restore(a, snapshot);

        assertEquals(snapshot, factory.snapshotOf(restored), "Restoring then snapshotting again is lossless");
        assertEquals(12L, restored.inventory().countOf(RuntimeFixture.POTION), "Inventory restored");
        assertTrue(restored.equipment().isEquipped(RuntimeFixture.sword().id()), "Equipment restored");
        assertEquals(original.progression().progression(), restored.progression().progression(), "Progression restored");
    }

    @Test
    public void restoreRejectsASnapshotOfAnotherCharacter() {
        CharacterRuntimeFactory factory = new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard());
        CharacterSummary a = character("A");
        CharacterSummary b = character("B");
        CharacterRuntimeSnapshot snapshotOfB = factory.snapshotOf(factory.createNew(b));

        assertThrows(IllegalArgumentException.class, () -> factory.restore(a, snapshotOfB),
                "A's identity must never be filled with B's saved state");
    }

    @Test
    public void snapshotEnvelopeRejectsPartsOfDifferentCharacters() {
        CharacterRuntimeFactory factory = new CharacterRuntimeFactory(CharacterRuntimeDefaults.standard());
        CharacterRuntimeSnapshot a = factory.snapshotOf(factory.createNew(character("A")));
        CharacterRuntimeSnapshot b = factory.snapshotOf(factory.createNew(character("B")));

        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntimeSnapshot(a.characterId(), b.progression(), a.inventory(), a.equipment()),
                "An envelope for A cannot hold B's progression");
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntimeSnapshot(a.characterId(), a.progression(), b.inventory(), a.equipment()),
                "An envelope for A cannot hold B's inventory");
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntimeSnapshot(a.characterId(), a.progression(), a.inventory(), b.equipment()),
                "An envelope for A cannot hold B's equipment");
    }

    @Test
    public void nullsAndInvalidDefaultsAreRejected() {
        assertThrows(NullPointerException.class, () -> new CharacterRuntimeFactory(null), "defaults are required");
        assertThrows(IllegalArgumentException.class, () -> new CharacterRuntimeDefaults(Map.of(), 10),
                "Defaults must specify every attribute");
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntimeDefaults(CharacterRuntimeDefaults.standard().baseAttributes(), 0),
                "Inventory needs at least one slot");
    }
}
