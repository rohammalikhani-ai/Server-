package castelslayer.application.runtime;

import character.contracts.CharacterId;
import equipment.domain.EquipmentSlot;
import equipment.domain.ItemCategory;
import equipment.domain.ItemDefinition;
import equipment.domain.ItemEquipment;
import equipment.domain.UnequipResult;
import inventory.contracts.ItemId;
import inventory.domain.AddItemResult;
import inventory.domain.Item;
import inventory.domain.ItemInventory;
import support.Test;
import static support.Assertions.*;

/**
 * Checks that Equipment and Inventory share ONE item identity ({@code inventory.contracts.ItemId})
 * and that the two containers stay separate: no automatic transfer in either direction.
 *
 * <p>Lives with the application tests because it is the one place that legitimately sees both
 * modules' aggregates at once (the way the application layer does); {@code equipment}'s own
 * tests never touch {@code inventory.domain}. There is no id translation: the same
 * {@link ItemId} value is handed to both containers as-is.
 */
public class EquipmentInventoryCompatibilityTest {

    private static final CharacterId OWNER = CharacterId.random();

    private static ItemDefinition sword() {
        return new ItemDefinition(
                new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
    }

    @Test
    public void oneItemIdTypeIsUsedByBothModules() {
        ItemId id = sword().id();

        assertEquals(new ItemId("iron_sword"), id, "Same value equals the canonical ItemId");
        assertEquals(id.hashCode(), new ItemId("iron_sword").hashCode(), "Same value hashes the same");
    }

    @Test
    public void sameItemIdIdentifiesTheItemInBothInventoryAndEquipment() {
        ItemDefinition def = sword();
        ItemInventory inventory = new ItemInventory(OWNER, 4);
        ItemEquipment equipment = new ItemEquipment(OWNER);

        // Building an Inventory Item from a definition is the caller's job for now.
        inventory.addItem(new Item(def.id(), def.maxStackSize()), 1);
        equipment.equip(def, EquipmentSlot.MAIN_HAND);

        assertTrue(inventory.hasItem(def.id()), "Inventory finds the item by its ItemId");
        assertTrue(equipment.isEquipped(def.id()), "Equipment finds the item by the very same ItemId");
    }

    @Test
    public void equippingDoesNotTouchTheInventory() {
        ItemDefinition def = sword();
        ItemInventory inventory = new ItemInventory(OWNER, 4);
        inventory.addItem(new Item(def.id(), def.maxStackSize()), 1);
        ItemEquipment equipment = new ItemEquipment(OWNER);

        equipment.equip(def, EquipmentSlot.MAIN_HAND);

        assertEquals(1L, inventory.countOf(def.id()),
                "No automatic Inventory -> Equipment transaction: the stack is still in the inventory");
    }

    @Test
    public void unequippingDoesNotAddToTheInventory() {
        ItemDefinition def = sword();
        ItemInventory inventory = new ItemInventory(OWNER, 4);
        ItemEquipment equipment = new ItemEquipment(OWNER);
        equipment.equip(def, EquipmentSlot.MAIN_HAND);

        UnequipResult result = equipment.unequip(EquipmentSlot.MAIN_HAND);

        assertTrue(result.isSuccess(), "Unequip succeeds");
        assertEquals(0L, inventory.countOf(def.id()),
                "No automatic Equipment -> Inventory transaction: the caller receives the item in the result");
        assertEquals(def, result.item(), "The removed item is available to the caller");
    }

    @Test
    public void definitionStackSizeMatchesWhatInventoryAccepts() {
        ItemDefinition potion = new ItemDefinition(
                new ItemId("health_potion"), "Health Potion", ItemCategory.CONSUMABLE, 20);
        ItemInventory inventory = new ItemInventory(OWNER, 2);

        AddItemResult result = inventory.addItem(new Item(potion.id(), potion.maxStackSize()), 25);

        assertTrue(result.isFullyAdded(), "25 potions fit in two stacks of up to 20");
        assertEquals(25L, inventory.countOf(potion.id()), "All 25 are in the inventory");
    }
}
