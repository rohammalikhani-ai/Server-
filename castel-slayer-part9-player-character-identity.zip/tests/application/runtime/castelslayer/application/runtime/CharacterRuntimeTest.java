package castelslayer.application.runtime;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import core.domain.PlayerId;
import equipment.domain.ItemEquipment;
import inventory.domain.ItemInventory;
import progression.domain.AttributeType;
import progression.domain.CharacterAttributes;
import progression.domain.CharacterStatsProfile;
import support.Test;
import static support.Assertions.*;

import java.util.EnumMap;
import java.util.Map;

/** CharacterRuntime: ownership of every part by ONE character is enforced at construction. */
public class CharacterRuntimeTest {

    private static CharacterSummary summary(CharacterId id) {
        return new CharacterSummary(id, PlayerId.random(), "Hero", true);
    }

    private static CharacterStatsProfile progression(CharacterId id) {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 5);
        }
        return CharacterStatsProfile.createNew(id, new CharacterAttributes(values));
    }

    @Test
    public void validRuntimeExposesEveryPartOwnedByTheCharacter() {
        CharacterId a = CharacterId.random();
        CharacterRuntime runtime = new CharacterRuntime(summary(a), progression(a), new ItemInventory(a, 4), new ItemEquipment(a));

        assertEquals(a, runtime.characterId(), "The runtime is identified by the character's id");
        assertEquals(a, runtime.progression().characterId(), "Progression belongs to A");
        assertEquals(a, runtime.inventory().ownerId(), "Inventory belongs to A");
        assertEquals(a, runtime.equipment().ownerId(), "Equipment belongs to A");
    }

    @Test
    public void mismatchedProgressionIsRejected() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntime(summary(a), progression(b), new ItemInventory(a, 4), new ItemEquipment(a)),
                "Character A must never be assembled with progression B");
    }

    @Test
    public void mismatchedInventoryIsRejected() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntime(summary(a), progression(a), new ItemInventory(b, 4), new ItemEquipment(a)),
                "Character A must never be assembled with inventory B");
    }

    @Test
    public void mismatchedEquipmentIsRejected() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntime(summary(a), progression(a), new ItemInventory(a, 4), new ItemEquipment(b)),
                "Character A must never be assembled with equipment B");
    }

    @Test
    public void runtimeExposesTheExactPartsItWasBuiltFromAndNeverSubstitutesOthers() {
        CharacterId a = CharacterId.random();
        CharacterSummary character = summary(a);
        CharacterStatsProfile progression = progression(a);
        ItemInventory inventory = new ItemInventory(a, 4);
        ItemEquipment equipment = new ItemEquipment(a);

        CharacterRuntime runtime = new CharacterRuntime(character, progression, inventory, equipment);

        assertTrue(runtime.character() == character, "The character summary is the one supplied");
        assertTrue(runtime.progression() == progression, "Progression is the instance supplied, not a copy");
        assertTrue(runtime.inventory() == inventory, "Inventory is the instance supplied, not a copy");
        assertTrue(runtime.equipment() == equipment, "Equipment is the instance supplied, not a copy");
    }

    @Test
    public void partsOfTwoCharactersCannotBeCrossAssembled() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        // Character B's identity with A's parts (every part wrong at once), in every direction.
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntime(summary(b), progression(a), new ItemInventory(a, 4), new ItemEquipment(a)),
                "Character B must never be assembled with A's parts");
        assertThrows(IllegalArgumentException.class,
                () -> new CharacterRuntime(summary(a), progression(a), new ItemInventory(b, 4), new ItemEquipment(b)),
                "A runtime cannot mix A's progression with B's inventory and equipment");
    }

    @Test
    public void mismatchMessageNamesBothCharactersAndThePart() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        try {
            new CharacterRuntime(summary(a), progression(a), new ItemInventory(b, 4), new ItemEquipment(a));
            throw new AssertionError("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains(a.toString()), "The message names the expected character");
            assertTrue(e.getMessage().contains(b.toString()), "The message names the offending owner");
            assertTrue(e.getMessage().contains("inventory"), "The message names the offending part");
        }
    }

    @Test
    public void nullDependenciesAreRejected() {
        CharacterId a = CharacterId.random();
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntime(null, progression(a), new ItemInventory(a, 4), new ItemEquipment(a)), "character");
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntime(summary(a), null, new ItemInventory(a, 4), new ItemEquipment(a)), "progression");
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntime(summary(a), progression(a), null, new ItemEquipment(a)), "inventory");
        assertThrows(NullPointerException.class,
                () -> new CharacterRuntime(summary(a), progression(a), new ItemInventory(a, 4), null), "equipment");
    }
}
