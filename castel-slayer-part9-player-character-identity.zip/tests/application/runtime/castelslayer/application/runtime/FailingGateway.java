package castelslayer.application.runtime;

import core.contracts.IPersistenceGateway;
import core.contracts.PersistenceException;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/** Test wrapper: delegates to a real gateway, but can be told to fail every read and/or write. */
public final class FailingGateway implements IPersistenceGateway {

    private final IPersistenceGateway delegate;
    public boolean failReads;
    public boolean failWrites;

    public FailingGateway(IPersistenceGateway delegate) {
        this.delegate = delegate;
    }

    @Override
    public <T> void save(String collection, String key, T value) {
        if (failWrites) {
            throw new PersistenceException("simulated write failure");
        }
        delegate.save(collection, key, value);
    }

    @Override
    public <T> Optional<T> load(String collection, String key, Class<T> type) {
        if (failReads) {
            throw new PersistenceException("simulated read failure");
        }
        return delegate.load(collection, key, type);
    }

    @Override
    public void delete(String collection, String key) {
        delegate.delete(collection, key);
    }

    @Override
    public <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
        if (failReads) {
            throw new PersistenceException("simulated read failure");
        }
        return delegate.query(collection, type, filter);
    }
}
