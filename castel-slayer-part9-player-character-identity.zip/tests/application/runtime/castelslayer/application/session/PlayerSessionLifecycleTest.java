package castelslayer.application.session;

import castelslayer.application.runtime.RuntimeFixture;
import character.contracts.CharacterSummary;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.PlayerJoinedWorld;
import core.events.PlayerLeftWorld;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import support.Test;
import static support.Assertions.*;

/**
 * The event-driven lifecycle through the real event bus and application services:
 * PlayerJoinedWorld → load → runtime active → PlayerLeftWorld → save → session removed.
 */
public class PlayerSessionLifecycleTest {

    private static final WorldId WORLD = WorldId.of("overworld");

    private static final class Recorder implements SessionOutcomeListener {
        final List<SessionJoinResult> joins = new ArrayList<>();
        final List<SessionQuitResult> quits = new ArrayList<>();

        @Override
        public void onJoin(PlayerId playerId, SessionJoinResult result) {
            joins.add(result);
        }

        @Override
        public void onQuit(PlayerId playerId, SessionQuitResult result) {
            quits.add(result);
        }
    }

    private static void join(RuntimeFixture f, PlayerId p) {
        f.eventBus.publish(new PlayerJoinedWorld(p, WORLD, Instant.now()));
    }

    private static void quit(RuntimeFixture f, PlayerId p) {
        f.eventBus.publish(new PlayerLeftWorld(p, WORLD, Instant.now()));
    }

    @Test
    public void joinLoadQuitSaveRemoveFullLifecycle() {
        RuntimeFixture f = new RuntimeFixture();
        Recorder recorder = new Recorder();
        PlayerSessionLifecycle lifecycle = new PlayerSessionLifecycle(f.eventBus, f.sessionService, recorder);
        PlayerId player = PlayerId.random();
        CharacterSummary aria = f.createCharacter(player, "Aria");

        join(f, player);                                                // join → load → active
        assertEquals(1, f.sessions.size(), "The runtime is active after PlayerJoinedWorld");
        PlayerSession session = f.sessions.find(player).orElseThrow();
        assertEquals(aria.id(), session.characterId(), "The player's own character was loaded");
        RuntimeFixture.giveStateA(session.runtime());                   // play

        quit(f, player);                                                // quit → save → removed
        assertEquals(0, f.sessions.size(), "The session is removed after PlayerLeftWorld");
        assertEquals(12L, f.loadedRuntime(aria).inventory().countOf(RuntimeFixture.POTION), "State was saved on quit");

        join(f, player);                                                // rejoin restores what was saved
        var again = f.sessions.find(player).orElseThrow().runtime();
        assertEquals(12L, again.inventory().countOf(RuntimeFixture.POTION), "Rejoining restores the saved inventory");
        assertTrue(again.equipment().isEquipped(RuntimeFixture.sword().id()), "…and equipment");
        assertEquals(session.runtime().progression().progression(), again.progression().progression(), "…and progression");
        assertTrue(again != session.runtime(), "…in a fresh runtime, not the old object");

        assertEquals(2, recorder.joins.size(), "Both joins were reported");
        assertEquals(1, recorder.quits.size(), "The quit was reported");
        assertTrue(recorder.quits.get(0) instanceof SessionQuitResult.Saved, "…as Saved");
        lifecycle.close();
    }

    @Test
    public void playerWithoutACharacterJoinsNothingAndQuitsQuietly() {
        RuntimeFixture f = new RuntimeFixture();
        Recorder recorder = new Recorder();
        PlayerSessionLifecycle lifecycle = new PlayerSessionLifecycle(f.eventBus, f.sessionService, recorder);
        PlayerId player = PlayerId.random();

        join(f, player);
        quit(f, player);

        assertEquals(new SessionJoinResult.NoCharacter(player), recorder.joins.get(0), "No character to activate");
        assertEquals(new SessionQuitResult.NoSession(player), recorder.quits.get(0), "Nothing to save");
        assertEquals(0, f.sessions.size(), "No session ever existed");
        lifecycle.close();
    }

    @Test
    public void duplicateJoinEventIsHandledDeterministically() {
        RuntimeFixture f = new RuntimeFixture();
        Recorder recorder = new Recorder();
        PlayerSessionLifecycle lifecycle = new PlayerSessionLifecycle(f.eventBus, f.sessionService, recorder);
        PlayerId player = PlayerId.random();
        f.createCharacter(player, "Aria");

        join(f, player);
        join(f, player);

        assertTrue(recorder.joins.get(0) instanceof SessionJoinResult.Joined, "First join activates");
        assertTrue(recorder.joins.get(1) instanceof SessionJoinResult.AlreadyActive, "Second join changes nothing");
        assertEquals(1, f.sessions.size(), "Still one session");
        lifecycle.close();
    }

    @Test
    public void saveFailureOnQuitIsSurfacedThroughTheListener() {
        RuntimeFixture f = new RuntimeFixture();
        Recorder recorder = new Recorder();
        PlayerSessionLifecycle lifecycle = new PlayerSessionLifecycle(f.eventBus, f.sessionService, recorder);
        PlayerId player = PlayerId.random();
        f.createCharacter(player, "Aria");
        join(f, player);
        f.gateway.failWrites = true;

        quit(f, player);

        assertTrue(recorder.quits.get(0) instanceof SessionQuitResult.SaveFailed,
                "The event bus swallows handler exceptions, so the failure must arrive as a result");
        assertEquals(0, f.sessions.size(), "The player is still released");
        lifecycle.close();
    }

    @Test
    public void closingTheLifecycleStopsReactingToEvents() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerSessionLifecycle lifecycle = new PlayerSessionLifecycle(f.eventBus, f.sessionService, SessionOutcomeListener.NONE);
        PlayerId player = PlayerId.random();
        f.createCharacter(player, "Aria");

        lifecycle.close();
        join(f, player);

        assertEquals(0, f.sessions.size(), "No subscription is left after close()");
    }

    @Test
    public void nullDependenciesAreRejected() {
        RuntimeFixture f = new RuntimeFixture();
        assertThrows(NullPointerException.class, () -> new PlayerSessionLifecycle(null, f.sessionService, SessionOutcomeListener.NONE), "eventBus");
        assertThrows(NullPointerException.class, () -> new PlayerSessionLifecycle(f.eventBus, null, SessionOutcomeListener.NONE), "service");
        assertThrows(NullPointerException.class, () -> new PlayerSessionLifecycle(f.eventBus, f.sessionService, null), "listener");
    }
}
