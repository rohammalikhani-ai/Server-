package castelslayer.application.session;

import castelslayer.application.runtime.CharacterLoadResult;
import castelslayer.application.runtime.CharacterRuntime;
import castelslayer.application.runtime.CharacterRuntimeService;
import castelslayer.application.runtime.CharacterRuntimeSnapshot;
import castelslayer.application.runtime.RuntimeFixture;
import character.contracts.CharacterSummary;
import core.contracts.IPersistenceGateway;
import core.domain.PlayerId;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import support.Test;
import static support.Assertions.*;

/** PlayerSessionService: every join/quit outcome is explicit and none of them loses state silently. */
public class PlayerSessionServiceTest {

    @Test
    public void joinWithoutACharacterReportsNoCharacter() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();

        assertEquals(new SessionJoinResult.NoCharacter(player), f.sessionService.join(player), "Nothing to play");
        assertEquals(0, f.sessions.size(), "No session was created");
    }

    @Test
    public void joinLoadsTheOwnersCharacterAndRegistersTheSession() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        CharacterSummary aria = f.createCharacter(player, "Aria");

        SessionJoinResult result = f.sessionService.join(player);

        assertTrue(result instanceof SessionJoinResult.Joined, "Joined (was " + result + ")");
        PlayerSession session = ((SessionJoinResult.Joined) result).session();
        assertEquals(player, session.playerId(), "The session is for the joining player");
        assertEquals(aria.id(), session.characterId(), "…and for that player's character");
        assertEquals(session, f.sessions.find(player).orElse(null), "The session is registered");
    }

    @Test
    public void secondJoinIsAlreadyActiveAndDoesNotReloadState() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        f.createCharacter(player, "Aria");
        PlayerSession first = ((SessionJoinResult.Joined) f.sessionService.join(player)).session();
        RuntimeFixture.giveStateA(first.runtime());

        SessionJoinResult second = f.sessionService.join(player);

        assertEquals(new SessionJoinResult.AlreadyActive(first), second, "Deterministic: same session, nothing reloaded");
        assertEquals(12L, first.runtime().inventory().countOf(RuntimeFixture.POTION), "Live state was not thrown away");
    }

    @Test
    public void duplicateJoinRacingTheFirstOneReturnsAlreadyActiveAndKeepsOneSession() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        f.createCharacter(player, "Aria");
        // The player's other join completes while this one is still loading (after its own
        // "already active?" check, before it registers) — the window a concurrent join can hit.
        RacingGateway racing = new RacingGateway(f.gateway, () -> f.sessionService.join(player));
        PlayerSessionService slow = new PlayerSessionService(f.sessions, new DirectoryCharacterSelector(f.directory),
                new CharacterRuntimeService(f.directory, racing, f.runtimeFactory));

        SessionJoinResult result = slow.join(player);

        assertEquals(1, f.sessions.size(), "A player never has two active sessions");
        PlayerSession active = f.sessions.find(player).orElseThrow();
        assertEquals(new SessionJoinResult.AlreadyActive(active), result, "The losing join reports AlreadyActive, it does not throw");
    }

    /** Delegates to a real gateway; runs {@code onFirstRuntimeLoad} once, when the first runtime snapshot is read. */
    private static final class RacingGateway implements IPersistenceGateway {
        private final IPersistenceGateway delegate;
        private Runnable onFirstRuntimeLoad;

        RacingGateway(IPersistenceGateway delegate, Runnable onFirstRuntimeLoad) {
            this.delegate = delegate;
            this.onFirstRuntimeLoad = onFirstRuntimeLoad;
        }

        @Override
        public <T> void save(String collection, String key, T value) {
            delegate.save(collection, key, value);
        }

        @Override
        public <T> Optional<T> load(String collection, String key, Class<T> type) {
            if (type == CharacterRuntimeSnapshot.class && onFirstRuntimeLoad != null) {
                Runnable once = onFirstRuntimeLoad;
                onFirstRuntimeLoad = null;
                once.run();
            }
            return delegate.load(collection, key, type);
        }

        @Override
        public void delete(String collection, String key) {
            delegate.delete(collection, key);
        }

        @Override
        public <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
            return delegate.query(collection, type, filter);
        }
    }

    @Test
    public void characterAlreadyActiveForAnotherPlayerIsReportedNotLoadedTwice() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId owner = PlayerId.random();
        f.createCharacter(owner, "Aria");
        f.sessionService.join(owner);
        // A selector that (wrongly) hands the same character to a second player.
        var owned = f.sessions.find(owner).orElseThrow().characterId();
        PlayerSessionService greedy = new PlayerSessionService(f.sessions, p -> java.util.Optional.of(owned), f.runtimeService);
        PlayerId other = PlayerId.random();

        SessionJoinResult result = greedy.join(other);

        assertEquals(new SessionJoinResult.CharacterInUse(other, owned, owner), result, "One character, one active player");
        assertEquals(1, f.sessions.size(), "Still only the first session");
    }

    @Test
    public void characterOwnedByAnotherPlayerIsRejectedEvenIfTheSelectorReturnsIt() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId owner = PlayerId.random();
        CharacterSummary aria = f.createCharacter(owner, "Aria");
        // A faulty/replaced selector that hands the owner's (active, not-in-use) character to a different player.
        PlayerSessionService faulty = new PlayerSessionService(f.sessions, p -> java.util.Optional.of(aria.id()), f.runtimeService);
        PlayerId intruder = PlayerId.random();

        SessionJoinResult result = faulty.join(intruder);

        assertTrue(result instanceof SessionJoinResult.LoadRejected
                        && ((SessionJoinResult.LoadRejected) result).reason() instanceof CharacterLoadResult.Failed,
                "Character.ownerId != PlayerId must be rejected, not joined (was " + result + ")");
        assertTrue(f.sessions.find(intruder).isEmpty(), "No session was registered for the intruder");
        assertEquals(0, f.sessions.size(), "Nobody is active");
        assertTrue(f.sessionService.join(owner) instanceof SessionJoinResult.Joined, "The real owner can still join");
    }

    @Test
    public void retiredCharacterIsRejectedAsNoCharacterOrNotActive() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        CharacterSummary aria = f.createCharacter(player, "Aria");
        f.lifecycle.retire(aria.id());
        // The directory selector only offers ACTIVE characters, so a retired one is simply not offered…
        assertEquals(new SessionJoinResult.NoCharacter(player), f.sessionService.join(player), "Retired is not selectable");
        // …and if a selector does offer it anyway, the load says NotActive.
        PlayerSessionService direct = new PlayerSessionService(f.sessions, p -> java.util.Optional.of(aria.id()), f.runtimeService);
        assertEquals(new SessionJoinResult.LoadRejected(player, new CharacterLoadResult.NotActive(aria.id())),
                direct.join(player), "A retired character cannot become active");
    }

    @Test
    public void loadFailureIsReportedAsRejectedAndLeavesNoSession() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        CharacterSummary aria = f.createCharacter(player, "Aria");
        PlayerSessionService direct = new PlayerSessionService(f.sessions, p -> java.util.Optional.of(aria.id()), f.runtimeService);
        f.gateway.failReads = true;

        SessionJoinResult result = direct.join(player);

        assertTrue(result instanceof SessionJoinResult.LoadRejected
                        && ((SessionJoinResult.LoadRejected) result).reason() instanceof CharacterLoadResult.Failed,
                "A storage failure is a Failed load, not 'no character' (was " + result + ")");
        assertEquals(0, f.sessions.size(), "A failed load never leaves a half-active session");
    }

    @Test
    public void quitSavesStateAndReleasesTheSession() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        CharacterSummary aria = f.createCharacter(player, "Aria");
        PlayerSession session = ((SessionJoinResult.Joined) f.sessionService.join(player)).session();
        RuntimeFixture.giveStateA(session.runtime());

        SessionQuitResult result = f.sessionService.quit(player);

        assertEquals(new SessionQuitResult.Saved(session), result, "Saved");
        assertTrue(f.sessions.find(player).isEmpty(), "The session is gone");
        assertEquals(12L, f.loadedRuntime(aria).inventory().countOf(RuntimeFixture.POTION), "The state reached the store");
    }

    @Test
    public void quitWithoutASessionIsNoSession() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();

        assertEquals(new SessionQuitResult.NoSession(player), f.sessionService.quit(player), "Nothing to save");
    }

    @Test
    public void quitWithFailingStoreReleasesTheSessionButReturnsTheUnsavedOne() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        f.createCharacter(player, "Aria");
        PlayerSession session = ((SessionJoinResult.Joined) f.sessionService.join(player)).session();
        RuntimeFixture.giveStateA(session.runtime());
        f.gateway.failWrites = true;

        SessionQuitResult result = f.sessionService.quit(player);

        assertTrue(result instanceof SessionQuitResult.SaveFailed, "The failure is reported (was " + result + ")");
        assertEquals(session, ((SessionQuitResult.SaveFailed) result).session(), "The unsaved session is handed back for a retry");
        assertTrue(f.sessions.find(player).isEmpty(), "The player is no longer active");
        f.gateway.failWrites = false;
        f.runtimeService.save(((SessionQuitResult.SaveFailed) result).session().runtime()); // retry works
        CharacterRuntime reloaded = f.loadedRuntime(session.runtime().character());
        assertEquals(12L, reloaded.inventory().countOf(RuntimeFixture.POTION), "Nothing was lost");
    }

    @Test
    public void quitAllSavesEverySession() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId p1 = PlayerId.random();
        PlayerId p2 = PlayerId.random();
        CharacterSummary a = f.createCharacter(p1, "Aria");
        CharacterSummary b = f.createCharacter(p2, "Bram");
        RuntimeFixture.giveStateA(((SessionJoinResult.Joined) f.sessionService.join(p1)).session().runtime());
        RuntimeFixture.giveStateB(((SessionJoinResult.Joined) f.sessionService.join(p2)).session().runtime());

        var results = f.sessionService.quitAll();

        assertEquals(2, results.size(), "Both sessions were quit");
        assertTrue(results.stream().allMatch(r -> r instanceof SessionQuitResult.Saved), "Both saved");
        assertEquals(0, f.sessions.size(), "Nobody is active");
        assertEquals(12L, f.loadedRuntime(a).inventory().countOf(RuntimeFixture.POTION), "A saved");
        assertEquals(30L, f.loadedRuntime(b).inventory().countOf(RuntimeFixture.ARROW), "B saved");
    }

    @Test
    public void nullDependenciesAndArgumentsAreRejected() {
        RuntimeFixture f = new RuntimeFixture();
        assertThrows(NullPointerException.class, () -> new PlayerSessionService(null, p -> java.util.Optional.empty(), f.runtimeService), "sessions");
        assertThrows(NullPointerException.class, () -> new PlayerSessionService(f.sessions, null, f.runtimeService), "selector");
        assertThrows(NullPointerException.class, () -> new PlayerSessionService(f.sessions, p -> java.util.Optional.empty(), null), "runtimes");
        assertThrows(NullPointerException.class, () -> f.sessionService.join(null), "playerId");
        assertThrows(NullPointerException.class, () -> f.sessionService.quit(null), "playerId");
    }
}
