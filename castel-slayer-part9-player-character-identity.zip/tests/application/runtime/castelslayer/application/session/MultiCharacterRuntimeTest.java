package castelslayer.application.session;

import castelslayer.application.runtime.CharacterRuntime;
import castelslayer.application.runtime.RuntimeFixture;
import character.contracts.CharacterSummary;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.PlayerJoinedWorld;
import core.events.PlayerLeftWorld;
import equipment.domain.EquipmentSlot;
import java.time.Instant;
import progression.domain.AttributeType;
import support.Test;
import static support.Assertions.*;

/**
 * The mandatory foundation test: two characters with distinguishable progression, inventory and
 * equipment, driven through the real join/quit lifecycle. It would fail on any accidental shared
 * singleton or static state, or on state saved under the wrong character.
 */
public class MultiCharacterRuntimeTest {

    @Test
    public void everyModuleStateIsOwnedByItsCharacter() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterRuntime ra = f.loadedRuntime(a);

        assertEquals(a.id(), ra.progression().characterId(), "Progression belongs to Character A");
        assertEquals(a.id(), ra.inventory().ownerId(), "Inventory belongs to Character A");
        assertEquals(a.id(), ra.equipment().ownerId(), "Equipment belongs to Character A");
    }

    @Test
    public void twoCharactersNeverShareOwnershipOrState() {
        RuntimeFixture f = new RuntimeFixture();
        CharacterSummary a = f.createCharacter(PlayerId.random(), "Aria");
        CharacterSummary b = f.createCharacter(PlayerId.random(), "Bram");
        CharacterRuntime ra = f.loadedRuntime(a);
        CharacterRuntime rb = f.loadedRuntime(b);

        assertNotEquals(a.id(), b.id(), "Distinct characters have distinct ids");
        assertEquals(a.id(), ra.inventory().ownerId(), "inventoryA.ownerId == characterA");
        assertEquals(b.id(), rb.inventory().ownerId(), "inventoryB.ownerId == characterB");
        assertEquals(a.id(), ra.equipment().ownerId(), "equipmentA.ownerId == characterA");
        assertEquals(b.id(), rb.equipment().ownerId(), "equipmentB.ownerId == characterB");
        assertTrue(ra.inventory() != rb.inventory(), "Inventory A is not Inventory B");
        assertTrue(ra.equipment() != rb.equipment(), "Equipment A is not Equipment B");
        assertTrue(ra.progression() != rb.progression(), "Progression A is not Progression B");
    }

    @Test
    public void loadModifySaveReloadKeepsBothCharactersIsolated() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId playerA = PlayerId.random();
        PlayerId playerB = PlayerId.random();
        CharacterSummary a = f.createCharacter(playerA, "Aria");
        CharacterSummary b = f.createCharacter(playerB, "Bram");
        WorldId world = WorldId.of("overworld");
        PlayerSessionLifecycle lifecycle = new PlayerSessionLifecycle(f.eventBus, f.sessionService, SessionOutcomeListener.NONE);

        // Give them distinguishable state and store it (A: levelled, potions, sword+helmet; B: arrows, staff).
        CharacterRuntime seedA = f.loadedRuntime(a);
        CharacterRuntime seedB = f.loadedRuntime(b);
        RuntimeFixture.giveStateA(seedA);
        RuntimeFixture.giveStateB(seedB);
        f.runtimeService.save(seedA);
        f.runtimeService.save(seedB);

        // 1-2. load A, load B (through the real join flow)
        f.eventBus.publish(new PlayerJoinedWorld(playerA, world, Instant.now()));
        f.eventBus.publish(new PlayerJoinedWorld(playerB, world, Instant.now()));
        CharacterRuntime liveA = f.sessions.find(playerA).orElseThrow().runtime();
        CharacterRuntime liveB = f.sessions.find(playerB).orElseThrow().runtime();

        // 3-4. A remains A, B remains B
        assertEquals(a.id(), liveA.characterId(), "Session A holds character A");
        assertEquals(b.id(), liveB.characterId(), "Session B holds character B");
        assertEquals(12L, liveA.inventory().countOf(RuntimeFixture.POTION), "A has A's potions");
        assertEquals(30L, liveB.inventory().countOf(RuntimeFixture.ARROW), "B has B's arrows");
        assertTrue(liveA.progression().progression().level() > 1, "A is levelled up");
        assertEquals(1, liveB.progression().progression().level(), "B is still level 1");
        assertTrue(liveA.equipment().isEquipped(RuntimeFixture.sword().id()), "A wears the sword");
        assertTrue(liveB.equipment().isEquipped(RuntimeFixture.staff().id()), "B wields the staff");

        var bBefore = f.runtimeFactory.snapshotOf(liveB);

        // 5. modify A: spend potions, drop the helmet, gain more XP
        liveA.inventory().removeItem(RuntimeFixture.POTION, 5);
        liveA.equipment().unequip(EquipmentSlot.HEAD);
        new progression.services.LevelingService(new progression.services.DefaultProgressionCurve(), RuntimeFixture.CLOCK)
                .gainXp(liveA.progression(), 100);
        var aModified = f.runtimeFactory.snapshotOf(liveA);

        // 6. B is unchanged
        assertEquals(bBefore, f.runtimeFactory.snapshotOf(liveB), "Modifying A never mutates B");
        assertEquals(0L, liveB.inventory().countOf(RuntimeFixture.POTION), "B never received A's potions");

        // 7. save A (via quit)
        f.eventBus.publish(new PlayerLeftWorld(playerA, world, Instant.now()));
        assertTrue(f.sessions.find(playerA).isEmpty(), "A's session is released");
        assertTrue(f.sessions.find(playerB).isPresent(), "B is still playing");

        // 8-9. load A again: A's modified state is preserved
        f.eventBus.publish(new PlayerJoinedWorld(playerA, world, Instant.now()));
        CharacterRuntime reloadedA = f.sessions.find(playerA).orElseThrow().runtime();
        assertEquals(aModified, f.runtimeFactory.snapshotOf(reloadedA), "A's modified state survived the save/load cycle");
        assertEquals(7L, reloadedA.inventory().countOf(RuntimeFixture.POTION), "A's inventory change persisted");
        assertFalse(reloadedA.equipment().isSlotOccupied(EquipmentSlot.HEAD), "A's unequip persisted");
        assertTrue(reloadedA.equipment().isEquipped(RuntimeFixture.sword().id()), "A still wears the sword");

        // 10. B remains isolated
        assertEquals(bBefore, f.runtimeFactory.snapshotOf(f.sessions.find(playerB).orElseThrow().runtime()), "B is still exactly as before");
        f.eventBus.publish(new PlayerLeftWorld(playerB, world, Instant.now()));
        CharacterRuntime reloadedB = f.loadedRuntime(b);
        assertEquals(bBefore, f.runtimeFactory.snapshotOf(reloadedB), "B's stored state is B's, untouched by A's saves");
        assertEquals(5, reloadedB.progression().attributes().baseValue(AttributeType.STRENGTH), "B's attributes are B's");
        lifecycle.close();
    }

    @Test
    public void runtimeStateIsPerInstanceNotGlobal() {
        RuntimeFixture first = new RuntimeFixture();
        RuntimeFixture second = new RuntimeFixture();
        CharacterSummary a1 = first.createCharacter(PlayerId.random(), "Aria");
        CharacterRuntime r1 = first.loadedRuntime(a1);
        RuntimeFixture.giveStateA(r1);
        first.runtimeService.save(r1);

        assertTrue(second.directory.findById(a1.id()).isEmpty(), "A second composition knows nothing of the first one's characters");
        assertEquals(0, second.sessions.size(), "…nor its sessions");
    }
}
