package castelslayer.application.session;

import castelslayer.application.runtime.CharacterRuntime;
import castelslayer.application.runtime.RuntimeFixture;
import character.contracts.CharacterSummary;
import core.domain.PlayerId;
import support.Test;
import static support.Assertions.*;

/** SessionManager: an in-memory registry that refuses duplicate players and duplicate characters. */
public class SessionManagerTest {

    private static PlayerSession session(RuntimeFixture f, PlayerId player, String name) {
        CharacterSummary character = f.createCharacter(PlayerId.random(), name);
        CharacterRuntime runtime = f.loadedRuntime(character);
        return new PlayerSession(player, runtime);
    }

    @Test
    public void registeredSessionCanBeRetrievedByPlayerAndByCharacter() {
        RuntimeFixture f = new RuntimeFixture();
        SessionManager manager = new SessionManager();
        PlayerId player = PlayerId.random();
        PlayerSession session = session(f, player, "Aria");

        manager.register(session);

        assertEquals(session, manager.find(player).orElse(null), "Found by player");
        assertEquals(session, manager.findByCharacter(session.characterId()).orElse(null), "Found by character");
        assertEquals(1, manager.size(), "One active session");
    }

    @Test
    public void unknownPlayerHasNoSession() {
        SessionManager manager = new SessionManager();

        assertTrue(manager.find(PlayerId.random()).isEmpty(), "Nobody is registered yet");
        assertTrue(manager.remove(PlayerId.random()).isEmpty(), "Removing an unknown player is a no-op");
    }

    @Test
    public void duplicateSessionForOnePlayerIsRejectedAndKeepsTheFirst() {
        RuntimeFixture f = new RuntimeFixture();
        SessionManager manager = new SessionManager();
        PlayerId player = PlayerId.random();
        PlayerSession first = session(f, player, "Aria");
        PlayerSession second = session(f, player, "Bram");
        manager.register(first);

        assertThrows(IllegalStateException.class, () -> manager.register(second), "One player, one active session");

        assertEquals(first, manager.find(player).orElse(null), "The first session is untouched");
        assertTrue(manager.findByCharacter(second.characterId()).isEmpty(), "The rejected session left no trace");
    }

    @Test
    public void sameCharacterCannotBeActiveForTwoPlayers() {
        RuntimeFixture f = new RuntimeFixture();
        SessionManager manager = new SessionManager();
        PlayerSession first = session(f, PlayerId.random(), "Aria");
        manager.register(first);
        PlayerSession thief = new PlayerSession(PlayerId.random(), first.runtime());

        assertThrows(IllegalStateException.class, () -> manager.register(thief), "One character, one active player");
        assertEquals(1, manager.size(), "Still just the first session");
    }

    @Test
    public void removeReturnsTheSessionAndFreesBothPlayerAndCharacter() {
        RuntimeFixture f = new RuntimeFixture();
        SessionManager manager = new SessionManager();
        PlayerId player = PlayerId.random();
        PlayerSession session = session(f, player, "Aria");
        manager.register(session);

        assertEquals(session, manager.remove(player).orElse(null), "The removed session is returned");

        assertTrue(manager.find(player).isEmpty(), "Player is free");
        assertTrue(manager.findByCharacter(session.characterId()).isEmpty(), "Character is free");
        manager.register(session); // can be registered again
        assertEquals(1, manager.size(), "Registering again works after removal");
    }

    @Test
    public void activeSessionsIsADetachedCopy() {
        RuntimeFixture f = new RuntimeFixture();
        SessionManager manager = new SessionManager();
        manager.register(session(f, PlayerId.random(), "Aria"));

        var copy = manager.activeSessions();
        manager.remove(copy.get(0).playerId());

        assertEquals(1, copy.size(), "A previously returned list does not change");
        assertEquals(0, manager.size(), "The registry did");
    }

    @Test
    public void managersAreIndependentInstances() {
        RuntimeFixture f = new RuntimeFixture();
        SessionManager one = new SessionManager();
        SessionManager two = new SessionManager();
        PlayerId player = PlayerId.random();

        one.register(session(f, player, "Aria"));

        assertTrue(two.find(player).isEmpty(), "No hidden global registry");
    }

    @Test
    public void playerIdAndCharacterIdAreDistinctIdentities() {
        RuntimeFixture f = new RuntimeFixture();
        PlayerId player = PlayerId.random();
        PlayerSession session = session(f, player, "Aria");

        assertNotEquals(player.value(), session.characterId().value(), "A player and their character are different identities");
        assertThrows(NullPointerException.class, () -> new PlayerSession(null, session.runtime()), "playerId");
        assertThrows(NullPointerException.class, () -> new PlayerSession(player, null), "runtime");
        assertThrows(NullPointerException.class, () -> manager().register(null), "session");
    }

    private static SessionManager manager() {
        return new SessionManager();
    }
}
