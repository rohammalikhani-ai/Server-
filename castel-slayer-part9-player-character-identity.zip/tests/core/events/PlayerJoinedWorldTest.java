package core.events;

import support.Test;
import static support.Assertions.*;

import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;

public class PlayerJoinedWorldTest {

    @Test
    public void isAGameEvent() {
        PlayerJoinedWorld event = new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now());
        assertTrue(event instanceof GameEvent, "PlayerJoinedWorld must implement GameEvent");
    }

    @Test
    public void rejectsNullOccurredAt() {
        assertThrows(NullPointerException.class,
                () -> new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), null),
                "occurredAt is required");
    }
}
