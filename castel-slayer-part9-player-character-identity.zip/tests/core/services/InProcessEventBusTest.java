package core.services;

import support.Test;
import static support.Assertions.*;

import core.contracts.Subscription;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.PlayerJoinedWorld;
import core.events.PlayerLeftWorld;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

public class InProcessEventBusTest {

    @Test
    public void subscriberReceivesPublishedEventOfItsType() {
        InProcessEventBus bus = new InProcessEventBus();
        AtomicInteger received = new AtomicInteger();
        bus.subscribe(PlayerJoinedWorld.class, e -> received.incrementAndGet());

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(1, received.get(), "subscriber should be invoked exactly once");
    }

    @Test
    public void subscribersOfOtherEventTypesAreNotInvoked() {
        InProcessEventBus bus = new InProcessEventBus();
        AtomicInteger joinedReceived = new AtomicInteger();
        AtomicInteger leftReceived = new AtomicInteger();
        bus.subscribe(PlayerJoinedWorld.class, e -> joinedReceived.incrementAndGet());
        bus.subscribe(PlayerLeftWorld.class, e -> leftReceived.incrementAndGet());

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(1, joinedReceived.get(), "PlayerJoinedWorld subscriber should fire");
        assertEquals(0, leftReceived.get(), "PlayerLeftWorld subscriber must not fire for a different event type");
    }

    @Test
    public void unsubscribeStopsFurtherDelivery() {
        InProcessEventBus bus = new InProcessEventBus();
        AtomicInteger received = new AtomicInteger();
        Subscription subscription = bus.subscribe(PlayerJoinedWorld.class, e -> received.incrementAndGet());
        bus.unsubscribe(subscription);

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(0, received.get(), "unsubscribed handler must not be invoked");
    }

    @Test
    public void publishNeverThrowsOnBadSubscriber() {
        InProcessEventBus bus = new InProcessEventBus();
        bus.subscribe(PlayerJoinedWorld.class, e -> {
            throw new RuntimeException("boom");
        });

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));
        // reaching here without the exception propagating is the assertion.
    }

    @Test
    public void unsubscribeIsSafeToCallTwice() {
        InProcessEventBus bus = new InProcessEventBus();
        Subscription subscription = bus.subscribe(PlayerJoinedWorld.class, e -> { });

        bus.unsubscribe(subscription);
        bus.unsubscribe(subscription);
        // reaching here without an exception is the assertion.
    }
}
