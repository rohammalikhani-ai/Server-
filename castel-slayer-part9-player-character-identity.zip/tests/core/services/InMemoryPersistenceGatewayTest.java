package core.services;

import support.Test;
import static support.Assertions.*;

import core.contracts.PersistenceException;
import java.util.List;
import java.util.Optional;

/** The production (development/testing) in-memory gateway; {@code tests/support}'s double is a separate, older class. */
public class InMemoryPersistenceGatewayTest {

    private record Widget(String name, int count) {
    }

    private record Gadget(String name) {
    }

    @Test
    public void savedValueCanBeLoadedBack() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));

        assertEquals(Optional.of(new Widget("bolt", 5)), gateway.load("widgets", "w1", Widget.class),
                "A saved value loads back equal");
    }

    @Test
    public void missingKeyAndMissingCollectionLoadEmptyNotFailed() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));

        assertTrue(gateway.load("widgets", "nope", Widget.class).isEmpty(), "Unknown key: empty");
        assertTrue(gateway.load("gadgets", "w1", Widget.class).isEmpty(), "Unknown collection: empty");
    }

    @Test
    public void saveOverwritesTheSameKey() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));
        gateway.save("widgets", "w1", new Widget("bolt", 9));

        assertEquals(9, gateway.load("widgets", "w1", Widget.class).orElseThrow().count(), "Last write wins");
    }

    @Test
    public void deleteRemovesOnlyThatKey() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));
        gateway.save("widgets", "w2", new Widget("nut", 1));

        gateway.delete("widgets", "w1");
        gateway.delete("widgets", "never-existed");
        gateway.delete("no-such-collection", "w1");

        assertTrue(gateway.load("widgets", "w1", Widget.class).isEmpty(), "Deleted");
        assertTrue(gateway.load("widgets", "w2", Widget.class).isPresent(), "Neighbour untouched");
    }

    @Test
    public void collectionsAreIndependent() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("a", "k", new Widget("in-a", 1));
        gateway.save("b", "k", new Widget("in-b", 2));

        assertEquals("in-a", gateway.load("a", "k", Widget.class).orElseThrow().name(), "Collection a");
        assertEquals("in-b", gateway.load("b", "k", Widget.class).orElseThrow().name(), "Collection b");
    }

    @Test
    public void queryIsFilteredAndDeterministicallyOrderedByKey() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "k3", new Widget("c", 30));
        gateway.save("widgets", "k1", new Widget("a", 10));
        gateway.save("widgets", "k2", new Widget("b", 20));

        List<Widget> all = gateway.query("widgets", Widget.class, w -> true);
        List<Widget> big = gateway.query("widgets", Widget.class, w -> w.count() > 15);

        assertEquals(List.of(new Widget("a", 10), new Widget("b", 20), new Widget("c", 30)), all,
                "Key order, regardless of insertion order");
        assertEquals(List.of(new Widget("b", 20), new Widget("c", 30)), big, "Filter applied, order kept");
        assertTrue(gateway.query("none", Widget.class, w -> true).isEmpty(), "Unknown collection: empty list");
    }

    @Test
    public void wrongTypeIsAPersistenceFailureNotAClassCastException() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("things", "t1", new Gadget("g"));

        assertThrows(PersistenceException.class, () -> gateway.load("things", "t1", Widget.class),
                "A stored value of another type is a failed read, distinct from 'absent'");
        assertThrows(PersistenceException.class, () -> gateway.query("things", Widget.class, w -> true),
                "Same for queries");
    }

    @Test
    public void nullArgumentsAreRejected() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();

        assertThrows(NullPointerException.class, () -> gateway.save("c", "k", null), "Null value");
        assertThrows(NullPointerException.class, () -> gateway.save(null, "k", "v"), "Null collection");
        assertThrows(NullPointerException.class, () -> gateway.load("c", null, String.class), "Null key");
    }

    @Test
    public void separateInstancesShareNothing() {
        InMemoryPersistenceGateway first = new InMemoryPersistenceGateway();
        InMemoryPersistenceGateway second = new InMemoryPersistenceGateway();
        first.save("widgets", "w1", new Widget("bolt", 5));

        assertTrue(second.load("widgets", "w1", Widget.class).isEmpty(), "No static/global state behind the gateway");
    }
}
