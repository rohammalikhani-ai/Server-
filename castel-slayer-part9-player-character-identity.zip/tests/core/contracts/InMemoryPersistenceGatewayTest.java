package core.contracts;

import support.InMemoryPersistenceGateway;
import support.Test;
import static support.Assertions.*;

import java.util.List;
import java.util.Optional;

public class InMemoryPersistenceGatewayTest {

    private record Widget(String name, int count) {
    }

    @Test
    public void savedValueCanBeLoadedBack() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));

        Optional<Widget> loaded = gateway.load("widgets", "w1", Widget.class);

        assertTrue(loaded.isPresent(), "value saved under a key should be loadable");
        assertEquals(new Widget("bolt", 5), loaded.get(), "loaded value should equal the saved value");
    }

    @Test
    public void missingKeyLoadsEmpty() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        assertTrue(gateway.load("widgets", "missing", Widget.class).isEmpty(), "missing key should load empty");
    }

    @Test
    public void deleteRemovesValue() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));
        gateway.delete("widgets", "w1");
        assertTrue(gateway.load("widgets", "w1", Widget.class).isEmpty(), "deleted key should load empty");
    }

    @Test
    public void queryFiltersByPredicate() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save("widgets", "w1", new Widget("bolt", 5));
        gateway.save("widgets", "w2", new Widget("nut", 12));

        List<Widget> big = gateway.query("widgets", Widget.class, w -> w.count() > 10);

        assertEquals(1, big.size(), "only widgets matching the predicate should be returned");
        assertEquals("nut", big.get(0).name(), "the matching widget should be 'nut'");
    }
}
