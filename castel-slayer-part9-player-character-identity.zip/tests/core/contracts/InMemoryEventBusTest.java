package core.contracts;

import support.InMemoryEventBus;
import support.Test;
import static support.Assertions.*;

import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.PlayerJoinedWorld;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

public class InMemoryEventBusTest {

    @Test
    public void subscriberReceivesPublishedEventOfItsType() {
        InMemoryEventBus bus = new InMemoryEventBus();
        AtomicInteger received = new AtomicInteger();
        bus.subscribe(PlayerJoinedWorld.class, e -> received.incrementAndGet());

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(1, received.get(), "subscriber should be invoked exactly once");
    }

    @Test
    public void unsubscribeStopsFurtherDelivery() {
        InMemoryEventBus bus = new InMemoryEventBus();
        AtomicInteger received = new AtomicInteger();
        Subscription subscription = bus.subscribe(PlayerJoinedWorld.class, e -> received.incrementAndGet());
        bus.unsubscribe(subscription);

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(0, received.get(), "unsubscribed handler must not be invoked");
    }

    @Test
    public void publishNeverThrowsOnBadSubscriber() {
        InMemoryEventBus bus = new InMemoryEventBus();
        bus.subscribe(PlayerJoinedWorld.class, e -> {
            throw new RuntimeException("boom");
        });

        bus.publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));
        // reaching here without an exception propagating is the assertion
    }
}
