package core.domain;

import support.Test;
import static support.Assertions.*;

import java.util.UUID;

public class PlayerIdTest {

    @Test
    public void equalIdsAreEqual() {
        UUID raw = UUID.randomUUID();
        assertEquals(PlayerId.of(raw), PlayerId.of(raw), "same underlying UUID should be equal");
    }

    @Test
    public void randomIdsAreDistinct() {
        assertNotEquals(PlayerId.random(), PlayerId.random(), "two random ids should not collide");
    }

    @Test
    public void rejectsNullUuid() {
        assertThrows(NullPointerException.class, () -> new PlayerId(null), "null UUID must be rejected");
    }
}
