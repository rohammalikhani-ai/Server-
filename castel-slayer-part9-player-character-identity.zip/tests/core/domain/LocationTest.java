package core.domain;

import support.Test;
import static support.Assertions.*;

public class LocationTest {

    @Test
    public void shorthandConstructorDefaultsFacing() {
        WorldId world = WorldId.of("overworld");
        Location loc = new Location(world, 1.0, 2.0, 3.0);
        assertEquals(0f, loc.yaw(), "default yaw should be 0");
        assertEquals(0f, loc.pitch(), "default pitch should be 0");
    }

    @Test
    public void rejectsNonFiniteCoordinates() {
        WorldId world = WorldId.of("overworld");
        assertThrows(IllegalArgumentException.class,
                () -> new Location(world, Double.NaN, 0, 0),
                "NaN coordinate must be rejected");
    }

    @Test
    public void worldIdRejectsBlankKey() {
        assertThrows(IllegalArgumentException.class, () -> WorldId.of("   "), "blank world key must be rejected");
    }
}
