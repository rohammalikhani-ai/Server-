package core.domain;

import support.Test;
import static support.Assertions.*;

public class EntityRefTest {

    @Test
    public void refOfPlayerRoundTripsToSamePlayerId() {
        PlayerId id = PlayerId.random();
        EntityRef ref = EntityRef.ofPlayer(id);
        assertTrue(ref.isPlayer(), "ref built from a player should report isPlayer()");
        assertEquals(id, ref.asPlayerId(), "asPlayerId() should recover the original PlayerId");
    }

    @Test
    public void nonPlayerRefRejectsAsPlayerId() {
        EntityRef ref = EntityRef.of(EntityKind.NPC, EntityId.random());
        assertThrows(IllegalStateException.class, ref::asPlayerId, "an NPC ref must not resolve as a player");
    }

    @Test
    public void ofRejectsPlayerKind() {
        assertThrows(IllegalArgumentException.class,
                () -> EntityRef.of(EntityKind.PLAYER, EntityId.random()),
                "PLAYER-kind refs must go through ofPlayer(PlayerId)");
    }
}
