package core.domain;

import support.Test;
import static support.Assertions.*;

public class PlayerIdentityTest {

    @Test
    public void rejectsBlankDisplayName() {
        assertThrows(IllegalArgumentException.class,
                () -> new PlayerIdentity(PlayerId.random(), "  ", ClientEdition.JAVA),
                "blank display name must be rejected");
    }

    @Test
    public void trimsDisplayName() {
        PlayerIdentity identity = new PlayerIdentity(PlayerId.random(), "  Slayer  ", ClientEdition.BEDROCK);
        assertEquals("Slayer", identity.displayName(), "display name should be trimmed");
    }
}
