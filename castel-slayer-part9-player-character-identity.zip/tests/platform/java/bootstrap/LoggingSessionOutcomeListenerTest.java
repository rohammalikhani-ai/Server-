package castelslayer.platform.paper.bootstrap;

import castelslayer.application.session.SessionOutcomeListener;
import core.domain.PlayerId;
import core.events.PlayerJoinedWorld;
import core.domain.WorldId;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import support.Test;
import static support.Assertions.*;

/** The outcome listener reports through a plain JDK Logger (no Bukkit needed). */
public class LoggingSessionOutcomeListenerTest {

    private static final class Capture extends Handler {
        final List<LogRecord> records = new ArrayList<>();

        @Override
        public void publish(LogRecord record) {
            records.add(record);
        }

        @Override
        public void flush() {
        }

        @Override
        public void close() {
        }
    }

    private static Logger logger(Capture capture) {
        Logger logger = Logger.getAnonymousLogger();
        logger.setUseParentHandlers(false);
        logger.setLevel(Level.ALL);
        logger.addHandler(capture);
        return logger;
    }

    @Test
    public void reportsNoCharacterAtInfoLevel() {
        Capture capture = new Capture();
        CoreRuntime runtime = CompositionRoot.bootstrap(new LoggingSessionOutcomeListener(logger(capture)));
        PlayerId noCharacter = PlayerId.random();

        runtime.eventBus().publish(new PlayerJoinedWorld(noCharacter, WorldId.of("overworld"), Instant.now()));

        assertEquals(1, capture.records.size(), "One line per outcome");
        assertEquals(Level.INFO, capture.records.get(0).getLevel(), "A player without a character is routine");
    }

    @Test
    public void joinAndQuitOfARealCharacterAreLogged() {
        Capture capture = new Capture();
        CoreRuntime runtime = CompositionRoot.bootstrap(new LoggingSessionOutcomeListener(logger(capture)));
        PlayerId player = PlayerId.random();
        runtime.characterLifecycle().create(player, "Aria");

        runtime.eventBus().publish(new PlayerJoinedWorld(player, WorldId.of("overworld"), Instant.now()));
        runtime.shutdown();

        assertTrue(capture.records.stream().anyMatch(r -> r.getMessage().contains("is now playing character")), "Join is logged");
    }

    @Test
    public void nullLoggerIsRejectedAndNoneIsANoOp() {
        assertThrows(NullPointerException.class, () -> new LoggingSessionOutcomeListener(null), "logger");
        SessionOutcomeListener.NONE.onJoin(PlayerId.random(), null); // must not throw
    }
}
