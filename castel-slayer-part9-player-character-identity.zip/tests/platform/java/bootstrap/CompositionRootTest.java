package castelslayer.platform.paper.bootstrap;

import support.Test;
import static support.Assertions.*;

import castelslayer.application.session.PlayerSession;
import castelslayer.application.session.SessionQuitResult;
import character.contracts.CharacterSummary;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.PlayerJoinedWorld;
import core.events.PlayerLeftWorld;
import inventory.domain.Item;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Covers only what {@code CompositionRoot.bootstrap()} does without touching Bukkit:
 * neither this class nor anything it calls imports {@code org.bukkit.*}, so it runs
 * as a plain JDK test the same way {@code tests/core/**} does. Everything else in
 * {@code platform/java} (the plugin entrypoint, the listener, the identity mapper)
 * needs a live Bukkit/Paper classpath to construct or exercise — see FINAL REPORT for
 * why those are reviewed manually instead of tested here.
 */
public class CompositionRootTest {

    @Test
    public void bootstrapProducesAWorkingEventBus() {
        CoreRuntime runtime = CompositionRoot.bootstrap();
        assertNotNull(runtime.eventBus(), "bootstrap() must produce a non-null event bus");

        AtomicInteger received = new AtomicInteger();
        runtime.eventBus().subscribe(PlayerJoinedWorld.class, e -> received.incrementAndGet());
        runtime.eventBus().publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(1, received.get(), "the wired event bus should actually dispatch publish/subscribe");
    }

    @Test
    public void eachBootstrapCallProducesAnIndependentEventBus() {
        CoreRuntime first = CompositionRoot.bootstrap();
        CoreRuntime second = CompositionRoot.bootstrap();

        AtomicInteger receivedOnFirst = new AtomicInteger();
        first.eventBus().subscribe(PlayerJoinedWorld.class, e -> receivedOnFirst.incrementAndGet());

        second.eventBus().publish(new PlayerJoinedWorld(PlayerId.random(), WorldId.of("overworld"), Instant.now()));

        assertEquals(0, receivedOnFirst.get(), "a subscriber on one bootstrap's bus must not see events published on another's");
    }

    @Test
    public void bootstrapAssemblesTheCharacterRuntimeEndToEnd() {
        CoreRuntime runtime = CompositionRoot.bootstrap();
        WorldId world = WorldId.of("overworld");
        PlayerId player = PlayerId.random();
        CharacterSummary hero = runtime.characterLifecycle().create(player, "Aria");

        runtime.eventBus().publish(new PlayerJoinedWorld(player, world, Instant.now()));

        PlayerSession session = runtime.sessions().find(player).orElseThrow();
        assertEquals(hero.id(), session.characterId(), "Joining activates the player's character runtime");
        assertNotEquals(player.value(), session.characterId().value(), "PlayerId and CharacterId stay distinct");
        session.runtime().inventory().addItem(new Item(new inventory.contracts.ItemId("potion"), 10), 4);

        runtime.eventBus().publish(new PlayerLeftWorld(player, world, Instant.now()));

        assertTrue(runtime.sessions().find(player).isEmpty(), "Leaving releases the session");
        runtime.eventBus().publish(new PlayerJoinedWorld(player, world, Instant.now()));
        assertEquals(4L, runtime.sessions().find(player).orElseThrow().runtime().inventory()
                .countOf(new inventory.contracts.ItemId("potion")), "What was saved on quit is loaded on the next join");
    }

    @Test
    public void shutdownSavesActiveSessionsAndStopsReactingToEvents() {
        CoreRuntime runtime = CompositionRoot.bootstrap();
        PlayerId player = PlayerId.random();
        runtime.characterLifecycle().create(player, "Aria");
        runtime.eventBus().publish(new PlayerJoinedWorld(player, WorldId.of("overworld"), Instant.now()));

        List<SessionQuitResult> results = runtime.shutdown();

        assertEquals(1, results.size(), "The one active session was quit");
        assertTrue(results.get(0) instanceof SessionQuitResult.Saved, "…and saved");
        assertEquals(0, runtime.sessions().size(), "Nobody is active after shutdown");
        runtime.eventBus().publish(new PlayerJoinedWorld(player, WorldId.of("overworld"), Instant.now()));
        assertEquals(0, runtime.sessions().size(), "The lifecycle no longer reacts to events");
    }

    @Test
    public void everyBootstrapHasItsOwnCharactersAndSessions() {
        CoreRuntime first = CompositionRoot.bootstrap();
        CoreRuntime second = CompositionRoot.bootstrap();
        PlayerId player = PlayerId.random();
        CharacterSummary hero = first.characterLifecycle().create(player, "Aria");

        assertTrue(second.characterDirectory().findById(hero.id()).isEmpty(), "No global character store is shared");
        assertTrue(second.characterDirectory().findActiveForPlayer(player).isEmpty(), "…nor any player lookup");
    }

    @Test
    public void nullOutcomeListenerIsRejected() {
        assertThrows(NullPointerException.class, () -> CompositionRoot.bootstrap(null), "outcomes");
    }
}
