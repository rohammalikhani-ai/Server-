package character.domain;

import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import core.domain.PlayerId;
import java.time.Instant;

public class PlayerCharacterTest {

    @Test
    public void newCharacterIsActive() {
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", Instant.now());
        assertTrue(character.isActive(), "a freshly created character should be active");
    }

    @Test
    public void retireFlipsStateAndUpdatesTimestamp() {
        Instant createdAt = Instant.parse("2026-01-01T00:00:00Z");
        Instant retiredAt = Instant.parse("2026-02-01T00:00:00Z");
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", createdAt);

        character.retire(retiredAt);

        assertFalse(character.isActive(), "a retired character should no longer be active");
        assertEquals(retiredAt, character.updatedAt(), "retiring should bump updatedAt");
        assertEquals(createdAt, character.createdAt(), "createdAt must never change");
    }

    @Test
    public void cannotRetireTwice() {
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", Instant.now());
        character.retire(Instant.now());

        assertThrows(IllegalStateException.class, () -> character.retire(Instant.now()),
                "retiring an already-retired character must be rejected");
    }

    @Test
    public void renameChangesNameAndBumpsUpdatedAtButNotIdentity() {
        CharacterId id = CharacterId.random();
        PlayerId owner = PlayerId.random();
        Instant createdAt = Instant.parse("2026-01-01T00:00:00Z");
        Instant renamedAt = Instant.parse("2026-01-05T00:00:00Z");
        PlayerCharacter character = PlayerCharacter.create(id, owner, "Aria", createdAt);

        character.rename("Borin", renamedAt);

        assertEquals("Borin", character.name(), "the display name changed");
        assertEquals(renamedAt, character.updatedAt(), "renaming bumps updatedAt");
        assertEquals(id, character.id(), "CharacterId is stable across a rename");
        assertEquals(owner, character.ownerId(), "PlayerId ownership is stable across a rename");
        assertEquals(createdAt, character.createdAt(), "createdAt must never change");
    }

    @Test
    public void renameRejectsBlankName() {
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", Instant.now());
        assertThrows(IllegalArgumentException.class, () -> character.rename("   ", Instant.now()), "blank name");
    }

    @Test
    public void renameRejectsNulls() {
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", Instant.now());
        assertThrows(NullPointerException.class, () -> character.rename(null, Instant.now()), "validatedName");
        assertThrows(NullPointerException.class, () -> character.rename("Borin", null), "at");
    }

    @Test
    public void renamingARetiredCharacterDoesNotChangeItsLifecycleState() {
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", Instant.now());
        character.retire(Instant.now());

        character.rename("Borin", Instant.now());

        assertFalse(character.isActive(), "still retired");
        assertEquals("Borin", character.name(), "but renamed");
    }

    @Test
    public void reconstituteRestoresGivenState() {
        CharacterId id = CharacterId.random();
        PlayerId owner = PlayerId.random();
        Instant createdAt = Instant.parse("2026-01-01T00:00:00Z");
        Instant updatedAt = Instant.parse("2026-01-05T00:00:00Z");

        PlayerCharacter character = PlayerCharacter.reconstitute(id, owner, "Aria", CharacterState.RETIRED, createdAt, updatedAt);

        assertFalse(character.isActive(), "reconstituted RETIRED state should not be active");
        assertEquals(updatedAt, character.updatedAt(), "reconstitute should preserve the persisted updatedAt");
    }
}
