package character.services;

import support.InMemoryEventBus;
import support.InMemoryPersistenceGateway;
import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import character.domain.PlayerCharacter;
import core.domain.PlayerId;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Optional;

public class CharacterDirectoryServiceTest {

    @Test
    public void savedCharacterIsFindableById() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        CharacterDirectoryService directory = new CharacterDirectoryService(gateway);
        CharacterFactory factory = new CharacterFactory(new InMemoryEventBus(), Clock.systemUTC());
        PlayerCharacter character = factory.create(PlayerId.random(), "Aria");

        directory.save(character);
        Optional<CharacterSummary> found = directory.findById(character.id());

        assertTrue(found.isPresent(), "a saved character should be findable by id");
        assertEquals("Aria", found.get().name(), "found summary should carry the character's name");
        assertTrue(found.get().active(), "found summary should reflect the character being active");
    }

    @Test
    public void findActiveForPlayerIgnoresRetiredCharacters() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        CharacterDirectoryService directory = new CharacterDirectoryService(gateway);
        Clock fixed = Clock.fixed(Instant.parse("2026-03-01T00:00:00Z"), ZoneOffset.UTC);
        CharacterFactory factory = new CharacterFactory(new InMemoryEventBus(), fixed);
        PlayerId owner = PlayerId.random();
        PlayerCharacter character = factory.create(owner, "Aria");
        character.retire(Instant.now());
        directory.save(character);

        Optional<CharacterSummary> active = directory.findActiveForPlayer(owner);

        assertTrue(active.isEmpty(), "a retired character must not be returned as the player's active character");
    }

    @Test
    public void findByIdReturnsEmptyForUnknownId() {
        CharacterDirectoryService directory = new CharacterDirectoryService(new InMemoryPersistenceGateway());
        assertTrue(directory.findById(CharacterId.random()).isEmpty(), "an unknown id should load empty, not throw");
    }
}
