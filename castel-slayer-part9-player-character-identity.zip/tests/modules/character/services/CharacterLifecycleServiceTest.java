package character.services;

import support.InMemoryEventBus;
import support.InMemoryPersistenceGateway;
import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import character.events.CharacterCreated;
import character.events.CharacterRenamed;
import character.events.CharacterRetired;
import core.contracts.IEventBus;
import core.contracts.Subscription;
import core.domain.PlayerId;
import core.events.GameEvent;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class CharacterLifecycleServiceTest {

    private static final Clock CLOCK = Clock.fixed(Instant.parse("2026-03-01T00:00:00Z"), ZoneOffset.UTC);

    /**
     * A fresh fixture per test: {@code support.TestRunner} reuses ONE instance of a test class for
     * all its methods, so instance fields would leak state from one test into the next.
     */
    private static final class Fixture {
        final InMemoryEventBus bus = new InMemoryEventBus();
        final CharacterDirectoryService directory = new CharacterDirectoryService(new InMemoryPersistenceGateway());
        final CharacterLifecycleService lifecycle =
                new CharacterLifecycleService(directory, new CharacterFactory(bus, CLOCK), bus, CLOCK);
    }

    @Test
    public void createPersistsTheCharacterAndPublishesCharacterCreated() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        PlayerId owner = PlayerId.random();

        CharacterSummary created = lifecycle.create(owner, "Aria");

        assertEquals("Aria", created.name(), "Summary carries the validated name");
        assertEquals(owner, created.ownerId(), "The account owns it");
        assertTrue(created.active(), "A new character is active");
        assertTrue(directory.findById(created.id()).isPresent(), "It is now in the directory");
        assertEquals(1, bus.published().size(), "Exactly one event");
        assertTrue(bus.published().get(0) instanceof CharacterCreated created2 && created2.characterId().equals(created.id()),
                "CharacterCreated names the new character");
    }

    @Test
    public void createSavesBeforePublishing() {
        CharacterDirectoryService directory = new Fixture().directory;
        // A subscriber that reacts to CharacterCreated by querying the directory must already see it.
        List<Optional<CharacterSummary>> seenBySubscriber = new ArrayList<>();
        InMemoryEventBus inner = new InMemoryEventBus();
        IEventBus recording = new IEventBus() {
            @Override
            public <T extends GameEvent> void publish(T event) {
                if (event instanceof CharacterCreated c) {
                    seenBySubscriber.add(directory.findById(c.characterId()));
                }
                inner.publish(event);
            }

            @Override
            public <T extends GameEvent> Subscription subscribe(Class<T> eventType, Consumer<T> handler) {
                return inner.subscribe(eventType, handler);
            }

            @Override
            public void unsubscribe(Subscription subscription) {
                inner.unsubscribe(subscription);
            }
        };
        CharacterLifecycleService service =
                new CharacterLifecycleService(directory, new CharacterFactory(recording, CLOCK), recording, CLOCK);

        service.create(PlayerId.random(), "Aria");

        assertEquals(1, seenBySubscriber.size(), "The event was published once");
        assertTrue(seenBySubscriber.get(0).isPresent(), "The character was already persisted when the event fired");
    }

    @Test
    public void invalidNameCreatesNothingAndPublishesNothing() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        assertThrows(IllegalArgumentException.class, () -> lifecycle.create(PlayerId.random(), "x"), "Name too short");
        assertTrue(bus.published().isEmpty(), "No event for a failed creation");
    }

    @Test
    public void playerCannotHaveTwoActiveCharacters() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        PlayerId owner = PlayerId.random();
        lifecycle.create(owner, "Aria");

        assertThrows(IllegalStateException.class, () -> lifecycle.create(owner, "Borin"),
                "The prototype allows one active character per player");
        assertEquals(1, bus.published().size(), "The rejected creation published nothing");
    }

    @Test
    public void playerMayCreateANewCharacterAfterRetiringTheOldOne() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        PlayerId owner = PlayerId.random();
        CharacterSummary first = lifecycle.create(owner, "Aria");
        lifecycle.retire(first.id());

        CharacterSummary second = lifecycle.create(owner, "Borin");

        assertNotEquals(first.id(), second.id(), "A different character");
        assertEquals(second.id(), directory.findActiveForPlayer(owner).orElseThrow().id(), "The new one is the active one");
    }

    @Test
    public void retirePersistsTheChangeAndPublishesCharacterRetired() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        CharacterSummary created = lifecycle.create(PlayerId.random(), "Aria");

        Optional<CharacterSummary> retired = lifecycle.retire(created.id());

        assertTrue(retired.isPresent(), "The character existed");
        assertFalse(retired.get().active(), "It is no longer active");
        assertFalse(directory.findById(created.id()).orElseThrow().active(), "The directory reflects it");
        assertEquals(2, bus.published().size(), "Created + Retired");
        assertTrue(bus.published().get(1) instanceof CharacterRetired r && r.characterId().equals(created.id()),
                "CharacterRetired is published (it previously never was)");
    }

    @Test
    public void retireOfUnknownCharacterIsEmptyAndPublishesNothing() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        assertTrue(lifecycle.retire(CharacterId.random()).isEmpty(), "Unknown id is reported, not thrown or null");
        assertTrue(bus.published().isEmpty(), "Nothing was retired, so nothing is announced");
    }

    @Test
    public void retiringTwiceIsRejected() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        CharacterSummary created = lifecycle.create(PlayerId.random(), "Aria");
        lifecycle.retire(created.id());

        assertThrows(IllegalStateException.class, () -> lifecycle.retire(created.id()), "Already retired");
    }

    // ---- rename (Gameplay Part 9) ---------------------------------------------------------

    @Test
    public void renamePersistsTheNewNameAndPublishesCharacterRenamed() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        CharacterSummary created = lifecycle.create(PlayerId.random(), "Aria");

        Optional<CharacterSummary> renamed = lifecycle.rename(created.id(), "Borin");

        assertTrue(renamed.isPresent(), "The character existed");
        assertEquals("Borin", renamed.get().name(), "New name in the returned summary");
        assertEquals("Borin", directory.findById(created.id()).orElseThrow().name(), "The directory reflects it");
        assertEquals(2, bus.published().size(), "Created + Renamed");
        assertTrue(bus.published().get(1) instanceof CharacterRenamed r && r.characterId().equals(created.id())
                        && r.previousName().equals("Aria") && r.newName().equals("Borin"),
                "CharacterRenamed carries both the old and new name");
    }

    @Test
    public void renameNeverChangesCharacterIdOrOwner() {
        Fixture fx = new Fixture();
        CharacterLifecycleService lifecycle = fx.lifecycle;
        PlayerId owner = PlayerId.random();
        CharacterSummary created = lifecycle.create(owner, "Aria");

        CharacterSummary renamed = lifecycle.rename(created.id(), "Borin").orElseThrow();

        assertEquals(created.id(), renamed.id(), "CharacterId is stable across a rename");
        assertEquals(owner, renamed.ownerId(), "PlayerId ownership is stable across a rename");
    }

    @Test
    public void invalidNewNameRenamesNothingAndPublishesNothing() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterDirectoryService directory = fx.directory;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        CharacterSummary created = lifecycle.create(PlayerId.random(), "Aria");

        assertThrows(IllegalArgumentException.class, () -> lifecycle.rename(created.id(), "x"), "Name too short");

        assertEquals("Aria", directory.findById(created.id()).orElseThrow().name(), "Unchanged");
        assertEquals(1, bus.published().size(), "Only the original CharacterCreated");
    }

    @Test
    public void renameOfUnknownCharacterIsEmptyAndPublishesNothing() {
        Fixture fx = new Fixture();
        InMemoryEventBus bus = fx.bus;
        CharacterLifecycleService lifecycle = fx.lifecycle;
        assertTrue(lifecycle.rename(CharacterId.random(), "Borin").isEmpty(), "Unknown id is reported, not thrown or null");
        assertTrue(bus.published().isEmpty(), "Nothing was renamed, so nothing is announced");
    }

    @Test
    public void renamingARetiredCharacterStillWorksDisplayNameIsIndependentOfLifecycleState() {
        Fixture fx = new Fixture();
        CharacterLifecycleService lifecycle = fx.lifecycle;
        CharacterSummary created = lifecycle.create(PlayerId.random(), "Aria");
        lifecycle.retire(created.id());

        Optional<CharacterSummary> renamed = lifecycle.rename(created.id(), "Borin");

        assertTrue(renamed.isPresent(), "Renaming a retired character is not itself a lifecycle operation");
        assertFalse(renamed.get().active(), "Still retired");
        assertEquals("Borin", renamed.get().name(), "But renamed");
    }
}
