package character.services;

import support.InMemoryPersistenceGateway;
import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import character.contracts.CharacterSnapshot;
import character.domain.CharacterState;
import character.domain.PlayerCharacter;
import core.domain.PlayerId;
import java.time.Instant;
import java.util.Optional;

/** The directory stores an explicit snapshot record, never the live aggregate. */
public class CharacterDirectoryPersistenceModelTest {

    private static final Instant CREATED = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void whatIsStoredIsASnapshotRecordNotTheAggregate() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        CharacterDirectoryService directory = new CharacterDirectoryService(gateway);
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", CREATED);

        directory.save(character);

        Optional<CharacterSnapshot> stored = gateway.load("characters", character.id().toString(), CharacterSnapshot.class);
        assertTrue(stored.isPresent(), "A CharacterSnapshot sits under the character's id");
        assertEquals(character.toSnapshot(), stored.get(), "It is exactly the character's persistence model");
    }

    @Test
    public void loadedCharacterIsAFreshAggregateSoMutatingItDoesNotChangeStoredState() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        CharacterDirectoryService directory = new CharacterDirectoryService(gateway);
        PlayerCharacter character = PlayerCharacter.create(CharacterId.random(), PlayerId.random(), "Aria", CREATED);
        directory.save(character);

        PlayerCharacter loaded = directory.loadCharacter(character.id()).orElseThrow();
        loaded.retire(Instant.parse("2026-02-01T00:00:00Z"));

        assertTrue(directory.findById(character.id()).orElseThrow().active(),
                "Retiring a loaded copy without saving leaves the stored character active");
        assertTrue(character.isActive(), "And the original aggregate is unaffected too");
    }

    @Test
    public void snapshotRoundTripPreservesEveryField() {
        PlayerCharacter original = PlayerCharacter.reconstitute(CharacterId.random(), PlayerId.random(), "Aria",
                CharacterState.RETIRED, CREATED, Instant.parse("2026-01-05T00:00:00Z"));

        PlayerCharacter copy = PlayerCharacter.fromSnapshot(original.toSnapshot());

        assertEquals(original.toSnapshot(), copy.toSnapshot(), "Identical persistence model after a round trip");
        assertFalse(copy.isActive(), "Retired state survives");
        assertEquals(original.updatedAt(), copy.updatedAt(), "Timestamps survive");
    }

    @Test
    public void unknownStateNameIsCorruptData() {
        CharacterSnapshot corrupt = new CharacterSnapshot(CharacterId.random(), PlayerId.random(), "Aria", "ZOMBIE", CREATED, CREATED);

        assertThrows(IllegalArgumentException.class, () -> PlayerCharacter.fromSnapshot(corrupt),
                "A state name the module does not know is rejected, not defaulted");
    }
}
