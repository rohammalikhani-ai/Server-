package character.services;

import support.InMemoryEventBus;
import support.Test;
import static support.Assertions.*;

import character.domain.PlayerCharacter;
import character.events.CharacterCreated;
import core.domain.PlayerId;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

public class CharacterFactoryTest {

    @Test
    public void createReturnsActiveCharacterAndPublishesEvent() {
        InMemoryEventBus bus = new InMemoryEventBus();
        Clock fixed = Clock.fixed(Instant.parse("2026-03-01T00:00:00Z"), ZoneOffset.UTC);
        CharacterFactory factory = new CharacterFactory(bus, fixed);
        PlayerId owner = PlayerId.random();

        PlayerCharacter character = factory.create(owner, "Aria");

        assertTrue(character.isActive(), "newly created character should be active");
        assertEquals(owner, character.ownerId(), "character should belong to the requesting player");
        assertEquals(1, bus.published().size(), "creation should publish exactly one event");
        assertTrue(bus.published().get(0) instanceof CharacterCreated, "published event should be CharacterCreated");
    }

    @Test
    public void rejectsTooShortName() {
        CharacterFactory factory = new CharacterFactory(new InMemoryEventBus(), Clock.systemUTC());
        assertThrows(IllegalArgumentException.class, () -> factory.create(PlayerId.random(), "ab"),
                "a 2-character name should be rejected");
    }

    @Test
    public void rejectsNonAlphanumericName() {
        CharacterFactory factory = new CharacterFactory(new InMemoryEventBus(), Clock.systemUTC());
        assertThrows(IllegalArgumentException.class, () -> factory.create(PlayerId.random(), "Ar!a"),
                "a name with punctuation should be rejected");
    }
}
