package equipment.domain;

import inventory.contracts.ItemId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import character.contracts.CharacterId;
import support.Test;
import static support.Assertions.*;

public class ItemEquipmentTest {

    private static final CharacterId OWNER = CharacterId.random();

    private static ItemDefinition helmet(String id) {
        return new ItemDefinition(new ItemId(id), "Iron Helmet", ItemCategory.ARMOR, EquipmentSlot.HEAD);
    }

    private static ItemDefinition helmet() {
        return helmet("iron_helmet");
    }

    private static ItemDefinition chestplate() {
        return new ItemDefinition(
                new ItemId("iron_chestplate"), "Iron Chestplate", ItemCategory.ARMOR, EquipmentSlot.CHEST);
    }

    private static ItemDefinition sword() {
        return new ItemDefinition(
                new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
    }

    private static ItemDefinition shield() {
        return new ItemDefinition(
                new ItemId("wooden_shield"), "Wooden Shield", ItemCategory.ARMOR, EquipmentSlot.OFF_HAND);
    }

    private static ItemDefinition potion() {
        return new ItemDefinition(new ItemId("health_potion"), "Health Potion", ItemCategory.CONSUMABLE, 20);
    }

    /** One equip attempt for the mixed-operations test; {@code slot} may be null (an invalid slot). */
    private record Attempt(ItemDefinition item, EquipmentSlot slot) {
    }

    // ---- initial state -------------------------------------------------

    @Test
    public void newEquipmentIsEmptyInEverySlot() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        assertEquals(0, equipment.equippedCount(), "Nothing equipped yet");
        for (EquipmentSlot slot : EquipmentSlots.ALL) {
            assertFalse(equipment.isSlotOccupied(slot), slot + " starts empty");
            assertNull(equipment.getEquipped(slot), slot + " has no item");
        }
    }

    // ---- equip: success ------------------------------------------------

    @Test
    public void equipEquippableItemInItsSlotSucceeds() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet();

        EquipResult result = equipment.equip(helmet, EquipmentSlot.HEAD);

        assertTrue(result.isSuccess(), "Equip succeeds");
        assertEquals(EquipStatus.SUCCESS, result.status(), "Status is Success");
        assertEquals(helmet, result.item(), "Result carries the item");
        assertEquals(EquipmentSlot.HEAD, result.requestedSlot(), "Result carries the slot");
        assertNull(result.blockingItem(), "Nothing blocked it");
        assertEquals(helmet, equipment.getEquipped(EquipmentSlot.HEAD), "Slot now holds the helmet");
        assertTrue(equipment.isSlotOccupied(EquipmentSlot.HEAD), "Slot is occupied");
        assertTrue(equipment.isEquipped(helmet.id()), "Item id reports equipped");
        assertEquals(1, equipment.equippedCount(), "One item equipped");
    }

    @Test
    public void equipIntoEachSlotSucceeds() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        List<ItemDefinition> items = new ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlots.ALL) {
            items.add(new ItemDefinition(
                    new ItemId("item_" + slot.name()), "Item " + slot.name(), ItemCategory.ARMOR, slot));
        }

        for (ItemDefinition item : items) {
            assertTrue(equipment.equip(item, item.slot()).isSuccess(), item.name() + " equips");
        }

        assertEquals(EquipmentSlots.ALL.size(), equipment.equippedCount(), "Every slot is filled");
    }

    // ---- equip: failures -----------------------------------------------

    @Test
    public void equipNonEquippableItemIsRefused() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition potion = potion();

        EquipResult result = equipment.equip(potion, EquipmentSlot.MAIN_HAND);

        assertFalse(result.isSuccess(), "A potion cannot be equipped");
        assertEquals(EquipStatus.NOT_EQUIPPABLE, result.status(), "Status is NotEquippable");
        assertEquals(potion, result.item(), "Result still references the item");
        assertEquals(0, equipment.equippedCount(), "Nothing was equipped");
        assertFalse(equipment.isEquipped(potion.id()), "Potion is not equipped");
    }

    @Test
    public void notEquippableIsReportedEvenWhenTheSlotIsInvalidToo() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        EquipResult result = equipment.equip(potion(), null);

        assertEquals(EquipStatus.NOT_EQUIPPABLE, result.status(), "Item property is checked before the slot");
    }

    @Test
    public void equipIntoInvalidSlotIsRefused() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet();

        // null is the only invalid slot a Java caller can pass (a Java enum has no undeclared values).
        EquipResult result = equipment.equip(helmet, null);

        assertEquals(EquipStatus.INVALID_SLOT, result.status(), "A null slot is InvalidSlot");
        assertNull(result.requestedSlot(), "Requested slot value is reported as given");
        assertEquals(helmet, result.item(), "The item is still the caller's");
        assertEquals(0, equipment.equippedCount(), "Nothing was equipped");
    }

    @Test
    public void equipIntoIncompatibleSlotIsRefused() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet();

        EquipResult result = equipment.equip(helmet, EquipmentSlot.FEET);

        assertFalse(result.isSuccess(), "A helmet does not go on the feet");
        assertEquals(EquipStatus.INCOMPATIBLE_SLOT, result.status(), "Status is IncompatibleSlot");
        assertEquals(EquipmentSlot.FEET, result.requestedSlot(), "Requested slot is reported");
        assertEquals(0, equipment.equippedCount(), "Nothing was equipped");
        assertFalse(equipment.isSlotOccupied(EquipmentSlot.FEET), "Feet stay empty");
        assertFalse(equipment.isSlotOccupied(EquipmentSlot.HEAD), "Head stays empty too");
    }

    @Test
    public void equipIntoOccupiedSlotIsRefusedAndKeepsTheOriginalItem() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition first = helmet("iron_helmet");
        ItemDefinition second = helmet("gold_helmet");
        equipment.equip(first, EquipmentSlot.HEAD);

        EquipResult result = equipment.equip(second, EquipmentSlot.HEAD);

        assertFalse(result.isSuccess(), "Occupied slot refuses a second item");
        assertEquals(EquipStatus.SLOT_OCCUPIED, result.status(), "Status is SlotOccupied");
        assertEquals(first, result.blockingItem(), "Result names the occupant");
        assertEquals(second, result.item(), "The new item is still the caller's");
        assertEquals(first, equipment.getEquipped(EquipmentSlot.HEAD), "The original item is untouched");
        assertFalse(equipment.isEquipped(second.id()), "The refused item is not equipped");
        assertEquals(1, equipment.equippedCount(), "Still one item equipped");
    }

    @Test
    public void equippingTheSameItemTwiceIsRefusedAsAlreadyEquipped() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet();
        equipment.equip(helmet, EquipmentSlot.HEAD);

        EquipResult result = equipment.equip(helmet, EquipmentSlot.HEAD);

        assertEquals(EquipStatus.ALREADY_EQUIPPED, result.status(), "Same item id twice is AlreadyEquipped");
        assertEquals(helmet, result.blockingItem(), "Result names the equipped copy");
        assertEquals(1, equipment.equippedCount(), "Still one item equipped");
    }

    @Test
    public void conflictingDefinitionWithSameIdCannotSneakIntoAnotherSlot() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet("relic");
        ItemDefinition sameIdOtherSlot = new ItemDefinition(
                new ItemId("relic"), "Relic Plate", ItemCategory.ARMOR, EquipmentSlot.CHEST);
        equipment.equip(helmet, EquipmentSlot.HEAD);

        EquipResult result = equipment.equip(sameIdOtherSlot, EquipmentSlot.CHEST);

        assertEquals(EquipStatus.ALREADY_EQUIPPED, result.status(), "One ItemId can be equipped at most once");
        assertFalse(equipment.isSlotOccupied(EquipmentSlot.CHEST), "Chest stays empty");
        assertEquals(1, equipment.equippedCount(), "Still one item equipped");
    }

    @Test
    public void nullItemIsRejectedWithAnException() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        assertThrows(NullPointerException.class,
                () -> equipment.equip(null, EquipmentSlot.HEAD),
                "A null item is a programming error, not a gameplay outcome");
    }

    // ---- unequip -------------------------------------------------------

    @Test
    public void unequipReturnsTheEquippedItemAndEmptiesTheSlot() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition sword = sword();
        equipment.equip(sword, EquipmentSlot.MAIN_HAND);

        UnequipResult result = equipment.unequip(EquipmentSlot.MAIN_HAND);

        assertTrue(result.isSuccess(), "Unequip succeeds");
        assertEquals(UnequipStatus.SUCCESS, result.status(), "Status is Success");
        assertEquals(sword, result.item(), "The item is handed back, not destroyed");
        assertEquals(EquipmentSlot.MAIN_HAND, result.requestedSlot(), "Slot is reported");
        assertFalse(equipment.isSlotOccupied(EquipmentSlot.MAIN_HAND), "Slot is now empty");
        assertFalse(equipment.isEquipped(sword.id()), "Item is no longer equipped");
        assertEquals(0, equipment.equippedCount(), "Nothing equipped");
    }

    @Test
    public void unequipEmptySlotIsRefused() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        UnequipResult result = equipment.unequip(EquipmentSlot.LEGS);

        assertFalse(result.isSuccess(), "Nothing to unequip");
        assertEquals(UnequipStatus.SLOT_EMPTY, result.status(), "Status is SlotEmpty");
        assertNull(result.item(), "No item is returned");
    }

    @Test
    public void unequipInvalidSlotIsRefused() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        equipment.equip(helmet(), EquipmentSlot.HEAD);

        // null is the only invalid slot a Java caller can pass (a Java enum has no undeclared values).
        UnequipResult result = equipment.unequip(null);

        assertEquals(UnequipStatus.INVALID_SLOT, result.status(), "Status is InvalidSlot");
        assertNull(result.requestedSlot(), "Requested slot value is reported as given");
        assertNull(result.item(), "No item is returned");
        assertEquals(1, equipment.equippedCount(), "Existing equipment is untouched");
    }

    @Test
    public void unequipTwiceSecondCallReportsEmptySlot() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        equipment.equip(helmet(), EquipmentSlot.HEAD);

        UnequipResult first = equipment.unequip(EquipmentSlot.HEAD);
        UnequipResult second = equipment.unequip(EquipmentSlot.HEAD);

        assertTrue(first.isSuccess(), "First unequip succeeds");
        assertEquals(UnequipStatus.SLOT_EMPTY, second.status(), "The item cannot be unequipped twice");
    }

    @Test
    public void slotCanBeRefilledAfterUnequip() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition old = helmet("iron_helmet");
        ItemDefinition replacement = helmet("gold_helmet");
        equipment.equip(old, EquipmentSlot.HEAD);
        equipment.unequip(EquipmentSlot.HEAD);

        EquipResult result = equipment.equip(replacement, EquipmentSlot.HEAD);

        assertTrue(result.isSuccess(), "Explicit unequip then equip replaces the item");
        assertEquals(replacement, equipment.getEquipped(EquipmentSlot.HEAD), "New item is in the slot");
        assertFalse(equipment.isEquipped(old.id()), "Old item is gone");
    }

    @Test
    public void itemCanBeReEquippedAfterUnequip() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet();
        equipment.equip(helmet, EquipmentSlot.HEAD);
        equipment.unequip(EquipmentSlot.HEAD);

        EquipResult result = equipment.equip(helmet, EquipmentSlot.HEAD);

        assertTrue(result.isSuccess(), "AlreadyEquipped no longer applies once unequipped");
    }

    // ---- multiple slots ------------------------------------------------

    @Test
    public void slotsAreIndependentOfEachOther() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition helmet = helmet();
        ItemDefinition chest = chestplate();
        ItemDefinition sword = sword();
        equipment.equip(helmet, EquipmentSlot.HEAD);
        equipment.equip(chest, EquipmentSlot.CHEST);
        equipment.equip(sword, EquipmentSlot.MAIN_HAND);

        assertEquals(3, equipment.equippedCount(), "Three items equipped");
        assertEquals(helmet, equipment.getEquipped(EquipmentSlot.HEAD), "Head holds the helmet");
        assertEquals(chest, equipment.getEquipped(EquipmentSlot.CHEST), "Chest holds the chestplate");
        assertEquals(sword, equipment.getEquipped(EquipmentSlot.MAIN_HAND), "MainHand holds the sword");
        assertFalse(equipment.isSlotOccupied(EquipmentSlot.OFF_HAND), "OffHand is untouched");

        equipment.unequip(EquipmentSlot.CHEST);

        assertEquals(2, equipment.equippedCount(), "Only the chestplate left");
        assertTrue(equipment.isEquipped(helmet.id()), "Helmet unaffected by unequipping the chestplate");
        assertTrue(equipment.isEquipped(sword.id()), "Sword unaffected by unequipping the chestplate");
    }

    @Test
    public void mainHandAndOffHandHoldDifferentItems() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        assertTrue(equipment.equip(sword(), EquipmentSlot.MAIN_HAND).isSuccess(), "Sword in main hand");
        assertTrue(equipment.equip(shield(), EquipmentSlot.OFF_HAND).isSuccess(), "Shield in off hand");
        assertEquals(2, equipment.equippedCount(), "Both hands are used");
    }

    @Test
    public void refusalInOneSlotDoesNotDisturbOtherSlots() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        equipment.equip(helmet(), EquipmentSlot.HEAD);
        equipment.equip(sword(), EquipmentSlot.MAIN_HAND);

        equipment.equip(helmet("gold_helmet"), EquipmentSlot.HEAD);
        equipment.equip(potion(), EquipmentSlot.CHEST);
        equipment.unequip(EquipmentSlot.FEET);

        assertEquals(2, equipment.equippedCount(), "Refusals changed nothing");
        assertEquals(new ItemId("iron_helmet"), equipment.getEquipped(EquipmentSlot.HEAD).id(),
                "Original helmet kept");
        assertEquals(new ItemId("iron_sword"), equipment.getEquipped(EquipmentSlot.MAIN_HAND).id(),
                "Sword kept");
    }

    // ---- read-only state -----------------------------------------------

    @Test
    public void slotsListsEverySlotInOrderIncludingEmptyOnes() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        ItemDefinition chest = chestplate();
        equipment.equip(chest, EquipmentSlot.CHEST);

        List<EquipmentSlotState> slots = equipment.slots();

        assertEquals(EquipmentSlots.ALL.size(), slots.size(), "One entry per declared slot");
        for (int i = 0; i < slots.size(); i++) {
            assertEquals(EquipmentSlots.ALL.get(i), slots.get(i).slot(), "Entries follow EquipmentSlots.ALL order");
        }

        assertTrue(slots.get(0).isEmpty(), "Head is empty");
        assertFalse(slots.get(1).isEmpty(), "Chest is filled");
        assertEquals(chest, slots.get(1).item(), "Chest snapshot holds the chestplate");
    }

    @Test
    public void snapshotCannotBeUsedToModifyEquipment() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        List<EquipmentSlotState> slots = equipment.slots();

        assertThrows(UnsupportedOperationException.class,
                () -> slots.set(0, new EquipmentSlotState(EquipmentSlot.HEAD, helmet())),
                "The returned list is read-only");

        assertEquals(0, equipment.equippedCount(), "Equipment is unchanged");
        assertFalse(equipment.isSlotOccupied(EquipmentSlot.HEAD), "Head is still empty");
    }

    @Test
    public void earlierSnapshotDoesNotChangeWhenEquipmentChanges() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        List<EquipmentSlotState> before = equipment.slots();

        equipment.equip(helmet(), EquipmentSlot.HEAD);

        assertTrue(before.get(0).isEmpty(), "The old snapshot still shows an empty Head");
        assertFalse(equipment.slots().get(0).isEmpty(), "A fresh snapshot shows the helmet");
    }

    @Test
    public void equippedItemsAreImmutableDefinitions() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        equipment.equip(helmet(), EquipmentSlot.HEAD);

        ItemDefinition item = equipment.getEquipped(EquipmentSlot.HEAD);

        // ItemDefinition is an immutable record; the only way to "change" one is to
        // build a new definition, which does not alter what is equipped.
        ItemDefinition other = new ItemDefinition(item.id(), "Renamed", item.category(), item.slot());
        assertEquals("Iron Helmet", equipment.getEquipped(EquipmentSlot.HEAD).name(),
                "Equipped item keeps its own definition");
        assertNotEquals(item, other, "A different definition is a different value");
    }

    // ---- invalid state protection ---------------------------------------

    @Test
    public void queriesRejectInvalidSlotsWithAnException() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        assertThrows(IllegalArgumentException.class,
                () -> equipment.getEquipped(null), "getEquipped rejects a null slot");
        assertThrows(IllegalArgumentException.class,
                () -> equipment.isSlotOccupied(null), "isSlotOccupied rejects a null slot");
    }

    @Test
    public void isEquippedRejectsNullId() {
        ItemEquipment equipment = new ItemEquipment(OWNER);

        assertThrows(NullPointerException.class,
                () -> equipment.isEquipped(null), "A null ItemId is a programming error");
    }

    @Test
    public void isEquippedIsFalseForUnknownIds() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        equipment.equip(helmet(), EquipmentSlot.HEAD);

        assertFalse(equipment.isEquipped(new ItemId("something_else")), "Unknown id is not equipped");
    }

    @Test
    public void everyEquippedItemAlwaysSitsInItsOwnSlotAfterAMixOfOperations() {
        ItemEquipment equipment = new ItemEquipment(OWNER);
        List<Attempt> attempts = List.of(
                new Attempt(helmet(), EquipmentSlot.HEAD),
                new Attempt(helmet(), EquipmentSlot.CHEST),               // incompatible
                new Attempt(chestplate(), EquipmentSlot.CHEST),
                new Attempt(helmet("gold_helmet"), EquipmentSlot.HEAD),   // occupied
                new Attempt(potion(), EquipmentSlot.OFF_HAND),            // not equippable
                new Attempt(shield(), null),                              // invalid slot
                new Attempt(shield(), EquipmentSlot.OFF_HAND),
                new Attempt(sword(), EquipmentSlot.MAIN_HAND));

        for (Attempt attempt : attempts) {
            equipment.equip(attempt.item(), attempt.slot());
        }

        equipment.unequip(EquipmentSlot.CHEST);
        equipment.unequip(EquipmentSlot.FEET);

        Set<ItemId> seenIds = new HashSet<>();
        for (EquipmentSlotState state : equipment.slots()) {
            if (state.item() == null) {
                continue;
            }

            assertEquals(state.slot(), state.item().slot(), "Item sits in the slot its definition names");
            assertTrue(seenIds.add(state.item().id()), "No ItemId appears twice");
        }

        assertEquals(seenIds.size(), equipment.equippedCount(), "Count matches the visible items");
        assertEquals(3, equipment.equippedCount(), "Helmet, shield and sword remain");
    }
}
