package equipment.domain;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import support.Test;
import static support.Assertions.*;

public class EquipmentSlotTest {

    @Test
    public void allContainsExactlyTheSixInitialSlots() {
        assertEquals(6, EquipmentSlots.ALL.size(), "Six initial slots");
        for (EquipmentSlot expected : List.of(
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
                EquipmentSlot.FEET, EquipmentSlot.MAIN_HAND, EquipmentSlot.OFF_HAND)) {
            assertTrue(EquipmentSlots.ALL.contains(expected), expected + " is a slot");
        }
    }

    @Test
    public void allHasNoDuplicates() {
        Set<EquipmentSlot> distinct = new HashSet<>(EquipmentSlots.ALL);

        assertEquals(EquipmentSlots.ALL.size(), distinct.size(), "No slot is listed twice");
    }

    @Test
    public void declaredSlotsAreValid() {
        for (EquipmentSlot slot : EquipmentSlots.ALL) {
            assertTrue(EquipmentSlots.isValid(slot), slot + " is valid");
        }
    }

    @Test
    public void nullSlotIsInvalid() {
        // Java enums cannot hold the C# reference's other undeclared values (default(EquipmentSlot),
        // out-of-range integer casts); null is the only invalid slot a caller can pass.
        assertFalse(EquipmentSlots.isValid(null), "null is not a declared slot");
    }

    @Test
    public void allIsInDeclarationOrder() {
        assertEquals(EquipmentSlot.HEAD, EquipmentSlots.ALL.get(0), "Head first");
        assertEquals(EquipmentSlot.OFF_HAND, EquipmentSlots.ALL.get(EquipmentSlots.ALL.size() - 1), "OffHand last");
    }
}
