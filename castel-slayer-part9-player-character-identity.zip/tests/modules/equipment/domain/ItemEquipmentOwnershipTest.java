package equipment.domain;

import character.contracts.CharacterId;
import equipment.contracts.EquipmentSnapshot;
import equipment.contracts.EquippedItemSnapshot;
import inventory.contracts.ItemId;
import java.util.List;
import support.Test;
import static support.Assertions.*;

/** Character ownership and the explicit snapshot (persistence) model of {@link ItemEquipment}. */
public class ItemEquipmentOwnershipTest {

    private static ItemDefinition sword() {
        return new ItemDefinition(new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
    }

    private static ItemDefinition helmet() {
        return new ItemDefinition(new ItemId("iron_helmet"), "Iron Helmet", ItemCategory.ARMOR, EquipmentSlot.HEAD);
    }

    // ---- ownership -----------------------------------------------------

    @Test
    public void equipmentExposesItsOwner() {
        CharacterId owner = CharacterId.random();

        assertEquals(owner, new ItemEquipment(owner).ownerId(), "The owner passed at construction is exposed");
    }

    @Test
    public void nullOwnerIsRejected() {
        assertThrows(NullPointerException.class, () -> new ItemEquipment(null),
                "Equipment without an owning character cannot exist");
    }

    @Test
    public void ownerIsUnchangedByEquipAndUnequip() {
        CharacterId owner = CharacterId.random();
        ItemEquipment equipment = new ItemEquipment(owner);

        equipment.equip(sword(), EquipmentSlot.MAIN_HAND);
        equipment.unequip(EquipmentSlot.MAIN_HAND);

        assertEquals(owner, equipment.ownerId(), "Owner is immutable: gameplay operations never change it");
    }

    @Test
    public void equipmentOfDifferentCharactersIsIndependent() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        ItemEquipment equipmentA = new ItemEquipment(a);
        ItemEquipment equipmentB = new ItemEquipment(b);

        equipmentA.equip(sword(), EquipmentSlot.MAIN_HAND);

        assertTrue(equipmentA.isEquipped(sword().id()), "A wears the sword");
        assertFalse(equipmentB.isEquipped(sword().id()), "Modifying A never touches B");
        assertEquals(a, equipmentA.ownerId(), "A is still owned by A");
        assertEquals(b, equipmentB.ownerId(), "B is still owned by B");
        // The same item id may be equipped by two different characters: ALREADY_EQUIPPED is per equipment set.
        assertTrue(equipmentB.equip(sword(), EquipmentSlot.MAIN_HAND).isSuccess(),
                "Uniqueness of an item id is per character, not global");
    }

    // ---- snapshot ------------------------------------------------------

    @Test
    public void emptyEquipmentSnapshotHasOwnerAndNoItems() {
        CharacterId owner = CharacterId.random();

        EquipmentSnapshot snapshot = new ItemEquipment(owner).toSnapshot();

        assertEquals(owner, snapshot.ownerId(), "Snapshot carries the owner");
        assertTrue(snapshot.items().isEmpty(), "Nothing is equipped");
    }

    @Test
    public void snapshotDescribesEachEquippedItemWithStableNames() {
        ItemEquipment equipment = new ItemEquipment(CharacterId.random());
        equipment.equip(sword(), EquipmentSlot.MAIN_HAND);

        List<EquippedItemSnapshot> items = equipment.toSnapshot().items();

        assertEquals(1, items.size(), "One equipped item");
        assertEquals(new EquippedItemSnapshot(new ItemId("iron_sword"), "Iron Sword", "WEAPON", 1, "MAIN_HAND"),
                items.get(0), "Category and slot are stored by name, not ordinal or internal type");
    }

    @Test
    public void restoreRebuildsEquivalentEquipment() {
        CharacterId owner = CharacterId.random();
        ItemEquipment original = new ItemEquipment(owner);
        original.equip(sword(), EquipmentSlot.MAIN_HAND);
        original.equip(helmet(), EquipmentSlot.HEAD);

        ItemEquipment restored = ItemEquipment.fromSnapshot(original.toSnapshot());

        assertEquals(owner, restored.ownerId(), "Owner survives the round trip");
        assertEquals(original.toSnapshot(), restored.toSnapshot(), "Same equipped items");
        assertEquals(sword(), restored.getEquipped(EquipmentSlot.MAIN_HAND), "Sword restored in its slot");
        assertEquals(helmet(), restored.getEquipped(EquipmentSlot.HEAD), "Helmet restored in its slot");
        assertFalse(restored.isSlotOccupied(EquipmentSlot.CHEST), "Empty slots stay empty");
    }

    @Test
    public void restoredEquipmentIsIndependentOfTheOriginal() {
        ItemEquipment original = new ItemEquipment(CharacterId.random());
        original.equip(sword(), EquipmentSlot.MAIN_HAND);

        ItemEquipment restored = ItemEquipment.fromSnapshot(original.toSnapshot());
        restored.unequip(EquipmentSlot.MAIN_HAND);

        assertTrue(original.isEquipped(sword().id()), "Changing the restored copy never changes the original");
        assertFalse(restored.isEquipped(sword().id()), "The restored copy changed");
    }

    @Test
    public void restoreRejectsUnknownCategoryAndSlotNames() {
        CharacterId owner = CharacterId.random();
        assertThrows(IllegalArgumentException.class, () -> ItemEquipment.fromSnapshot(new EquipmentSnapshot(owner,
                List.of(new EquippedItemSnapshot(new ItemId("x"), "X", "NOT_A_CATEGORY", 1, "HEAD")))),
                "An unknown category name is corrupt data");
        assertThrows(IllegalArgumentException.class, () -> ItemEquipment.fromSnapshot(new EquipmentSnapshot(owner,
                List.of(new EquippedItemSnapshot(new ItemId("x"), "X", "ARMOR", 1, "TAIL")))),
                "An unknown slot name is corrupt data");
    }

    @Test
    public void restoreRejectsSameItemEquippedTwice() {
        CharacterId owner = CharacterId.random();
        EquipmentSnapshot corrupt = new EquipmentSnapshot(owner, List.of(
                new EquippedItemSnapshot(new ItemId("ring"), "Ring", "ARMOR", 1, "HEAD"),
                new EquippedItemSnapshot(new ItemId("ring"), "Ring", "ARMOR", 1, "CHEST")));

        assertThrows(IllegalArgumentException.class, () -> ItemEquipment.fromSnapshot(corrupt),
                "An item id can be equipped at most once; the invariant is re-checked on restore");
    }

    @Test
    public void restoreRejectsInvalidDefinitions() {
        CharacterId owner = CharacterId.random();
        assertThrows(IllegalArgumentException.class, () -> ItemEquipment.fromSnapshot(new EquipmentSnapshot(owner,
                List.of(new EquippedItemSnapshot(new ItemId("stack"), "Stack", "ARMOR", 5, "HEAD")))),
                "An equippable item must have stack size 1 — ItemDefinition re-validates on restore");
    }

    // ---- snapshot record validation ------------------------------------

    @Test
    public void snapshotRejectsNullOwnerAndDuplicateSlots() {
        assertThrows(NullPointerException.class, () -> new EquipmentSnapshot(null, List.of()), "Owner is mandatory");
        assertThrows(IllegalArgumentException.class, () -> new EquipmentSnapshot(CharacterId.random(), List.of(
                new EquippedItemSnapshot(new ItemId("a"), "A", "ARMOR", 1, "HEAD"),
                new EquippedItemSnapshot(new ItemId("b"), "B", "ARMOR", 1, "HEAD"))),
                "One slot holds at most one item");
    }

    @Test
    public void snapshotIsNormalisedToSlotNameOrder() {
        EquippedItemSnapshot head = new EquippedItemSnapshot(new ItemId("h"), "H", "ARMOR", 1, "HEAD");
        EquippedItemSnapshot hand = new EquippedItemSnapshot(new ItemId("s"), "S", "WEAPON", 1, "MAIN_HAND");
        CharacterId owner = CharacterId.random();

        assertEquals(new EquipmentSnapshot(owner, List.of(head, hand)),
                new EquipmentSnapshot(owner, List.of(hand, head)),
                "Equal contents give equal snapshots regardless of input order");
    }
}
