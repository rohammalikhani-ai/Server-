package equipment.domain;

import inventory.contracts.ItemId;
import support.Test;
import static support.Assertions.*;

public class ItemDefinitionTest {

    @Test
    public void validNonEquippableDefinitionIsCreated() {
        ItemDefinition def = new ItemDefinition(
                new ItemId("health_potion"), "Health Potion", ItemCategory.CONSUMABLE, 20);

        assertEquals(new ItemId("health_potion"), def.id(), "Id is kept");
        assertEquals("Health Potion", def.name(), "Name is kept");
        assertEquals(ItemCategory.CONSUMABLE, def.category(), "Category is kept");
        assertEquals(20, def.maxStackSize(), "MaxStackSize is kept");
        assertFalse(def.isEquippable(), "No slot means not equippable");
        assertNull(def.slot(), "No slot is kept as null");
    }

    @Test
    public void validEquippableDefinitionIsCreated() {
        ItemDefinition def = new ItemDefinition(
                new ItemId("iron_helmet"), "Iron Helmet", ItemCategory.ARMOR, EquipmentSlot.HEAD);

        assertTrue(def.isEquippable(), "A definition with a slot is equippable");
        assertEquals(EquipmentSlot.HEAD, def.slot(), "Slot is kept");
        assertEquals(1, def.maxStackSize(), "MaxStackSize defaults to 1");
    }

    @Test
    public void nonEquippableItemDefaultsToStackSizeOne() {
        ItemDefinition def = new ItemDefinition(new ItemId("key"), "Rusty Key", ItemCategory.MISCELLANEOUS);

        assertEquals(1, def.maxStackSize(), "MaxStackSize defaults to 1");
        assertFalse(def.isEquippable(), "Default is not equippable");
    }

    @Test
    public void everyDeclaredSlotCanBeUsedByADefinition() {
        for (EquipmentSlot slot : EquipmentSlots.ALL) {
            ItemDefinition def = new ItemDefinition(
                    new ItemId("thing_" + slot.name()), "Thing", ItemCategory.ARMOR, slot);

            assertEquals(slot, def.slot(), "Slot " + slot + " is accepted");
        }
    }

    @Test
    public void nullIdIsRejected() {
        assertThrows(NullPointerException.class,
                () -> new ItemDefinition(null, "Name", ItemCategory.MATERIAL),
                "A definition needs an id");
    }

    @Test
    public void nullNameIsRejected() {
        assertThrows(NullPointerException.class,
                () -> new ItemDefinition(new ItemId("a"), null, ItemCategory.MATERIAL),
                "A definition needs a name");
    }

    @Test
    public void blankNameIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new ItemDefinition(new ItemId("a"), "", ItemCategory.MATERIAL),
                "Empty name is invalid");
        assertThrows(IllegalArgumentException.class,
                () -> new ItemDefinition(new ItemId("a"), "   ", ItemCategory.MATERIAL),
                "Whitespace name is invalid");
    }

    @Test
    public void nullCategoryIsRejected() {
        // Java enums cannot hold the C# reference's other undeclared values (default(ItemCategory),
        // out-of-range integer casts); null is the only invalid category a caller can pass.
        assertThrows(IllegalArgumentException.class,
                () -> new ItemDefinition(new ItemId("a"), "Name", null),
                "null is not a declared category");
    }

    @Test
    public void zeroOrNegativeMaxStackSizeIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new ItemDefinition(new ItemId("a"), "Name", ItemCategory.MATERIAL, 0),
                "MaxStackSize 0 is invalid");
        assertThrows(IllegalArgumentException.class,
                () -> new ItemDefinition(new ItemId("a"), "Name", ItemCategory.MATERIAL, -5),
                "Negative MaxStackSize is invalid");
    }

    @Test
    public void equippableItemMustNotBeStackable() {
        assertThrows(IllegalArgumentException.class,
                () -> new ItemDefinition(new ItemId("a"), "Name", ItemCategory.ARMOR, 5, EquipmentSlot.CHEST),
                "An equippable item with MaxStackSize > 1 is invalid");
    }

    @Test
    public void definitionsWithSameValuesAreEqual() {
        ItemDefinition a = new ItemDefinition(
                new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
        ItemDefinition b = new ItemDefinition(
                new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.MAIN_HAND);
        ItemDefinition c = new ItemDefinition(
                new ItemId("iron_sword"), "Iron Sword", ItemCategory.WEAPON, EquipmentSlot.OFF_HAND);

        assertEquals(a, b, "Value equality holds for identical definitions");
        assertNotEquals(a, c, "A different slot makes a different definition");
    }
}
