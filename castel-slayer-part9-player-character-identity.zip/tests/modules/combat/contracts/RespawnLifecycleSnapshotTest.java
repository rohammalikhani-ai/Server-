package combat.contracts;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;
import java.util.Optional;

public class RespawnLifecycleSnapshotTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final Location LOC = new Location(WorldId.of("overworld"), 1, 2, 3);
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void carriesItsFields() {
        RespawnLifecycleSnapshot s = new RespawnLifecycleSnapshot(1, 7, ENTITY, "RESPAWN_DECIDED", Optional.of(LOC), T);
        assertEquals(1, s.schemaVersion(), "schema");
        assertEquals(7L, s.revision(), "revision");
        assertEquals(ENTITY, s.entity(), "entity");
        assertEquals("RESPAWN_DECIDED", s.status(), "status");
        assertEquals(Optional.of(LOC), s.destination(), "destination");
        assertEquals(T, s.savedAt(), "savedAt");
    }

    @Test
    public void rejectsNullsSoMissingIdentityCannotExist() {
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleSnapshot(1, 1, null, "ALIVE", Optional.empty(), T), "entity");
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleSnapshot(1, 1, ENTITY, null, Optional.empty(), T), "status");
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleSnapshot(1, 1, ENTITY, "ALIVE", null, T), "destination optional");
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleSnapshot(1, 1, ENTITY, "ALIVE", Optional.empty(), null), "savedAt");
    }

    @Test
    public void onlyStructureIsCheckedHereContentIsCheckedAtRecovery() {
        RespawnLifecycleSnapshot odd = new RespawnLifecycleSnapshot(99, -5, ENTITY, "", Optional.empty(), T);
        assertEquals(99, odd.schemaVersion(), "a bad snapshot stays representable so it can be diagnosed");
    }

    @Test
    public void isAnImmutablePlainDataRecord() {
        assertTrue(RespawnLifecycleSnapshot.class.isRecord(), "record");
        for (var component : RespawnLifecycleSnapshot.class.getRecordComponents()) {
            String name = component.getType().getName();
            assertTrue(name.startsWith("java.") || name.equals("int") || name.equals("long")
                            || name.startsWith("core.domain."),
                    "only JDK/core.domain types, no internal or platform type: " + name);
        }
    }

    @Test
    public void equalByValueAndCurrentSchemaIsOne() {
        assertEquals(new RespawnLifecycleSnapshot(1, 1, ENTITY, "ALIVE", Optional.empty(), T),
                new RespawnLifecycleSnapshot(1, 1, ENTITY, "ALIVE", Optional.empty(), T), "value equality");
        assertEquals(1, RespawnLifecycleSnapshot.CURRENT_SCHEMA_VERSION, "current schema");
    }
}
