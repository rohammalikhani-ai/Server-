package combat.contracts;

import support.Test;
import static support.Assertions.*;

import core.domain.Location;
import core.domain.WorldId;

public class RespawnPointTest {

    private static final Location SPAWN = new Location(WorldId.of("overworld"), 10.5, 64, -3.25, 90f, 0f);

    @Test
    public void wrapsAValidLocation() {
        RespawnPoint point = new RespawnPoint(SPAWN);
        assertEquals(SPAWN, point.location(), "the location is carried unchanged");
    }

    @Test
    public void rejectsNullLocation() {
        assertThrows(NullPointerException.class, () -> new RespawnPoint(null), "location is required");
    }

    @Test
    public void invalidDestinationsCannotBeConstructed() {
        // An invalid destination is unrepresentable: Location rejects it before a RespawnPoint exists.
        WorldId world = WorldId.of("overworld");
        assertThrows(IllegalArgumentException.class, () -> new RespawnPoint(new Location(world, Double.NaN, 0, 0)),
                "NaN x rejected");
        assertThrows(IllegalArgumentException.class,
                () -> new RespawnPoint(new Location(world, 0, Double.POSITIVE_INFINITY, 0)), "infinite y rejected");
        assertThrows(IllegalArgumentException.class,
                () -> new RespawnPoint(new Location(world, 0, 0, 0, Float.NaN, 0f)), "NaN yaw rejected");
        assertThrows(IllegalArgumentException.class, () -> new RespawnPoint(new Location(WorldId.of("  "), 0, 0, 0)),
                "blank world rejected");
        assertThrows(NullPointerException.class, () -> new RespawnPoint(new Location(null, 0, 0, 0)),
                "missing world rejected");
    }

    @Test
    public void equalityIsByValue() {
        assertEquals(new RespawnPoint(SPAWN), new RespawnPoint(
                new Location(WorldId.of("overworld"), 10.5, 64, -3.25, 90f, 0f)), "same location, equal point");
        assertNotEquals(new RespawnPoint(SPAWN), new RespawnPoint(new Location(WorldId.of("nether"), 10.5, 64, -3.25)),
                "different location, different point");
    }

    @Test
    public void carriesOnlyANeutralCoreLocationType() {
        assertEquals(1, RespawnPoint.class.getRecordComponents().length, "exactly one component");
        assertEquals(Location.class, RespawnPoint.class.getRecordComponents()[0].getType(),
                "the component is core.domain.Location — no Minecraft/Bukkit type");
    }
}
