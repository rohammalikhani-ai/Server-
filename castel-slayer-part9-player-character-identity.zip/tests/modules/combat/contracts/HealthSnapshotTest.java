package combat.contracts;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityRef;
import core.domain.PlayerId;
import java.time.Instant;

public class HealthSnapshotTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void carriesItsFields() {
        HealthSnapshot s = new HealthSnapshot(1, 7, ENTITY, 12.5, 20.0, T);
        assertEquals(1, s.schemaVersion(), "schema");
        assertEquals(7L, s.revision(), "revision");
        assertEquals(ENTITY, s.entity(), "entity");
        assertEquals(12.5, s.current(), "current");
        assertEquals(20.0, s.max(), "max");
        assertEquals(T, s.savedAt(), "savedAt");
    }

    @Test
    public void rejectsNullsSoMissingIdentityCannotExist() {
        assertThrows(NullPointerException.class, () -> new HealthSnapshot(1, 1, null, 1, 1, T), "entity");
        assertThrows(NullPointerException.class, () -> new HealthSnapshot(1, 1, ENTITY, 1, 1, null), "savedAt");
    }

    @Test
    public void onlyStructureIsCheckedHereContentIsCheckedAtRecovery() {
        HealthSnapshot odd = new HealthSnapshot(99, -5, ENTITY, -50, -1, T);
        assertEquals(99, odd.schemaVersion(), "a bad snapshot stays representable so it can be diagnosed");
        assertEquals(-50.0, odd.current(), "even an invalid current is representable");
    }

    @Test
    public void isAnImmutablePlainDataRecord() {
        assertTrue(HealthSnapshot.class.isRecord(), "record");
        for (var component : HealthSnapshot.class.getRecordComponents()) {
            String name = component.getType().getName();
            assertTrue(name.startsWith("java.") || name.equals("int") || name.equals("long")
                            || name.equals("double") || name.startsWith("core.domain."),
                    "only JDK/core.domain types, no internal or platform type: " + name);
        }
    }

    @Test
    public void equalByValueAndCurrentSchemaIsOne() {
        assertEquals(new HealthSnapshot(1, 1, ENTITY, 20, 20, T), new HealthSnapshot(1, 1, ENTITY, 20, 20, T),
                "value equality");
        assertEquals(1, HealthSnapshot.CURRENT_SCHEMA_VERSION, "current schema");
    }
}
