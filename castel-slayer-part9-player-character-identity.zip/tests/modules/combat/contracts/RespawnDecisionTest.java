package combat.contracts;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;

public class RespawnDecisionTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 1, 2, 3));
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void grantedCarriesEntityDestinationAndTime() {
        RespawnDecision.Granted granted = new RespawnDecision.Granted(ENTITY, POINT, T);
        assertEquals(ENTITY, granted.entity(), "entity");
        assertEquals(POINT, granted.destination(), "destination");
        assertEquals(T, granted.decidedAt(), "time");
    }

    @Test
    public void deniedCarriesEntityReasonAndTime() {
        RespawnDecision.Denied denied = new RespawnDecision.Denied(ENTITY, RespawnDenialReason.NO_RESPAWN_POINT, T);
        assertEquals(ENTITY, denied.entity(), "entity");
        assertEquals(RespawnDenialReason.NO_RESPAWN_POINT, denied.reason(), "reason");
        assertEquals(T, denied.decidedAt(), "time");
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> new RespawnDecision.Granted(null, POINT, T), "granted entity");
        assertThrows(NullPointerException.class, () -> new RespawnDecision.Granted(ENTITY, null, T),
                "granted destination is required — a grant without one is unrepresentable");
        assertThrows(NullPointerException.class, () -> new RespawnDecision.Granted(ENTITY, POINT, null), "granted time");
        assertThrows(NullPointerException.class, () -> new RespawnDecision.Denied(null, RespawnDenialReason.ENTITY_ALIVE, T),
                "denied entity");
        assertThrows(NullPointerException.class, () -> new RespawnDecision.Denied(ENTITY, null, T),
                "denied reason is required");
        assertThrows(NullPointerException.class, () -> new RespawnDecision.Denied(ENTITY, RespawnDenialReason.ENTITY_ALIVE, null),
                "denied time");
    }

    @Test
    public void isExhaustivelySwitchableAndValueEqual() {
        RespawnDecision decision = new RespawnDecision.Granted(ENTITY, POINT, T);
        String label = switch (decision) {
            case RespawnDecision.Granted g -> "granted";
            case RespawnDecision.Denied d -> "denied";
        };
        assertEquals("granted", label, "sealed: exactly Granted or Denied");
        assertEquals(new RespawnDecision.Granted(ENTITY, POINT, T), decision, "value equality");
        assertNotEquals(new RespawnDecision.Denied(ENTITY, RespawnDenialReason.ENTITY_ALIVE, T), decision,
                "a denial never equals a grant");
    }
}
