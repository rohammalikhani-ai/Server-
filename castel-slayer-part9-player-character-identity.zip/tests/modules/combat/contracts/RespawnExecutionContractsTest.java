package combat.contracts;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;

public class RespawnExecutionContractsTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 1, 2, 3));
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void requestCarriesItsFieldsAndRejectsNulls() {
        RespawnExecutionRequest request = new RespawnExecutionRequest(ENTITY, POINT, T);
        assertEquals(ENTITY, request.entity(), "entity");
        assertEquals(POINT, request.destination(), "destination");
        assertEquals(T, request.requestedAt(), "time");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionRequest(null, POINT, T), "entity");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionRequest(ENTITY, null, T), "destination");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionRequest(ENTITY, POINT, null), "time");
    }

    @Test
    public void succeededRejectsNulls() {
        assertEquals(POINT, new RespawnExecutionResult.Succeeded(ENTITY, POINT, T).destination(), "destination");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionResult.Succeeded(null, POINT, T), "entity");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionResult.Succeeded(ENTITY, null, T), "destination");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionResult.Succeeded(ENTITY, POINT, null), "time");
    }

    @Test
    public void failedRequiresAMeaningfulReason() {
        assertEquals("chunk unavailable", new RespawnExecutionResult.Failed(ENTITY, "chunk unavailable", T).reason(), "reason");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionResult.Failed(null, "x", T), "entity");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionResult.Failed(ENTITY, null, T), "reason");
        assertThrows(NullPointerException.class, () -> new RespawnExecutionResult.Failed(ENTITY, "x", null), "time");
        assertThrows(IllegalArgumentException.class, () -> new RespawnExecutionResult.Failed(ENTITY, "  ", T),
                "a failure must say why");
    }

    @Test
    public void resultIsSealedAndValueEqual() {
        RespawnExecutionResult result = new RespawnExecutionResult.Failed(ENTITY, "gone", T);
        String label = switch (result) {
            case RespawnExecutionResult.Succeeded s -> "ok";
            case RespawnExecutionResult.Failed f -> "failed";
        };
        assertEquals("failed", label, "exactly two shapes");
        assertEquals(new RespawnExecutionResult.Failed(ENTITY, "gone", T), result, "value equality");
        assertNotEquals(new RespawnExecutionResult.Succeeded(ENTITY, POINT, T), result, "success is never a failure");
    }

    @Test
    public void boundaryTypesContainNoPlatformTypes() {
        for (Class<?> type : new Class<?>[] {RespawnExecutionRequest.class, RespawnExecutionResult.Succeeded.class,
                RespawnExecutionResult.Failed.class}) {
            for (var component : type.getRecordComponents()) {
                String name = component.getType().getName();
                assertFalse(name.startsWith("org.bukkit") || name.startsWith("io.papermc") || name.startsWith("net.minecraft"),
                        type.getSimpleName() + "." + component.getName() + " must be platform-neutral");
            }
        }
    }
}
