package combat.contracts;

import support.Test;
import static support.Assertions.*;

import combat.events.EntityDied;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;
import java.time.Instant;

public class RespawnRequestTest {

    private static final EntityRef PLAYER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef NPC = EntityRef.of(EntityKind.NPC, EntityId.random());
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void rejectsNulls() {
        assertThrows(NullPointerException.class, () -> new RespawnRequest(null, T), "entity required");
        assertThrows(NullPointerException.class, () -> new RespawnRequest(PLAYER, null), "requestedAt required");
        assertThrows(NullPointerException.class, () -> RespawnRequest.from(null), "died required");
    }

    @Test
    public void fromEntityDiedUsesTargetAndTimestamp() {
        RespawnRequest request = RespawnRequest.from(new EntityDied(PLAYER, NPC, T));
        assertEquals(PLAYER, request.entity(), "the request is for the entity that died, not the killer");
        assertEquals(T, request.requestedAt(), "the request is stamped with the time of death");
    }

    @Test
    public void nonPlayerDeathProducesARequestToo() {
        RespawnRequest request = RespawnRequest.from(new EntityDied(NPC, PLAYER, T));
        assertEquals(NPC, request.entity(), "no player assumption");
    }

    @Test
    public void equalInputsGiveEqualRequests() {
        assertEquals(RespawnRequest.from(new EntityDied(PLAYER, NPC, T)),
                RespawnRequest.from(new EntityDied(PLAYER, NPC, T)), "deterministic");
    }
}
