package combat.events;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;
import core.events.GameEvent;
import java.time.Instant;

public class EntityDiedTest {

    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());
    private static final EntityRef SOURCE = EntityRef.ofPlayer(PlayerId.random());

    @Test
    public void isAGameEvent() {
        EntityDied event = new EntityDied(TARGET, SOURCE, Instant.now());
        assertTrue(event instanceof GameEvent, "EntityDied must implement GameEvent");
    }

    @Test
    public void exposesTargetAndSource() {
        EntityDied event = new EntityDied(TARGET, SOURCE, Instant.now());
        assertEquals(TARGET, event.target(), "target is the entity that died");
        assertEquals(SOURCE, event.source(), "source is the entity that dealt the killing damage");
    }

    @Test
    public void rejectsNullTarget() {
        assertThrows(NullPointerException.class,
                () -> new EntityDied(null, SOURCE, Instant.now()),
                "target is required");
    }

    @Test
    public void rejectsNullSource() {
        assertThrows(NullPointerException.class,
                () -> new EntityDied(TARGET, null, Instant.now()),
                "source is required");
    }

    @Test
    public void rejectsNullOccurredAt() {
        assertThrows(NullPointerException.class,
                () -> new EntityDied(TARGET, SOURCE, null),
                "occurredAt is required");
    }

    @Test
    public void twoEventsWithEqualFieldsAreEqual() {
        Instant when = Instant.parse("2026-01-01T00:00:00Z");
        EntityDied first = new EntityDied(TARGET, SOURCE, when);
        EntityDied second = new EntityDied(TARGET, SOURCE, when);
        assertEquals(first, second, "EntityDied is a value — equal fields mean equal events");
    }
}
