package combat.events;

import support.Test;
import static support.Assertions.*;

import combat.contracts.RespawnPoint;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.events.GameEvent;
import java.time.Instant;

public class EntityRespawnedTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 1, 2, 3));
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    public void carriesEntityDestinationAndTime() {
        EntityRespawned event = new EntityRespawned(ENTITY, POINT, T);
        assertEquals(ENTITY, event.entity(), "entity");
        assertEquals(POINT, event.destination(), "destination");
        assertEquals(T, event.occurredAt(), "time");
    }

    @Test
    public void isAGameEvent() {
        GameEvent event = new EntityRespawned(ENTITY, POINT, T);
        assertEquals(T, event.occurredAt(), "usable through the shared GameEvent type");
    }

    @Test
    public void rejectsNulls() {
        assertThrows(NullPointerException.class, () -> new EntityRespawned(null, POINT, T), "entity");
        assertThrows(NullPointerException.class, () -> new EntityRespawned(ENTITY, null, T), "destination");
        assertThrows(NullPointerException.class, () -> new EntityRespawned(ENTITY, POINT, null), "time");
    }

    @Test
    public void isImmutableValueData() {
        assertTrue(EntityRespawned.class.isRecord(), "a record: no behaviour, no mutable fields");
        assertEquals(new EntityRespawned(ENTITY, POINT, T), new EntityRespawned(ENTITY, POINT, T), "value equality");
    }
}
