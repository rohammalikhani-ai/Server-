package combat.domain;

import support.Test;
import static support.Assertions.*;

public class DamageTypeTest {

    @Test
    public void hasExactlyTheEightInitialDamageTypes() {
        DamageType[] values = DamageType.values();
        assertEquals(8, values.length, "initial damage type set size");

        assertNotNull(DamageType.valueOf("PHYSICAL"), "PHYSICAL");
        assertNotNull(DamageType.valueOf("MAGICAL"), "MAGICAL");
        assertNotNull(DamageType.valueOf("FIRE"), "FIRE");
        assertNotNull(DamageType.valueOf("FROST"), "FROST");
        assertNotNull(DamageType.valueOf("LIGHTNING"), "LIGHTNING");
        assertNotNull(DamageType.valueOf("POISON"), "POISON");
        assertNotNull(DamageType.valueOf("SHADOW"), "SHADOW");
        assertNotNull(DamageType.valueOf("HOLY"), "HOLY");
    }
}
