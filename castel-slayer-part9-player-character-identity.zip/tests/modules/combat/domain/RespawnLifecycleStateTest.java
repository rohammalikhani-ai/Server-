package combat.domain;

import support.Test;
import static support.Assertions.*;

import combat.contracts.RespawnPoint;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.util.Optional;

public class RespawnLifecycleStateTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 1, 64, 1));

    private static RespawnLifecycleState atStatus(RespawnLifecycleStatus status) {
        RespawnLifecycleState s = RespawnLifecycleState.alive(ENTITY);
        if (status == RespawnLifecycleStatus.ALIVE) return s;
        s = s.died();
        if (status == RespawnLifecycleStatus.DEAD) return s;
        s = s.eligible();
        if (status == RespawnLifecycleStatus.RESPAWN_ELIGIBLE) return s;
        s = s.decided(POINT);
        if (status == RespawnLifecycleStatus.RESPAWN_DECIDED) return s;
        return s.executionRequested();
    }

    @Test
    public void startsAliveWithNoDestination() {
        RespawnLifecycleState s = RespawnLifecycleState.alive(ENTITY);
        assertEquals(RespawnLifecycleStatus.ALIVE, s.status(), "alive");
        assertTrue(s.isAlive(), "isAlive");
        assertTrue(s.destination().isEmpty(), "no destination");
        assertEquals(ENTITY, s.entity(), "entity");
    }

    @Test
    public void walksTheWholeForwardPath() {
        RespawnLifecycleState s = RespawnLifecycleState.alive(ENTITY);
        s = s.died();
        assertEquals(RespawnLifecycleStatus.DEAD, s.status(), "dead");
        s = s.eligible();
        assertEquals(RespawnLifecycleStatus.RESPAWN_ELIGIBLE, s.status(), "eligible");
        s = s.decided(POINT);
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED, s.status(), "decided");
        assertEquals(Optional.of(POINT), s.destination(), "destination recorded");
        s = s.executionRequested();
        assertEquals(RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED, s.status(), "requested");
        assertEquals(Optional.of(POINT), s.destination(), "destination kept while requested");
        s = s.respawned();
        assertEquals(RespawnLifecycleState.alive(ENTITY), s, "back to a clean ALIVE, destination dropped");
    }

    @Test
    public void failedExecutionReturnsToTheExactPreRequestState() {
        RespawnLifecycleState decided = atStatus(RespawnLifecycleStatus.RESPAWN_DECIDED);
        assertEquals(decided, decided.executionRequested().executionFailed(),
                "request then failure leaves state equal to before the request");
    }

    @Test
    public void transitionsNeverModifyTheReceiver() {
        RespawnLifecycleState alive = RespawnLifecycleState.alive(ENTITY);
        RespawnLifecycleState dead = alive.died();
        assertEquals(RespawnLifecycleStatus.ALIVE, alive.status(), "the original is unchanged");
        assertTrue(dead != alive, "a new instance was returned");
    }

    @Test
    public void everyTransitionRejectsEveryWrongStartingStatus() {
        for (RespawnLifecycleStatus status : RespawnLifecycleStatus.values()) {
            RespawnLifecycleState s = atStatus(status);
            if (status != RespawnLifecycleStatus.ALIVE) {
                assertThrows(IllegalStateException.class, s::died, "died from " + status);
            }
            if (status != RespawnLifecycleStatus.DEAD) {
                assertThrows(IllegalStateException.class, s::eligible, "eligible from " + status);
            }
            if (status != RespawnLifecycleStatus.RESPAWN_ELIGIBLE) {
                assertThrows(IllegalStateException.class, () -> s.decided(POINT), "decided from " + status);
            }
            if (status != RespawnLifecycleStatus.RESPAWN_DECIDED) {
                assertThrows(IllegalStateException.class, s::executionRequested, "requested from " + status);
            }
            if (status != RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED) {
                assertThrows(IllegalStateException.class, s::respawned, "respawned from " + status);
                assertThrows(IllegalStateException.class, s::executionFailed, "failed from " + status);
            }
        }
    }

    @Test
    public void aLivingEntityCannotBeRespawnedAsIfDead() {
        RespawnLifecycleState alive = RespawnLifecycleState.alive(ENTITY);
        assertThrows(IllegalStateException.class, alive::eligible, "no eligibility for the living");
        assertThrows(IllegalStateException.class, () -> alive.decided(POINT), "no destination for the living");
        assertThrows(IllegalStateException.class, alive::respawned, "no respawn for the living");
    }

    @Test
    public void destinationInvariantHoldsForEveryStatus() {
        for (RespawnLifecycleStatus status : RespawnLifecycleStatus.values()) {
            RespawnLifecycleState s = atStatus(status);
            assertEquals(status.carriesDestination(), s.destination().isPresent(),
                    "destination present exactly when the status carries one: " + status);
            if (status.carriesDestination()) {
                assertThrows(IllegalArgumentException.class,
                        () -> new RespawnLifecycleState(ENTITY, status, Optional.empty()), status + " needs a destination");
            } else {
                assertThrows(IllegalArgumentException.class,
                        () -> new RespawnLifecycleState(ENTITY, status, Optional.of(POINT)), status + " forbids one");
            }
        }
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> RespawnLifecycleState.alive(null), "entity");
        assertThrows(NullPointerException.class,
                () -> new RespawnLifecycleState(ENTITY, null, Optional.empty()), "status");
        assertThrows(NullPointerException.class,
                () -> new RespawnLifecycleState(ENTITY, RespawnLifecycleStatus.ALIVE, null), "destination optional");
        assertThrows(NullPointerException.class, () -> atStatus(RespawnLifecycleStatus.RESPAWN_ELIGIBLE).decided(null),
                "a decided state with no point is not constructible");
    }

    @Test
    public void worksForNonPlayerEntities() {
        EntityRef npc = EntityRef.of(EntityKind.NPC, EntityId.random());
        assertEquals(RespawnLifecycleStatus.DEAD, RespawnLifecycleState.alive(npc).died().status(), "no player assumption");
    }

    @Test
    public void valueEquality() {
        assertEquals(atStatus(RespawnLifecycleStatus.RESPAWN_DECIDED), atStatus(RespawnLifecycleStatus.RESPAWN_DECIDED),
                "equal by value");
        assertNotEquals(atStatus(RespawnLifecycleStatus.DEAD), atStatus(RespawnLifecycleStatus.ALIVE), "status matters");
    }
}
