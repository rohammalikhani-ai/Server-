package combat.domain;

import support.Test;
import static support.Assertions.*;

import combat.contracts.RespawnDenialReason;
import core.domain.EntityRef;
import core.domain.PlayerId;
import java.util.Optional;

public class RespawnEligibilityTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());

    @Test
    public void eligibleHasNoDenial() {
        RespawnEligibility e = RespawnEligibility.eligible(ENTITY);
        assertTrue(e.isEligible(), "eligible");
        assertTrue(e.denialReason().isEmpty(), "no reason");
    }

    @Test
    public void ineligibleCarriesExactlyItsReason() {
        RespawnEligibility e = RespawnEligibility.ineligible(ENTITY, RespawnDenialReason.ENTITY_ALIVE);
        assertFalse(e.isEligible(), "not eligible");
        assertEquals(Optional.of(RespawnDenialReason.ENTITY_ALIVE), e.denialReason(), "reason");
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> RespawnEligibility.eligible(null), "entity");
        assertThrows(NullPointerException.class, () -> RespawnEligibility.ineligible(ENTITY, null), "reason");
        assertThrows(NullPointerException.class, () -> new RespawnEligibility(ENTITY, null), "optional itself");
    }
}
