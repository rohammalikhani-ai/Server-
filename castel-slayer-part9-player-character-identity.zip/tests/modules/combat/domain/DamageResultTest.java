package combat.domain;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;

public class DamageResultTest {

    private static final EntityRef ATTACKER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());

    @Test
    public void preservesPositiveAmountAndFields() {
        DamageResult result = new DamageResult(ATTACKER, TARGET, DamageType.HOLY, 30);
        assertEquals(ATTACKER, result.source(), "source");
        assertEquals(TARGET, result.target(), "target");
        assertEquals(DamageType.HOLY, result.type(), "type");
        assertEquals(30.0, result.amount(), "amount");
    }

    @Test
    public void allowsZeroAmount() {
        DamageResult result = new DamageResult(ATTACKER, TARGET, DamageType.POISON, 0);
        assertEquals(0.0, result.amount(), "zero amount must be allowed");
    }

    @Test
    public void clampsNegativeAmountToZero() {
        // A direct negative construction models what a future subtractive formula
        // (resistance, damage reduction) could otherwise produce — the result itself
        // must never expose a negative amount, regardless of how it got there.
        DamageResult result = new DamageResult(ATTACKER, TARGET, DamageType.FROST, -50);
        assertEquals(0.0, result.amount(), "final damage can never be negative");
    }

    @Test
    public void rejectsNaNAmount() {
        assertThrows(IllegalArgumentException.class,
                () -> new DamageResult(ATTACKER, TARGET, DamageType.LIGHTNING, Double.NaN),
                "NaN amount must be rejected");
    }

    @Test
    public void rejectsInfiniteAmount() {
        assertThrows(IllegalArgumentException.class,
                () -> new DamageResult(ATTACKER, TARGET, DamageType.LIGHTNING, Double.NEGATIVE_INFINITY),
                "infinite amount must be rejected");
    }

    @Test
    public void rejectsNullFields() {
        assertThrows(NullPointerException.class,
                () -> new DamageResult(null, TARGET, DamageType.PHYSICAL, 1),
                "null source must be rejected");
        assertThrows(NullPointerException.class,
                () -> new DamageResult(ATTACKER, null, DamageType.PHYSICAL, 1),
                "null target must be rejected");
        assertThrows(NullPointerException.class,
                () -> new DamageResult(ATTACKER, TARGET, null, 1),
                "null type must be rejected");
    }
}
