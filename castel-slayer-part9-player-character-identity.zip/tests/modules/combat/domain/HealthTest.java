package combat.domain;

import support.Test;
import static support.Assertions.*;

import combat.services.DamageCalculator;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;

public class HealthTest {

    private static final EntityRef ATTACKER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());

    private static DamageResult damage(double amount) {
        return new DamageResult(ATTACKER, TARGET, DamageType.PHYSICAL, amount);
    }

    // --- initial HP -----------------------------------------------------------------

    @Test
    public void startsAtMaximumHpAndAlive() {
        Health health = Health.full(100);
        assertEquals(100.0, health.current(), "current HP starts at max");
        assertEquals(100.0, health.max(), "max HP");
        assertTrue(health.isAlive(), "a fresh pool is alive");
        assertFalse(health.isDead(), "a fresh pool is not dead");
    }

    // --- invalid HP values ----------------------------------------------------------

    @Test
    public void rejectsInvalidMaxHp() {
        assertThrows(IllegalArgumentException.class, () -> Health.full(0), "zero max HP");
        assertThrows(IllegalArgumentException.class, () -> Health.full(-1), "negative max HP");
        assertThrows(IllegalArgumentException.class, () -> Health.full(Double.NaN), "NaN max HP");
        assertThrows(IllegalArgumentException.class, () -> Health.full(Double.POSITIVE_INFINITY), "infinite max HP");
        assertThrows(IllegalArgumentException.class, () -> new Health(0, 0), "max HP zero via constructor");
    }

    @Test
    public void rejectsInvalidCurrentHp() {
        assertThrows(IllegalArgumentException.class, () -> new Health(-0.1, 10), "negative current HP");
        assertThrows(IllegalArgumentException.class, () -> new Health(Double.NaN, 10), "NaN current HP");
        assertThrows(IllegalArgumentException.class, () -> new Health(Double.POSITIVE_INFINITY, 10), "infinite current HP");
        assertThrows(IllegalArgumentException.class, () -> new Health(Double.NEGATIVE_INFINITY, 10), "-infinite current HP");
    }

    // --- maximum HP boundary --------------------------------------------------------

    @Test
    public void currentHpCannotExceedMaxHp() {
        assertThrows(IllegalArgumentException.class, () -> new Health(10.5, 10), "current above max");
        Health atMax = new Health(10, 10);
        assertEquals(10.0, atMax.current(), "current exactly at max is allowed");
    }

    @Test
    public void currentHpMayBeZeroAndThenTheHealthIsDead() {
        Health health = new Health(0, 10);
        assertTrue(health.isDead(), "0 HP is dead");
        assertFalse(health.isAlive(), "0 HP is not alive");
    }

    @Test
    public void negativeZeroIsNormalisedToZero() {
        assertEquals(new Health(0.0, 10), new Health(-0.0, 10), "-0.0 must equal 0.0 as a value");
        assertTrue(new Health(-0.0, 10).isDead(), "-0.0 HP is dead");
    }

    @Test
    public void damageNeverPushesCurrentAboveMax() {
        Health health = Health.full(50);
        Health after = health.apply(damage(1));
        assertTrue(after.current() <= after.max(), "current must stay <= max after damage");
        assertEquals(50.0, after.max(), "max unchanged by damage");
    }

    // --- normal / zero damage -------------------------------------------------------

    @Test
    public void normalDamageReducesCurrentHp() {
        Health after = Health.full(100).apply(damage(30));
        assertEquals(70.0, after.current(), "100 - 30");
        assertEquals(100.0, after.max(), "max unchanged");
        assertTrue(after.isAlive(), "still alive");
    }

    @Test
    public void fractionalDamageIsSupported() {
        Health after = Health.full(10).apply(damage(2.5));
        assertEquals(7.5, after.current(), "10 - 2.5");
    }

    @Test
    public void zeroDamageChangesNothing() {
        Health health = new Health(42, 100);
        Health after = health.apply(damage(0));
        assertEquals(health, after, "zero damage leaves the value equal");
        assertEquals(42.0, after.current(), "current unchanged");
        assertEquals(100.0, after.max(), "max unchanged");
        assertTrue(after.isAlive(), "still alive");
    }

    @Test
    public void zeroDamageOnFullHealthStaysFull() {
        Health after = Health.full(20).apply(damage(0));
        assertEquals(Health.full(20), after, "full stays full");
    }

    // --- lethal damage --------------------------------------------------------------

    @Test
    public void exactLethalDamageReachesZeroAndIsDead() {
        Health after = new Health(40, 100).apply(damage(40));
        assertEquals(0.0, after.current(), "40 - 40");
        assertTrue(after.isDead(), "reaching 0 means dead");
        assertFalse(after.isAlive(), "reaching 0 means not alive");
    }

    @Test
    public void overkillDamageIsFlooredAtZero() {
        Health after = new Health(10, 100).apply(damage(9999));
        assertEquals(0.0, after.current(), "HP must not go negative");
        assertTrue(after.isDead(), "overkill is dead");
        assertEquals(100.0, after.max(), "max unchanged");
    }

    @Test
    public void justBelowLethalStaysAlive() {
        Health after = Health.full(10).apply(damage(9.5));
        assertEquals(0.5, after.current(), "10 - 9.5");
        assertTrue(after.isAlive(), "0.5 HP is still alive");
    }

    // --- repeated damage / dead state -----------------------------------------------

    @Test
    public void repeatedDamageAccumulatesUntilDeadThenStaysDead() {
        Health health = Health.full(100);
        health = health.apply(damage(30));
        assertEquals(70.0, health.current(), "after 30");
        health = health.apply(damage(0));
        assertEquals(70.0, health.current(), "zero in the middle changes nothing");
        health = health.apply(damage(45));
        assertEquals(25.0, health.current(), "after 45 more");
        assertTrue(health.isAlive(), "alive at 25");
        health = health.apply(damage(25));
        assertEquals(0.0, health.current(), "exactly lethal");
        assertTrue(health.isDead(), "dead at 0");
        health = health.apply(damage(10));
        assertEquals(0.0, health.current(), "damage to the dead keeps 0 HP");
        assertTrue(health.isDead(), "dead stays dead");
    }

    @Test
    public void damageToADeadPoolReturnsAnEqualValue() {
        Health dead = new Health(0, 30);
        assertEquals(dead, dead.apply(damage(5)), "dead + damage == same dead value");
    }

    // --- immutability / determinism -------------------------------------------------

    @Test
    public void applyDoesNotModifyTheOriginal() {
        Health original = Health.full(100);
        Health after = original.apply(damage(60));
        assertEquals(100.0, original.current(), "original current unchanged");
        assertEquals(100.0, original.max(), "original max unchanged");
        assertEquals(40.0, after.current(), "new value carries the damage");
        assertNotEquals(original, after, "a real change yields a different value");
    }

    @Test
    public void sameInputAlwaysGivesSameResult() {
        Health a = new Health(80, 100).apply(damage(35));
        Health b = new Health(80, 100).apply(damage(35));
        assertEquals(a, b, "deterministic: same health + same damage -> equal result");
        assertEquals(a.isDead(), b.isDead(), "deterministic alive/dead state");
    }

    @Test
    public void equalityIsByValue() {
        assertEquals(new Health(5, 10), new Health(5, 10), "equal fields -> equal");
        assertNotEquals(new Health(5, 10), new Health(6, 10), "different current -> not equal");
        assertNotEquals(new Health(5, 10), new Health(5, 11), "different max -> not equal");
    }

    @Test
    public void rejectsNullDamage() {
        assertThrows(NullPointerException.class, () -> Health.full(10).apply(null), "null damage");
    }

    // --- integration with the existing Part 1 pipeline ------------------------------

    @Test
    public void appliesADamageResultProducedByTheDamageCalculator() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.FIRE, 35);
        DamageResult result = new DamageCalculator().calculate(request);
        Health after = Health.full(100).apply(result);
        assertEquals(65.0, after.current(), "DamageRequest -> DamageCalculator -> DamageResult -> Health");
        assertTrue(after.isAlive(), "alive after 35 of 100");
    }

    @Test
    public void damageTypeDoesNotChangeTheAppliedAmountInThisPart() {
        // No resistance/armor exists yet: only the amount matters to Health.
        Health fire = Health.full(100).apply(new DamageResult(ATTACKER, TARGET, DamageType.FIRE, 10));
        Health holy = Health.full(100).apply(new DamageResult(ATTACKER, TARGET, DamageType.HOLY, 10));
        assertEquals(fire, holy, "type-agnostic in Part 2");
    }
}
