package combat.domain;

import support.Test;
import static support.Assertions.*;

import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;

public class DamageRequestTest {

    private static final EntityRef ATTACKER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());

    @Test
    public void acceptsZeroBaseAmount() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, 0);
        assertEquals(0.0, request.baseAmount(), "zero base amount must be accepted");
    }

    @Test
    public void acceptsPositiveBaseAmount() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.FIRE, 42.5);
        assertEquals(42.5, request.baseAmount(), "positive base amount must be preserved exactly");
    }

    @Test
    public void rejectsNegativeBaseAmount() {
        assertThrows(IllegalArgumentException.class,
                () -> new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, -1),
                "negative base amount must be rejected");
    }

    @Test
    public void rejectsNaNBaseAmount() {
        assertThrows(IllegalArgumentException.class,
                () -> new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, Double.NaN),
                "NaN base amount must be rejected");
    }

    @Test
    public void rejectsInfiniteBaseAmount() {
        assertThrows(IllegalArgumentException.class,
                () -> new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, Double.POSITIVE_INFINITY),
                "infinite base amount must be rejected");
    }

    @Test
    public void rejectsNullSource() {
        assertThrows(NullPointerException.class,
                () -> new DamageRequest(null, TARGET, DamageType.PHYSICAL, 10),
                "null source must be rejected");
    }

    @Test
    public void rejectsNullTarget() {
        assertThrows(NullPointerException.class,
                () -> new DamageRequest(ATTACKER, null, DamageType.PHYSICAL, 10),
                "null target must be rejected");
    }

    @Test
    public void rejectsNullType() {
        assertThrows(NullPointerException.class,
                () -> new DamageRequest(ATTACKER, TARGET, null, 10),
                "null damage type must be rejected");
    }

    @Test
    public void acceptsLargeBoundaryBaseAmount() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.SHADOW, Double.MAX_VALUE);
        assertEquals(Double.MAX_VALUE, request.baseAmount(), "extreme finite base amount must be accepted as-is");
    }
}
