package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.RespawnLifecycleSnapshot;
import combat.contracts.RespawnPoint;
import combat.domain.RespawnLifecycleState;
import combat.domain.RespawnLifecycleStatus;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public class RespawnLifecycleSnapshotMapperTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final Location LOC = new Location(WorldId.of("overworld"), 1.5, 64, -2.5, 45f, 10f);
    private static final RespawnPoint POINT = new RespawnPoint(LOC);
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");
    private final RespawnLifecycleSnapshotMapper mapper = new RespawnLifecycleSnapshotMapper();

    private static List<RespawnLifecycleState> everyStatus() {
        RespawnLifecycleState alive = RespawnLifecycleState.alive(ENTITY);
        RespawnLifecycleState dead = alive.died();
        RespawnLifecycleState eligible = dead.eligible();
        RespawnLifecycleState decided = eligible.decided(POINT);
        return List.of(alive, dead, eligible, decided, decided.executionRequested());
    }

    private static RespawnLifecycleSnapshot snap(int schema, long revision, String status, Optional<Location> dest, Instant at) {
        return new RespawnLifecycleSnapshot(schema, revision, ENTITY, status, dest, at);
    }

    private static void assertRejected(RespawnRecoveryResult result, RespawnRecoveryFailure expected, String message) {
        assertTrue(result instanceof RespawnRecoveryResult.Rejected, message + " — should be rejected");
        assertEquals(expected, ((RespawnRecoveryResult.Rejected) result).reason(), message);
    }

    @Test
    public void everyStatusRoundTripsExactly() {
        for (RespawnLifecycleState state : everyStatus()) {
            RespawnLifecycleSnapshot snapshot = mapper.toSnapshot(state, 3, T);
            RespawnRecoveryResult result = mapper.restore(snapshot);
            assertTrue(result instanceof RespawnRecoveryResult.Recovered, "recovers " + state.status());
            RespawnRecoveryResult.Recovered recovered = (RespawnRecoveryResult.Recovered) result;
            assertEquals(state, recovered.state(), "round-trip equal for " + state.status());
            assertEquals(3L, recovered.revision(), "revision preserved");
        }
    }

    @Test
    public void snapshotUsesStatusNamesAndCurrentSchema() {
        RespawnLifecycleSnapshot s = mapper.toSnapshot(everyStatus().get(3), 1, T);
        assertEquals("RESPAWN_DECIDED", s.status(), "status stored as its name");
        assertEquals(RespawnLifecycleSnapshot.CURRENT_SCHEMA_VERSION, s.schemaVersion(), "current schema");
        assertEquals(Optional.of(LOC), s.destination(), "destination stored as a plain Location");
        assertEquals(ENTITY, s.entity(), "identity");
        assertEquals(T, s.savedAt(), "timestamp");
    }

    @Test
    public void statesWithoutADestinationStoreNone() {
        assertTrue(mapper.toSnapshot(everyStatus().get(0), 1, T).destination().isEmpty(), "alive has none");
        assertTrue(mapper.toSnapshot(everyStatus().get(2), 1, T).destination().isEmpty(), "eligible has none");
    }

    @Test
    public void recoveryIsDeterministic() {
        RespawnLifecycleSnapshot s = mapper.toSnapshot(everyStatus().get(4), 9, T);
        RespawnRecoveryResult first = mapper.restore(s);
        for (int i = 0; i < 10; i++) {
            assertEquals(first, mapper.restore(s), "same snapshot, same result");
        }
        assertEquals(first, new RespawnLifecycleSnapshotMapper().restore(s), "and from a different mapper");
    }

    @Test
    public void incompatibleSchemaVersionsAreRejected() {
        for (int schema : new int[] {0, 2, 99, -1, Integer.MAX_VALUE}) {
            assertRejected(mapper.restore(snap(schema, 1, "ALIVE", Optional.empty(), T)),
                    RespawnRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION, "schema " + schema);
        }
    }

    @Test
    public void invalidRevisionsAreRejected() {
        for (long revision : new long[] {0, -1, Long.MIN_VALUE}) {
            assertRejected(mapper.restore(snap(1, revision, "ALIVE", Optional.empty(), T)),
                    RespawnRecoveryFailure.INVALID_REVISION, "revision " + revision);
        }
    }

    @Test
    public void malformedTimestampsAreRejected() {
        assertRejected(mapper.restore(snap(1, 1, "ALIVE", Optional.empty(), Instant.parse("1969-12-31T23:59:59Z"))),
                RespawnRecoveryFailure.INVALID_TIMESTAMP, "before the epoch");
        assertRejected(mapper.restore(snap(1, 1, "ALIVE", Optional.empty(), Instant.MIN)),
                RespawnRecoveryFailure.INVALID_TIMESTAMP, "Instant.MIN");
        assertTrue(mapper.restore(snap(1, 1, "ALIVE", Optional.empty(), Instant.EPOCH)) instanceof RespawnRecoveryResult.Recovered,
                "the epoch itself is fine");
    }

    @Test
    public void unknownOrMisspelledStatusesAreRejectedNotRepaired() {
        for (String status : new String[] {"BOGUS", "", " ", "alive", "Alive", " ALIVE", "ALIVE ", "RESPAWN-DECIDED", "RESPAWNED"}) {
            assertRejected(mapper.restore(snap(1, 1, status, Optional.empty(), T)),
                    RespawnRecoveryFailure.INVALID_LIFECYCLE_STATE, "status '" + status + "'");
        }
    }

    @Test
    public void destinationMustMatchTheStatus() {
        for (RespawnLifecycleStatus status : RespawnLifecycleStatus.values()) {
            Optional<Location> wrong = status.carriesDestination() ? Optional.empty() : Optional.of(LOC);
            assertRejected(mapper.restore(snap(1, 1, status.name(), wrong, T)),
                    RespawnRecoveryFailure.INVALID_DESTINATION, "wrong destination for " + status);
        }
    }

    @Test
    public void checksRunInAFixedOrderSchemaFirst() {
        assertRejected(mapper.restore(snap(2, 0, "NOPE", Optional.of(LOC), Instant.MIN)),
                RespawnRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION, "a foreign schema is reported before anything else is interpreted");
        assertRejected(mapper.restore(snap(1, 0, "NOPE", Optional.of(LOC), Instant.MIN)),
                RespawnRecoveryFailure.INVALID_REVISION, "then revision");
    }

    @Test
    public void rejectionCarriesAReadableDetail() {
        RespawnRecoveryResult.Rejected r = (RespawnRecoveryResult.Rejected) mapper.restore(snap(1, 1, "BOGUS", Optional.empty(), T));
        assertTrue(r.detail().contains("BOGUS"), "the detail names the offending value");
    }

    @Test
    public void toSnapshotNeverWritesWhatRestoreWouldRefuse() {
        RespawnLifecycleState state = everyStatus().get(0);
        assertThrows(IllegalArgumentException.class, () -> mapper.toSnapshot(state, 0, T), "revision 0");
        assertThrows(IllegalArgumentException.class, () -> mapper.toSnapshot(state, -3, T), "negative revision");
        assertThrows(IllegalArgumentException.class, () -> mapper.toSnapshot(state, 1, Instant.parse("1960-01-01T00:00:00Z")),
                "pre-epoch timestamp");
    }

    @Test
    public void snapshotsAreDetachedFromTheStateTheyCameFrom() {
        RespawnLifecycleState decided = everyStatus().get(3);
        RespawnLifecycleSnapshot snapshot = mapper.toSnapshot(decided, 1, T);
        RespawnLifecycleState later = decided.executionRequested().respawned();
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED.name(), snapshot.status(), "later transitions cannot reach the snapshot");
        assertEquals(RespawnLifecycleStatus.ALIVE, later.status(), "and the domain moved on independently");
    }

    @Test
    public void nonPlayerIdentitiesSurviveTheTrip() {
        EntityRef npc = EntityRef.of(EntityKind.NPC, EntityId.random());
        RespawnLifecycleState state = RespawnLifecycleState.alive(npc).died();
        assertEquals(state, ((RespawnRecoveryResult.Recovered) mapper.restore(mapper.toSnapshot(state, 1, T))).state(),
                "kind and id are preserved");
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> mapper.toSnapshot(null, 1, T), "state");
        assertThrows(NullPointerException.class, () -> mapper.toSnapshot(everyStatus().get(0), 1, null), "savedAt");
        assertThrows(NullPointerException.class, () -> mapper.restore(null), "snapshot");
        assertThrows(NullPointerException.class, () -> new RespawnRecoveryResult.Recovered(null, 1), "recovered state");
        assertThrows(NullPointerException.class, () -> new RespawnRecoveryResult.Rejected(null, "x"), "rejected reason");
        assertThrows(NullPointerException.class,
                () -> new RespawnRecoveryResult.Rejected(RespawnRecoveryFailure.INVALID_REVISION, null), "rejected detail");
    }
}
