package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.domain.DamageRequest;
import combat.domain.DamageResult;
import combat.domain.DamageType;
import combat.domain.Health;
import combat.events.EntityDied;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

/**
 * Covers the Gameplay Part 3 orchestration seam:
 * {@code DamageResult + Health -> DamageApplicationService.apply -> new Health}, plus the
 * complete path {@code DamageRequest -> DamageCalculator -> DamageResult -> DamageApplicationService -> Health}.
 */
public class DamageApplicationServiceTest {

    private static final EntityRef ATTACKER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());

    private final DamageApplicationService service = new DamageApplicationService();

    private static DamageResult damage(double amount) {
        return new DamageResult(ATTACKER, TARGET, DamageType.PHYSICAL, amount);
    }

    // --- normal damage application ---------------------------------------------------

    @Test
    public void appliesNormalDamageToHealth() {
        Health before = Health.full(100);
        Health after = service.apply(damage(30), before);
        assertEquals(70.0, after.current(), "current HP reduced by the damage amount");
        assertEquals(100.0, after.max(), "max HP unchanged");
        assertTrue(after.isAlive(), "70/100 HP is alive");
    }

    // --- zero damage -------------------------------------------------------------------

    @Test
    public void zeroDamageReturnsEqualHealth() {
        Health before = Health.full(50);
        Health after = service.apply(damage(0), before);
        assertEquals(before, after, "zero damage does not change HP");
    }

    // --- overkill damage -----------------------------------------------------------

    @Test
    public void overkillDamageFloorsAtZero() {
        Health before = Health.full(20);
        Health after = service.apply(damage(999), before);
        assertEquals(0.0, after.current(), "HP floors at zero, never negative");
        assertEquals(20.0, after.max(), "max HP unchanged");
        assertTrue(after.isDead(), "0 HP is dead");
    }

    // --- lethal damage (damage exactly equal to current HP) ------------------------

    @Test
    public void lethalDamageBringsHealthToExactlyZero() {
        Health before = Health.full(40);
        Health after = service.apply(damage(40), before);
        assertEquals(0.0, after.current(), "damage exactly equal to current HP kills");
        assertTrue(after.isDead(), "target is dead at exactly 0 HP");
    }

    // --- already-dead target --------------------------------------------------------

    @Test
    public void damageToAnAlreadyDeadTargetIsANoOp() {
        Health dead = new Health(0, 30);
        Health after = service.apply(damage(15), dead);
        assertEquals(dead, after, "further damage to a dead target changes nothing");
        assertTrue(after.isDead(), "still dead");
    }

    // --- immutability of the original Health ----------------------------------------

    @Test
    public void originalHealthInstanceIsNeverMutated() {
        Health before = Health.full(100);
        Health after = service.apply(damage(25), before);
        assertEquals(100.0, before.current(), "the original Health instance is untouched");
        assertNotEquals(before, after, "a new, different Health value was returned");
    }

    // --- deterministic repeated application ------------------------------------------

    @Test
    public void repeatedApplicationOfTheSameResultIsDeterministic() {
        Health before = Health.full(80);
        DamageResult hit = damage(15);
        Health first = service.apply(hit, before);
        Health second = service.apply(hit, before);
        assertEquals(first, second, "applying the same result to the same health twice yields equal results");
    }

    @Test
    public void sequentialApplicationsAccumulate() {
        Health health = Health.full(100);
        health = service.apply(damage(10), health);
        health = service.apply(damage(20), health);
        health = service.apply(damage(5), health);
        assertEquals(65.0, health.current(), "three sequential hits accumulate in order");
    }

    // --- null/invalid inputs ---------------------------------------------------------

    @Test
    public void nullDamageResultIsRejected() {
        assertThrows(NullPointerException.class,
                () -> service.apply(null, Health.full(10)),
                "null DamageResult must be rejected");
    }

    @Test
    public void nullTargetHealthIsRejected() {
        assertThrows(NullPointerException.class,
                () -> service.apply(damage(5), null),
                "null target Health must be rejected");
    }

    @Test
    public void bothArgumentsNullIsRejected() {
        assertThrows(NullPointerException.class,
                () -> service.apply(null, null),
                "both null must be rejected");
    }

    // --- complete path: DamageRequest -> DamageCalculator -> DamageResult -> DamageApplicationService -> Health

    @Test
    public void completePathFromDamageRequestToUpdatedHealth() {
        DamageCalculator calculator = new DamageCalculator();
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.FIRE, 45);

        DamageResult result = calculator.calculate(request);
        Health startingHealth = Health.full(100);
        Health finalHealth = service.apply(result, startingHealth);

        assertEquals(55.0, finalHealth.current(), "full path applies the calculated amount");
        assertTrue(finalHealth.isAlive(), "55/100 HP survives the hit");
    }

    @Test
    public void completePathCanBeLethal() {
        DamageCalculator calculator = new DamageCalculator();
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, 500);

        DamageResult result = calculator.calculate(request);
        Health finalHealth = service.apply(result, Health.full(60));

        assertTrue(finalHealth.isDead(), "an overwhelming request is lethal end-to-end");
        assertEquals(0.0, finalHealth.current(), "HP floors at zero through the full path");
    }

    // === Gameplay Part 4: death transition/event ======================================

    private static final Instant FIXED_INSTANT = Instant.parse("2026-01-01T00:00:00Z");
    private static final Clock FIXED_CLOCK = Clock.fixed(FIXED_INSTANT, ZoneOffset.UTC);
    private final DamageApplicationService deathAwareService = new DamageApplicationService(FIXED_CLOCK);

    // --- lethal damage produces a death event ------------------------------------------

    @Test
    public void lethalDamageProducesOneDeathEvent() {
        Health before = Health.full(40);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(40), before);

        assertTrue(result.health().isDead(), "target is dead after lethal damage");
        assertEquals(1, result.events().size(), "exactly one death event for a lethal hit");

        EntityDied event = result.events().get(0);
        assertEquals(TARGET, event.target(), "the entity that died");
        assertEquals(ATTACKER, event.source(), "the entity that dealt the killing damage");
        assertEquals(FIXED_INSTANT, event.occurredAt(), "timestamped from the service's clock");
    }

    @Test
    public void overkillDamageAlsoProducesOneDeathEvent() {
        Health before = Health.full(20);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(999), before);

        assertTrue(result.health().isDead(), "overwhelming damage is still lethal");
        assertEquals(0.0, result.health().current(), "HP floors at zero");
        assertEquals(1, result.events().size(), "overkill still produces exactly one death event");
    }

    // --- non-lethal damage produces no death event -------------------------------------

    @Test
    public void nonLethalDamageProducesNoDeathEvent() {
        Health before = Health.full(100);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(30), before);

        assertTrue(result.health().isAlive(), "70/100 HP is alive");
        assertTrue(result.events().isEmpty(), "surviving a hit produces no death event");
    }

    // --- zero damage produces no event --------------------------------------------------

    @Test
    public void zeroDamageProducesNoEvent() {
        Health before = Health.full(50);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(0), before);

        assertEquals(before, result.health(), "zero damage does not change HP");
        assertTrue(result.events().isEmpty(), "zero damage never kills, so no event");
    }

    @Test
    public void zeroDamageToAnAlreadyDeadTargetProducesNoEvent() {
        Health dead = new Health(0, 30);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(0), dead);

        assertTrue(result.events().isEmpty(), "zero damage to a dead target still produces no event");
    }

    // --- already-dead target produces no duplicate event --------------------------------

    @Test
    public void furtherDamageToAnAlreadyDeadTargetProducesNoDuplicateEvent() {
        Health dead = new Health(0, 30);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(15), dead);

        assertTrue(result.health().isDead(), "still dead");
        assertTrue(result.events().isEmpty(), "a target that was already dead does not die again");
    }

    // --- exact-zero HP -------------------------------------------------------------------

    @Test
    public void damageBringingHealthToExactlyZeroIsDetectedAsDeath() {
        Health before = Health.full(25);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(25), before);

        assertEquals(0.0, result.health().current(), "HP is exactly zero");
        assertTrue(result.health().isDead(), "exactly zero HP is dead");
        assertEquals(1, result.events().size(), "damage landing exactly on zero HP still triggers death");
    }

    @Test
    public void damageThatLeavesOnePointOfHealthProducesNoDeathEvent() {
        Health before = Health.full(25);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(24), before);

        assertEquals(1.0, result.health().current(), "one HP remains");
        assertTrue(result.health().isAlive(), "1 HP is still alive");
        assertTrue(result.events().isEmpty(), "one HP remaining is not a death");
    }

    // --- original immutable state remains unchanged --------------------------------------

    @Test
    public void originalHealthInstanceIsNeverMutatedByDeathDetection() {
        Health before = Health.full(40);
        DamageApplicationResult result = deathAwareService.applyDetectingDeath(damage(40), before);

        assertEquals(40.0, before.current(), "the original Health instance passed in is untouched");
        assertTrue(before.isAlive(), "the original instance still reports alive — it was never mutated");
        assertNotEquals(before, result.health(), "a new, different Health value was returned");
    }

    // --- deterministic behavior ------------------------------------------------------------

    @Test
    public void repeatedDeathDetectionOnTheSameInputsIsDeterministic() {
        Health before = Health.full(40);
        DamageResult hit = damage(40);

        DamageApplicationResult first = deathAwareService.applyDetectingDeath(hit, before);
        DamageApplicationResult second = deathAwareService.applyDetectingDeath(hit, before);

        assertEquals(first.health(), second.health(), "same resulting Health both times");
        assertEquals(first.events(), second.events(), "same death events both times, including timestamp");
    }

    // --- null/invalid inputs ---------------------------------------------------------------

    @Test
    public void nullDamageResultIsRejectedByDeathDetection() {
        assertThrows(NullPointerException.class,
                () -> deathAwareService.applyDetectingDeath(null, Health.full(10)),
                "null DamageResult must be rejected");
    }

    @Test
    public void nullTargetHealthIsRejectedByDeathDetection() {
        assertThrows(NullPointerException.class,
                () -> deathAwareService.applyDetectingDeath(damage(5), null),
                "null target Health must be rejected");
    }

    @Test
    public void bothArgumentsNullIsRejectedByDeathDetection() {
        assertThrows(NullPointerException.class,
                () -> deathAwareService.applyDetectingDeath(null, null),
                "both null must be rejected");
    }

    @Test
    public void nullClockIsRejectedByConstructor() {
        assertThrows(NullPointerException.class,
                () -> new DamageApplicationService(null),
                "a null Clock must be rejected at construction");
    }

    // --- full path: DamageRequest -> DamageCalculator -> DamageResult -> DamageApplicationService -> Death detection/event

    @Test
    public void completePathDetectsDeathFromARawDamageRequest() {
        DamageCalculator calculator = new DamageCalculator();
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, 500);

        DamageResult result = calculator.calculate(request);
        DamageApplicationResult outcome = deathAwareService.applyDetectingDeath(result, Health.full(60));

        assertTrue(outcome.health().isDead(), "an overwhelming request is lethal end-to-end");
        assertEquals(1, outcome.events().size(), "the full path produces exactly one death event");
        assertEquals(TARGET, outcome.events().get(0).target(), "death event target matches the original request's target");
        assertEquals(ATTACKER, outcome.events().get(0).source(), "death event source matches the original request's source");
    }

    @Test
    public void completePathProducesNoDeathEventWhenTargetSurvives() {
        DamageCalculator calculator = new DamageCalculator();
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.FIRE, 45);

        DamageResult result = calculator.calculate(request);
        DamageApplicationResult outcome = deathAwareService.applyDetectingDeath(result, Health.full(100));

        assertTrue(outcome.health().isAlive(), "55/100 HP survives the hit");
        assertTrue(outcome.events().isEmpty(), "no death event when the target survives, end-to-end");
    }

    @Test
    public void applyAndApplyDetectingDeathAgreeOnResultingHealth() {
        Health before = Health.full(40);
        DamageResult hit = damage(40);

        Health viaApply = service.apply(hit, before);
        Health viaDeathDetection = deathAwareService.applyDetectingDeath(hit, before).health();

        assertEquals(viaApply, viaDeathDetection, "both orchestration methods compute the same resulting Health");
    }
}
