package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.domain.Health;
import combat.events.EntityDied;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;
import java.time.Instant;
import java.util.List;

public class DamageApplicationResultTest {

    private static final EntityRef ATTACKER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());

    @Test
    public void rejectsNullHealth() {
        assertThrows(NullPointerException.class,
                () -> new DamageApplicationResult(null, List.of()),
                "health is required");
    }

    @Test
    public void rejectsNullEventsList() {
        assertThrows(NullPointerException.class,
                () -> new DamageApplicationResult(Health.full(10), null),
                "events list is required (use List.of() for none)");
    }

    @Test
    public void emptyEventsMeansNoDeath() {
        DamageApplicationResult result = new DamageApplicationResult(Health.full(10), List.of());
        assertTrue(result.events().isEmpty(), "no death occurred");
    }

    @Test
    public void carriesOneEntityDiedEvent() {
        EntityDied died = new EntityDied(TARGET, ATTACKER, Instant.now());
        DamageApplicationResult result = new DamageApplicationResult(new Health(0, 10), List.of(died));
        assertEquals(1, result.events().size(), "exactly one death event carried");
        assertEquals(died, result.events().get(0), "the carried event is the one supplied");
    }
}
