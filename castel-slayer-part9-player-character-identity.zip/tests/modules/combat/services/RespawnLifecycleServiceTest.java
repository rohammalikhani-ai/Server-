package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.IRespawnExecutor;
import combat.contracts.IRespawnPointProvider;
import combat.contracts.RespawnDenialReason;
import combat.contracts.RespawnExecutionRequest;
import combat.contracts.RespawnExecutionResult;
import combat.contracts.RespawnPoint;
import combat.domain.DamageResult;
import combat.domain.DamageType;
import combat.domain.Health;
import combat.domain.RespawnLifecycleState;
import combat.domain.RespawnLifecycleStatus;
import combat.events.EntityDied;
import combat.events.EntityRespawned;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class RespawnLifecycleServiceTest {

    private static final EntityRef PLAYER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef OTHER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef MOB = EntityRef.of(EntityKind.NPC, EntityId.random());
    private static final EntityRef ARROW = EntityRef.of(EntityKind.PROJECTILE, EntityId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 0, 64, 0));
    private static final RespawnPoint ELSEWHERE = new RespawnPoint(new Location(WorldId.of("nether"), 5, 70, 5));
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");
    private static final Instant LATER = Instant.parse("2026-01-01T00:00:05Z");
    private static final Health DEAD = new Health(0, 20);
    private static final Health ALIVE = Health.full(20);

    /** Records every request and answers with whatever the test scripted. */
    private static final class ScriptedExecutor implements IRespawnExecutor {
        final List<RespawnExecutionRequest> calls = new ArrayList<>();
        private final java.util.function.Function<RespawnExecutionRequest, RespawnExecutionResult> script;

        ScriptedExecutor(java.util.function.Function<RespawnExecutionRequest, RespawnExecutionResult> script) {
            this.script = script;
        }

        static ScriptedExecutor succeeding() {
            return new ScriptedExecutor(r -> new RespawnExecutionResult.Succeeded(r.entity(), r.destination(), LATER));
        }

        static ScriptedExecutor failing(String reason) {
            return new ScriptedExecutor(r -> new RespawnExecutionResult.Failed(r.entity(), reason, LATER));
        }

        @Override
        public RespawnExecutionResult execute(RespawnExecutionRequest request) {
            calls.add(request);
            return script.apply(request);
        }
    }

    private static RespawnLifecycleService lifecycle(IRespawnPointProvider provider) {
        return new RespawnLifecycleService(
                new RespawnDecisionService(provider, Set.of(EntityKind.PLAYER, EntityKind.NPC)),
                Clock.fixed(T, ZoneOffset.UTC));
    }

    private static RespawnLifecycleService lifecycle() {
        return lifecycle(e -> Optional.of(POINT));
    }

    private static EntityDied died(EntityRef who) {
        return new EntityDied(who, MOB, T);
    }

    private static RespawnLifecycleState dead() {
        return RespawnLifecycleState.alive(PLAYER).died();
    }

    private static RespawnLifecycleState eligible() {
        return dead().eligible();
    }

    private static RespawnLifecycleState decided() {
        return eligible().decided(POINT);
    }

    // ---- step 1: death ----------------------------------------------------------------------

    @Test
    public void deathIsRecordedOnceForALivingEntity() {
        RespawnLifecycleResult r = lifecycle().recordDeath(RespawnLifecycleState.alive(PLAYER), died(PLAYER), DEAD);
        assertEquals(RespawnLifecycleOutcome.APPLIED, r.outcome(), "applied");
        assertEquals(RespawnLifecycleStatus.DEAD, r.state().status(), "dead");
    }

    @Test
    public void repeatedDeathEventsDoNotCreateSecondTransitions() {
        RespawnLifecycleService service = lifecycle();
        RespawnLifecycleState first = service.recordDeath(RespawnLifecycleState.alive(PLAYER), died(PLAYER), DEAD).state();
        RespawnLifecycleResult again = service.recordDeath(first, died(PLAYER), DEAD);
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, again.outcome(), "second EntityDied is a duplicate");
        assertEquals(first, again.state(), "state unchanged");
    }

    @Test
    public void repeatedDeathDoesNotRewindProgressAlreadyMade() {
        RespawnLifecycleService service = lifecycle();
        for (RespawnLifecycleState later : List.of(eligible(), decided(), decided().executionRequested())) {
            RespawnLifecycleResult r = service.recordDeath(later, died(PLAYER), DEAD);
            assertEquals(RespawnLifecycleOutcome.DUPLICATE, r.outcome(), "duplicate at " + later.status());
            assertEquals(later, r.state(), "progress preserved at " + later.status());
        }
    }

    @Test
    public void deathForAnotherEntityIsRejected() {
        RespawnLifecycleResult r = lifecycle().recordDeath(RespawnLifecycleState.alive(PLAYER), died(OTHER), DEAD);
        assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "wrong entity");
        assertEquals(RespawnLifecycleStatus.ALIVE, r.state().status(), "unchanged");
    }

    @Test
    public void deathWhileHealthIsAliveIsRejected() {
        RespawnLifecycleResult r = lifecycle().recordDeath(RespawnLifecycleState.alive(PLAYER), died(PLAYER), ALIVE);
        assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "the event and Health disagree");
        assertTrue(r.state().isAlive(), "unchanged");
    }

    // ---- step 2: eligibility ------------------------------------------------------------------

    @Test
    public void deadEntityBecomesEligible() {
        RespawnLifecycleResult r = lifecycle().evaluateEligibility(dead(), DEAD);
        assertEquals(RespawnLifecycleOutcome.APPLIED, r.outcome(), "applied");
        assertEquals(RespawnLifecycleStatus.RESPAWN_ELIGIBLE, r.state().status(), "eligible");
    }

    @Test
    public void aliveEntityCannotBeEvaluatedForRespawn() {
        RespawnLifecycleState alive = RespawnLifecycleState.alive(PLAYER);
        RespawnLifecycleResult r = lifecycle().evaluateEligibility(alive, ALIVE);
        assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "alive entity attempting respawn");
        assertEquals(alive, r.state(), "unchanged");
    }

    @Test
    public void deadStateWithLivingHealthIsDeniedAsAlive() {
        RespawnLifecycleResult r = lifecycle().evaluateEligibility(dead(), ALIVE);
        assertEquals(RespawnLifecycleOutcome.DENIED, r.outcome(), "denied");
        assertEquals(Optional.of(RespawnDenialReason.ENTITY_ALIVE), r.denialReason(), "Health says alive");
        assertEquals(RespawnLifecycleStatus.DEAD, r.state().status(), "still dead, not eligible");
    }

    @Test
    public void nonRespawnableKindIsDeniedAndStaysDead() {
        RespawnLifecycleState deadArrow = RespawnLifecycleState.alive(ARROW).died();
        RespawnLifecycleResult r = lifecycle().evaluateEligibility(deadArrow, DEAD);
        assertEquals(RespawnLifecycleOutcome.DENIED, r.outcome(), "denied");
        assertEquals(Optional.of(RespawnDenialReason.KIND_NOT_RESPAWNABLE), r.denialReason(), "reason");
        assertEquals(deadArrow, r.state(), "unchanged");
    }

    @Test
    public void evaluatingEligibilityTwiceIsADuplicate() {
        for (RespawnLifecycleState later : List.of(eligible(), decided(), decided().executionRequested())) {
            RespawnLifecycleResult r = lifecycle().evaluateEligibility(later, DEAD);
            assertEquals(RespawnLifecycleOutcome.DUPLICATE, r.outcome(), "duplicate at " + later.status());
            assertEquals(later, r.state(), "unchanged");
        }
    }

    // ---- step 3: destination ------------------------------------------------------------------

    @Test
    public void eligibleEntityGetsAValidDestination() {
        RespawnLifecycleResult r = lifecycle().decideDestination(eligible());
        assertEquals(RespawnLifecycleOutcome.APPLIED, r.outcome(), "applied");
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED, r.state().status(), "decided");
        assertEquals(Optional.of(POINT), r.state().destination(), "the provider's destination");
    }

    @Test
    public void missingDestinationIsDeniedAndStateIsUnchanged() {
        RespawnLifecycleState eligible = eligible();
        RespawnLifecycleResult r = lifecycle(e -> Optional.empty()).decideDestination(eligible);
        assertEquals(RespawnLifecycleOutcome.DENIED, r.outcome(), "denied");
        assertEquals(Optional.of(RespawnDenialReason.NO_RESPAWN_POINT), r.denialReason(), "reason");
        assertEquals(eligible, r.state(), "still eligible; may be retried when a point exists");
    }

    @Test
    public void destinationRequiresEligibility() {
        for (RespawnLifecycleState early : List.of(RespawnLifecycleState.alive(PLAYER), dead())) {
            RespawnLifecycleResult r = lifecycle().decideDestination(early);
            assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "rejected at " + early.status());
            assertEquals(early, r.state(), "unchanged");
        }
    }

    @Test
    public void decidingTwiceIsADuplicateAndKeepsTheFirstDestination() {
        RespawnLifecycleService moved = lifecycle(e -> Optional.of(ELSEWHERE));
        RespawnLifecycleResult r = moved.decideDestination(decided());
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, r.outcome(), "duplicate");
        assertEquals(Optional.of(POINT), r.state().destination(), "the first decision stands");
    }

    // ---- step 4: request ----------------------------------------------------------------------

    @Test
    public void requestingExecutionProducesTheCommandAndMovesState() {
        RespawnLifecycleResult r = lifecycle().requestExecution(decided());
        assertEquals(RespawnLifecycleOutcome.APPLIED, r.outcome(), "applied");
        assertEquals(RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED, r.state().status(), "requested");
        assertEquals(new RespawnExecutionRequest(PLAYER, POINT, T), r.executionRequest().orElseThrow(),
                "entity X may respawn at destination Y — stamped by the injected clock");
    }

    @Test
    public void duplicateRespawnRequestProducesNoSecondCommand() {
        RespawnLifecycleState requested = lifecycle().requestExecution(decided()).state();
        RespawnLifecycleResult again = lifecycle().requestExecution(requested);
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, again.outcome(), "duplicate");
        assertTrue(again.executionRequest().isEmpty(), "the platform is never asked twice");
        assertEquals(requested, again.state(), "unchanged");
    }

    @Test
    public void requestWithoutADecisionIsRejected() {
        for (RespawnLifecycleState early : List.of(RespawnLifecycleState.alive(PLAYER), dead(), eligible())) {
            RespawnLifecycleResult r = lifecycle().requestExecution(early);
            assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "rejected at " + early.status());
            assertTrue(r.executionRequest().isEmpty(), "no command");
            assertEquals(early, r.state(), "unchanged");
        }
    }

    // ---- step 5: completion -------------------------------------------------------------------

    @Test
    public void confirmedSuccessMakesTheEntityAliveAndEmitsOneEvent() {
        RespawnLifecycleState requested = decided().executionRequested();
        RespawnLifecycleResult r = lifecycle().completeExecution(requested,
                new RespawnExecutionResult.Succeeded(PLAYER, POINT, LATER));
        assertEquals(RespawnLifecycleOutcome.APPLIED, r.outcome(), "applied");
        assertEquals(RespawnLifecycleState.alive(PLAYER), r.state(), "alive again, no leftover destination");
        assertEquals(List.of(new EntityRespawned(PLAYER, POINT, LATER)), r.events(), "exactly one event, timestamped by the executor");
    }

    @Test
    public void reportedFailureReturnsToTheDecidedStateWithoutAnyEvent() {
        RespawnLifecycleState decided = decided();
        RespawnLifecycleState requested = decided.executionRequested();
        RespawnLifecycleResult r = lifecycle().completeExecution(requested,
                new RespawnExecutionResult.Failed(PLAYER, "chunk unavailable", LATER));
        assertEquals(RespawnLifecycleOutcome.EXECUTION_FAILED, r.outcome(), "failure is explicit, never success");
        assertEquals(Optional.of("chunk unavailable"), r.detail(), "the reason is kept");
        assertEquals(decided, r.state(), "state equals the pre-request state — nothing silently changed");
        assertTrue(r.events().isEmpty(), "no EntityRespawned for a failure");
    }

    @Test
    public void retryAfterFailureCanSucceed() {
        RespawnLifecycleService service = lifecycle();
        RespawnLifecycleState state = decided();
        RespawnLifecycleResult failed = service.execute(state, ScriptedExecutor.failing("try later"));
        assertEquals(RespawnLifecycleOutcome.EXECUTION_FAILED, failed.outcome(), "first attempt fails");
        RespawnLifecycleResult retried = service.execute(failed.state(), ScriptedExecutor.succeeding());
        assertEquals(RespawnLifecycleOutcome.APPLIED, retried.outcome(), "second attempt succeeds");
        assertTrue(retried.state().isAlive(), "alive");
    }

    @Test
    public void successForADifferentDestinationIsRejectedAndStateIsUntouched() {
        RespawnLifecycleState requested = decided().executionRequested();
        RespawnLifecycleResult r = lifecycle().completeExecution(requested,
                new RespawnExecutionResult.Succeeded(PLAYER, ELSEWHERE, LATER));
        assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "executor violated the contract");
        assertEquals(requested, r.state(), "unchanged");
        assertTrue(r.events().isEmpty(), "no event");
    }

    @Test
    public void resultForAnotherEntityIsRejected() {
        RespawnLifecycleState requested = decided().executionRequested();
        RespawnLifecycleResult r = lifecycle().completeExecution(requested,
                new RespawnExecutionResult.Succeeded(OTHER, POINT, LATER));
        assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "misrouted result");
        assertEquals(requested, r.state(), "unchanged");
    }

    @Test
    public void repeatedSuccessReportDoesNotEmitASecondEvent() {
        RespawnLifecycleService service = lifecycle();
        RespawnExecutionResult success = new RespawnExecutionResult.Succeeded(PLAYER, POINT, LATER);
        RespawnLifecycleResult first = service.completeExecution(decided().executionRequested(), success);
        RespawnLifecycleResult second = service.completeExecution(first.state(), success);
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, second.outcome(), "duplicate");
        assertTrue(second.events().isEmpty(), "no second EntityRespawned");
        assertEquals(first.state(), second.state(), "unchanged");
    }

    @Test
    public void completionWhenNotAwaitingOneIsRejected() {
        for (RespawnLifecycleState s : List.of(dead(), eligible(), decided())) {
            RespawnLifecycleResult r = lifecycle().completeExecution(s, new RespawnExecutionResult.Succeeded(PLAYER, POINT, LATER));
            assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "rejected at " + s.status());
            assertEquals(s, r.state(), "unchanged");
        }
        RespawnLifecycleState alive = RespawnLifecycleState.alive(PLAYER);
        assertEquals(RespawnLifecycleOutcome.REJECTED,
                lifecycle().completeExecution(alive, new RespawnExecutionResult.Failed(PLAYER, "x", LATER)).outcome(),
                "a stale failure report for a living entity is rejected, not applied");
    }

    // ---- execution boundary (execute) ---------------------------------------------------------

    @Test
    public void executeCallsTheBoundaryOnceWithTheDecidedDestination() {
        ScriptedExecutor executor = ScriptedExecutor.succeeding();
        RespawnLifecycleResult r = lifecycle().execute(decided(), executor);
        assertEquals(RespawnLifecycleOutcome.APPLIED, r.outcome(), "applied");
        assertEquals(List.of(new RespawnExecutionRequest(PLAYER, POINT, T)), executor.calls,
                "the core says 'entity X may respawn at Y' and nothing else crosses the boundary");
        assertTrue(r.state().isAlive(), "alive");
        assertEquals(1, r.events().size(), "one EntityRespawned");
    }

    @Test
    public void executeWithAFailingExecutorLeavesStateAtDecided() {
        RespawnLifecycleState decided = decided();
        RespawnLifecycleResult r = lifecycle().execute(decided, ScriptedExecutor.failing("world unloaded"));
        assertEquals(RespawnLifecycleOutcome.EXECUTION_FAILED, r.outcome(), "failure surfaced");
        assertEquals(decided, r.state(), "no silent mutation");
    }

    @Test
    public void executeDoesNotCallTheBoundaryForDuplicateOrPrematureRequests() {
        ScriptedExecutor executor = ScriptedExecutor.succeeding();
        assertEquals(RespawnLifecycleOutcome.DUPLICATE,
                lifecycle().execute(decided().executionRequested(), executor).outcome(), "already requested");
        assertEquals(RespawnLifecycleOutcome.REJECTED, lifecycle().execute(eligible(), executor).outcome(), "nothing decided");
        assertEquals(RespawnLifecycleOutcome.REJECTED,
                lifecycle().execute(RespawnLifecycleState.alive(PLAYER), executor).outcome(), "alive entity");
        assertTrue(executor.calls.isEmpty(), "the executor was never invoked");
    }

    @Test
    public void executingTheSameStateTwiceAfterSuccessDoesNotRespawnTwice() {
        ScriptedExecutor executor = ScriptedExecutor.succeeding();
        RespawnLifecycleResult first = lifecycle().execute(decided(), executor);
        RespawnLifecycleResult second = lifecycle().execute(first.state(), executor);
        assertEquals(RespawnLifecycleOutcome.REJECTED, second.outcome(), "an alive entity has nothing to execute");
        assertEquals(1, executor.calls.size(), "one execution in total");
    }

    @Test
    public void executorExceptionPropagatesAndCallerStateIsIntact() {
        RespawnLifecycleState decided = decided();
        IRespawnExecutor broken = r -> {
            throw new IllegalStateException("platform crashed");
        };
        assertThrows(IllegalStateException.class, () -> lifecycle().execute(decided, broken),
                "never converted into success or swallowed");
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED, decided.status(), "the caller's state was not mutated");
    }

    @Test
    public void executorReturningNullFailsFast() {
        assertThrows(NullPointerException.class, () -> lifecycle().execute(decided(), r -> null),
                "a null result is a contract violation, not a success");
    }

    @Test
    public void executorClaimingAnotherDestinationIsRejectedInsideExecute() {
        ScriptedExecutor liar = new ScriptedExecutor(r -> new RespawnExecutionResult.Succeeded(r.entity(), ELSEWHERE, LATER));
        RespawnLifecycleResult r = lifecycle().execute(decided(), liar);
        assertEquals(RespawnLifecycleOutcome.REJECTED, r.outcome(), "rejected");
        assertTrue(r.events().isEmpty(), "and no respawn event");
    }

    // ---- whole lifecycle / integration --------------------------------------------------------

    @Test
    public void fullLifecycleFromLethalDamageThroughEntityDiedToRespawn() {
        DamageApplicationService damage = new DamageApplicationService(Clock.fixed(T, ZoneOffset.UTC));
        DamageApplicationResult hit = damage.applyDetectingDeath(new DamageResult(MOB, PLAYER, DamageType.PHYSICAL, 99), ALIVE);
        assertEquals(1, hit.events().size(), "one EntityDied from the existing detector");

        RespawnLifecycleService service = lifecycle();
        RespawnLifecycleState state = RespawnLifecycleState.alive(PLAYER);
        state = service.recordDeath(state, hit.events().get(0), hit.health()).state();
        state = service.evaluateEligibility(state, hit.health()).state();
        state = service.decideDestination(state).state();
        RespawnLifecycleResult done = service.execute(state, ScriptedExecutor.succeeding());

        assertEquals(RespawnLifecycleOutcome.APPLIED, done.outcome(), "respawned");
        assertEquals(RespawnLifecycleState.alive(PLAYER), done.state(), "back to alive");
        assertEquals(new EntityRespawned(PLAYER, POINT, LATER), done.events().get(0), "with its event");
    }

    @Test
    public void furtherDamageToTheDeadProducesNoSecondDeathTransition() {
        DamageApplicationService damage = new DamageApplicationService(Clock.fixed(T, ZoneOffset.UTC));
        RespawnLifecycleService service = lifecycle();
        DamageResult lethal = new DamageResult(MOB, PLAYER, DamageType.PHYSICAL, 99);
        DamageApplicationResult first = damage.applyDetectingDeath(lethal, ALIVE);
        DamageApplicationResult overkill = damage.applyDetectingDeath(lethal, first.health());
        assertTrue(overkill.events().isEmpty(), "the existing detector already emits nothing for the already dead");

        RespawnLifecycleState state = service.recordDeath(RespawnLifecycleState.alive(PLAYER), first.events().get(0), first.health()).state();
        RespawnLifecycleResult replay = service.recordDeath(state, first.events().get(0), overkill.health());
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, replay.outcome(), "even a replayed EntityDied is absorbed");
        assertEquals(state, replay.state(), "single DEAD transition");
    }

    @Test
    public void deathOfANonPlayerFollowsTheSameLifecycle() {
        RespawnLifecycleService service = lifecycle();
        RespawnLifecycleState state = RespawnLifecycleState.alive(MOB);
        state = service.recordDeath(state, new EntityDied(MOB, PLAYER, T), DEAD).state();
        state = service.evaluateEligibility(state, DEAD).state();
        state = service.decideDestination(state).state();
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED, state.status(), "no player assumption");
    }

    @Test
    public void decisionsAreDeterministic() {
        RespawnLifecycleService a = lifecycle();
        RespawnLifecycleService b = lifecycle();
        for (int i = 0; i < 10; i++) {
            assertEquals(a.requestExecution(decided()), b.requestExecution(decided()), "same inputs, equal results");
            assertEquals(a.evaluateEligibility(dead(), DEAD), a.evaluateEligibility(dead(), DEAD), "repeatable");
        }
    }

    @Test
    public void inputStatesAreNeverModified() {
        RespawnLifecycleState decided = decided();
        RespawnLifecycleState snapshot = new RespawnLifecycleState(decided.entity(), decided.status(), decided.destination());
        lifecycle().execute(decided, ScriptedExecutor.succeeding());
        lifecycle().requestExecution(decided);
        assertEquals(snapshot, decided, "the caller's value is exactly as it was");
    }

    @Test
    public void providerFailurePropagatesFromDestinationStep() {
        RespawnLifecycleService service = lifecycle(e -> {
            throw new IllegalStateException("provider down");
        });
        assertThrows(IllegalStateException.class, () -> service.decideDestination(eligible()),
                "a provider outage is not a denial");
    }

    @Test
    public void nullValidation() {
        RespawnLifecycleService s = lifecycle();
        RespawnLifecycleState alive = RespawnLifecycleState.alive(PLAYER);
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleService(null), "decisions");
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleService(
                new RespawnDecisionService(e -> Optional.empty(), Set.of()), null), "clock");
        assertThrows(NullPointerException.class, () -> s.recordDeath(null, died(PLAYER), DEAD), "state");
        assertThrows(NullPointerException.class, () -> s.recordDeath(alive, null, DEAD), "died");
        assertThrows(NullPointerException.class, () -> s.recordDeath(alive, died(PLAYER), null), "health");
        assertThrows(NullPointerException.class, () -> s.evaluateEligibility(null, DEAD), "state");
        assertThrows(NullPointerException.class, () -> s.evaluateEligibility(alive, null), "health");
        assertThrows(NullPointerException.class, () -> s.decideDestination(null), "state");
        assertThrows(NullPointerException.class, () -> s.requestExecution(null), "state");
        assertThrows(NullPointerException.class, () -> s.completeExecution(null,
                new RespawnExecutionResult.Failed(PLAYER, "x", T)), "state");
        assertThrows(NullPointerException.class, () -> s.completeExecution(alive, null), "result");
        assertThrows(NullPointerException.class, () -> s.execute(null, ScriptedExecutor.succeeding()), "state");
        assertThrows(NullPointerException.class, () -> s.execute(alive, null), "executor");
    }
}
