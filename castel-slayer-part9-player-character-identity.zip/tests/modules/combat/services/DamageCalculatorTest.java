package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.domain.DamageRequest;
import combat.domain.DamageResult;
import combat.domain.DamageType;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;

public class DamageCalculatorTest {

    private static final EntityRef ATTACKER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef TARGET = EntityRef.of(EntityKind.NPC, EntityId.random());

    private final DamageCalculator calculator = new DamageCalculator();

    @Test
    public void normalDamagePassesThroughToTheResult() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.PHYSICAL, 25);
        DamageResult result = calculator.calculate(request);
        assertEquals(25.0, result.amount(), "normal damage amount");
    }

    @Test
    public void zeroDamageProducesZeroResult() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.MAGICAL, 0);
        DamageResult result = calculator.calculate(request);
        assertEquals(0.0, result.amount(), "zero damage must work correctly, not be treated as invalid");
    }

    @Test
    public void resultAmountIsNeverNegative() {
        // baseAmount can never be negative by the time it reaches the calculator
        // (DamageRequest rejects it), so this proves the calculator's own output
        // is also always non-negative for every accepted input, including zero.
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.POISON, 0);
        DamageResult result = calculator.calculate(request);
        assertTrue(result.amount() >= 0, "final damage can never be negative");
    }

    @Test
    public void damageTypeIsPreservedForEveryInitialType() {
        for (DamageType type : DamageType.values()) {
            DamageRequest request = new DamageRequest(ATTACKER, TARGET, type, 10);
            DamageResult result = calculator.calculate(request);
            assertEquals(type, result.type(), "damage type must be preserved for " + type);
        }
    }

    @Test
    public void sourceAndTargetArePreserved() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.SHADOW, 5);
        DamageResult result = calculator.calculate(request);
        assertEquals(ATTACKER, result.source(), "source must be preserved");
        assertEquals(TARGET, result.target(), "target must be preserved");
    }

    @Test
    public void calculationIsDeterministic() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.LIGHTNING, 17.5);

        DamageResult first = calculator.calculate(request);
        DamageResult second = calculator.calculate(request);
        DamageResult third = calculator.calculate(request);

        assertEquals(first, second, "same request must always produce an equal result");
        assertEquals(second, third, "same request must always produce an equal result");
    }

    @Test
    public void handlesExtremeBoundaryValue() {
        DamageRequest request = new DamageRequest(ATTACKER, TARGET, DamageType.FIRE, Double.MAX_VALUE);
        DamageResult result = calculator.calculate(request);
        assertEquals(Double.MAX_VALUE, result.amount(), "extreme finite values must be handled without overflowing to infinity or throwing");
    }

    @Test
    public void rejectsNullRequest() {
        assertThrows(NullPointerException.class,
                () -> calculator.calculate(null),
                "null request must be rejected");
    }
}
