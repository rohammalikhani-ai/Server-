package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.HealthSnapshot;
import combat.domain.Health;
import core.domain.EntityRef;
import core.domain.PlayerId;
import java.time.Instant;

public class HealthSnapshotMapperTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");
    private final HealthSnapshotMapper mapper = new HealthSnapshotMapper();

    // ---- toSnapshot -----------------------------------------------------------------------

    @Test
    public void toSnapshotCarriesHealthAndBookkeeping() {
        HealthSnapshot s = mapper.toSnapshot(new Health(15, 20), ENTITY, 3, T);
        assertEquals(HealthSnapshot.CURRENT_SCHEMA_VERSION, s.schemaVersion(), "schema");
        assertEquals(3L, s.revision(), "revision");
        assertEquals(ENTITY, s.entity(), "entity");
        assertEquals(15.0, s.current(), "current");
        assertEquals(20.0, s.max(), "max");
        assertEquals(T, s.savedAt(), "savedAt");
    }

    @Test
    public void toSnapshotRejectsInvalidRevisionOrTimestamp() {
        assertThrows(IllegalArgumentException.class, () -> mapper.toSnapshot(Health.full(20), ENTITY, 0, T), "revision 0");
        assertThrows(IllegalArgumentException.class, () -> mapper.toSnapshot(Health.full(20), ENTITY, -1, T), "negative revision");
        assertThrows(IllegalArgumentException.class,
                () -> mapper.toSnapshot(Health.full(20), ENTITY, 1, Instant.parse("1900-01-01T00:00:00Z")), "pre-epoch");
    }

    @Test
    public void toSnapshotRejectsNulls() {
        assertThrows(NullPointerException.class, () -> mapper.toSnapshot(null, ENTITY, 1, T), "health");
        assertThrows(NullPointerException.class, () -> mapper.toSnapshot(Health.full(20), null, 1, T), "entity");
        assertThrows(NullPointerException.class, () -> mapper.toSnapshot(Health.full(20), ENTITY, 1, null), "savedAt");
    }

    // ---- restore: happy path ---------------------------------------------------------------

    @Test
    public void restoreRoundTripsAValidSnapshot() {
        HealthSnapshot s = mapper.toSnapshot(new Health(7.5, 20), ENTITY, 1, T);
        HealthRecoveryResult result = mapper.restore(s);
        assertTrue(result instanceof HealthRecoveryResult.Recovered, "recovered");
        HealthRecoveryResult.Recovered r = (HealthRecoveryResult.Recovered) result;
        assertEquals(new Health(7.5, 20), r.health(), "health");
        assertEquals(1L, r.revision(), "revision");
    }

    @Test
    public void restoreAcceptsZeroCurrentAndFullCurrent() {
        assertTrue(mapper.restore(new HealthSnapshot(1, 1, ENTITY, 0, 20, T)) instanceof HealthRecoveryResult.Recovered, "dead is valid");
        assertTrue(mapper.restore(new HealthSnapshot(1, 1, ENTITY, 20, 20, T)) instanceof HealthRecoveryResult.Recovered, "full is valid");
    }

    // ---- restore: rejections ---------------------------------------------------------------

    @Test
    public void restoreRejectsUnsupportedSchemaVersion() {
        assertEquals(HealthRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION,
                rejectedReason(new HealthSnapshot(2, 1, ENTITY, 10, 20, T)), "future schema is not guessed at");
    }

    @Test
    public void restoreRejectsInvalidRevision() {
        assertEquals(HealthRecoveryFailure.INVALID_REVISION,
                rejectedReason(new HealthSnapshot(1, 0, ENTITY, 10, 20, T)), "revision below 1");
    }

    @Test
    public void restoreRejectsInvalidTimestamp() {
        assertEquals(HealthRecoveryFailure.INVALID_TIMESTAMP,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, 10, 20, Instant.parse("1900-01-01T00:00:00Z"))), "pre-epoch");
    }

    @Test
    public void restoreRejectsNonPositiveMax() {
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, 0, 0, T)), "max must be > 0");
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, 0, -5, T)), "negative max");
    }

    @Test
    public void restoreRejectsNegativeCurrent() {
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, -1, 20, T)), "negative current");
    }

    @Test
    public void restoreRejectsCurrentAboveMax() {
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, 25, 20, T)), "current > max");
    }

    @Test
    public void restoreRejectsNonFiniteValues() {
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, Double.NaN, 20, T)), "NaN current");
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                rejectedReason(new HealthSnapshot(1, 1, ENTITY, 10, Double.POSITIVE_INFINITY, T)), "infinite max");
    }

    @Test
    public void restoreNeverThrowsForBadData() {
        // Every rejection above returns a Rejected result rather than propagating Health's own
        // IllegalArgumentException — recovery must never crash on untrusted stored data.
        HealthRecoveryResult result = mapper.restore(new HealthSnapshot(1, 1, ENTITY, 999, 1, T));
        assertTrue(result instanceof HealthRecoveryResult.Rejected, "reported, not thrown");
    }

    @Test
    public void restoreRejectsNull() {
        assertThrows(NullPointerException.class, () -> mapper.restore(null), "snapshot");
    }

    @Test
    public void restoreIsDeterministic() {
        HealthSnapshot s = new HealthSnapshot(1, 4, ENTITY, 9, 20, T);
        assertEquals(mapper.restore(s), mapper.restore(s), "same snapshot restores to an equal result every time");
    }

    private HealthRecoveryFailure rejectedReason(HealthSnapshot bad) {
        HealthRecoveryResult result = mapper.restore(bad);
        assertTrue(result instanceof HealthRecoveryResult.Rejected, "rejected: " + result);
        return ((HealthRecoveryResult.Rejected) result).reason();
    }
}
