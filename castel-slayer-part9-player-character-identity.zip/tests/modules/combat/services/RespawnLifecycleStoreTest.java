package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.IRespawnExecutor;
import combat.contracts.RespawnExecutionResult;
import combat.contracts.RespawnLifecycleSnapshot;
import combat.contracts.RespawnPoint;
import combat.domain.Health;
import combat.domain.RespawnLifecycleState;
import combat.domain.RespawnLifecycleStatus;
import combat.events.EntityDied;
import core.contracts.IPersistenceGateway;
import core.contracts.PersistenceException;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import core.services.InMemoryPersistenceGateway;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

public class RespawnLifecycleStoreTest {

    private static final EntityRef PLAYER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef MOB = EntityRef.of(EntityKind.NPC, EntityId.random());
    private static final Location LOC = new Location(WorldId.of("overworld"), 0, 64, 0);
    private static final RespawnPoint POINT = new RespawnPoint(LOC);
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");
    private static final Instant LATER = Instant.parse("2026-01-01T00:00:05Z");
    private static final Health DEAD = new Health(0, 20);

    /** Delegates to a real gateway but can be told to fail reads/writes (mirrors the runtime tests' FailingGateway). */
    private static class FlakyGateway implements IPersistenceGateway {
        final IPersistenceGateway delegate;
        boolean failReads;
        boolean failWrites;

        FlakyGateway(IPersistenceGateway delegate) {
            this.delegate = delegate;
        }

        @Override
        public <T> void save(String collection, String key, T value) {
            if (failWrites) {
                throw new PersistenceException("simulated write failure");
            }
            delegate.save(collection, key, value);
        }

        @Override
        public <T> Optional<T> load(String collection, String key, Class<T> type) {
            if (failReads) {
                throw new PersistenceException("simulated read failure");
            }
            return delegate.load(collection, key, type);
        }

        @Override
        public void delete(String collection, String key) {
            delegate.delete(collection, key);
        }

        @Override
        public <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
            return delegate.query(collection, type, filter);
        }
    }

    private static RespawnLifecycleStore store(IPersistenceGateway gateway) {
        return new RespawnLifecycleStore(gateway, Clock.fixed(T, ZoneOffset.UTC));
    }

    private static RespawnLifecycleState dead() {
        return RespawnLifecycleState.alive(PLAYER).died();
    }

    private static RespawnLifecycleState decided() {
        return dead().eligible().decided(POINT);
    }

    private static String key(EntityRef e) {
        return e.kind().name() + ":" + e.id();
    }

    private static RespawnLifecycleService lifecycle() {
        return new RespawnLifecycleService(new RespawnDecisionService(e -> Optional.of(POINT), Set.of(EntityKind.PLAYER)),
                Clock.fixed(T, ZoneOffset.UTC));
    }

    // ---- save / load / round trip -------------------------------------------------------------

    @Test
    public void firstSaveThenLoadRoundTrips() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        assertEquals(new RespawnSaveResult.Saved(PLAYER, 1), store.save(dead(), 0), "first save is revision 1");
        assertEquals(new RespawnLoadResult.Loaded(PLAYER, dead(), 1), store.load(PLAYER), "loads back equal");
    }

    @Test
    public void everyStatusRoundTripsThroughTheGateway() {
        RespawnLifecycleState alive = RespawnLifecycleState.alive(PLAYER);
        for (RespawnLifecycleState state : List.of(alive, alive.died(), alive.died().eligible(), decided(),
                decided().executionRequested())) {
            RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
            store.save(state, 0);
            RespawnLoadResult.Loaded loaded = (RespawnLoadResult.Loaded) store.load(PLAYER);
            assertEquals(state, loaded.state(), "round trip for " + state.status());
        }
    }

    @Test
    public void loadOfAnUnknownEntityIsNotFoundNotAnError() {
        assertEquals(new RespawnLoadResult.NotFound(PLAYER), store(new InMemoryPersistenceGateway()).load(PLAYER),
                "missing entity");
    }

    @Test
    public void entitiesAreStoredIndependently() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        store.save(dead(), 0);
        store.save(RespawnLifecycleState.alive(MOB), 0);
        assertEquals(RespawnLifecycleStatus.DEAD, ((RespawnLoadResult.Loaded) store.load(PLAYER)).state().status(), "player");
        assertEquals(RespawnLifecycleStatus.ALIVE, ((RespawnLoadResult.Loaded) store.load(MOB)).state().status(), "mob");
    }

    @Test
    public void savedAtComesFromTheInjectedClock() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        store(gateway).save(dead(), 0);
        RespawnLifecycleSnapshot stored = gateway.load(RespawnLifecycleStore.COLLECTION, key(PLAYER),
                RespawnLifecycleSnapshot.class).orElseThrow();
        assertEquals(T, stored.savedAt(), "timestamp");
        assertEquals(RespawnLifecycleSnapshot.CURRENT_SCHEMA_VERSION, stored.schemaVersion(), "schema written");
        assertEquals(1L, stored.revision(), "revision written");
    }

    // ---- versioning ---------------------------------------------------------------------------

    @Test
    public void revisionsIncreaseByOnePerSave() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        assertEquals(new RespawnSaveResult.Saved(PLAYER, 1), store.save(RespawnLifecycleState.alive(PLAYER), 0), "1");
        assertEquals(new RespawnSaveResult.Saved(PLAYER, 2), store.save(dead(), 1), "2");
        assertEquals(new RespawnSaveResult.Saved(PLAYER, 3), store.save(decided(), 2), "3");
        assertEquals(3L, ((RespawnLoadResult.Loaded) store.load(PLAYER)).revision(), "loaded revision matches");
    }

    @Test
    public void staleWriterGetsAVersionConflictAndNothingIsWritten() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        store.save(RespawnLifecycleState.alive(PLAYER), 0);
        store.save(dead(), 1);
        RespawnSaveResult result = store.save(decided(), 1);
        assertEquals(new RespawnSaveResult.VersionConflict(PLAYER, 1, 2), result, "stale revision 1, actual 2");
        assertEquals(RespawnLifecycleStatus.DEAD, ((RespawnLoadResult.Loaded) store.load(PLAYER)).state().status(),
                "stored state untouched");
    }

    @Test
    public void creatingOverAnExistingRecordConflicts() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        store.save(dead(), 0);
        assertEquals(new RespawnSaveResult.VersionConflict(PLAYER, 0, 1), store.save(dead(), 0), "expected nothing, found revision 1");
    }

    @Test
    public void updatingSomethingThatDoesNotExistConflicts() {
        assertEquals(new RespawnSaveResult.VersionConflict(PLAYER, 5, 0),
                store(new InMemoryPersistenceGateway()).save(dead(), 5), "expected 5, nothing stored");
    }

    @Test
    public void aFutureRevisionCannotBeSkippedTo() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        store.save(dead(), 0);
        assertTrue(store.save(decided(), 7) instanceof RespawnSaveResult.VersionConflict, "revision must match exactly");
    }

    @Test
    public void twoRacingRespawnRequestsCannotBothBeSaved() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        RespawnLifecycleStore store = store(gateway);
        store.save(decided(), 0);

        RespawnLoadResult.Loaded callerA = (RespawnLoadResult.Loaded) store.load(PLAYER);
        RespawnLoadResult.Loaded callerB = (RespawnLoadResult.Loaded) store.load(PLAYER);
        IRespawnExecutor ok = r -> new RespawnExecutionResult.Succeeded(r.entity(), r.destination(), LATER);

        RespawnLifecycleResult a = lifecycle().execute(callerA.state(), ok);
        RespawnLifecycleResult b = lifecycle().execute(callerB.state(), ok);
        assertEquals(new RespawnSaveResult.Saved(PLAYER, 2), store.save(a.state(), callerA.revision()), "first commit wins");
        assertTrue(store.save(b.state(), callerB.revision()) instanceof RespawnSaveResult.VersionConflict,
                "the second, based on a stale read, is refused — the revision check is what stops a duplicate transition from being persisted");
    }

    @Test
    public void negativeExpectedRevisionIsAProgrammingError() {
        assertThrows(IllegalArgumentException.class, () -> store(new InMemoryPersistenceGateway()).save(dead(), -1),
                "negative expectedRevision");
    }

    // ---- failure semantics --------------------------------------------------------------------

    @Test
    public void writeFailureThrowsAndStoresNothing() {
        FlakyGateway gateway = new FlakyGateway(new InMemoryPersistenceGateway());
        RespawnLifecycleStore store = store(gateway);
        gateway.failWrites = true;
        assertThrows(PersistenceException.class, () -> store.save(dead(), 0), "a failed save must not look like success");
        gateway.failWrites = false;
        assertEquals(new RespawnLoadResult.NotFound(PLAYER), store.load(PLAYER), "nothing was stored");
    }

    @Test
    public void readFailureOnLoadIsFailedNeverNotFound() {
        FlakyGateway gateway = new FlakyGateway(new InMemoryPersistenceGateway());
        RespawnLifecycleStore store = store(gateway);
        store.save(dead(), 0);
        gateway.failReads = true;
        RespawnLoadResult result = store.load(PLAYER);
        assertTrue(result instanceof RespawnLoadResult.Failed, "an outage is a failure, not 'not found' or data loss");
        assertTrue(((RespawnLoadResult.Failed) result).cause() instanceof PersistenceException, "cause preserved");
    }

    @Test
    public void readFailureOnSavePropagates() {
        FlakyGateway gateway = new FlakyGateway(new InMemoryPersistenceGateway());
        gateway.failReads = true;
        assertThrows(PersistenceException.class, () -> store(gateway).save(dead(), 0),
                "cannot verify the revision, so cannot save — and says so");
    }

    @Test
    public void wrongTypeInTheStoreIsFailedNotACrash() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(RespawnLifecycleStore.COLLECTION, key(PLAYER), "not a snapshot");
        assertTrue(store(gateway).load(PLAYER) instanceof RespawnLoadResult.Failed, "reported, not thrown");
    }

    @Test
    public void programmingErrorsAreNotSwallowedAsLoadFailures() {
        IPersistenceGateway buggy = new FlakyGateway(new InMemoryPersistenceGateway()) {
            @Override
            public <T> Optional<T> load(String collection, String key, Class<T> type) {
                throw new IllegalStateException("bug");
            }
        };
        assertThrows(IllegalStateException.class, () -> store(buggy).load(PLAYER), "only PersistenceException is translated");
    }

    // ---- invalid / incompatible stored data ---------------------------------------------------

    private static InMemoryPersistenceGateway gatewayHolding(RespawnLifecycleSnapshot snapshot) {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(RespawnLifecycleStore.COLLECTION, key(PLAYER), snapshot);
        return gateway;
    }

    @Test
    public void invalidStoredSnapshotsAreReportedAsCorruptWithTheirReason() {
        assertEquals(RespawnRecoveryFailure.INVALID_LIFECYCLE_STATE, corruptReason(
                new RespawnLifecycleSnapshot(1, 1, PLAYER, "BOGUS", Optional.empty(), T)), "bad status");
        assertEquals(RespawnRecoveryFailure.INVALID_DESTINATION, corruptReason(
                new RespawnLifecycleSnapshot(1, 1, PLAYER, "RESPAWN_DECIDED", Optional.empty(), T)), "missing destination");
        assertEquals(RespawnRecoveryFailure.INVALID_TIMESTAMP, corruptReason(
                new RespawnLifecycleSnapshot(1, 1, PLAYER, "ALIVE", Optional.empty(), Instant.parse("1900-01-01T00:00:00Z"))), "bad time");
        assertEquals(RespawnRecoveryFailure.INVALID_REVISION, corruptReason(
                new RespawnLifecycleSnapshot(1, 0, PLAYER, "ALIVE", Optional.empty(), T)), "bad revision");
    }

    private static RespawnRecoveryFailure corruptReason(RespawnLifecycleSnapshot bad) {
        RespawnLoadResult result = store(gatewayHolding(bad)).load(PLAYER);
        assertTrue(result instanceof RespawnLoadResult.Corrupt, "corrupt: " + result);
        return ((RespawnLoadResult.Corrupt) result).reason();
    }

    @Test
    public void incompatibleSchemaVersionIsCorruptNotGuessed() {
        assertEquals(RespawnRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION, corruptReason(
                new RespawnLifecycleSnapshot(2, 1, PLAYER, "ALIVE", Optional.empty(), T)), "a newer schema is not interpreted");
    }

    @Test
    public void aSnapshotUnderTheWrongKeyIsAnIdentityMismatch() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(RespawnLifecycleStore.COLLECTION, key(PLAYER),
                new RespawnLifecycleSnapshot(1, 1, MOB, "ALIVE", Optional.empty(), T));
        RespawnLoadResult result = store(gateway).load(PLAYER);
        assertEquals(RespawnRecoveryFailure.IDENTITY_MISMATCH, ((RespawnLoadResult.Corrupt) result).reason(),
                "PLAYER's key must never hand back the mob's state");
    }

    @Test
    public void unreadableExistingRecordsAreNeverOverwritten() {
        RespawnLifecycleSnapshot newer = new RespawnLifecycleSnapshot(2, 1, PLAYER, "ALIVE", Optional.empty(), T);
        InMemoryPersistenceGateway gateway = gatewayHolding(newer);
        RespawnLifecycleStore store = store(gateway);
        assertEquals(new RespawnSaveResult.Blocked(PLAYER, RespawnRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION),
                store.save(dead(), 1), "saving over data from a newer schema is refused");
        assertEquals(new RespawnSaveResult.Blocked(PLAYER, RespawnRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION),
                store.save(dead(), 0), "whatever revision the caller claims");
        assertEquals(Optional.of(newer), gateway.load(RespawnLifecycleStore.COLLECTION, key(PLAYER), RespawnLifecycleSnapshot.class),
                "the stored record is byte-for-byte what it was");
    }

    @Test
    public void aMismatchedStoredIdentityBlocksSaving() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(RespawnLifecycleStore.COLLECTION, key(PLAYER),
                new RespawnLifecycleSnapshot(1, 1, MOB, "ALIVE", Optional.empty(), T));
        assertEquals(new RespawnSaveResult.Blocked(PLAYER, RespawnRecoveryFailure.IDENTITY_MISMATCH),
                store(gateway).save(dead(), 1), "blocked");
    }

    @Test
    public void discardIsTheExplicitWayOutOfABlockedRecord() {
        InMemoryPersistenceGateway gateway = gatewayHolding(
                new RespawnLifecycleSnapshot(1, 1, PLAYER, "BOGUS", Optional.empty(), T));
        RespawnLifecycleStore store = store(gateway);
        assertTrue(store.save(dead(), 1) instanceof RespawnSaveResult.Blocked, "blocked while corrupt");
        store.discard(PLAYER);
        assertEquals(new RespawnLoadResult.NotFound(PLAYER), store.load(PLAYER), "gone");
        assertEquals(new RespawnSaveResult.Saved(PLAYER, 1), store.save(dead(), 0), "a fresh record can be created");
    }

    @Test
    public void discardingSomethingAbsentIsHarmless() {
        store(new InMemoryPersistenceGateway()).discard(PLAYER);
    }

    // ---- determinism, immutability, no leakage -------------------------------------------------

    @Test
    public void recoveryIsDeterministicAcrossLoadsAndStoreInstances() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        store(gateway).save(decided(), 0);
        RespawnLoadResult first = store(gateway).load(PLAYER);
        assertEquals(first, store(gateway).load(PLAYER), "another store instance over the same data");
        assertEquals(first, store(gateway).load(PLAYER), "and again");
    }

    @Test
    public void storedDataIsNotAffectedByLaterDomainTransitions() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        RespawnLifecycleState state = decided();
        store.save(state, 0);
        RespawnLifecycleState moved = state.executionRequested().respawned();
        assertEquals(RespawnLifecycleStatus.ALIVE, moved.status(), "the domain value moved on");
        assertEquals(state, ((RespawnLoadResult.Loaded) store.load(PLAYER)).state(),
                "what is stored is still the state that was saved — no mutation leaks through");
    }

    @Test
    public void loadedStateIsAnIndependentValue() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        store.save(decided(), 0);
        RespawnLifecycleState loaded = ((RespawnLoadResult.Loaded) store.load(PLAYER)).state();
        loaded.executionRequested();
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED,
                ((RespawnLoadResult.Loaded) store.load(PLAYER)).state().status(), "using a loaded state changes nothing stored");
    }

    @Test
    public void storeHoldsOnlySnapshotsNeverDomainObjects() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        store(gateway).save(decided(), 0);
        assertTrue(gateway.query(RespawnLifecycleStore.COLLECTION, Object.class, o -> true).stream()
                        .allMatch(o -> o instanceof RespawnLifecycleSnapshot),
                "the gateway only ever sees RespawnLifecycleSnapshot");
    }

    // ---- compatibility with the respawn lifecycle ----------------------------------------------

    @Test
    public void lifecycleCanBePersistedAtEveryStepAndResumedAfterARestart() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        RespawnLifecycleService service = lifecycle();
        RespawnLifecycleStore store = store(gateway);

        RespawnLifecycleState state = RespawnLifecycleState.alive(PLAYER);
        long revision = ((RespawnSaveResult.Saved) store.save(state, 0)).revision();

        state = service.recordDeath(state, new EntityDied(PLAYER, MOB, T), DEAD).state();
        revision = ((RespawnSaveResult.Saved) store.save(state, revision)).revision();
        state = service.evaluateEligibility(state, DEAD).state();
        revision = ((RespawnSaveResult.Saved) store.save(state, revision)).revision();
        state = service.decideDestination(state).state();
        revision = ((RespawnSaveResult.Saved) store.save(state, revision)).revision();

        // "Server restart": new store + service instances over the same data, nothing carried in memory.
        RespawnLifecycleStore restarted = store(gateway);
        RespawnLoadResult.Loaded recovered = (RespawnLoadResult.Loaded) restarted.load(PLAYER);
        assertEquals(state, recovered.state(), "the decided state was recovered exactly");
        assertEquals(revision, recovered.revision(), "with its revision");

        RespawnLifecycleResult done = lifecycle().execute(recovered.state(),
                r -> new RespawnExecutionResult.Succeeded(r.entity(), r.destination(), LATER));
        assertEquals(RespawnLifecycleStatus.ALIVE, done.state().status(), "and the lifecycle continued to completion");
        assertEquals(new RespawnSaveResult.Saved(PLAYER, revision + 1), restarted.save(done.state(), recovered.revision()),
                "the final state saves cleanly");
    }

    @Test
    public void aRecoveredDeadStateStillAbsorbsAReplayedDeathEvent() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        store.save(dead(), 0);
        RespawnLifecycleState recovered = ((RespawnLoadResult.Loaded) store.load(PLAYER)).state();
        RespawnLifecycleResult replay = lifecycle().recordDeath(recovered, new EntityDied(PLAYER, MOB, T), DEAD);
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, replay.outcome(), "no second death transition after recovery");
    }

    @Test
    public void anInFlightExecutionIsRecoveredUnchangedAndCanBeResolvedExplicitly() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        RespawnLifecycleState requested = decided().executionRequested();
        store.save(requested, 0);
        RespawnLifecycleState recovered = ((RespawnLoadResult.Loaded) store.load(PLAYER)).state();
        assertEquals(requested, recovered, "not silently rolled back or completed");
        RespawnLifecycleResult resolved = lifecycle().completeExecution(recovered,
                new RespawnExecutionResult.Failed(PLAYER, "outcome unknown after restart", LATER));
        assertEquals(RespawnLifecycleStatus.RESPAWN_DECIDED, resolved.state().status(), "resolved by the caller, explicitly");
    }

    @Test
    public void persistenceDoesNotChangeOrDependOnHealth() {
        assertTrue(java.util.Arrays.stream(RespawnLifecycleSnapshot.class.getRecordComponents())
                        .noneMatch(c -> c.getType() == Health.class),
                "health is not persisted by this contract");
    }

    @Test
    public void nullValidation() {
        RespawnLifecycleStore store = store(new InMemoryPersistenceGateway());
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleStore(null), "gateway");
        assertThrows(NullPointerException.class, () -> new RespawnLifecycleStore(new InMemoryPersistenceGateway(), null), "clock");
        assertThrows(NullPointerException.class, () -> store.load(null), "load entity");
        assertThrows(NullPointerException.class, () -> store.save(null, 0), "save state");
        assertThrows(NullPointerException.class, () -> store.discard(null), "discard entity");
        assertThrows(NullPointerException.class, () -> new RespawnLoadResult.Loaded(null, dead(), 1), "loaded entity");
        assertThrows(NullPointerException.class, () -> new RespawnLoadResult.Failed(PLAYER, "x", null), "failed cause");
        assertThrows(NullPointerException.class, () -> new RespawnSaveResult.Blocked(PLAYER, null), "blocked reason");
    }

    @Test
    public void resultTypesRejectInconsistentValues() {
        assertThrows(IllegalArgumentException.class, () -> new RespawnLoadResult.Loaded(MOB, dead(), 1),
                "a Loaded result can never hold another entity's state");
        assertThrows(IllegalArgumentException.class, () -> new RespawnLoadResult.Loaded(PLAYER, dead(), 0), "revision >= 1");
        assertThrows(IllegalArgumentException.class, () -> new RespawnSaveResult.Saved(PLAYER, 0), "saved revision >= 1");
        assertThrows(IllegalArgumentException.class, () -> new RespawnSaveResult.VersionConflict(PLAYER, 2, 2),
                "equal revisions are not a conflict");
        assertThrows(IllegalArgumentException.class, () -> new RespawnSaveResult.VersionConflict(PLAYER, -1, 2), "no negatives");
    }
}
