package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.RespawnDenialReason;
import combat.contracts.RespawnExecutionRequest;
import combat.contracts.RespawnPoint;
import combat.domain.RespawnLifecycleState;
import combat.events.EntityRespawned;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RespawnLifecycleResultTest {

    private static final EntityRef ENTITY = EntityRef.ofPlayer(PlayerId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 1, 2, 3));
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");
    private static final RespawnLifecycleState STATE = RespawnLifecycleState.alive(ENTITY);

    @Test
    public void factoriesProduceConsistentResults() {
        assertEquals(RespawnLifecycleOutcome.APPLIED, RespawnLifecycleResult.applied(STATE).outcome(), "applied");
        assertEquals(RespawnLifecycleOutcome.DUPLICATE, RespawnLifecycleResult.duplicate(STATE).outcome(), "duplicate");
        RespawnLifecycleResult denied = RespawnLifecycleResult.denied(STATE, RespawnDenialReason.ENTITY_ALIVE);
        assertEquals(Optional.of(RespawnDenialReason.ENTITY_ALIVE), denied.denialReason(), "denial reason");
        assertEquals(Optional.of("why"), RespawnLifecycleResult.rejected(STATE, "why").detail(), "rejection detail");
        assertEquals(Optional.of("boom"), RespawnLifecycleResult.executionFailed(STATE, "boom").detail(), "failure detail");
        RespawnExecutionRequest request = new RespawnExecutionRequest(ENTITY, POINT, T);
        assertEquals(Optional.of(request), RespawnLifecycleResult.applied(STATE, request).executionRequest(), "request");
        EntityRespawned event = new EntityRespawned(ENTITY, POINT, T);
        assertEquals(List.of(event), RespawnLifecycleResult.applied(STATE, event).events(), "event");
    }

    @Test
    public void detailsMustMatchTheOutcome() {
        assertThrows(IllegalArgumentException.class, () -> new RespawnLifecycleResult(STATE,
                RespawnLifecycleOutcome.APPLIED, Optional.of(RespawnDenialReason.ENTITY_ALIVE), Optional.empty(),
                Optional.empty(), List.of()), "a denial reason on APPLIED");
        assertThrows(IllegalArgumentException.class, () -> new RespawnLifecycleResult(STATE,
                RespawnLifecycleOutcome.DENIED, Optional.empty(), Optional.empty(), Optional.empty(), List.of()),
                "DENIED needs a reason");
        assertThrows(IllegalArgumentException.class, () -> new RespawnLifecycleResult(STATE,
                RespawnLifecycleOutcome.REJECTED, Optional.empty(), Optional.empty(), Optional.empty(), List.of()),
                "REJECTED needs a detail");
        assertThrows(IllegalArgumentException.class, () -> RespawnLifecycleResult.rejected(STATE, " "), "blank detail");
        assertThrows(IllegalArgumentException.class, () -> new RespawnLifecycleResult(STATE,
                RespawnLifecycleOutcome.DUPLICATE, Optional.empty(), Optional.empty(), Optional.empty(),
                List.of(new EntityRespawned(ENTITY, POINT, T))), "a duplicate can never carry an event");
        assertThrows(IllegalArgumentException.class, () -> new RespawnLifecycleResult(STATE,
                RespawnLifecycleOutcome.EXECUTION_FAILED, Optional.empty(), Optional.of("x"),
                Optional.of(new RespawnExecutionRequest(ENTITY, POINT, T)), List.of()), "a failure carries no request");
    }

    @Test
    public void eventsAreCopiedAndImmutable() {
        List<EntityRespawned> events = new ArrayList<>(List.of(new EntityRespawned(ENTITY, POINT, T)));
        RespawnLifecycleResult result = new RespawnLifecycleResult(STATE, RespawnLifecycleOutcome.APPLIED,
                Optional.empty(), Optional.empty(), Optional.empty(), events);
        events.clear();
        assertEquals(1, result.events().size(), "caller's list mutation does not leak in");
        assertThrows(UnsupportedOperationException.class, () -> result.events().clear(), "exposed list is immutable");
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.applied((RespawnLifecycleState) null), "state");
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.applied(STATE, (RespawnExecutionRequest) null), "request");
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.applied(STATE, (EntityRespawned) null), "event");
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.denied(STATE, null), "reason");
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.rejected(STATE, null), "detail");
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.executionFailed(STATE, null), "reason");
        assertThrows(NullPointerException.class, () -> RespawnLifecycleResult.duplicate(null), "state");
    }
}
