package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.HealthSnapshot;
import combat.domain.Health;
import core.contracts.IPersistenceGateway;
import core.contracts.PersistenceException;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.PlayerId;
import core.services.InMemoryPersistenceGateway;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class HealthStoreTest {

    private static final EntityRef PLAYER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef MOB = EntityRef.of(EntityKind.NPC, EntityId.random());
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    /** Mirrors RespawnLifecycleStoreTest's FlakyGateway. */
    private static class FlakyGateway implements IPersistenceGateway {
        final IPersistenceGateway delegate;
        boolean failReads;
        boolean failWrites;

        FlakyGateway(IPersistenceGateway delegate) {
            this.delegate = delegate;
        }

        @Override
        public <T> void save(String collection, String key, T value) {
            if (failWrites) {
                throw new PersistenceException("simulated write failure");
            }
            delegate.save(collection, key, value);
        }

        @Override
        public <T> Optional<T> load(String collection, String key, Class<T> type) {
            if (failReads) {
                throw new PersistenceException("simulated read failure");
            }
            return delegate.load(collection, key, type);
        }

        @Override
        public void delete(String collection, String key) {
            delegate.delete(collection, key);
        }

        @Override
        public <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
            return delegate.query(collection, type, filter);
        }
    }

    private static HealthStore store(IPersistenceGateway gateway) {
        return new HealthStore(gateway, Clock.fixed(T, ZoneOffset.UTC));
    }

    private static String key(EntityRef e) {
        return e.kind().name() + ":" + e.id();
    }

    // ---- save / load / round trip -----------------------------------------------------------

    @Test
    public void firstSaveThenLoadRoundTrips() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        assertEquals(new HealthSaveResult.Saved(PLAYER, 1), store.save(PLAYER, Health.full(20), 0), "first save is revision 1");
        assertEquals(new HealthLoadResult.Loaded(PLAYER, Health.full(20), 1), store.load(PLAYER), "loads back equal");
    }

    @Test
    public void partialAndZeroHealthRoundTrip() {
        for (Health h : List.of(Health.full(20), new Health(10, 20), new Health(0, 20))) {
            HealthStore store = store(new InMemoryPersistenceGateway());
            store.save(PLAYER, h, 0);
            HealthLoadResult.Loaded loaded = (HealthLoadResult.Loaded) store.load(PLAYER);
            assertEquals(h, loaded.health(), "round trip for " + h);
        }
    }

    @Test
    public void loadOfAnUnknownEntityIsNotFoundNotAnError() {
        assertEquals(new HealthLoadResult.NotFound(PLAYER), store(new InMemoryPersistenceGateway()).load(PLAYER),
                "missing entity");
    }

    @Test
    public void entitiesAreStoredIndependently() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        store.save(PLAYER, new Health(5, 20), 0);
        store.save(MOB, new Health(40, 40), 0);
        assertEquals(5.0, ((HealthLoadResult.Loaded) store.load(PLAYER)).health().current(), "player");
        assertEquals(40.0, ((HealthLoadResult.Loaded) store.load(MOB)).health().current(), "mob");
    }

    @Test
    public void savedAtComesFromTheInjectedClock() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        store(gateway).save(PLAYER, Health.full(20), 0);
        HealthSnapshot stored = gateway.load(HealthStore.COLLECTION, key(PLAYER), HealthSnapshot.class).orElseThrow();
        assertEquals(T, stored.savedAt(), "timestamp");
        assertEquals(HealthSnapshot.CURRENT_SCHEMA_VERSION, stored.schemaVersion(), "schema written");
        assertEquals(1L, stored.revision(), "revision written");
    }

    // ---- versioning ---------------------------------------------------------------------------

    @Test
    public void revisionsIncreaseByOnePerSave() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        assertEquals(new HealthSaveResult.Saved(PLAYER, 1), store.save(PLAYER, Health.full(20), 0), "1");
        assertEquals(new HealthSaveResult.Saved(PLAYER, 2), store.save(PLAYER, new Health(15, 20), 1), "2");
        assertEquals(new HealthSaveResult.Saved(PLAYER, 3), store.save(PLAYER, new Health(5, 20), 2), "3");
        assertEquals(3L, ((HealthLoadResult.Loaded) store.load(PLAYER)).revision(), "loaded revision matches");
    }

    @Test
    public void staleWriterGetsAVersionConflictAndNothingIsWritten() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        store.save(PLAYER, Health.full(20), 0);
        store.save(PLAYER, new Health(10, 20), 1);
        HealthSaveResult result = store.save(PLAYER, new Health(1, 20), 1);
        assertEquals(new HealthSaveResult.VersionConflict(PLAYER, 1, 2), result, "stale revision 1, actual 2");
        assertEquals(10.0, ((HealthLoadResult.Loaded) store.load(PLAYER)).health().current(), "stored value untouched");
    }

    @Test
    public void creatingOverAnExistingRecordConflicts() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        store.save(PLAYER, Health.full(20), 0);
        assertEquals(new HealthSaveResult.VersionConflict(PLAYER, 0, 1), store.save(PLAYER, Health.full(20), 0),
                "expected nothing, found revision 1");
    }

    @Test
    public void updatingSomethingThatDoesNotExistConflicts() {
        assertEquals(new HealthSaveResult.VersionConflict(PLAYER, 5, 0),
                store(new InMemoryPersistenceGateway()).save(PLAYER, Health.full(20), 5), "expected 5, nothing stored");
    }

    @Test
    public void aFutureRevisionCannotBeSkippedTo() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        store.save(PLAYER, Health.full(20), 0);
        assertTrue(store.save(PLAYER, new Health(10, 20), 7) instanceof HealthSaveResult.VersionConflict,
                "revision must match exactly");
    }

    @Test
    public void twoRacingDamageApplicationsCannotBothBeSaved() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        HealthStore store = store(gateway);
        store.save(PLAYER, Health.full(20), 0);

        HealthLoadResult.Loaded callerA = (HealthLoadResult.Loaded) store.load(PLAYER);
        HealthLoadResult.Loaded callerB = (HealthLoadResult.Loaded) store.load(PLAYER);

        assertEquals(new HealthSaveResult.Saved(PLAYER, 2), store.save(PLAYER, new Health(15, 20), callerA.revision()),
                "first commit wins");
        assertTrue(store.save(PLAYER, new Health(12, 20), callerB.revision()) instanceof HealthSaveResult.VersionConflict,
                "the second, based on a stale read, is refused");
    }

    @Test
    public void negativeExpectedRevisionIsAProgrammingError() {
        assertThrows(IllegalArgumentException.class, () -> store(new InMemoryPersistenceGateway()).save(PLAYER, Health.full(20), -1),
                "negative expectedRevision");
    }

    // ---- failure semantics --------------------------------------------------------------------

    @Test
    public void writeFailureThrowsAndStoresNothing() {
        FlakyGateway gateway = new FlakyGateway(new InMemoryPersistenceGateway());
        HealthStore store = store(gateway);
        gateway.failWrites = true;
        assertThrows(PersistenceException.class, () -> store.save(PLAYER, Health.full(20), 0),
                "a failed save must not look like success");
        gateway.failWrites = false;
        assertEquals(new HealthLoadResult.NotFound(PLAYER), store.load(PLAYER), "nothing was stored");
    }

    @Test
    public void readFailureOnLoadIsFailedNeverNotFound() {
        FlakyGateway gateway = new FlakyGateway(new InMemoryPersistenceGateway());
        HealthStore store = store(gateway);
        store.save(PLAYER, Health.full(20), 0);
        gateway.failReads = true;
        HealthLoadResult result = store.load(PLAYER);
        assertTrue(result instanceof HealthLoadResult.Failed, "an outage is a failure, not 'not found' or data loss");
        assertTrue(((HealthLoadResult.Failed) result).cause() instanceof PersistenceException, "cause preserved");
    }

    @Test
    public void readFailureOnSavePropagates() {
        FlakyGateway gateway = new FlakyGateway(new InMemoryPersistenceGateway());
        gateway.failReads = true;
        assertThrows(PersistenceException.class, () -> store(gateway).save(PLAYER, Health.full(20), 0),
                "cannot verify the revision, so cannot save — and says so");
    }

    @Test
    public void wrongTypeInTheStoreIsFailedNotACrash() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(HealthStore.COLLECTION, key(PLAYER), "not a snapshot");
        assertTrue(store(gateway).load(PLAYER) instanceof HealthLoadResult.Failed, "reported, not thrown");
    }

    @Test
    public void programmingErrorsAreNotSwallowedAsLoadFailures() {
        IPersistenceGateway buggy = new FlakyGateway(new InMemoryPersistenceGateway()) {
            @Override
            public <T> Optional<T> load(String collection, String key, Class<T> type) {
                throw new IllegalStateException("bug");
            }
        };
        assertThrows(IllegalStateException.class, () -> store(buggy).load(PLAYER), "only PersistenceException is translated");
    }

    // ---- invalid / incompatible stored data ---------------------------------------------------

    private static InMemoryPersistenceGateway gatewayHolding(HealthSnapshot snapshot) {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(HealthStore.COLLECTION, key(PLAYER), snapshot);
        return gateway;
    }

    @Test
    public void invalidStoredSnapshotsAreReportedAsCorruptWithTheirReason() {
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES, corruptReason(
                new HealthSnapshot(1, 1, PLAYER, 99, 20, T)), "current above max");
        assertEquals(HealthRecoveryFailure.INVALID_TIMESTAMP, corruptReason(
                new HealthSnapshot(1, 1, PLAYER, 10, 20, Instant.parse("1900-01-01T00:00:00Z"))), "bad time");
        assertEquals(HealthRecoveryFailure.INVALID_REVISION, corruptReason(
                new HealthSnapshot(1, 0, PLAYER, 10, 20, T)), "bad revision");
    }

    private static HealthRecoveryFailure corruptReason(HealthSnapshot bad) {
        HealthLoadResult result = store(gatewayHolding(bad)).load(PLAYER);
        assertTrue(result instanceof HealthLoadResult.Corrupt, "corrupt: " + result);
        return ((HealthLoadResult.Corrupt) result).reason();
    }

    @Test
    public void incompatibleSchemaVersionIsCorruptNotGuessed() {
        assertEquals(HealthRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION, corruptReason(
                new HealthSnapshot(2, 1, PLAYER, 10, 20, T)), "a newer schema is not interpreted");
    }

    @Test
    public void aSnapshotUnderTheWrongKeyIsAnIdentityMismatch() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(HealthStore.COLLECTION, key(PLAYER), new HealthSnapshot(1, 1, MOB, 10, 20, T));
        HealthLoadResult result = store(gateway).load(PLAYER);
        assertEquals(HealthRecoveryFailure.IDENTITY_MISMATCH, ((HealthLoadResult.Corrupt) result).reason(),
                "PLAYER's key must never hand back the mob's health");
    }

    @Test
    public void unreadableExistingRecordsAreNeverOverwritten() {
        HealthSnapshot newer = new HealthSnapshot(2, 1, PLAYER, 10, 20, T);
        InMemoryPersistenceGateway gateway = gatewayHolding(newer);
        HealthStore store = store(gateway);
        assertEquals(new HealthSaveResult.Blocked(PLAYER, HealthRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION),
                store.save(PLAYER, Health.full(20), 1), "saving over data from a newer schema is refused");
        assertEquals(new HealthSaveResult.Blocked(PLAYER, HealthRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION),
                store.save(PLAYER, Health.full(20), 0), "whatever revision the caller claims");
        assertEquals(Optional.of(newer), gateway.load(HealthStore.COLLECTION, key(PLAYER), HealthSnapshot.class),
                "the stored record is byte-for-byte what it was");
    }

    @Test
    public void aMismatchedStoredIdentityBlocksSaving() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(HealthStore.COLLECTION, key(PLAYER), new HealthSnapshot(1, 1, MOB, 10, 20, T));
        assertEquals(new HealthSaveResult.Blocked(PLAYER, HealthRecoveryFailure.IDENTITY_MISMATCH),
                store(gateway).save(PLAYER, Health.full(20), 1), "blocked");
    }

    @Test
    public void discardIsTheExplicitWayOutOfABlockedRecord() {
        InMemoryPersistenceGateway gateway = gatewayHolding(new HealthSnapshot(1, 1, PLAYER, 99, 20, T));
        HealthStore store = store(gateway);
        assertTrue(store.save(PLAYER, Health.full(20), 1) instanceof HealthSaveResult.Blocked, "blocked while corrupt");
        store.discard(PLAYER);
        assertEquals(new HealthLoadResult.NotFound(PLAYER), store.load(PLAYER), "gone");
        assertEquals(new HealthSaveResult.Saved(PLAYER, 1), store.save(PLAYER, Health.full(20), 0), "a fresh record can be created");
    }

    @Test
    public void discardingSomethingAbsentIsHarmless() {
        store(new InMemoryPersistenceGateway()).discard(PLAYER);
    }

    // ---- determinism, immutability, no leakage -------------------------------------------------

    @Test
    public void recoveryIsDeterministicAcrossLoadsAndStoreInstances() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        store(gateway).save(PLAYER, new Health(13, 20), 0);
        HealthLoadResult first = store(gateway).load(PLAYER);
        assertEquals(first, store(gateway).load(PLAYER), "another store instance over the same data");
        assertEquals(first, store(gateway).load(PLAYER), "and again");
    }

    @Test
    public void storeHoldsOnlySnapshotsNeverDomainObjects() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        store(gateway).save(PLAYER, Health.full(20), 0);
        assertTrue(gateway.query(HealthStore.COLLECTION, Object.class, o -> true).stream()
                        .allMatch(o -> o instanceof HealthSnapshot),
                "the gateway only ever sees HealthSnapshot");
    }

    @Test
    public void nullValidation() {
        HealthStore store = store(new InMemoryPersistenceGateway());
        assertThrows(NullPointerException.class, () -> new HealthStore(null), "gateway");
        assertThrows(NullPointerException.class, () -> new HealthStore(new InMemoryPersistenceGateway(), null), "clock");
        assertThrows(NullPointerException.class, () -> store.load(null), "load entity");
        assertThrows(NullPointerException.class, () -> store.save(null, Health.full(20), 0), "save entity");
        assertThrows(NullPointerException.class, () -> store.save(PLAYER, null, 0), "save health");
        assertThrows(NullPointerException.class, () -> store.discard(null), "discard entity");
        assertThrows(NullPointerException.class, () -> new HealthLoadResult.Loaded(null, Health.full(20), 1), "loaded entity");
        assertThrows(NullPointerException.class, () -> new HealthLoadResult.Failed(PLAYER, "x", null), "failed cause");
        assertThrows(NullPointerException.class, () -> new HealthSaveResult.Blocked(PLAYER, null), "blocked reason");
    }

    @Test
    public void resultTypesRejectInconsistentValues() {
        assertThrows(IllegalArgumentException.class, () -> new HealthLoadResult.Loaded(PLAYER, Health.full(20), 0), "revision >= 1");
        assertThrows(IllegalArgumentException.class, () -> new HealthSaveResult.Saved(PLAYER, 0), "saved revision >= 1");
        assertThrows(IllegalArgumentException.class, () -> new HealthSaveResult.VersionConflict(PLAYER, 2, 2),
                "equal revisions are not a conflict");
        assertThrows(IllegalArgumentException.class, () -> new HealthSaveResult.VersionConflict(PLAYER, -1, 2), "no negatives");
    }
}
