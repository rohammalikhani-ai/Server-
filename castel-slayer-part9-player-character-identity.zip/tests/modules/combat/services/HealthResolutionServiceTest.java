package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.HealthSnapshot;
import combat.domain.Health;
import core.contracts.IPersistenceGateway;
import core.contracts.PersistenceException;
import core.domain.EntityRef;
import core.domain.PlayerId;
import core.services.InMemoryPersistenceGateway;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class HealthResolutionServiceTest {

    private static final EntityRef PLAYER = EntityRef.ofPlayer(PlayerId.random());
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");

    private static HealthStore store(IPersistenceGateway gateway) {
        return new HealthStore(gateway, Clock.fixed(T, ZoneOffset.UTC));
    }

    @Test
    public void resolvesAKnownEntityWithValidHealth() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        HealthStore store = store(gateway);
        store.save(PLAYER, new Health(12, 20), 0);

        HealthResolutionResult result = new HealthResolutionService(store).resolve(PLAYER);
        assertEquals(new HealthResolutionResult.Resolved(PLAYER, new Health(12, 20)), result, "resolved");
    }

    @Test
    public void unknownEntityIsExplicitNotFoundNeverADefaultHealth() {
        HealthResolutionResult result = new HealthResolutionService(store(new InMemoryPersistenceGateway())).resolve(PLAYER);
        assertEquals(new HealthResolutionResult.NotFound(PLAYER), result, "not found");
        assertFalse(result instanceof HealthResolutionResult.Resolved, "never silently defaulted to a Health");
    }

    @Test
    public void corruptStoredStateIsReportedAsCorrupt() {
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        gateway.save(HealthStore.COLLECTION, PLAYER.kind().name() + ":" + PLAYER.id(),
                new HealthSnapshot(1, 1, PLAYER, 999, 20, T));
        HealthResolutionResult result = new HealthResolutionService(store(gateway)).resolve(PLAYER);
        assertTrue(result instanceof HealthResolutionResult.Corrupt, "corrupt: " + result);
        assertEquals(HealthRecoveryFailure.INVALID_HEALTH_VALUES, ((HealthResolutionResult.Corrupt) result).reason(), "reason");
    }

    @Test
    public void storeOutageIsReportedAsFailed() {
        IPersistenceGateway flaky = new IPersistenceGateway() {
            final InMemoryPersistenceGateway delegate = new InMemoryPersistenceGateway();

            @Override
            public <T> void save(String collection, String key, T value) {
                delegate.save(collection, key, value);
            }

            @Override
            public <T> Optional<T> load(String collection, String key, Class<T> type) {
                throw new PersistenceException("simulated outage");
            }

            @Override
            public void delete(String collection, String key) {
                delegate.delete(collection, key);
            }

            @Override
            public <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
                return delegate.query(collection, type, filter);
            }
        };
        HealthResolutionResult result = new HealthResolutionService(store(flaky)).resolve(PLAYER);
        assertTrue(result instanceof HealthResolutionResult.Failed, "failed: " + result);
        assertTrue(((HealthResolutionResult.Failed) result).cause() instanceof PersistenceException, "cause preserved");
    }

    @Test
    public void theFourCasesAreNeverConflated() {
        // Sanity: all four are distinct sealed-interface cases with no overlap in a switch.
        InMemoryPersistenceGateway gateway = new InMemoryPersistenceGateway();
        HealthStore store = store(gateway);
        HealthResolutionService service = new HealthResolutionService(store);

        assertTrue(service.resolve(PLAYER) instanceof HealthResolutionResult.NotFound, "not found first");
        store.save(PLAYER, Health.full(20), 0);
        assertTrue(service.resolve(PLAYER) instanceof HealthResolutionResult.Resolved, "then resolved");
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> new HealthResolutionService(null), "store");
        assertThrows(NullPointerException.class,
                () -> new HealthResolutionService(store(new InMemoryPersistenceGateway())).resolve(null), "entity");
    }
}
