package combat.services;

import support.Test;
import static support.Assertions.*;

import combat.contracts.IRespawnPointProvider;
import combat.contracts.RespawnDecision;
import combat.contracts.RespawnDenialReason;
import combat.contracts.RespawnPoint;
import combat.contracts.RespawnRequest;
import combat.domain.DamageResult;
import combat.domain.DamageType;
import combat.domain.Health;
import combat.domain.RespawnEligibility;
import core.domain.EntityId;
import core.domain.EntityKind;
import core.domain.EntityRef;
import core.domain.Location;
import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public class RespawnDecisionServiceTest {

    private static final EntityRef PLAYER = EntityRef.ofPlayer(PlayerId.random());
    private static final EntityRef NPC = EntityRef.of(EntityKind.NPC, EntityId.random());
    private static final EntityRef PROJECTILE = EntityRef.of(EntityKind.PROJECTILE, EntityId.random());
    private static final RespawnPoint POINT = new RespawnPoint(new Location(WorldId.of("overworld"), 0, 64, 0));
    private static final Instant T = Instant.parse("2026-01-01T00:00:00Z");
    private static final Health DEAD = new Health(0, 20);
    private static final Health ALIVE = Health.full(20);

    private static RespawnDecisionService service(IRespawnPointProvider provider, EntityKind... kinds) {
        return new RespawnDecisionService(provider, Set.of(kinds));
    }

    private static RespawnRequest request(EntityRef entity) {
        return new RespawnRequest(entity, T);
    }

    @Test
    public void deadRespawnableEntityWithDestinationIsGranted() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        RespawnDecision decision = service.decide(request(PLAYER), DEAD);
        assertEquals(new RespawnDecision.Granted(PLAYER, POINT, T), decision, "granted with the provider's point");
    }

    @Test
    public void livingEntityIsDeniedAsAlive() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        assertEquals(new RespawnDecision.Denied(PLAYER, RespawnDenialReason.ENTITY_ALIVE, T),
                service.decide(request(PLAYER), ALIVE), "a living entity cannot be respawned as if dead");
    }

    @Test
    public void oneHitPointLeftIsStillAlive() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        assertEquals(new RespawnDecision.Denied(PLAYER, RespawnDenialReason.ENTITY_ALIVE, T),
                service.decide(request(PLAYER), new Health(0.5, 20)), "alive iff current > 0");
    }

    @Test
    public void nonRespawnableKindIsDenied() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        assertEquals(new RespawnDecision.Denied(PROJECTILE, RespawnDenialReason.KIND_NOT_RESPAWNABLE, T),
                service.decide(request(PROJECTILE), DEAD), "projectiles are not configured as respawnable");
    }

    @Test
    public void nonPlayerKindsCanBeRespawnableWhenConfigured() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.NPC);
        assertEquals(new RespawnDecision.Granted(NPC, POINT, T), service.decide(request(NPC), DEAD),
                "no player assumption: an NPC respawns when NPC is configured");
        assertEquals(new RespawnDecision.Denied(PLAYER, RespawnDenialReason.KIND_NOT_RESPAWNABLE, T),
                service.decide(request(PLAYER), DEAD), "and a player does not when PLAYER is not configured");
    }

    @Test
    public void emptyRespawnableSetMeansNobodyRespawns() {
        RespawnDecisionService service = new RespawnDecisionService(e -> Optional.of(POINT), Set.of());
        assertEquals(RespawnDenialReason.KIND_NOT_RESPAWNABLE,
                ((RespawnDecision.Denied) service.decide(request(PLAYER), DEAD)).reason(), "nobody is eligible");
    }

    @Test
    public void missingDestinationIsDeniedNotGranted() {
        RespawnDecisionService service = service(e -> Optional.empty(), EntityKind.PLAYER);
        assertEquals(new RespawnDecision.Denied(PLAYER, RespawnDenialReason.NO_RESPAWN_POINT, T),
                service.decide(request(PLAYER), DEAD), "eligible but no destination");
    }

    @Test
    public void providerIsNotConsultedForIneligibleEntities() {
        AtomicInteger calls = new AtomicInteger();
        RespawnDecisionService service = service(e -> {
            calls.incrementAndGet();
            return Optional.of(POINT);
        }, EntityKind.PLAYER);
        service.decide(request(PLAYER), ALIVE);
        service.decide(request(PROJECTILE), DEAD);
        assertEquals(0, calls.get(), "eligibility is decided before destinations are looked up");
        service.decide(request(PLAYER), DEAD);
        assertEquals(1, calls.get(), "consulted exactly once for an eligible entity");
    }

    @Test
    public void providerIsAskedAboutTheRequestedEntity() {
        Set<EntityRef> asked = new HashSet<>();
        service(e -> {
            asked.add(e);
            return Optional.of(POINT);
        }, EntityKind.PLAYER).decide(request(PLAYER), DEAD);
        assertEquals(Set.of(PLAYER), asked, "the provider sees only the requested entity");
    }

    @Test
    public void evaluateEligibilityAndResolveDestinationWorkSeparately() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        assertEquals(RespawnEligibility.eligible(PLAYER), service.evaluateEligibility(PLAYER, DEAD), "eligible");
        assertEquals(RespawnEligibility.ineligible(PLAYER, RespawnDenialReason.ENTITY_ALIVE),
                service.evaluateEligibility(PLAYER, ALIVE), "alive");
        assertEquals(Optional.of(POINT), service.resolveDestination(PLAYER), "destination");
    }

    @Test
    public void aliveWinsOverKindWhenBothApply() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        assertEquals(RespawnDenialReason.ENTITY_ALIVE,
                service.evaluateEligibility(PROJECTILE, ALIVE).denialReason().orElseThrow(),
                "a fixed, documented precedence: alive is checked first");
    }

    @Test
    public void decisionsAreDeterministic() {
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        RespawnDecision first = service.decide(request(PLAYER), DEAD);
        for (int i = 0; i < 20; i++) {
            assertEquals(first, service.decide(request(PLAYER), DEAD), "same inputs, same decision, every time");
        }
        assertEquals(first, service(e -> Optional.of(POINT), EntityKind.PLAYER).decide(request(PLAYER), DEAD),
                "and across separate service instances");
    }

    @Test
    public void decidedAtComesFromTheRequestNotAClock() {
        Instant other = Instant.parse("2030-06-01T12:00:00Z");
        RespawnDecision decision = service(e -> Optional.of(POINT), EntityKind.PLAYER)
                .decide(new RespawnRequest(PLAYER, other), DEAD);
        assertEquals(other, decision.decidedAt(), "no clock is read");
    }

    @Test
    public void respawnableKindsAreCopiedDefensively() {
        Set<EntityKind> kinds = new HashSet<>(Set.of(EntityKind.PLAYER));
        RespawnDecisionService service = new RespawnDecisionService(e -> Optional.of(POINT), kinds);
        kinds.clear();
        kinds.add(EntityKind.NPC);
        assertTrue(service.decide(request(PLAYER), DEAD) instanceof RespawnDecision.Granted,
                "later mutation of the caller's set cannot change the service");
        assertTrue(service.decide(request(NPC), DEAD) instanceof RespawnDecision.Denied, "nor add kinds");
    }

    @Test
    public void servicesHoldNoSharedState() {
        RespawnDecisionService players = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        RespawnDecisionService npcs = service(e -> Optional.empty(), EntityKind.NPC);
        assertTrue(players.decide(request(PLAYER), DEAD) instanceof RespawnDecision.Granted, "players service");
        assertTrue(npcs.decide(request(PLAYER), DEAD) instanceof RespawnDecision.Denied, "independent config");
        assertTrue(players.decide(request(PLAYER), DEAD) instanceof RespawnDecision.Granted,
                "unaffected by the other instance");
    }

    @Test
    public void providerFailureIsNotSwallowed() {
        RespawnDecisionService service = service(e -> {
            throw new IllegalStateException("provider down");
        }, EntityKind.PLAYER);
        assertThrows(IllegalStateException.class, () -> service.decide(request(PLAYER), DEAD),
                "a failing provider must not look like a denial");
    }

    @Test
    public void nullOptionalFromProviderFailsFast() {
        RespawnDecisionService service = service(e -> null, EntityKind.PLAYER);
        assertThrows(NullPointerException.class, () -> service.decide(request(PLAYER), DEAD),
                "the provider contract is Optional, never null");
    }

    @Test
    public void nullValidation() {
        assertThrows(NullPointerException.class, () -> new RespawnDecisionService(null, Set.of()), "provider");
        assertThrows(NullPointerException.class, () -> new RespawnDecisionService(e -> Optional.empty(), null), "kinds");
        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        assertThrows(NullPointerException.class, () -> service.decide(null, DEAD), "request");
        assertThrows(NullPointerException.class, () -> service.decide(request(PLAYER), null), "health");
        assertThrows(NullPointerException.class, () -> service.evaluateEligibility(null, DEAD), "entity");
        assertThrows(NullPointerException.class, () -> service.evaluateEligibility(PLAYER, null), "health");
        assertThrows(NullPointerException.class, () -> service.resolveDestination(null), "entity");
    }

    @Test
    public void fullPipelineFromLethalDamageThroughEntityDiedToDecision() {
        DamageApplicationService damage = new DamageApplicationService(Clock.fixed(T, ZoneOffset.UTC));
        DamageResult lethal = new DamageResult(NPC, PLAYER, DamageType.PHYSICAL, 50);
        DamageApplicationResult applied = damage.applyDetectingDeath(lethal, ALIVE);
        assertEquals(1, applied.events().size(), "exactly one EntityDied");

        RespawnDecisionService service = service(e -> Optional.of(POINT), EntityKind.PLAYER);
        RespawnDecision decision = service.decide(RespawnRequest.from(applied.events().get(0)), applied.health());
        assertEquals(new RespawnDecision.Granted(PLAYER, POINT, T), decision,
                "Damage -> Health dead -> EntityDied -> RespawnRequest -> RespawnDecision");
    }

    @Test
    public void nonLethalDamageProducesNoDeathSoNothingToRespawn() {
        DamageApplicationService damage = new DamageApplicationService(Clock.fixed(T, ZoneOffset.UTC));
        DamageApplicationResult applied = damage.applyDetectingDeath(
                new DamageResult(NPC, PLAYER, DamageType.PHYSICAL, 5), ALIVE);
        assertTrue(applied.events().isEmpty(), "no EntityDied");
        RespawnDecision decision = service(e -> Optional.of(POINT), EntityKind.PLAYER)
                .decide(new RespawnRequest(PLAYER, T), applied.health());
        assertEquals(RespawnDenialReason.ENTITY_ALIVE, ((RespawnDecision.Denied) decision).reason(),
                "a mistaken request for a survivor is denied");
    }
}
