package progression.domain;

import support.Test;
import static support.Assertions.*;

import java.util.EnumMap;
import java.util.Map;

public class CharacterAttributesTest {

    private static Map<AttributeType, Integer> allTens() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 10);
        }
        return values;
    }

    @Test
    public void initialBaseValuesAreStoredExactly() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        assertEquals(10, attributes.baseValue(AttributeType.STRENGTH), "Strength base value");
        assertEquals(10, attributes.baseValue(AttributeType.LUCK), "Luck base value");
    }

    @Test
    public void missingAttributeTypeIsRejected() {
        Map<AttributeType, Integer> incomplete = new EnumMap<>(AttributeType.class);
        incomplete.put(AttributeType.STRENGTH, 10);
        // every other AttributeType intentionally omitted

        assertThrows(IllegalArgumentException.class, () -> new CharacterAttributes(incomplete),
                "Constructing with a missing attribute type should throw");
    }

    @Test
    public void outOfRangeBaseValueIsRejected() {
        Map<AttributeType, Integer> values = new EnumMap<>(allTens());
        values.put(AttributeType.STRENGTH, -1);

        assertThrows(IllegalArgumentException.class, () -> new CharacterAttributes(values),
                "Negative base value should throw");
    }

    @Test
    public void effectiveValueWithNoModifiersEqualsBaseValue() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        assertEquals(10, attributes.effectiveValue(AttributeType.STRENGTH), "Effective value with no modifiers");
    }

    @Test
    public void flatModifierIsAddedToBaseValue() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        attributes.addModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.STRENGTH, ModifierOperation.FLAT, 5));

        assertEquals(15, attributes.effectiveValue(AttributeType.STRENGTH), "Strength after +5 flat modifier");
    }

    @Test
    public void percentModifierAppliesAfterFlatModifiers() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        attributes.addModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.STRENGTH, ModifierOperation.FLAT, 10));
        attributes.addModifier(new AttributeModifier("m2", "buff:might", AttributeType.STRENGTH, ModifierOperation.PERCENT_ADDITIVE, 50));

        // base 10 + flat 10 = 20, then *1.5 = 30
        assertEquals(30, attributes.effectiveValue(AttributeType.STRENGTH), "Strength after flat +10 then +50%");
    }

    @Test
    public void effectiveValueNeverGoesNegative() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        attributes.addModifier(new AttributeModifier("m1", "curse:weaken", AttributeType.STRENGTH, ModifierOperation.FLAT, -1000));

        assertEquals(0, attributes.effectiveValue(AttributeType.STRENGTH), "Effective value floors at zero");
    }

    @Test
    public void duplicateModifierKeyIsRejected() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        attributes.addModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.STRENGTH, ModifierOperation.FLAT, 5));

        assertThrows(IllegalStateException.class,
                () -> attributes.addModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.DEXTERITY, ModifierOperation.FLAT, 1)),
                "Adding a modifier with an already-active source+id should throw");
    }

    @Test
    public void removingUnknownModifierIsRejected() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());

        assertThrows(IllegalStateException.class, () -> attributes.removeModifier("equipment:sword", "m1"),
                "Removing a modifier that was never added should throw");
    }

    @Test
    public void removedModifierNoLongerAffectsEffectiveValue() {
        CharacterAttributes attributes = new CharacterAttributes(allTens());
        attributes.addModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.STRENGTH, ModifierOperation.FLAT, 5));
        attributes.removeModifier("equipment:sword", "m1");

        assertEquals(10, attributes.effectiveValue(AttributeType.STRENGTH), "Strength after modifier removed");
    }
}
