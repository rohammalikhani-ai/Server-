package progression.domain;

import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

public class CharacterStatsProfileTest {

    private static CharacterAttributes newAttributes() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 5);
        }
        return new CharacterAttributes(values);
    }

    @Test
    public void createNewStartsAtInitialProgressionState() {
        CharacterStatsProfile profile = CharacterStatsProfile.createNew(CharacterId.random(), newAttributes());

        assertEquals(ProgressionState.initial(), profile.progression(), "createNew starts at ProgressionState.initial()");
    }

    @Test
    public void reconstituteUsesTheSuppliedProgressionState() {
        CharacterId characterId = CharacterId.random();
        ProgressionState savedState = new ProgressionState(12, 4500);

        CharacterStatsProfile profile = CharacterStatsProfile.reconstitute(characterId, newAttributes(), savedState);

        assertEquals(characterId, profile.characterId(), "characterId round-trips through reconstitute");
        assertEquals(savedState, profile.progression(), "reconstitute preserves the supplied progression state");
    }

    @Test
    public void nullAttributesAreRejected() {
        assertThrows(NullPointerException.class,
                () -> CharacterStatsProfile.createNew(CharacterId.random(), null),
                "Null attributes should throw");
    }

    @Test
    public void emptyCharacterIdIsRejected() {
        // character.contracts.CharacterId requires a non-null UUID value; unlike the
        // C# reference (which rejects Guid.Empty specifically), a UUID has no
        // reserved "empty" sentinel in this codebase's CharacterId — the equivalent
        // invalid-construction case here is a null value, which it does reject.
        assertThrows(NullPointerException.class, () -> new CharacterId((UUID) null),
                "A null UUID is not a valid CharacterId");
    }
}
