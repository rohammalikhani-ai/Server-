package progression.domain;

import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import java.time.Clock;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import progression.contracts.CharacterProgressionSnapshot;
import progression.services.AttributeModifierService;
import progression.services.DefaultProgressionCurve;
import progression.services.LevelingService;

/** The explicit persistence model of {@link CharacterStatsProfile}, and its character ownership. */
public class CharacterStatsProfileSnapshotTest {

    private static CharacterAttributes attributes(int strength) {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 5);
        }
        values.put(AttributeType.STRENGTH, strength);
        return new CharacterAttributes(values);
    }

    @Test
    public void profileIsOwnedByItsCharacterAndSnapshotCarriesIt() {
        CharacterId owner = CharacterId.random();
        CharacterStatsProfile profile = CharacterStatsProfile.createNew(owner, attributes(5));

        assertEquals(owner, profile.characterId(), "The profile is owned by its CharacterId");
        assertEquals(owner, profile.toSnapshot().characterId(), "The snapshot carries the same owner");
        assertThrows(NullPointerException.class, () -> CharacterStatsProfile.createNew(null, attributes(5)),
                "A profile without an owning character cannot exist");
    }

    @Test
    public void snapshotRoundTripPreservesLevelXpAndBaseAttributes() {
        CharacterId owner = CharacterId.random();
        CharacterStatsProfile original = CharacterStatsProfile.createNew(owner, attributes(17));
        new LevelingService(new DefaultProgressionCurve(), Clock.systemUTC()).gainXp(original, 450);

        CharacterStatsProfile restored = CharacterStatsProfile.fromSnapshot(original.toSnapshot());

        assertEquals(owner, restored.characterId(), "Owner survives");
        assertEquals(original.progression(), restored.progression(), "Level and XP survive");
        assertEquals(17, restored.attributes().baseValue(AttributeType.STRENGTH), "Base attributes survive");
        assertEquals(original.toSnapshot(), restored.toSnapshot(), "Snapshots are equal after a round trip");
    }

    @Test
    public void restoredProfileIsIndependentOfTheOriginal() {
        CharacterStatsProfile original = CharacterStatsProfile.createNew(CharacterId.random(), attributes(5));
        CharacterStatsProfile restored = CharacterStatsProfile.fromSnapshot(original.toSnapshot());

        new LevelingService(new DefaultProgressionCurve(), Clock.systemUTC()).gainXp(restored, 1000);

        assertEquals(ProgressionState.initial(), original.progression(), "Changing the restored copy never changes the original");
    }

    @Test
    public void modifiersAreNotPersisted() {
        CharacterStatsProfile profile = CharacterStatsProfile.createNew(CharacterId.random(), attributes(10));
        new AttributeModifierService().applyModifier(profile,
                new AttributeModifier("bonus", "equipment:iron-sword", AttributeType.STRENGTH, ModifierOperation.FLAT, 5));

        CharacterStatsProfile restored = CharacterStatsProfile.fromSnapshot(profile.toSnapshot());

        assertEquals(15, profile.attributes().effectiveValue(AttributeType.STRENGTH), "The live profile has the modifier");
        assertEquals(10, restored.attributes().effectiveValue(AttributeType.STRENGTH),
                "Modifiers belong to their source and are re-applied by it, never stored twice");
        assertTrue(restored.attributes().modifiers().isEmpty(), "No modifiers come back from a snapshot");
    }

    @Test
    public void restoreRejectsUnknownMissingAndOutOfRangeAttributes() {
        CharacterId owner = CharacterId.random();
        Map<String, Integer> complete = new HashMap<>();
        for (AttributeType type : AttributeType.values()) {
            complete.put(type.name(), 5);
        }

        Map<String, Integer> unknown = new HashMap<>(complete);
        unknown.put("CHARISMA", 5);
        assertThrows(IllegalArgumentException.class,
                () -> CharacterStatsProfile.fromSnapshot(new CharacterProgressionSnapshot(owner, 1, 0, unknown)),
                "An unknown attribute name is corrupt data");

        Map<String, Integer> missing = new HashMap<>(complete);
        missing.remove("LUCK");
        assertThrows(IllegalArgumentException.class,
                () -> CharacterStatsProfile.fromSnapshot(new CharacterProgressionSnapshot(owner, 1, 0, missing)),
                "A missing attribute is corrupt data");

        Map<String, Integer> outOfRange = new HashMap<>(complete);
        outOfRange.put("LUCK", 5000);
        assertThrows(IllegalArgumentException.class,
                () -> CharacterStatsProfile.fromSnapshot(new CharacterProgressionSnapshot(owner, 1, 0, outOfRange)),
                "An out-of-range attribute is corrupt data");
    }

    @Test
    public void snapshotRecordRejectsInvalidShape() {
        assertThrows(NullPointerException.class, () -> new CharacterProgressionSnapshot(null, 1, 0, Map.of()), "Owner is mandatory");
        assertThrows(IllegalArgumentException.class, () -> new CharacterProgressionSnapshot(CharacterId.random(), 0, 0, Map.of()), "Level below 1");
        assertThrows(IllegalArgumentException.class, () -> new CharacterProgressionSnapshot(CharacterId.random(), 1, -1, Map.of()), "Negative XP");
    }
}
