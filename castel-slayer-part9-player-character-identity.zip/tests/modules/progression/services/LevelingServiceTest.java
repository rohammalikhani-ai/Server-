package progression.services;

import support.Test;
import static support.Assertions.*;

import character.contracts.CharacterId;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.EnumMap;
import java.util.Map;
import progression.domain.AttributeType;
import progression.domain.CharacterAttributes;
import progression.domain.CharacterStatsProfile;

public class LevelingServiceTest {

    private static final Clock FIXED_CLOCK = Clock.fixed(Instant.parse("2026-01-01T00:00:00Z"), ZoneOffset.UTC);

    private static CharacterAttributes newAttributes() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 5);
        }
        return new CharacterAttributes(values);
    }

    private static CharacterStatsProfile newProfile() {
        return CharacterStatsProfile.createNew(CharacterId.random(), newAttributes());
    }

    private static LevelingService newService(int maxLevel) {
        return new LevelingService(new DefaultProgressionCurve(maxLevel), FIXED_CLOCK);
    }

    private static LevelingService newService() {
        return newService(60);
    }

    @Test
    public void newCharacterStartsAtLevelOneWithZeroXp() {
        CharacterStatsProfile profile = newProfile();
        assertEquals(1, profile.progression().level(), "Initial level");
        assertEquals(0L, profile.progression().totalXp(), "Initial XP");
    }

    @Test
    public void gainingXpBelowNextLevelThresholdDoesNotLevelUp() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService();

        // Level 1 -> 2 costs 100 XP (DefaultProgressionCurve step 1).
        LevelingResult result = service.gainXp(profile, 50);

        assertEquals(1, result.newState().level(), "Level after sub-threshold XP gain");
        assertEquals(50L, result.newState().totalXp(), "TotalXp after sub-threshold XP gain");
        assertEquals(0, result.levelsGained(), "LevelsGained after sub-threshold XP gain");
        assertEquals(0, result.events().size(), "No level-up event should be published");
    }

    @Test
    public void invalidXpAmountIsRejected() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService();

        assertThrows(IllegalArgumentException.class, () -> service.gainXp(profile, 0), "Gaining zero XP should throw");
        assertThrows(IllegalArgumentException.class, () -> service.gainXp(profile, -10), "Gaining negative XP should throw");
    }

    @Test
    public void exactThresholdXpTriggersOneLevelUp() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService();

        // Exactly the cost of level 1 -> 2.
        LevelingResult result = service.gainXp(profile, 100);

        assertEquals(2, result.newState().level(), "Level after exact-threshold XP gain");
        assertEquals(1, result.levelsGained(), "LevelsGained after exact-threshold XP gain");
        assertEquals(1, result.events().size(), "One level-up event expected");
        assertEquals(1, result.events().get(0).fromLevel(), "Event fromLevel");
        assertEquals(2, result.events().get(0).toLevel(), "Event toLevel");
    }

    @Test
    public void oneXpBelowThresholdDoesNotLevelUp() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService();

        LevelingResult result = service.gainXp(profile, 99);

        assertEquals(1, result.newState().level(), "Level one XP below threshold");
        assertEquals(0, result.levelsGained(), "LevelsGained one XP below threshold");
    }

    @Test
    public void largeXpGainCrossesMultipleLevels() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService();

        // Level 1->2 costs 100, 2->3 costs 200 (cumulative 300), 3->4 costs 300 (cumulative 600).
        LevelingResult result = service.gainXp(profile, 650);

        assertEquals(4, result.newState().level(), "Level after large XP gain crossing several thresholds");
        assertEquals(3, result.levelsGained(), "LevelsGained after large XP gain");
        assertEquals(1, result.events().size(), "A multi-level gain still publishes a single summarizing event");
        assertEquals(1, result.events().get(0).fromLevel(), "Multi-level event fromLevel");
        assertEquals(4, result.events().get(0).toLevel(), "Multi-level event toLevel");
        assertEquals(650L, result.newState().totalXp(), "TotalXp is preserved exactly when below the level cap");
    }

    @Test
    public void xpGainAtMaxLevelIsDiscarded() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService(2);

        service.gainXp(profile, 100); // now at level 2 == max level
        LevelingResult result = service.gainXp(profile, 9999);

        assertEquals(2, result.newState().level(), "Level stays at the cap");
        assertEquals(0, result.levelsGained(), "No further levels can be gained at the cap");
        assertEquals(0, result.events().size(), "No level-up event once already at max level");
        assertEquals(100L, result.newState().totalXp(), "TotalXp does not grow once at max level");
    }

    @Test
    public void xpGainThatWouldCrossIntoMaxLevelCapsTotalXp() {
        CharacterStatsProfile profile = newProfile();
        LevelingService service = newService(2);

        // Level 1 -> 2 costs exactly 100; gaining far more than that in one
        // call must still land exactly at the level-2 requirement, not carry
        // the extra 900 forward with nowhere to spend it.
        LevelingResult result = service.gainXp(profile, 1000);

        assertEquals(2, result.newState().level(), "Level caps at maxLevel");
        assertEquals(100L, result.newState().totalXp(), "TotalXp is capped at the max level's requirement");
    }

    @Test
    public void nullProfileIsRejected() {
        LevelingService service = newService();
        assertThrows(NullPointerException.class, () -> service.gainXp(null, 10), "Null profile should throw");
    }
}
