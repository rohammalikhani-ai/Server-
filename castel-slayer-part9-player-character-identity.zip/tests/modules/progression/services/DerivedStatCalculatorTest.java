package progression.services;

import support.Test;
import static support.Assertions.*;

import java.util.EnumMap;
import java.util.Map;
import progression.domain.AttributeModifier;
import progression.domain.AttributeType;
import progression.domain.CharacterAttributes;
import progression.domain.DerivedStatType;
import progression.domain.ModifierOperation;

public class DerivedStatCalculatorTest {

    @Test
    public void derivedStatsAreComputedFromBaseAttributesWithNoModifiers() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        values.put(AttributeType.STRENGTH, 10);
        values.put(AttributeType.DEXTERITY, 4);
        values.put(AttributeType.INTELLIGENCE, 6);
        values.put(AttributeType.VITALITY, 8);
        values.put(AttributeType.WISDOM, 2);
        values.put(AttributeType.LUCK, 3);
        CharacterAttributes attributes = new CharacterAttributes(values);

        Map<DerivedStatType, Integer> derived = new DerivedStatCalculator().calculate(attributes);

        assertEquals(50 + 8 * 10 + 10 * 2, derived.get(DerivedStatType.MAX_HEALTH), "MaxHealth");
        assertEquals(20 + 6 * 8 + 2 * 4, derived.get(DerivedStatType.MAX_MANA), "MaxMana");
        assertEquals(10 * 2 + 4, derived.get(DerivedStatType.PHYSICAL_POWER), "PhysicalPower");
        assertEquals(6 * 2 + 2, derived.get(DerivedStatType.MAGIC_POWER), "MagicPower");
        assertEquals(8 + 10 / 2, derived.get(DerivedStatType.DEFENSE), "Defense");
        assertEquals(4 + 3 / 2, derived.get(DerivedStatType.SPEED), "Speed");
    }

    @Test
    public void derivedStatsReflectActiveModifiers() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 10);
        }
        CharacterAttributes attributes = new CharacterAttributes(values);
        attributes.addModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.STRENGTH, ModifierOperation.FLAT, 10));

        Map<DerivedStatType, Integer> baseline = new DerivedStatCalculator().calculate(attributes);

        // Strength effective value is now 20 instead of 10, so PhysicalPower
        // (2*Strength + Dexterity) must reflect the modifier, not the base value.
        assertEquals(20 * 2 + 10, baseline.get(DerivedStatType.PHYSICAL_POWER), "PhysicalPower reflects modifier");
    }

    @Test
    public void derivedStatsAreNeverNegative() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, 0);
        }
        CharacterAttributes attributes = new CharacterAttributes(values);

        Map<DerivedStatType, Integer> derived = new DerivedStatCalculator().calculate(attributes);

        for (Map.Entry<DerivedStatType, Integer> entry : derived.entrySet()) {
            assertTrue(entry.getValue() >= 0, entry.getKey() + " must not be negative, was " + entry.getValue());
        }
    }
}
