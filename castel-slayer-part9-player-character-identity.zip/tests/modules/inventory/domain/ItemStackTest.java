package inventory.domain;

import inventory.contracts.ItemId;
import support.Test;
import static support.Assertions.*;

public class ItemStackTest {

    private static Item potion(int maxStackSize) {
        return new Item(new ItemId("potion"), maxStackSize);
    }

    private static Item potion() {
        return potion(10);
    }

    @Test
    public void validStackIsCreated() {
        ItemStack stack = new ItemStack(potion(10), 4);

        assertEquals(4, stack.quantity(), "Quantity is kept");
        assertEquals(new ItemId("potion"), stack.item().id(), "Item is kept");
        assertEquals(6, stack.freeSpace(), "freeSpace is maxStackSize - quantity");
    }

    @Test
    public void stackAtExactlyMaxStackSizeIsValid() {
        ItemStack stack = new ItemStack(potion(10), 10);

        assertEquals(0, stack.freeSpace(), "A full stack has no free space");
    }

    @Test
    public void zeroQuantityIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new ItemStack(potion(), 0),
                "Quantity 0 is not a valid stack");
    }

    @Test
    public void negativeQuantityIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new ItemStack(potion(), -3),
                "Negative quantity is not a valid stack");
    }

    @Test
    public void quantityAboveMaxStackSizeIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new ItemStack(potion(10), 11),
                "Quantity above maxStackSize is not a valid stack");
    }

    @Test
    public void nullItemIsRejected() {
        assertThrows(NullPointerException.class, () -> new ItemStack(null, 1),
                "A stack needs an item");
    }

    @Test
    public void invalidMaxStackSizeIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new Item(new ItemId("potion"), 0),
                "maxStackSize 0 is invalid");
        assertThrows(IllegalArgumentException.class, () -> new Item(new ItemId("potion"), -1),
                "Negative maxStackSize is invalid");
    }

    @Test
    public void blankItemIdIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new ItemId("   "),
                "Whitespace ItemId is invalid");
        assertThrows(NullPointerException.class, () -> new ItemId(null),
                "Null ItemId is invalid");
    }
}
