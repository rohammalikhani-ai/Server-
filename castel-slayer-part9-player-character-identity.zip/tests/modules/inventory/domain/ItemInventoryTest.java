package inventory.domain;

import character.contracts.CharacterId;
import inventory.contracts.ItemId;
import support.Test;
import static support.Assertions.*;

public class ItemInventoryTest {

    private static final CharacterId OWNER = CharacterId.random();

    private static final ItemId POTION_ID = new ItemId("potion");
    private static final ItemId ARROW_ID = new ItemId("arrow");

    private static Item potion(int maxStackSize) {
        return new Item(POTION_ID, maxStackSize);
    }

    private static Item potion() {
        return potion(10);
    }

    private static Item arrow(int maxStackSize) {
        return new Item(ARROW_ID, maxStackSize);
    }

    @Test
    public void inventoryIsCreatedWithTheGivenCapacity() {
        ItemInventory inventory = new ItemInventory(OWNER, 5);

        assertEquals(5, inventory.capacity(), "Capacity matches the constructor argument");
        assertEquals(5, inventory.slots().size(), "One slot per unit of capacity");
        for (InventorySlot slot : inventory.slots()) {
            assertTrue(slot.isEmpty(), "A new inventory starts with every slot empty");
        }
    }

    @Test
    public void zeroOrNegativeCapacityIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new ItemInventory(OWNER, 0), "Capacity 0 is invalid");
        assertThrows(IllegalArgumentException.class, () -> new ItemInventory(OWNER, -1), "Negative capacity is invalid");
    }

    @Test
    public void addItemPlacesItIntoAnEmptySlot() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);

        AddItemResult result = inventory.addItem(potion(), 4);

        assertTrue(result.isFullyAdded(), "Everything fits");
        assertEquals(4, result.addedQuantity(), "All four were added");
        assertEquals(0, result.remainingQuantity(), "Nothing left over");
        assertEquals(4, inventory.slot(0).stack().quantity(), "The first empty slot received the stack");
        assertTrue(inventory.slot(1).isEmpty(), "No other slot was touched");
    }

    @Test
    public void addItemFillsAnExistingStackUpToMaxStackSize() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);
        inventory.addItem(potion(10), 6);

        AddItemResult result = inventory.addItem(potion(10), 4);

        assertTrue(result.isFullyAdded(), "The existing stack had room for all four");
        assertEquals(10, inventory.slot(0).stack().quantity(), "Existing stack is topped up to maxStackSize");
        assertTrue(inventory.slot(1).isEmpty(), "No new stack was opened while the old one had room");
    }

    @Test
    public void addItemTopsUpExistingStackBeforeUsingEmptySlots() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);
        inventory.addItem(potion(10), 8);

        AddItemResult result = inventory.addItem(potion(10), 5);

        assertTrue(result.isFullyAdded(), "Everything fits");
        assertEquals(10, inventory.slot(0).stack().quantity(), "The existing stack is filled first");
        assertEquals(3, inventory.slot(1).stack().quantity(), "The rest goes into an empty slot");
    }

    @Test
    public void addItemUsesMultipleSlotsWhenNeeded() {
        ItemInventory inventory = new ItemInventory(OWNER, 4);

        AddItemResult result = inventory.addItem(potion(10), 25);

        assertTrue(result.isFullyAdded(), "Three slots are enough for 25 with max 10");
        assertEquals(10, inventory.slot(0).stack().quantity(), "Slot 0 is full");
        assertEquals(10, inventory.slot(1).stack().quantity(), "Slot 1 is full");
        assertEquals(5, inventory.slot(2).stack().quantity(), "Slot 2 holds the rest");
        assertTrue(inventory.slot(3).isEmpty(), "Slot 3 stays empty");
        assertEquals(25L, inventory.countOf(POTION_ID), "Total is preserved");
    }

    @Test
    public void addItemDoesNotLoseTheOverflowWhenThereIsNotEnoughRoom() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);

        AddItemResult result = inventory.addItem(potion(10), 25);

        assertFalse(result.isFullyAdded(), "Not everything fits");
        assertEquals(20, result.addedQuantity(), "Two full stacks were stored");
        assertEquals(5, result.remainingQuantity(), "The overflow is reported back to the caller");
        assertEquals(25, result.addedQuantity() + result.remainingQuantity(),
                "Added + remaining equals requested: nothing vanished");
        assertEquals(20L, inventory.countOf(POTION_ID), "The inventory holds exactly what was reported as added");
    }

    @Test
    public void addItemToAFullInventoryAddsNothingAndReportsEverythingRemaining() {
        ItemInventory inventory = new ItemInventory(OWNER, 1);
        inventory.addItem(potion(10), 10);

        AddItemResult result = inventory.addItem(potion(10), 3);

        assertEquals(0, result.addedQuantity(), "Nothing was added");
        assertEquals(3, result.remainingQuantity(), "The whole request is reported back");
        assertEquals(10L, inventory.countOf(POTION_ID), "The inventory is unchanged");
    }

    @Test
    public void addItemKeepsDifferentItemsInSeparateStacks() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);
        inventory.addItem(potion(10), 3);

        inventory.addItem(arrow(64), 20);

        assertEquals(3L, inventory.countOf(POTION_ID), "Potions are untouched");
        assertEquals(20L, inventory.countOf(ARROW_ID), "Arrows got their own stack");
        assertEquals(ARROW_ID, inventory.slot(1).stack().item().id(),
                "Arrows opened slot 1 rather than merging into potions");
    }

    @Test
    public void addItemRejectsInvalidQuantity() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);

        assertThrows(IllegalArgumentException.class, () -> inventory.addItem(potion(), 0), "Adding 0 is rejected");
        assertThrows(IllegalArgumentException.class, () -> inventory.addItem(potion(), -2),
                "Adding a negative amount is rejected");
        assertThrows(NullPointerException.class, () -> inventory.addItem(null, 1), "Adding a null item is rejected");
        assertEquals(0L, inventory.countOf(POTION_ID), "Rejected calls leave the inventory unchanged");
    }

    @Test
    public void addItemRejectsAConflictingDefinitionOfTheSameItemId() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);
        inventory.addItem(potion(10), 5);

        assertThrows(IllegalArgumentException.class, () -> inventory.addItem(potion(20), 5),
                "The same ItemId with a different maxStackSize is a conflicting definition");
        assertEquals(5L, inventory.countOf(POTION_ID), "The rejected add changed nothing");
    }

    @Test
    public void removeItemReducesTheCorrectAmount() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);
        inventory.addItem(potion(10), 25);

        RemoveItemResult result = inventory.removeItem(POTION_ID, 12);

        assertTrue(result.isFullyRemoved(), "There was enough to remove");
        assertEquals(12, result.removedQuantity(), "Exactly the requested amount was removed");
        assertEquals(13L, inventory.countOf(POTION_ID), "25 - 12 = 13 remain");
        assertTrue(inventory.slot(0).isEmpty(), "Slot 0 (10) was emptied first");
        assertEquals(8, inventory.slot(1).stack().quantity(), "Slot 1 was reduced from 10 to 8");
        assertEquals(5, inventory.slot(2).stack().quantity(), "Slot 2 is untouched");
    }

    @Test
    public void removingAStackCompletelyEmptiesItsSlot() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);
        inventory.addItem(potion(10), 4);

        RemoveItemResult result = inventory.removeItem(POTION_ID, 4);

        assertTrue(result.isFullyRemoved(), "The whole stack was removed");
        assertTrue(inventory.slot(0).isEmpty(), "A zero-quantity stack is never left behind; the slot is empty");
        assertFalse(inventory.hasItem(POTION_ID), "The item is gone");
    }

    @Test
    public void removeItemMoreThanAvailableRemovesOnlyWhatExistsAndStaysValid() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);
        inventory.addItem(potion(10), 7);

        RemoveItemResult result = inventory.removeItem(POTION_ID, 20);

        assertFalse(result.isFullyRemoved(), "The request could not be fully satisfied");
        assertEquals(7, result.removedQuantity(), "Only the 7 that existed were removed");
        assertEquals(13, result.shortfallQuantity(), "The shortfall is reported");
        assertEquals(0L, inventory.countOf(POTION_ID), "Nothing is left");
        for (InventorySlot slot : inventory.slots()) {
            assertTrue(slot.isEmpty(), "Every slot is a valid empty slot, never a negative or zero stack");
        }
    }

    @Test
    public void removeItemOfAnAbsentItemRemovesNothing() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);
        inventory.addItem(arrow(64), 5);

        RemoveItemResult result = inventory.removeItem(POTION_ID, 1);

        assertEquals(0, result.removedQuantity(), "There were no potions to remove");
        assertEquals(1, result.shortfallQuantity(), "The whole request is a shortfall");
        assertEquals(5L, inventory.countOf(ARROW_ID), "Other items are unaffected");
    }

    @Test
    public void removeItemRejectsInvalidQuantity() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);
        inventory.addItem(potion(10), 5);

        assertThrows(IllegalArgumentException.class, () -> inventory.removeItem(POTION_ID, 0),
                "Removing 0 is rejected");
        assertThrows(IllegalArgumentException.class, () -> inventory.removeItem(POTION_ID, -1),
                "Removing a negative amount is rejected");
        assertThrows(NullPointerException.class, () -> inventory.removeItem(null, 1),
                "Removing a null item id is rejected");
        assertEquals(5L, inventory.countOf(POTION_ID), "Rejected calls leave the inventory unchanged");
    }

    @Test
    public void hasItemReportsWhetherEnoughIsPresentAcrossStacks() {
        ItemInventory inventory = new ItemInventory(OWNER, 3);
        inventory.addItem(potion(10), 15);

        assertTrue(inventory.hasItem(POTION_ID), "Default quantity is 1");
        assertTrue(inventory.hasItem(POTION_ID, 15), "Exactly the held amount counts, even split over two stacks");
        assertFalse(inventory.hasItem(POTION_ID, 16), "One more than held does not");
        assertFalse(inventory.hasItem(ARROW_ID), "An item that is not present is not held");
    }

    @Test
    public void hasItemRejectsInvalidQuantity() {
        ItemInventory inventory = new ItemInventory(OWNER, 1);

        assertThrows(IllegalArgumentException.class, () -> inventory.hasItem(POTION_ID, 0),
                "Checking for 0 is rejected");
        assertThrows(IllegalArgumentException.class, () -> inventory.hasItem(POTION_ID, -1),
                "Checking for a negative amount is rejected");
    }

    @Test
    public void slotRejectsAnOutOfRangeIndex() {
        ItemInventory inventory = new ItemInventory(OWNER, 2);

        assertThrows(IllegalArgumentException.class, () -> inventory.slot(-1), "Negative index is rejected");
        assertThrows(IllegalArgumentException.class, () -> inventory.slot(2), "Index == capacity is rejected");
    }
}
