package inventory.domain;

import character.contracts.CharacterId;
import inventory.contracts.InventorySnapshot;
import inventory.contracts.InventoryStackSnapshot;
import inventory.contracts.ItemId;
import java.util.List;
import support.Test;
import static support.Assertions.*;

/** Character ownership and the explicit snapshot (persistence) model of {@link ItemInventory}. */
public class ItemInventoryOwnershipTest {

    private static final ItemId POTION = new ItemId("potion");
    private static final ItemId ARROW = new ItemId("arrow");

    // ---- ownership -----------------------------------------------------

    @Test
    public void inventoryExposesItsOwner() {
        CharacterId owner = CharacterId.random();

        ItemInventory inventory = new ItemInventory(owner, 4);

        assertEquals(owner, inventory.ownerId(), "The owner passed at construction is exposed");
    }

    @Test
    public void nullOwnerIsRejected() {
        assertThrows(NullPointerException.class, () -> new ItemInventory(null, 4),
                "An inventory without an owning character cannot exist");
    }

    @Test
    public void ownerIsUnchangedByInventoryOperations() {
        CharacterId owner = CharacterId.random();
        ItemInventory inventory = new ItemInventory(owner, 2);

        inventory.addItem(new Item(POTION, 5), 7);
        inventory.removeItem(POTION, 3);

        assertEquals(owner, inventory.ownerId(), "Owner is immutable: gameplay operations never change it");
    }

    @Test
    public void inventoriesOfDifferentCharactersAreIndependent() {
        CharacterId a = CharacterId.random();
        CharacterId b = CharacterId.random();
        ItemInventory inventoryA = new ItemInventory(a, 4);
        ItemInventory inventoryB = new ItemInventory(b, 4);

        inventoryA.addItem(new Item(POTION, 10), 6);

        assertEquals(6L, inventoryA.countOf(POTION), "A holds the potions");
        assertEquals(0L, inventoryB.countOf(POTION), "Modifying A never touches B");
        assertEquals(a, inventoryA.ownerId(), "A is still owned by A");
        assertEquals(b, inventoryB.ownerId(), "B is still owned by B");
        assertNotEquals(inventoryA.toSnapshot(), inventoryB.toSnapshot(), "Different owners and contents");
    }

    // ---- snapshot ------------------------------------------------------

    @Test
    public void emptyInventorySnapshotHasOwnerCapacityAndNoStacks() {
        CharacterId owner = CharacterId.random();

        InventorySnapshot snapshot = new ItemInventory(owner, 6).toSnapshot();

        assertEquals(owner, snapshot.ownerId(), "Snapshot carries the owner");
        assertEquals(6, snapshot.capacity(), "Snapshot carries the capacity");
        assertTrue(snapshot.stacks().isEmpty(), "Nothing is occupied");
    }

    @Test
    public void snapshotListsOnlyOccupiedSlotsInSlotOrder() {
        ItemInventory inventory = new ItemInventory(CharacterId.random(), 5);
        inventory.addItem(new Item(POTION, 10), 12); // slot 0: 10, slot 1: 2
        inventory.addItem(new Item(ARROW, 64), 30);  // slot 2: 30

        List<InventoryStackSnapshot> stacks = inventory.toSnapshot().stacks();

        assertEquals(3, stacks.size(), "Three occupied slots");
        assertEquals(new InventoryStackSnapshot(0, POTION, 10, 10), stacks.get(0), "Slot 0");
        assertEquals(new InventoryStackSnapshot(1, POTION, 10, 2), stacks.get(1), "Slot 1");
        assertEquals(new InventoryStackSnapshot(2, ARROW, 64, 30), stacks.get(2), "Slot 2");
    }

    @Test
    public void restoreRebuildsAnEquivalentInventory() {
        CharacterId owner = CharacterId.random();
        ItemInventory original = new ItemInventory(owner, 5);
        original.addItem(new Item(POTION, 10), 12);
        original.addItem(new Item(ARROW, 64), 30);
        original.removeItem(POTION, 10); // leaves a gap at slot 0

        ItemInventory restored = ItemInventory.fromSnapshot(original.toSnapshot());

        assertEquals(owner, restored.ownerId(), "Owner survives the round trip");
        assertEquals(original.capacity(), restored.capacity(), "Capacity survives");
        assertEquals(original.toSnapshot(), restored.toSnapshot(), "Slot layout, including gaps, survives");
        assertEquals(2L, restored.countOf(POTION), "Quantities survive");
        assertEquals(30L, restored.countOf(ARROW), "Quantities survive");
    }

    @Test
    public void restoredInventoryIsIndependentOfTheOriginal() {
        ItemInventory original = new ItemInventory(CharacterId.random(), 3);
        original.addItem(new Item(POTION, 10), 4);

        ItemInventory restored = ItemInventory.fromSnapshot(original.toSnapshot());
        restored.addItem(new Item(POTION, 10), 3);

        assertEquals(4L, original.countOf(POTION), "Changing the restored copy never changes the original");
        assertEquals(7L, restored.countOf(POTION), "The restored copy changed");
    }

    @Test
    public void restoreRejectsConflictingDefinitionsOfOneItem() {
        InventorySnapshot bad = new InventorySnapshot(CharacterId.random(), 3, List.of(
                new InventoryStackSnapshot(0, POTION, 10, 5),
                new InventoryStackSnapshot(1, POTION, 20, 5)));

        assertThrows(IllegalArgumentException.class, () -> ItemInventory.fromSnapshot(bad),
                "Two different stack limits for one item is corrupt data, not something to silently accept");
    }

    // ---- snapshot record validation ------------------------------------

    @Test
    public void snapshotRejectsSlotOutsideCapacity() {
        assertThrows(IllegalArgumentException.class,
                () -> new InventorySnapshot(CharacterId.random(), 2, List.of(new InventoryStackSnapshot(2, POTION, 10, 1))),
                "Slot index must be below capacity");
    }

    @Test
    public void snapshotRejectsDuplicateSlots() {
        assertThrows(IllegalArgumentException.class,
                () -> new InventorySnapshot(CharacterId.random(), 4, List.of(
                        new InventoryStackSnapshot(1, POTION, 10, 1),
                        new InventoryStackSnapshot(1, ARROW, 10, 1))),
                "One slot cannot hold two stacks");
    }

    @Test
    public void snapshotRejectsNullOwnerAndBadStacks() {
        assertThrows(NullPointerException.class, () -> new InventorySnapshot(null, 2, List.of()), "Owner is mandatory");
        assertThrows(IllegalArgumentException.class, () -> new InventoryStackSnapshot(0, POTION, 10, 11),
                "Quantity above the stack limit is invalid");
        assertThrows(IllegalArgumentException.class, () -> new InventoryStackSnapshot(0, POTION, 10, 0),
                "A zero-quantity stack does not exist");
    }

    @Test
    public void snapshotIsNormalisedToSlotOrder() {
        InventoryStackSnapshot first = new InventoryStackSnapshot(0, POTION, 10, 1);
        InventoryStackSnapshot second = new InventoryStackSnapshot(3, ARROW, 10, 1);
        CharacterId owner = CharacterId.random();

        assertEquals(new InventorySnapshot(owner, 4, List.of(first, second)),
                new InventorySnapshot(owner, 4, List.of(second, first)),
                "Equal contents give equal snapshots regardless of input order");
    }
}
