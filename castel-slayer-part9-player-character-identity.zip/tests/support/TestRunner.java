package support;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Reflectively runs every {@link Test}-annotated method on each class named in
 * {@code args}, printing PASS/FAIL per test and a summary line, exiting non-zero if
 * any test failed (so it plugs into a CI step the same way a real runner would).
 */
public final class TestRunner {

    private TestRunner() {
    }

    public static void main(String[] args) throws Exception {
        int total = 0;
        int failed = 0;

        for (String className : args) {
            Class<?> testClass = Class.forName(className);
            Object instance = testClass.getDeclaredConstructor().newInstance();
            List<Method> methods = new ArrayList<>(List.of(testClass.getDeclaredMethods()));
            for (Method method : methods) {
                if (!method.isAnnotationPresent(Test.class)) {
                    continue;
                }
                total++;
                method.setAccessible(true);
                try {
                    method.invoke(instance);
                    System.out.println("PASS  " + className + "#" + method.getName());
                } catch (Exception e) {
                    failed++;
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    System.out.println("FAIL  " + className + "#" + method.getName() + " — " + cause.getMessage());
                }
            }
        }

        System.out.println();
        System.out.println(total + " tests, " + failed + " failed");
        if (failed > 0) {
            System.exit(1);
        }
    }
}
