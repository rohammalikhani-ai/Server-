package support;

import core.contracts.IEventBus;
import core.contracts.Subscription;
import core.events.GameEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * A minimal in-process {@link IEventBus} test double. Not the production
 * implementation (that belongs to whichever module/composition-root wires the real
 * bus — see IEventBus.md's open question on in-process vs. multi-server); this lets
 * core/module tests verify publish/subscribe behavior without one.
 */
public final class InMemoryEventBus implements IEventBus {

    private final Map<Class<?>, List<Consumer<?>>> handlers = new HashMap<>();
    private final List<GameEvent> published = new ArrayList<>();

    @Override
    public <T extends GameEvent> void publish(T event) {
        published.add(event);
        List<Consumer<?>> subs = handlers.get(event.getClass());
        if (subs == null) {
            return;
        }
        for (Consumer<?> raw : List.copyOf(subs)) {
            @SuppressWarnings("unchecked")
            Consumer<T> handler = (Consumer<T>) raw;
            try {
                handler.accept(event);
            } catch (RuntimeException ignored) {
                // A bad subscriber must never break the publisher — see IEventBus.md.
            }
        }
    }

    @Override
    public <T extends GameEvent> Subscription subscribe(Class<T> eventType, Consumer<T> handler) {
        List<Consumer<?>> subs = handlers.computeIfAbsent(eventType, k -> new ArrayList<>());
        subs.add(handler);
        return new HandleSubscription(eventType, handler);
    }

    @Override
    public void unsubscribe(Subscription subscription) {
        if (!(subscription instanceof HandleSubscription handle)) {
            return;
        }
        List<Consumer<?>> subs = handlers.get(handle.eventType());
        if (subs != null) {
            subs.remove(handle.handler());
        }
    }

    public List<GameEvent> published() {
        return List.copyOf(published);
    }

    private record HandleSubscription(Class<?> eventType, Consumer<?> handler) implements Subscription {
    }
}
