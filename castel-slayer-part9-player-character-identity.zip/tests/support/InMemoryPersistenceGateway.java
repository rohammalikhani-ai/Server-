package support;

import core.contracts.IPersistenceGateway;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * A minimal in-memory {@link IPersistenceGateway} test double. No real database is
 * chosen yet (see docs/decisions/ and PROJECT_MAP.md's database/ note); this lets
 * modules that depend on the gateway interface be tested now without one.
 */
public final class InMemoryPersistenceGateway implements IPersistenceGateway {

    private final Map<String, Map<String, Object>> store = new HashMap<>();

    @Override
    public <T> void save(String collection, String key, T value) {
        store.computeIfAbsent(collection, k -> new HashMap<>()).put(key, value);
    }

    @Override
    public <T> Optional<T> load(String collection, String key, Class<T> type) {
        Map<String, Object> bucket = store.get(collection);
        if (bucket == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(type.cast(bucket.get(key)));
    }

    @Override
    public void delete(String collection, String key) {
        Map<String, Object> bucket = store.get(collection);
        if (bucket != null) {
            bucket.remove(key);
        }
    }

    @Override
    public <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
        Map<String, Object> bucket = store.get(collection);
        if (bucket == null) {
            return List.of();
        }
        List<T> result = new ArrayList<>();
        for (Object value : bucket.values()) {
            T typed = type.cast(value);
            if (filter.test(typed)) {
                result.add(typed);
            }
        }
        return result;
    }
}
