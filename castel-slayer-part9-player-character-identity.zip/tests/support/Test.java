package support;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a no-argument method as a test case, discovered and run by {@link TestRunner}.
 * A minimal stand-in for a JUnit-style {@code @Test} annotation — this sandbox has no
 * network access to fetch a real test framework yet (see
 * docs/decisions/0001-jvm-language-and-source-layout.md). The method shape used
 * throughout {@code tests/} is deliberately JUnit-5-compatible so swapping to a real
 * framework later is a mechanical import change, not a rewrite.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Test {
}
