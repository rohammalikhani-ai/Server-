package support;

import java.util.Objects;

/** A minimal, dependency-free assertion library — see {@link Test} for why this exists instead of JUnit. */
public final class Assertions {

    private Assertions() {
    }

    public static void assertTrue(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    public static void assertFalse(boolean condition, String message) {
        assertTrue(!condition, message);
    }

    public static void assertEquals(Object expected, Object actual, String message) {
        if (!Objects.equals(expected, actual)) {
            throw new AssertionError(message + " — expected <" + expected + "> but was <" + actual + ">");
        }
    }

    public static void assertNotEquals(Object unexpected, Object actual, String message) {
        if (Objects.equals(unexpected, actual)) {
            throw new AssertionError(message + " — expected value to differ from <" + unexpected + ">");
        }
    }

    public static void assertNull(Object value, String message) {
        assertTrue(value == null, message);
    }

    public static void assertNotNull(Object value, String message) {
        assertTrue(value != null, message);
    }

    public static void assertThrows(Class<? extends Throwable> expectedType, ThrowingRunnable runnable, String message) {
        try {
            runnable.run();
        } catch (Throwable t) {
            if (expectedType.isInstance(t)) {
                return;
            }
            throw new AssertionError(message + " — expected " + expectedType.getSimpleName()
                    + " but caught " + t.getClass().getSimpleName() + ": " + t.getMessage(), t);
        }
        throw new AssertionError(message + " — expected " + expectedType.getSimpleName() + " but nothing was thrown");
    }

    @FunctionalInterface
    public interface ThrowingRunnable {
        void run() throws Throwable;
    }
}
