# PROJECT MAP

This file is the map of the repository. Update it whenever a
directory's purpose changes or a new top-level module is added.
For the *rules* behind this structure (dependency directions,
naming, public/private boundaries), see `ARCHITECTURE.md` and
`DEVELOPMENT_RULES.md`.

## Top-Level Layout

```
castel-slayer/
├── dotnet-core/    DEPRECATED, reference-only (Prompt 08 — see
│                   docs/decisions/0002-java-as-sole-production-language.md).
│                   Was THE authoritative C# Core under the since-reversed
│                   Prompt 05 decision. Not deleted, not extended with new
│                   modules, not on any build/ship path.
├── core/           THE authoritative Java engine-agnostic layer: domain
│                   models, services, events, contracts. Java is the sole
│                   production language as of Prompt 08 — see
│                   docs/decisions/0002-java-as-sole-production-language.md.
│                   New gameplay-supporting foundation code belongs here.
├── modules/        Java vertical feature slices (character, combat,
│                   quest, economy, etc). Only `character` has real code
│                   so far (identity/lifecycle only — no stats/
│                   progression). `inventory`/`equipment`/`progression`
│                   gameplay logic does not exist here yet — it was built
│                   in C# under the reversed Prompt 05 decision and has
│                   not been migrated; see
│                   docs/decisions/0002-java-as-sole-production-language.md.
│                   As of Prompt 08, all new gameplay modules are built
│                   here, in Java.
├── platform/       Minecraft-specific adapters. Translates core game
│                   state into what Java Edition and Bedrock Edition
│                   clients can render/receive, and translates client
│                   input back into core commands. Contains no game rules.
│                   The C# Core ↔ Java/Fabric integration boundary
│                   Prompt 05 anticipated here is moot as of Prompt 08 —
│                   no bridge is being built.
├── integrations/   Adapters around external mods/plugins/libraries
│                   (e.g. a specific persistence library, a specific
│                   proxy/bridge). Isolates the rest of the codebase from
│                   any single external dependency.
├── docs/           Design docs, the long-term 100-section master
│                   architecture, and decision records.
├── tests/          Automated tests, mirroring core/modules/platform/
│                   integrations 1:1. (dotnet-core/ has its own mirrored
│                   tests/ tree — see dotnet-core/README.md.)
└── database/       Schema/migrations, present only if/when a concrete
                    persistence choice is made (currently a placeholder —
                    see CURRENT_STATE.md).
```

## `/dotnet-core`

**Deprecated, reference-only as of Prompt 08** — see
`docs/decisions/0002-java-as-sole-production-language.md`. Was the C# Core
introduced in Prompt 05; not on any build/ship path now, not extended with
new modules. See `dotnet-core/README.md` (deprecation notice at the top)
for its internal layout as it stood under the reversed decision (it
mirrored `core/` + `modules/<name>/public|internal` below, in C#) and
`dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md` for
why it existed alongside the Java tree below. It contains three modules,
kept as reference only: `CastelSlayer.Modules.Progression` (Stats,
Attributes, Progression), `CastelSlayer.Modules.Inventory` (Prompt 06
Inventory Foundation: slots, stacks, add/remove/has) and
`CastelSlayer.Modules.Equipment` (Prompt 07 Equipment Foundation:
`ItemDefinition`, slots, equip/unequip; references Inventory for `ItemId`
only — see `dotnet-core/docs/decisions/0003-equipment-module-boundary.md`).
None of this logic exists in Java yet.

## `/core`

| Directory | Responsibility |
|---|---|
| `core/domain` | Pure data models and value objects shared across modules: `PlayerId`, `EntityId`, `EntityKind`, `EntityRef`, `WorldId`, `AreaId`, `Location`, `ClientEdition`, `PlayerIdentity` (added Prompt 03). No framework or Minecraft types allowed here. Depends on nothing. |
| `core/services` | Cross-cutting server-authoritative services (e.g. validation, authority/permission checks) that don't belong to one feature module. As of Prompt 09/10 holds `InProcessEventBus` — the production `IEventBus` — otherwise still empty; see `core/services/README.md`. |
| `core/events` | The event bus contract plus truly cross-cutting event types needed by core services regardless of module: `GameEvent` (marker), `PlayerJoinedWorld`, `PlayerLeftWorld` (added Prompt 03). Module-owned events live in that module's own `public/events` instead. |
| `core/contracts` | The small set of foundational, engine-wide interfaces every module/platform adapter may need. Kept deliberately small — see below. |

As of Prompt 03, `core/domain`, `core/events`, and `core/contracts`
contain real, compiled Java (see
`docs/decisions/0001-jvm-language-and-source-layout.md` for the
language/package/source-layout decision — no `src/main/java` wrapper,
package names mirror the folder names, e.g. `core/domain/PlayerId.java`
is `package core.domain;`).

### `core/contracts` — current interfaces (implemented as `.java`; each `.md` is now supplementary design rationale)

| Interface | Purpose |
|---|---|
| `IEventBus` | Publish/subscribe contract used by all modules. |
| `IPersistenceGateway` | Save/load state without knowing the database engine. |
| `IPlatformPresenter` | What a platform adapter implements to receive core state and forward client input. |
| `IContentValidator` | Gate for AI-proposed or externally-sourced content before it can affect authoritative state. |
| `IVisibilityProvider` | How world-state answers "what can this player see right now." |
| `IConfigProvider` | How any module/platform reads config without knowing the config source (added Prompt 02). |

Module-specific contracts (e.g. "can economy ask inventory if a
player owns item X") do **not** go here — they live in that module's
own `public/contracts`, listed in its `MODULE.md`.

## `/modules`

Each subdirectory is one feature module, split into `public/` (its
entire external surface) and `internal/` (private implementation).
See `ARCHITECTURE.md` → "Module Internal Structure" for the exact
rules. Standard internal shape for every module:

```
modules/<name>/
├── MODULE.md               (added once work on the module begins)
├── public/
│   ├── contracts/           interfaces other modules/platform may depend on
│   └── events/               event types this module publishes
└── internal/
    ├── domain/               this module's own data models
    └── services/             this module's actual logic
```

Modules present now, in the order the prototype is expected to need
them:

| Module | Prototype-scope responsibility |
|---|---|
| `character` | Player↔character identity join point and lifecycle (Prompt 04 — see `modules/character/MODULE.md`). Gameplay Part 9 adds display-name rename: `PlayerCharacter.rename(...)`, `ICharacterLifecycle.rename(...)`, `CharacterRenamed` event — `CharacterId`/owning `PlayerId` never change across a rename. Race/class selection, stats, appearance/resource-pack mapping are future work this module is designed to attach cleanly, not yet built. |
| `combat` | Damage resolution, skills/abilities, server-authoritative combat rules. Gameplay Part 1 (damage foundation only) implemented: `DamageType`, `DamageRequest`, `DamageResult`, `DamageCalculator` — see `modules/combat/MODULE.md`. Gameplay Part 2 adds `Health` (immutable HP pool + `apply(DamageResult)`). Gameplay Part 3 adds `DamageApplicationService` (orchestrates `DamageResult + Health -> new Health`). Gameplay Part 4 adds the death transition/event: `DamageApplicationService.applyDetectingDeath(...)` returns a `DamageApplicationResult` carrying the module's first published event, `combat.events.EntityDied`, on the alive-to-dead HP transition. Gameplay Part 5 adds the neutral respawn foundation: `RespawnPoint`/`IRespawnPointProvider`/`RespawnRequest`/`RespawnDecision` and `RespawnDecisionService` (eligibility + destination). Gameplay Part 6 adds the respawn lifecycle boundary: `RespawnLifecycleState`/`RespawnLifecycleStatus` and `RespawnLifecycleService`, plus the execution boundary `IRespawnExecutor` (no implementation here) and `combat.events.EntityRespawned`. Gameplay Part 7 adds the respawn persistence boundary: `RespawnLifecycleSnapshot`, `RespawnLifecycleSnapshotMapper`, and `RespawnLifecycleStore` (built on the existing `core.contracts.IPersistenceGateway`, with optimistic-revision conflict detection). Gameplay Part 8 adds the entity identity & health persistence boundary: `HealthSnapshot`, `HealthSnapshotMapper`, `HealthStore` (same `IPersistenceGateway`/optimistic-revision pattern as Part 7, keyed by the existing `core.domain.EntityRef` — no new identity type), and `HealthResolutionService` (`resolve(EntityRef) -> Resolved/NotFound/Corrupt/Failed`, never fabricates a default `Health`). Healing, weapons, armor, resistance, crit, abilities, respawn timers, penalties/rewards, wiring `HealthStore` into `DamageApplicationService`, and any concrete `IRespawnPointProvider`/`IRespawnExecutor` not built yet. |
| `inventory` | Items, equipment, item instances, stacking, storage. Java domain implementation for the `inventory` and `equipment` modules (both character-owned via `CharacterId`, each with a public snapshot persistence model; one canonical `inventory.contracts.ItemId`). The C# prototype (`dotnet-core/…`) is deprecated/reference-only (see `docs/decisions/0002-java-as-sole-production-language.md`). Cross-module composition lives in `application/runtime`. |
| `quest` | Quest definitions, state per player, objectives, rewards. |
| `npc` | NPC definitions, spawning, basic dialogue/behavior hooks. |
| `economy` | Currency, shops, basic transactions (prototype-scale, not full market). |
| `progression` | XP, levels, unlocks. |
| `world-state` | Per-player/per-area visibility, story phasing, world flags. Implements `IVisibilityProvider`. |
| `ai-director` | Adapter boundary for AI-assisted content generation + validation pipeline (proposal only — never final authority). |
| `persistence` | Save/load of player and world state; the only module whose `internal/` is allowed to depend on `database/`. Implements `IPersistenceGateway`. |

## `/platform`

| Directory | Responsibility |
|---|---|
| `platform/java` | Java Edition–specific presentation/input adapters. May depend on `core/*` and any module's `public/*`; never on another module's `internal/*`. A real Gradle-built Paper plugin as of Prompt 09/10: `CastelSlayerPlugin` (entrypoint), `bootstrap/` (`CompositionRoot`, `CoreRuntime` — see `ARCHITECTURE.md` → "Composition Root"), `identity/PlayerIdentityMapper` (Bukkit `Player` → `core.domain.PlayerId`/`PlayerIdentity`; does not resolve `character.contracts.CharacterId` yet), `listeners/PlayerConnectionListener` (Bukkit join/quit → `core.events.PlayerJoinedWorld`/`PlayerLeftWorld`), `commands/` (intentionally empty). Base package `castelslayer.platform.paper` — see `docs/decisions/0003-...` point 6 for why it departs from the folder-mirroring convention. |
| `platform/bedrock` | Bedrock Edition–specific presentation/input adapters (via whatever bridge is chosen — see `docs/decisions/`). Same dependency rules as `platform/java`. |
| `platform/shared` | Logic genuinely shared by both clients that is still presentation-layer (not game rules). `java` and `bedrock` may depend on `shared`; `shared` never depends on either of them, and `java`/`bedrock` never depend on each other directly. |

## `/integrations`

Currently empty. Each external dependency gets its own
`integrations/<tool-name>/` folder once a subsystem is implemented
and a specific tool is chosen, containing an adapter implementing a
`core/contracts` (or module `public/contracts`) interface plus a
`README.md` (what it wraps, why, license, pinned version,
Java/Bedrock/Geyser implications). See `DEVELOPMENT_RULES.md` →
"External Dependency Wrapping".

## `/docs`

- `master-architecture-100-sections.md` — the original long-term spec,
  annotated with per-section status as it's re-scoped for Minecraft.
- `decisions/` — short decision records (one file per major choice:
  Minecraft version, Java/Bedrock bridge, persistence engine, an
  external dependency adopted, etc.) as they're made.
  `0001-jvm-language-and-source-layout.md` (Prompt 03) is the first:
  Java 17, no build tool yet (no network access in this environment to
  fetch Maven/Gradle/JUnit), source lives directly in the folders this
  file already documents, package names mirror folder names.
  `0002-java-as-sole-production-language.md` (Prompt 08) reverses
  Prompt 05's C# split: Java is once again the sole production language,
  and `dotnet-core/` is deprecated/reference-only.
  `0003-paper-platform-and-composition-root.md` (Prompt 09/10) picks
  Paper (Minecraft Java Edition 1.21.11) as the first loader, adds a
  Gradle Kotlin DSL multi-project build (`:core`, `:platform:java`),
  raises the Java language level from 17 to 21, and settles the
  composition root's location — see the `/platform` row below. As of
  Phase 11 the same Gradle build also includes `:modules:character`,
  `:modules:progression`, `:modules:inventory`, and `:modules:equipment`
  (existing folders, no source moved; see the ADR's Phase 11 amendment).

## `/application`

`application/runtime` (`:application:runtime`) — Paper-free application layer between `platform/java` and the
feature modules: `CharacterRuntime`, `CharacterRuntimeFactory`/`Service`, `PlayerSession`, `SessionManager`,
`PlayerSessionService`/`Lifecycle`. See `docs/decisions/0004-application-runtime-layer.md`.

## `/tests`

Mirrors `core/`, `modules/`, `platform/`, and `integrations/` 1:1
(e.g. `tests/modules/economy/` tests `modules/economy/`). Empty until
code exists to test. See `DEVELOPMENT_RULES.md` → "Testing Rules".

`tests/support/` (added Prompt 03) is one documented exception to the
1:1 mirror: a small, dependency-free `@Test`/`Assertions`/`TestRunner`
harness plus `InMemoryEventBus`/`InMemoryPersistenceGateway` test
doubles for `IEventBus`/`IPersistenceGateway`, needed because this
environment has no network access to fetch JUnit — see
`docs/decisions/0001-jvm-language-and-source-layout.md`.
`tests/core/{domain,events,contracts}/` and
`tests/modules/character/{domain,services}/` now contain real tests
against `core` and the `character` module (see `CURRENT_STATE.md` for
their run status in this environment).

## `/database`

Placeholder. No persistence engine has been chosen yet (open item —
see `CURRENT_STATE.md`). Nothing here should be treated as a real
schema until a decision record exists in `docs/decisions/`. Only the
`persistence` module's `internal/` may ever depend on this directory.
