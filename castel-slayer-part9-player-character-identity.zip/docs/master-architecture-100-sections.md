# Master Architecture & Project Specification — 100 Sections (v0.1 Draft)

**Status:** Architecture Planning. This is a placeholder for the
long-term 100-section specification referenced by `README.md`.

## Provenance

The original 100-section document was written assuming a Unity 2D
client + ASP.NET Core C# server. Following the pivot to Minecraft as
the runtime/platform, Minecraft replaces the Client/Presentation
layer; the Server/Domain core architecture principles from the
original document are kept and re-expressed in `ARCHITECTURE.md` and
`DESIGN_PRINCIPLES.md` in this repository.

## Known Re-Scoping Needed (carried over, not yet re-solved here)

- **Section 23/24 — Character Creator:** replaced with a preset Race
  system (fixed list: Human, Elf, Orc, Dwarf, Undead, ...), each with
  a custom body model + skin via a custom Resource Pack (Custom
  Player Model on Java, CEM on Bedrock). Fallback: default flat-skin
  preset if the Resource Pack fails to load.
- **Sections 84/85 — Advertising, Rewarded Ads:** no viable in-client
  ad system on Java or Bedrock (Bedrock Marketplace prohibits
  third-party ads). Needs to move outside the Minecraft client
  entirely (e.g. companion website or Discord bot) or be dropped from
  prototype scope.
- **Sections 74–76 — Story Mode / Adventure Mode / Community
  Stories:** no true cutscenes, dynamic camera, or lip-sync available;
  can only use simple camera commands, books/chat, and particle
  effects. Needs heavy compromise versus the original spec.

## Next Step

Paste or import the full 100-section source document into this file
(or a `docs/master-architecture/` subfolder, one file per section, if
it's large) and annotate each section with a status: `kept as-is`,
`re-scoped for Minecraft`, `deferred past prototype`, or `dropped`.
This wasn't done in Prompt 01 because the source document itself
wasn't provided in this session — only its existence and the notes
above were available.
