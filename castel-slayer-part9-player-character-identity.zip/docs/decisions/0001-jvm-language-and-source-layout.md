# 0001 — JVM Language, Source Layout, and Package Convention

**Status:** decided (Prompt 03)
**Context:** `CURRENT_STATE.md` (as of Prompt 02) listed "no concrete tech
stack chosen" as the top item ready for the next prompt. Prompt 03 asks
for real, compilable, testable Core domain code, which requires making
this decision now rather than deferring it further.

## Decision

- **Language:** Java 17 language level (compiled here with an available
  JDK 21 toolchain via `javac --release 17`, for compatibility with the
  Java versions modern Minecraft server software — Paper, Fabric —
  commonly targets). Records and pattern-matching `instanceof` (both
  Java 16+) are used freely for immutable value types and events.
- **Build tool:** none yet. This sandbox has no network access, so
  Maven/Gradle and any dependency (including JUnit) cannot be fetched.
  Code is compiled and run directly with `javac`/`java`. The source
  layout below was chosen so that adding a real build tool later (Maven
  or Gradle, whichever is chosen when `platform/java` needs real
  Minecraft-API dependencies) requires no code changes — only adding a
  `pom.xml`/`build.gradle` per module that points at the existing
  folders as source roots. Revisit this file when that happens.
- **Testing:** no external test framework (no network to fetch JUnit).
  A minimal, self-contained, JUnit-shaped test harness lives in
  `tests/support/` (`@Test` annotation, `Assertions`, `TestRunner`).
  Test methods are written the same way they would be under real JUnit
  5, so swapping later is a mechanical import change, not a rewrite.
- **Source layout:** no `src/main/java` wrapper. Java files live
  directly in the conceptual folders `PROJECT_MAP.md` already defines
  (`core/domain`, `core/events`, `core/contracts`, `core/services`;
  `modules/<name>/public/{contracts,events}`,
  `modules/<name>/internal/{domain,services}`). `tests/` mirrors this
  1:1, per `DEVELOPMENT_RULES.md`. A source file's physical path is not
  required to mirror its package path (only a Maven/IDE convention, not
  a `javac` requirement when compiling an explicit file list, which is
  how this project's compile step and any future build tool's
  file-scanning both work).
- **Package convention:** every top-level package is named after its
  owning layer/module folder, kebab-case hyphens removed (e.g.
  `world-state` → `worldstate`, `ai-director` → `aidirector`):
  - `core/domain` → `package core.domain;` (same for `core.events`,
    `core.contracts`, `core.services`).
  - `modules/<name>/public/contracts` → `package <name>.contracts;`
    (same pattern for `<name>.events`, `<name>.domain`,
    `<name>.services` from `internal/`).
  - The `public`/`internal` directory segment is **not** part of the
    package name — `public` is a reserved Java keyword and cannot be a
    package identifier. The public/internal boundary stays a
    directory-location + code-review convention (matching
    `ARCHITECTURE.md`'s existing "convention now, compiler-enforced
    later if the toolchain supports it" stance for module boundaries),
    not a package-level one.
  - Tests share the same package as the code they test (e.g.
    `tests/core/domain/PlayerIdTest.java` is also `package
    core.domain;`, matching `core/domain/PlayerId.java`), which is the
    standard Java convention for enabling same-package (including
    package-private) test access.

## Open Questions Carried Forward

- Concrete build tool (Maven vs. Gradle) and dependency management —
  deferred until either network access is available or `platform/java`
  needs a real Minecraft API dependency, whichever comes first.
- Real test framework (JUnit 5) — swap in once dependencies can be
  fetched; `tests/support/Test`'s method shape was chosen to make that
  swap mechanical.
