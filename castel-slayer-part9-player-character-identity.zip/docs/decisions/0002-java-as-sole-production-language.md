# 0002 — Java as the Sole Production Language; `dotnet-core/` Deprecated (Reference-Only)

**Status:** decided (Prompt 08)
**Supersedes:** `dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md`
(Prompt 05's decision to make C# the authoritative gameplay-logic language).

## Context

Prompt 05 made C#, under `dotnet-core/`, the authoritative home for all
new gameplay logic, with Java/Fabric reduced to the Minecraft
integration/platform layer. Prompts 06–07 built `CastelSlayer.Modules.
Progression`, `CastelSlayer.Modules.Inventory`, and `CastelSlayer.Modules.
Equipment` in C# under that decision. None of it was ever compiled or run
in this environment (no .NET SDK, no network access to install one —
see `CURRENT_STATE.md`), and the C#↔Java integration mechanism the split
depended on (`dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md`
→ "What Is Deferred") was never chosen or built either.

This prompt reverses that decision for this step only: **Java is now the
only production language for this project.** This record does not
introduce a Java↔C# bridge, does not migrate any C# module into Java, and
does not implement any new gameplay logic — it only re-establishes which
language production code is written in going forward and states what
happens to the existing `dotnet-core/` tree as a result.

## Decision

1. **Java is the sole production language, effective immediately.** All
   new gameplay logic, from this prompt forward, is built in Java under
   the existing `core/` + `modules/<name>/public|internal` tree (per
   `docs/decisions/0001-jvm-language-and-source-layout.md`), not under
   `dotnet-core/`.
2. **`dotnet-core/` is deprecated and reference-only.** It is not deleted
   and not modified beyond the documentation updates this decision
   requires. Nothing in it should be treated as authoritative, targeted
   for compilation, or extended with new modules. It remains in the
   repository as prior art — the `Progression`/`Inventory`/`Equipment`
   domain modeling done there may still be useful to consult when the
   equivalent Java modules are eventually built — but it is not on any
   build or ship path.
3. **No C#↔Java bridge is built.** The integration mechanism Prompt 05
   deferred (`dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md`
   → "What Is Deferred") is now moot for production purposes and is not
   picked up by this decision either.
4. **No migration happens in this step.** `Progression`, `Inventory`, and
   `Equipment` gameplay logic does not yet exist in Java. This decision
   does not port it. A future prompt must decide, module by module,
   whether/how/when to rebuild that logic in Java under `modules/` — until
   then, those systems have no authoritative production implementation.
5. **No new gameplay logic is implemented by this decision.** This is a
   documentation/decision-record change only.

## What Is Deferred (explicitly, not forgotten)

- Rebuilding `Progression`, `Inventory`, and `Equipment` gameplay logic in
  Java under `modules/` — module by module, each as its own prompt/decision.
- Whether any part of the C# domain modeling in `dotnet-core/` (value
  types, validation rules, test cases) is worth consulting as reference
  while doing that Java rebuild, versus designing it fresh.
- Whether `dotnet-core/` is ever deleted outright — not decided here; it
  stays as reference-only until a future decision addresses it.
- Everything already deferred by the superseded decision that is still
  relevant to Java-only development going forward (composition root
  location, persistence engine, config source, Minecraft version,
  plugin/mod loader, Java/Bedrock bridge) — unaffected by this record,
  still open per `CURRENT_STATE.md`.

## Consequences

- `ARCHITECTURE.md`'s "C# Core / Java Platform Split (Prompt 05)" section
  no longer describes the current architecture; it has been replaced with
  a short section pointing here, per `docs/decisions/0001-jvm-language-and-source-layout.md`'s
  Java 17 / source-layout decision (which was never superseded — only the
  Prompt 05 C#-first split was).
- `dotnet-core/README.md` now carries a deprecation notice at the top.
- `PROJECT_MAP.md` and `CURRENT_STATE.md` are updated to describe
  `dotnet-core/` as deprecated/reference-only rather than "THE
  authoritative C# Core."
- `dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md` and
  `0003-equipment-module-boundary.md` are left unmodified as historical
  record of decisions made under the since-reversed C#-first split; this
  record is the one to read for current status.
- No `.cs` or `.java` source file is added, removed, or edited by this
  decision.
