# 0004 — Application runtime layer (`:application:runtime`)

Status: accepted (Master Phase 12–14)

## Context

Character, Progression, Inventory and Equipment are separate modules that must not know about each other
(character must not know inventory/equipment; inventory and equipment must not depend on each other; nothing in the
domain may depend on Paper). Yet a connected player needs *one* active character whose module states belong together,
loaded on join and saved on quit.

## Decision

Add a small Gradle module `:application:runtime` (packages `castelslayer.application.runtime` and
`castelslayer.application.session`). It depends on `:core` and the four feature modules and is depended on by
`:platform:java`. It contains **no gameplay rules**:

- `CharacterRuntime` — groups one character's `CharacterSummary`, progression, inventory and equipment and rejects, at
  construction, any part owned by a different `CharacterId`. Not an aggregate.
- `CharacterRuntimeFactory` / `CharacterRuntimeService` — build a runtime from defaults or from a saved
  `CharacterRuntimeSnapshot`, and load/save it through `core.contracts.IPersistenceGateway`. Load returns a sealed result
  (`Loaded`, `NotFound`, `NotActive`, `Failed`); a storage failure is never reported as "does not exist". A `Loaded` runtime always belongs to the requested `CharacterId`; a directory that answers with a different character is a `Failed`.
- `PlayerSession`, `SessionManager` — `PlayerId` ↔ `CharacterRuntime` registry; refuses duplicate players and duplicate
  characters. `PlayerId` and `CharacterId` are never derived from each other.
- `CharacterSelector` (+ `DirectoryCharacterSelector`), `PlayerSessionService`, `PlayerSessionLifecycle` — join/quit
  flow, driven by `PlayerJoinedWorld` / `PlayerLeftWorld`. The bus only triggers; outcomes go to a
  `SessionOutcomeListener` because the bus swallows handler failures.

## Why a new module

Composing four modules needs a dependency on all four. Putting that in any one of them would make them depend on each
other; putting it in `platform/java` would put application logic in the Paper layer and make Paper the place that
understands every domain module. A separate module keeps the domain Paper-free and the plugin thin, and lets the whole
join → load → quit → save flow be tested with plain Java.

## Persistence shape

One immutable `CharacterRuntimeSnapshot` (the three modules' public snapshots) is stored under one key per character:
`IPersistenceGateway` has no transactions, so one write is all-or-nothing, whereas three writes could leave e.g. a sword
removed from the inventory but not recorded as equipped. Modifiers are not persisted (their sources re-apply them).

## Consequences / known limits

- Dev persistence is in-memory (lost on restart) until a real gateway replaces it at the composition root.
- One active character per player is the character module's documented prototype rule; `CharacterSelector` is the seam for
  real selection later. No character-creation flow exists yet.
- Synchronous by design; `SessionManager` is `synchronized` and nothing else is concurrent.
