# 0003 — Paper as the Java Edition Loader, Gradle Build, Composition Root Location

**Status:** decided (Prompt 09/10 — Paper Platform Foundation)
**Amends:** `0001-jvm-language-and-source-layout.md` (build tool, Java version).
**Resolves open items from `CURRENT_STATE.md` → "Ready For The Next Prompt":**
Minecraft version/loader, composition-root location, first production `IEventBus`.

## Context

`0001` deferred choosing a build tool until either network access became
available or `platform/java` needed a real Minecraft API dependency —
"whichever comes first." `platform/java` now needs Paper's API, so that
moment has arrived. `ARCHITECTURE.md` → "Composition Root" also deferred
where startup wiring lives until a loader was chosen; that choice is made
here too, together, since the two are the same decision in practice.

## Decision

1. **Minecraft target: Java Edition 1.21.11, via the Paper server
   software** (`paper-api`). Bedrock is unaffected and still open — Java
   Edition is the first concrete platform, not the only planned one; see
   `platform/bedrock` in `PROJECT_MAP.md`, still empty.
2. **Build tool: Gradle, Kotlin DSL.** A root multi-project build with two
   subprojects for now: `:core` and `:platform:java`.
   - `:core`'s `build.gradle.kts` does **not** introduce a `src/main/java`
     wrapper — per `0001`, it points a custom source set directly at the
     existing `core/domain`, `core/events`, `core/contracts`,
     `core/services` folders. This is exactly the "add a build file that
     points at the existing folders" path `0001` already anticipated; no
     source file moved or changed package.
   - `:platform:java` is a real Paper plugin project using the standard
     `src/main/java` / `src/main/resources` Gradle convention, since it is
     new code with no prior layout to preserve, and Paper/plugin.yml
     tooling assumes that convention.
   - `modules/*` are **not** added as Gradle subprojects yet — nothing in
     this phase's platform code depends on a module (see "Deferred" in the
     FINAL REPORT for why `modules/character` isn't wired in even though
     Phase 10A's identity work touches it conceptually). Add
     `modules/<name>` as a subproject, the same way `:core` was, the first
     time `platform/java` needs a real dependency on one.
   - Root `settings.gradle.kts` centralizes repositories
     (`mavenCentral()` and PaperMC's repository) via
     `dependencyResolutionManagement`; the root `build.gradle.kts`
     centralizes the Java 21 toolchain across subprojects.
3. **Java version raised from 17 to 21 (amends `0001`).** `0001` picked
   17 speculatively, "for compatibility with the Java versions modern
   Minecraft server software commonly targets." Paper 1.21.11 concretely
   requires Java 21 at runtime, so that guess is now replaced with the
   real number. No source change is required — the records and
   pattern-matching `0001` already used are Java 21-compatible — only the
   compiler target: `core/build.gradle.kts` and `platform/java/build.gradle.kts`
   both set `JavaLanguageVersion.of(21)`.
4. **Composition root location: `platform/java`'s `bootstrap` package**
   (`castelslayer.platform.paper.bootstrap.CompositionRoot` /
   `CoreRuntime`), constructed once in `CastelSlayerPlugin#onEnable` and
   discarded in `#onDisable`. Reasoning: Paper's plugin lifecycle already
   *is* a single, well-defined startup/shutdown point for a single-server
   deployment, and Java Edition is currently the only implemented
   platform — `core/bootstrap` would be a speculative extra layer with
   nothing else calling it yet (`DEVELOPMENT_RULES.md`: don't build for a
   feature that isn't needed yet). If/when Bedrock or a second Java loader
   needs its own entry point, revisit whether wiring should move to
   `platform/shared` so both call the same construction code — not
   decided now, deliberately, since only one loader exists to inform that
   design.
5. **First production `core.contracts.IEventBus` implementation:
   `core.services.InProcessEventBus`.** In-process, synchronous,
   single-server — matching the shape `tests/support/InMemoryEventBus`
   already demonstrated as a test double, now promoted to real code
   because the composition root has a real need to publish
   `PlayerJoinedWorld`/`PlayerLeftWorld`. This is not speculative: it is
   wired to an actual caller (`PlayerConnectionListener`) and an actual
   constructor call (`CompositionRoot.bootstrap()`) in this same phase,
   consistent with `DEVELOPMENT_RULES.md`'s "never create a
   manager/service for a feature that isn't being built yet." No other
   `core.contracts` interface (`IPersistenceGateway`, `IConfigProvider`,
   `IVisibilityProvider`, `IContentValidator`, `IPlatformPresenter`) gets
   a production implementation this phase — see FINAL REPORT for why.
6. **`platform/java`'s base package is `castelslayer.platform.paper`, not
   the folder-literal `platform.java`.** `0001`'s package convention
   (folder name, kebab-case removed) is not extended here, for two
   reasons specific to this directory:
   - `java` as a bare package segment sits awkwardly next to the JDK's
     own `java.*` packages — legal, but a readability cost `0001`'s
     convention was never designed to pay (`core`/`modules` folder names
     never collide with a JDK namespace).
   - Unlike `core`/`modules` (compiled sources only, never distributed
     standalone), `platform/java` is shaded into a real deployable jar
     dropped into a shared `plugins/` folder next to arbitrary
     third-party plugins on someone's server. It needs a
     collision-resistant namespace the bare `platform` folder name
     doesn't provide. `castelslayer` is used in place of a reverse-DNS
     domain because the project has no registered domain yet; revisit if
     one is acquired.
7. **Paper/Bukkit API is the platform layer itself, not a wrapped
   "integration."** `DEVELOPMENT_RULES.md` → "External Dependency
   Wrapping" requires every external library to be isolated behind an
   `integrations/<tool>/` adapter with no other file importing it
   directly. That rule is about optional third-party plugins layered on
   top of the game (Geyser, Floodgate, MythicMobs, WorldGuard, ... — all
   still forbidden this phase, and `integrations/` stays empty). It was
   never meant to cover the Minecraft server API `platform/java` exists
   to adapt — `core.contracts.IPlatformPresenter`'s own Javadoc already
   assumes `platform/java`/`platform/bedrock` are where that adaptation
   happens. `platform/java` importing `org.bukkit.*`/`io.papermc.*`
   directly is therefore the intended design, not a rule violation.

## What Is Deferred (explicitly, not forgotten)

- `IPersistenceGateway` and `IConfigProvider` production implementations
  — no persistence engine or config source is chosen yet; this phase's
  brief explicitly forbids adding persistence.
- `modules/character`'s `ICharacterDirectory` is **not** wired into the
  composition root, because it is backed by `IPersistenceGateway`, which
  has no production implementation (see above). `PlayerId` →
  `character.contracts.CharacterId` resolution therefore does not exist
  yet on the Paper side — see `identity.PlayerIdentityMapper`'s Javadoc.
- `platform/bedrock`, and the Java/Bedrock bridge (Geyser/Floodgate)
  needed to reach it — untouched.
- The Gradle wrapper binary (`gradle/wrapper/gradle-wrapper.jar`) — this
  environment has no network access to download one; `gradle-wrapper.properties`
  records the intended distribution (Gradle 8.10.2) for whoever runs
  `gradle wrapper` on a machine that has both Gradle and network access.
- Adding `modules/*` as Gradle subprojects — deferred until a platform
  adapter has a real dependency on one (see point 2 above).
- A core-level logging abstraction — `InProcessEventBus` reports
  subscriber failures to stderr rather than inventing an `ILogger`
  contract nothing else needs yet.

## Consequences

- `ARCHITECTURE.md` → "Composition Root" is updated to point here instead
  of saying "not decided yet."
- `0001-jvm-language-and-source-layout.md` remains the record of *why*
  Java/records/the folder layout were chosen; only its build-tool and
  Java-version status are superseded by points 2–3 above — it is not
  otherwise revised.
- `PROJECT_MAP.md` gains rows for the new Gradle files and
  `core/services/InProcessEventBus.java`.

## Amendment — Phase 11 (Gradle multi-module integration)

Points 2 and "Deferred" above said `modules/*` would be added as Gradle
subprojects only once `platform/java` depended on one. That is superseded:
`:modules:character`, `:modules:progression`, `:modules:inventory`, and
`:modules:equipment` are now Gradle subprojects, each with a
`build.gradle.kts` that points at its existing `internal/` and `public/`
folders (no source moved). Project dependencies follow the actual imports
only (`character → core`; `progression → core, character`;
`equipment → inventory`; `inventory` has none). `:platform:java` still
depends only on `:core`, because it imports no module code yet. Tests
(custom `tests/support` harness, not JUnit) are wired through a
`harnessTest` task that `test` delegates to — see the root
`build.gradle.kts`.

