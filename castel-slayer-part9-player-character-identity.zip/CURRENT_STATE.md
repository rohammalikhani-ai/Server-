# CURRENT STATE

## Gameplay Part 9 — Player & Character Identity Boundary (added)

Establishes the minimal, future-proof `PlayerId -> CharacterId -> Entity Identity` boundary. Most
of what Part 9 asks for already existed in `:modules:character` from earlier work (not a Part 9
addition, discovered during this pass): `core.domain.PlayerId` (stable account identity),
`character.contracts.CharacterId` (its own type, never reused from `core.domain` — see
`character.MODULE.md`), `character.domain.PlayerCharacter` (the `CharacterId owned-by PlayerId`
aggregate — an explicit ownership relationship that cannot silently switch owners, since `ownerId`
is a `final` field with no setter), `character.contracts.CharacterSnapshot`/
`character.services.CharacterDirectoryService` (validated persistence over
`core.contracts.IPersistenceGateway`, collection `"characters"`), and
`character.services.CharacterLifecycleService` (`create`/`retire`, save-then-publish). What Part 9
actually adds: **display-name rename semantics**, the one genuine gap — `name` was previously a
`final` field set only at construction. `character.domain.PlayerCharacter.rename(String, Instant)`
now changes the name and bumps `updatedAt` while leaving `CharacterId`, owner `PlayerId`, and
lifecycle state untouched (renaming a retired character is allowed — rename and lifecycle state are
independent); `character.contracts.ICharacterLifecycle.rename(CharacterId, String)` +
`CharacterLifecycleService.rename` validate the new name through the same
`CharacterNameRules.validate` `CharacterFactory` already uses, persist, then publish the new
`character.events.CharacterRenamed(characterId, previousName, newName, occurredAt)` event — the same
persist-then-publish ordering `create`/`retire` already established. An invalid name or an unknown
`CharacterId` renames nothing and publishes nothing (mirrors `create`'s/`retire`'s existing failure
semantics exactly).

Entity Identity integration (relationship to `combat.EntityRef`, established Gameplay Part 8):
documented, not coded. `core.domain.EntityRef.ofPlayer(PlayerId)` already carries a player's stable
runtime identity into combat/health/respawn; a played `CharacterId` resolves to that `EntityRef` via
its owning `PlayerId` (`CharacterSummary.ownerId()` → `EntityRef.ofPlayer`), so no second identity
system was introduced and no Minecraft entity-binding code was written here — that binding is
future platform-adapter work.

**Not built yet:** login/session/authentication (explicitly out of scope), multi-character-per-
player (still one active character per player — a pre-existing, unchanged constraint), display-name
uniqueness policy, chat/cosmetics/moderation, and any code that actually binds a `CharacterId` to a
live `EntityRef` at runtime (Minecraft join/leave wiring) — that is future platform/composition-root
work, not Part 9's.

**External dependency check:** re-examined whether an external identity/persistence library would
help `PlayerId`/`CharacterId`/ownership or the new rename path; nothing changed since
`character.MODULE.md`'s existing conclusion (plain `UUID`-backed records plus
`IPersistenceGateway` is sufficient) — nothing adopted. No `integrations/` adapter or decision
record needed.

**Verified in this addition** (`javac` 21 via `java -m jdk.compiler/com.sun.tools.javac.Main` +
`support.TestRunner`, whole repo excluding the three Bukkit-dependent `platform/java` files, same
convention as every prior addition): full suite 556 tests, 0 failed (baseline immediately before
Part 9: 547, 0 failed — i.e. after Part 8, see below; +9 new: 4 added to `PlayerCharacterTest`, 5
added to `CharacterLifecycleServiceTest`). Focused character-module-only run: 31 tests, 0 failed.
Combat-focused run unaffected: 291 tests, 0 failed. Gradle not run (no Gradle/wrapper/network in
this sandbox).

## Gameplay Part 8 — Entity Identity & Health State Boundary (added)

`:modules:combat` gains the boundary that resolves and persists `combat.domain.Health` by stable
entity identity, without implementing Player/Character persistence, Minecraft integration, or any
gameplay-specific player system (foundation/boundary part, not a full player system). Identity
decision: **no new identity type was introduced** — `core.domain.EntityRef` (already used by
`RespawnLifecycleStore` since Gameplay Part 7) already satisfies every requirement (immutable,
value-based, UUID-backed, never display-name-based, already future-compatible with
`PlayerId`/`CharacterId` via `EntityRef.ofPlayer`), so `combat.contracts.HealthSnapshot`,
`combat.services.HealthStore`, and `combat.services.HealthResolutionService` all key off it, the
same way respawn persistence already does. New: `combat.contracts.HealthSnapshot` (persistence
model: `schemaVersion`, `revision`, `entity`, `current`, `max`, `savedAt`),
`combat.services.HealthSnapshotMapper` (validated, non-repairing two-way mapping — checks the same
finite/`max > 0`/`0 <= current <= max` invariants `Health`'s own constructor enforces, explicitly,
rather than constructing a `Health` and catching its exception, so recovery cannot crash on
untrusted data), `combat.services.HealthStore` (`load`/`save`/`discard` against
`IPersistenceGateway`, collection `"entity-health"`, with the exact same optimistic-revision
contract and three-way `NotFound`/`Failed`/`Corrupt` load / `Saved`/`VersionConflict`/`Blocked` save
results `RespawnLifecycleStore` established in Part 7 — no new persistence pattern invented), and
`combat.services.HealthResolutionService` (the small application/domain service Part 8 asks for:
`resolve(EntityRef) -> HealthResolutionResult`, a thin remap of `HealthStore.load`'s result that
**never fabricates a default `Health` for an unknown entity** — `NotFound` stays explicit; a future
`resolveOrDefault(EntityRef, Supplier<Health>)` is the documented, undecided extension point for
that gameplay rule). What is persisted: entity identity, `current`/`max` HP, plus
`schemaVersion`/`revision`/`savedAt`. What is deliberately not: alive/dead (still derived, not
stored), the respawn lifecycle (untouched, still its own collection), and anything platform-
specific. `DamageApplicationService` itself is unchanged — it still receives/returns `Health`
directly from its caller; wiring its output through `HealthStore.save` is future integration work,
not built here.

**Not built yet:** any code that actually calls `HealthStore.save` from `DamageApplicationService`
or a respawn-completion path (this part builds the boundary, not the wiring), default/starting HP
for a new entity, healing/regeneration, and — as before — armor, weapons, XP, loot, NPC AI, PvP.

**External dependency check:** see `modules/combat/MODULE.md` → "External dependency check
(Gameplay Part 8)". Re-checked the same optimistic-versioning question Part 7 already answered;
nothing new adopted — `HealthStore` reuses `IPersistenceGateway`/`InMemoryPersistenceGateway`
unchanged. No `integrations/` adapter or decision record needed.

**Verified in this addition** (`javac` 21 + `support.TestRunner`, whole repo excluding the three
Bukkit-dependent `platform/java` files): full suite 547 tests, 0 failed (baseline immediately before
Part 8: 493, 0 failed; +54 new — `HealthSnapshotTest` 5, `HealthSnapshotMapperTest` 15,
`HealthStoreTest` 28, `HealthResolutionServiceTest` 6). Focused combat-module-only run: 291 tests, 0
failed (baseline before Part 8: 237, 0 failed). Gradle not run (no Gradle/wrapper/network in this
sandbox).

## Gameplay Part 4 — Combat: Death Transition/Event (added)

`:modules:combat` gains its first published event, `combat.events.EntityDied` (`public/events` —
`target`, `source`: both `core.domain.EntityRef`; `occurredAt`), and a new orchestration method,
`combat.services.DamageApplicationService.applyDetectingDeath(DamageResult, Health) ->
DamageApplicationResult`, closing `Alive Health -> lethal Damage Application -> Death
transition/event`. `DamageApplicationResult` (new, `internal/services`) carries `Health health` and
`List<EntityDied> events`. Death is detected purely by comparing `targetHealth.isAlive()` before the
call to the resulting `Health.isDead()` after it — `Health`'s own `current == 0` dead definition and
`apply(DamageResult)` logic are reused unchanged, not duplicated. Exactly one `EntityDied` is
returned on an alive-to-dead transition (including overkill, which still floors at zero); zero
otherwise — non-lethal damage, zero damage, and any further damage to an already-dead target all
produce none, so no duplicate death event is possible. The event is not published by this module:
`DamageApplicationService` still has no `core.contracts.IEventBus` dependency and there is no global
mutable event bus anywhere in this addition — the caller receives `events()` and decides how/whether
to publish it, the same pattern `progression.services.LevelingService`/`LevelingResult` already
established for `CharacterLeveledUp`. The existing `apply(DamageResult, Health) -> Health` method and
its no-arg constructor are unchanged (a new `DamageApplicationService(Clock)` constructor was added
alongside the existing no-arg one, which now delegates to it with `Clock.systemUTC()`, purely to
timestamp `EntityDied.occurredAt()` deterministically in tests — the same reason
`LevelingService` takes a `Clock`). `DamageType`, `DamageRequest`, `DamageCalculator`, `DamageResult`,
and `Health` are all unchanged from Parts 1-3; `Health` was not duplicated or redesigned. No
Bukkit/Paper/Minecraft dependency, no automatic respawn, no persistence, no player/NPC assumption
(both event fields are `EntityRef`).

**Not built yet:** respawn, healing/regeneration, target-health storage/lookup by identity, armor,
resistance, weapons, abilities, NPC AI, PvP, any Minecraft combat hook, and anything that reacts to
`EntityDied` (loot, XP, despawn) — those are later Gameplay Parts and/or the composition root's job
once this event is actually wired to `IEventBus`.

**External dependency check:** see `modules/combat/MODULE.md` → "Death event external dependency
check (Gameplay Part 4)". Checked Bukkit/Paper `EntityDeathEvent`, Forge/NeoForge
`LivingDeathEvent`, `tfredrich/Domain-Eventing` (Apache-2.0), and `banq/jdonframework`
(Apache-2.0); none adopted — Minecraft-coupled, a competing event-bus abstraction, or far more
machinery (CQRS/event sourcing/distributed sagas) than "detect a transition and hand back one
immutable event" needs. No `integrations/` adapter or decision record was needed.

**Verified in this addition** (`javac` 21 via `java -m jdk.compiler/com.sun.tools.javac.Main` in
this sandbox — same approach as every prior addition below — + `support.TestRunner`, whole repo
excluding the three Bukkit-dependent `platform/java` files): 342 tests, 0 failed (baseline
immediately before: 315, 0 failed; +27 new: 17 added to the existing `DamageApplicationServiceTest`
(13 pre-existing `apply` methods untouched, now 30 total), 4 in the new
`DamageApplicationResultTest`, 6 in the new `EntityDiedTest`). Focused combat-module-only run: 86
tests, 0 failed (baseline 59, 0 failed). Gradle was not run (no Gradle/wrapper/network in this
sandbox, consistent with every prior addition below).

## Gameplay Part 7 — Combat: Respawn Persistence (added)

`:modules:combat` gains the persistence/recovery boundary for `combat.domain.RespawnLifecycleState`,
built on the existing `core.contracts.IPersistenceGateway` (no new repository abstraction):
`combat.contracts.RespawnLifecycleSnapshot` (immutable persistence model: `schemaVersion`, `revision`,
`entity`, `status` name, `destination`, `savedAt`), `combat.services.RespawnLifecycleSnapshotMapper`
(validated, non-repairing two-way mapping — `toSnapshot`/`restore`), and
`combat.services.RespawnLifecycleStore` (`load`/`save`/`discard` against `IPersistenceGateway`, with
optimistic-revision conflict detection and three-way `NotFound`/`Failed`/`Corrupt` load results and
`Saved`/`VersionConflict`/`Blocked` save results). What is persisted: identity, lifecycle status, the
decided destination while one exists, plus schema/revision/timestamp bookkeeping. `Health` and the
death/respawn events themselves are deliberately not persisted. No Bukkit/Paper dependency, no
distributed-transaction machinery, no database choice made (still `InMemoryPersistenceGateway` only).

**External dependency check:** see `modules/combat/MODULE.md` → "Respawn persistence external
dependency check (Gameplay Part 7)". Referenced Spring Data's `@Version` optimistic-locking pattern
(Apache-2.0) as a shape reference only; not adopted (full ORM framework for a ~15-line need). No
`integrations/` adapter or decision record was needed.

**Verified in this addition** (`javac` 21 + `support.TestRunner`, whole repo including the
previously-excluded three Bukkit-dependent `platform/java` files were still excluded — same
convention as every prior addition): full suite 493 tests, 0 failed (baseline immediately before
Part 7: 439, 0 failed; +54 new — `RespawnLifecycleSnapshotTest` 5,
`RespawnLifecycleSnapshotMapperTest` 15, `RespawnLifecycleStoreTest` 34). Focused combat-module-only
run: 237 tests, 0 failed (baseline before Part 7: 183, 0 failed). Gradle not run (no
Gradle/wrapper/network in this sandbox).

## Gameplay Part 6 — Combat: Respawn Lifecycle Boundary (added)

`:modules:combat` gains the application/domain-level respawn lifecycle:
`combat.domain.RespawnLifecycleStatus` (`ALIVE`, `DEAD`, `RESPAWN_ELIGIBLE`, `RESPAWN_DECIDED`,
`RESPAWN_EXECUTION_REQUESTED`) and `combat.domain.RespawnLifecycleState` (one immutable per-entity
value with validated transition methods — calling one from the wrong status throws
`IllegalStateException`, so e.g. a living entity simply cannot be moved toward respawn). New
orchestration service `combat.services.RespawnLifecycleService` drives that state through five
separate steps (`recordDeath`, `evaluateEligibility`, `decideDestination`, `requestExecution`,
`completeExecution`, plus a convenience `execute`), each returning a `RespawnLifecycleResult` that
distinguishes `APPLIED`/`DUPLICATE`/`DENIED`/`REJECTED`/`EXECUTION_FAILED` — repeated death events,
repeated respawn requests, and repeated success reports are all absorbed as `DUPLICATE` with no
second transition and no second `EntityRespawned`; a reported execution failure returns state to
exactly what it was before the request (states are immutable, so nothing is silently mutated even
on failure). The execution boundary itself — `combat.contracts.IRespawnExecutor` plus
`RespawnExecutionRequest`/`RespawnExecutionResult` — has no implementation in this module and no
Bukkit/Paper/Minecraft type anywhere in its signature; the core only ever says "entity X may respawn
at destination Y" and receives success-or-failure back. `combat.events.EntityRespawned` is published
(returned, not bus-published) exactly once, only on confirmed success. No event bus dependency, no
global mutable state, no hidden static state.

**Not built yet:** any `IRespawnExecutor` implementation (a platform adapter's job), respawn timers,
death penalties/rewards, and persistence of this lifecycle state (Gameplay Part 7).

**External dependency check:** see `modules/combat/MODULE.md` → "Respawn lifecycle external
dependency check (Gameplay Part 6)". Checked Spring Statemachine and Squirrel Foundation
(Apache-2.0 each); neither adopted — full state-machine frameworks for a five-state, one-path
lifecycle this project's existing immutable-value-with-transitions style already covers in a few
small types. Re-checked Bukkit/Paper respawn events (still Minecraft-coupled, still events not a
lifecycle model). No `integrations/` adapter or decision record was needed.

**Verified in this addition:** full suite 439 tests, 0 failed (baseline immediately before Part 6:
378, 0 failed; +61 new — `RespawnLifecycleStateTest` 10, `RespawnExecutionContractsTest` 5,
`EntityRespawnedTest` 4, `RespawnLifecycleResultTest` 4, `RespawnLifecycleServiceTest` 38). Focused
combat-module-only run: 183 tests, 0 failed (baseline before Part 6: 122, 0 failed). Gradle not run.

## Gameplay Part 5 — Combat: Respawn Foundation (added)

`:modules:combat` gains the neutral Respawn domain foundation, laying groundwork for Gameplay Parts
6+. New `public/contracts`: `combat.contracts.RespawnPoint` (validated wrapper around
`core.domain.Location` — invalid destinations are unrepresentable, not merely rejected later),
`IRespawnPointProvider` (extension point, no implementation), `RespawnDenialReason`
(`ENTITY_ALIVE`, `KIND_NOT_RESPAWNABLE`, `NO_RESPAWN_POINT`), `RespawnRequest` (with
`RespawnRequest.from(EntityDied)` bridging the existing death pipeline), and `RespawnDecision`
(sealed `Granted`/`Denied`). New `internal`: `combat.domain.RespawnEligibility` and
`combat.services.RespawnDecisionService` — a pure, stateless service answering eligibility (reusing
`Health.isAlive()`, not duplicating it) and destination (via the injected provider) separately or
together via `decide`. No entity kind is hardcoded as respawnable; the configured set (even empty)
is constructor data. No teleport, no revival, no Bukkit/Paper dependency, no timers, no penalties.

**Not built yet:** the respawn lifecycle boundary/state machine (Part 6), any real
`IRespawnPointProvider` implementation, execution of a decision, persistence.

**External dependency check:** see `modules/combat/MODULE.md` → "Respawn external dependency check
(Gameplay Part 5)". Checked Bukkit/Paper `PlayerRespawnEvent`/`PlayerPostRespawnEvent`
(Minecraft-coupled, event not a rules model); nothing adopted. No `integrations/` adapter or
decision record was needed.

**Verified in this addition:** full suite 378 tests, 0 failed (baseline immediately before Part 5:
342, 0 failed; +36 new — `RespawnPointTest` 5, `RespawnRequestTest` 4, `RespawnDecisionTest` 4,
`RespawnDecisionServiceTest` 20, `RespawnEligibilityTest` 3). Focused combat-module-only run: 122
tests, 0 failed (baseline before Part 5: 86, 0 failed). Gradle not run (no Gradle/wrapper/network in
this sandbox, consistent with every prior addition).

## Gameplay Part 3 — Combat: Damage Application / Orchestration (added)

`:modules:combat` gains `combat.services.DamageApplicationService`, a stateless orchestration
service with one method, `apply(DamageResult, Health) -> Health`, closing the loop
`DamageResult + Target Health -> Apply Damage -> New Health`. It delegates entirely to the
existing, unchanged `Health.apply(DamageResult)` — it does not duplicate damage-application rules,
does not know which `Health` belongs to a `DamageResult.target()`, and does not look one up, store
one, or publish anything (target-health storage/persistence remains out of scope, as before).
`DamageType`, `DamageRequest`, `DamageCalculator`, `DamageResult`, and `Health` are all unchanged
from Parts 1 and 2.

**Not built yet:** target-health storage/lookup by identity, death events, respawn,
healing/regeneration, armor, resistance, weapons, abilities, NPC AI, PvP, any Minecraft combat
hook.

**Verified in this addition** (`javac` 21 + `support.TestRunner`, whole repo excluding the three
Bukkit-dependent `platform/java` files): 315 tests, 0 failed (baseline immediately before: 302, 0
failed; +13 new, all in `tests/modules/combat/services/DamageApplicationServiceTest.java`). Focused
combat-module-only run: 59 tests, 0 failed (baseline 46, 0 failed). Gradle was not run.

## Gameplay Part 2 — Combat: Health/HP (added)

`:modules:combat` gains `combat.domain.Health` — an immutable record `(current, max)` with
`Health.full(max)`, `isAlive()`/`isDead()` (dead iff `current == 0`) and `apply(DamageResult)`
returning a new `Health`. Invalid HP (non-finite/non-positive max, negative/non-finite/above-max
current) is rejected at construction; damage floors HP at zero; zero damage returns an equal
value. Part 1 types (`DamageRequest`, `DamageCalculator`, `DamageResult`) are unchanged. No new
identity/entity/stat concept was added — `Health` has no owner; mapping a `DamageResult.target()`
to a `Health` and storing the result is combat orchestration (later Part). It is also not yet
connected to `progression`'s `DerivedStatType.MAX_HEALTH`.

**Not built yet:** healing/regeneration, armor, resistance, death events, respawn, orchestration,
weapons, abilities, NPC AI, PvP, any Minecraft combat hook.

**Verified in this addition** (`javac` 21 + `support.TestRunner`, whole repo excluding the three
Bukkit-dependent `platform/java` files): 302 tests, 0 failed (baseline immediately before:
280, 0 failed; +22 new, all in `tests/modules/combat/domain/HealthTest.java`). Focused
combat-module-only run: 46 tests, 0 failed. Gradle was not run.

## Gameplay Part 1 — Combat: Damage Model (added)

`:modules:combat` now has its first real code (was an empty scaffold): `DamageType`
(Physical/Magical/Fire/Frost/Lightning/Poison/Shadow/Holy), `DamageRequest`,
`DamageResult`, and `DamageCalculator` implementing
`Attacker -> DamageRequest -> DamageCalculator -> DamageResult`. Deterministic, no
randomness, final amount clamped to a minimum of zero, zero damage supported.
`source`/`target` are `core.domain.EntityRef` — no new identity type, `PlayerId`
remains the sole player-identity boundary. See `modules/combat/MODULE.md` for the
external-library check and full detail.

**Not built yet:** Health/HP, weapons, armor, resistance/weakness, crit, abilities,
NPC AI, PvP, or any Minecraft combat hook — these are later Gameplay Parts.

**Verified in this addition** (`javac` 21 + `support.TestRunner`, same exclusions as
below): 274 tests, 0 failed (baseline before this addition: 250, 0 failed; +24 new,
all in `tests/modules/combat/`). Gradle was not run.

## CharacterRuntime ownership review (added, post Phase 14)

- **Project status (owner-reported):** the project owner states it has been tested and has had no errors so far. This is
  the owner's statement; it is recorded here as such. It does not replace the verification notes below (Gradle build and
  real-Paper verification are still listed as not done by the authoring sandbox — the owner's statement did not say
  whether those were covered).
- **Verified in this review (assistant, `javac` 21 + `support.TestRunner`, whole repo excluding the three Bukkit-dependent
  `platform/java` files):** 254 tests, 0 failed (baseline before the review: 249, 0 failed; +5 new). Gradle was not run.
- **CharacterRuntime ownership — reviewed, one defect fixed:** every part (progression, inventory, equipment) must be
  owned by the runtime's `CharacterId`; this is enforced at `CharacterRuntime` construction, in `CharacterRuntimeSnapshot`,
  in `CharacterRuntimeFactory.restore`, and (fixed now) in `CharacterRuntimeService.load`, which returns `Failed` if the
  directory answers with a character other than the one requested.
- **PlayerSessionService ownership guard (fixed afterwards):** `PlayerSessionService.join` now checks that the loaded
  character's `ownerId` equals the joining `PlayerId` before registering a session, and does not trust the
  `CharacterSelector`. A mismatch returns `LoadRejected(playerId, Failed(...))` and registers nothing. Covered by
  `PlayerSessionServiceTest#characterOwnedByAnotherPlayerIsRejectedEvenIfTheSelectorReturnsIt` (255 tests, 0 failed).

## Master Phase 12–14 — Character Runtime Foundation (added)

What exists now: character-owned Inventory/Equipment/Progression with public snapshot models, one canonical
`inventory.contracts.ItemId`, `:application:runtime` (runtime, sessions, join/quit lifecycle, load/save through
`IPersistenceGateway`), an in-memory development store, and a composition root that wires them. See
`ARCHITECTURE.md` → "Character runtime" and `docs/decisions/0004-application-runtime-layer.md`.

Verification status: all Java domain/application code compiles with `javac` and its tests pass under
`support.TestRunner`. **Not verified:** a Gradle build (no Gradle/wrapper/network in the authoring sandbox) and the Paper
layer against the real Paper API (only compiled against local stubs). Characters/inventories are **not persistent across
restarts** (in-memory store). No character-creation flow exists yet, so a player without a character joins "with no character".

_Last updated: Phase 11 — Gradle Multi-Module Integration & Build Graph_

## Phase 11 — Gradle Multi-Module Integration (added)

- **Gradle project graph:** `:core`, `:modules:character`,
  `:modules:progression`, `:modules:inventory`, `:modules:equipment`,
  `:platform:java` (settings + one `build.gradle.kts` per module; no source
  moved, no Java changed). Module source roots are the existing
  `internal/` and `public/` folders; tests are `tests/<mirror>` plus the
  shared `tests/support`. Dependencies follow real imports only:
  `character → core`, `progression → core, character`,
  `equipment → inventory`, `inventory → (none)`, `platform:java → core`.
- **Tests:** the custom `@Test`/`TestRunner` harness is not JUnit, so the
  root `build.gradle.kts` adds a `harnessTest` task (runs
  `support.TestRunner` over compiled `*Test` classes) and `test` delegates
  to it.
- **Verification status:** Gradle itself was **not** executed (no Gradle,
  no `gradlew`/wrapper jar, no network). The graph was emulated with
  `javac` 21 (invoked as `java -m jdk.compiler/com.sun.tools.javac.Main`,
  which this JRE does provide) and `support.TestRunner`: all modules
  compile and their 139 harness tests pass, except the three
  Bukkit-dependent `platform/java` files, which need `paper-api` and could
  not be compiled. The "no `javac`" statements in the sections below refer
  to there being no `javac` launcher, and predate this run.

## Prompt 09/10 — Paper Platform Foundation & Composition Root (added)

## Prompt 09/10 — Paper Platform Foundation & Composition Root (added)

- **Architecture decisions:** `docs/decisions/0003-paper-platform-and-composition-root.md`
  (new) — Minecraft Java Edition 1.21.11 via Paper is the first concrete
  loader; Gradle (Kotlin DSL) is the build tool, as a multi-project
  build (`:core`, `:platform:java`); Java language level raised 17 → 21
  (amends `0001`); the composition root lives in `platform/java`'s
  `bootstrap` package; Paper/Bukkit is the platform layer itself, not
  an `integrations/`-wrapped external dependency.
- **New Gradle build:** root `settings.gradle.kts` (repositories:
  Maven Central + PaperMC) and `build.gradle.kts` (shared Java 21
  toolchain across subprojects); `core/build.gradle.kts` (points a
  source set at the existing `core/{domain,events,contracts,services}`
  folders — no code moved, no `src/main/java` wrapper added, per
  `0001`); `platform/java/build.gradle.kts` (Paper API `compileOnly`,
  `:core` `implementation`, `com.gradleup.shadow` for a shaded
  deployable jar, `processResources` filtering `plugin.yml`'s
  `${version}` token). `gradle/wrapper/gradle-wrapper.properties`
  records the intended Gradle version (8.10.2); the wrapper `.jar`
  itself could not be fetched — no network access in this environment
  (see Known Limitation below).
- **New production core service:** `core/services/InProcessEventBus.java`
  — the first concrete `core.contracts.IEventBus`, in-process/
  single-server/synchronous. Tested: `tests/core/services/InProcessEventBusTest.java`
  (5 methods). `core/services/README.md` updated (no longer "intentionally
  empty").
- **New Paper plugin — `platform/java/src/main/java/castelslayer/platform/paper/`:**
  - `CastelSlayerPlugin` — entrypoint; `onEnable` runs the composition
    root and registers `PlayerConnectionListener`; `onDisable` releases
    nothing (no service yet needs a shutdown hook — no fake shutdown
    logic was added for that).
  - `bootstrap/CompositionRoot` + `bootstrap/CoreRuntime` — the
    composition root; wires only `IEventBus` (→ `InProcessEventBus`),
    since it's the only `core.contracts` interface with both a
    production implementation and a real consumer this phase.
  - `identity/PlayerIdentityMapper` — Bukkit `Player` →
    `core.domain.PlayerId`/`PlayerIdentity`. Deliberately does **not**
    resolve `character.contracts.CharacterId` — that needs
    `ICharacterDirectory`, which needs `IPersistenceGateway`, which has
    no production implementation yet (persistence is out of scope this
    phase). No UUID-equals-CharacterId assumption was made.
  - `listeners/PlayerConnectionListener` — translates Bukkit
    `PlayerJoinEvent`/`PlayerQuitEvent` into
    `core.events.PlayerJoinedWorld`/`PlayerLeftWorld`, published via
    the composition root's event bus. Never exposes a Bukkit `Event`
    type to `core`.
  - `commands/` — intentionally empty (`package-info.java` only); no
    commands were invented, per the task brief.
  - Base package is `castelslayer.platform.paper`, not the
    folder-literal `platform.java` — see `docs/decisions/0003-...`
    point 6 for why.
  - `src/main/resources/plugin.yml` — name `CastelSlayer`, main class
    above, `api-version: '1.21'`, version injected from Gradle via
    `${version}`.
- **Tested:** `tests/core/services/InProcessEventBusTest.java` (5
  methods) and `tests/platform/java/bootstrap/CompositionRootTest.java`
  (2 methods) — both pure-JDK, no Bukkit/Paper classpath needed. The
  plugin entrypoint, the listener, and the identity mapper import
  `org.bukkit.*`/`io.papermc.*` directly and were **not** unit-tested
  this phase — see Known Limitation below for why, and for what manual
  review was done instead.
- **Forbidden-list compliance (verified by review):** no gameplay,
  commands, NPCs, items, quests, economy, AI, Geyser, Floodgate,
  MythicMobs, ItemsAdder, ModelEngine, WorldGuard, or database/
  persistence code was added. `modules/character`'s `ICharacterDirectory`
  is referenced only in Javadoc explaining why it *isn't* wired in yet
  — no call to it exists in `platform/java`.

## Known Limitation — Paper Plugin Not Compiled, Gradle Not Run Here

This sandbox has a JRE (`java` — OpenJDK 21.0.10) but **no `javac`, no
Gradle, and no network access** (`curl` to `repo.papermc.io` returns
`403`/`host_not_allowed`, matching the JDK/dotnet install failures
recorded in the two "Known Limitation" sections below). Concretely,
this means:

- **Static structure only was validated.** Every new `.java` file was
  reviewed by hand for compile-correctness (imports, `@Override`
  signatures against the Bukkit/Paper API surface as documented
  upstream, package declarations matching directory placement, no
  `org.bukkit.*`/`io.papermc.*` import anywhere under `core/`).
  `settings.gradle.kts`/`build.gradle.kts`/`core/build.gradle.kts`/
  `platform/java/build.gradle.kts` were reviewed the same way; none
  were run.
- **No Gradle build, dependency resolution, or artifact generation was
  attempted or could succeed here.** `paper-api:1.21.11-R0.1-SNAPSHOT`
  cannot be fetched from PaperMC's repository without network access.
  No `.jar` (shaded or otherwise) exists in this environment. Do not
  treat this as a working, deployable plugin until it has actually been
  built on a machine with network access.
- **The Gradle wrapper is incomplete.** `gradle/wrapper/gradle-wrapper.properties`
  records the intended distribution (Gradle 8.10.2); the wrapper
  `.jar` and the `gradlew`/`gradlew.bat` launcher scripts were not
  generated, since doing so requires either network access or a local
  Gradle install this sandbox doesn't have. Run
  `gradle wrapper --gradle-version 8.10.2` on a machine with both to
  complete it.
- **Only the pure-JDK slice was test-covered.**
  `tests/core/services/InProcessEventBusTest.java` and
  `tests/platform/java/bootstrap/CompositionRootTest.java` (7 methods
  total) touch no Bukkit/Paper type and were written the same way
  existing `tests/core/**` tests were — but, like all Java tests in
  this repo (see the older Known Limitation section below), they have
  **not actually been run**, for the same javac/network reasons.
  `CastelSlayerPlugin`, `PlayerConnectionListener`, and
  `PlayerIdentityMapper` import Bukkit/Paper types directly and cannot
  be unit-tested at all without either a live Paper server or a mocking
  library (e.g. MockBukkit) — neither is available here, and none was
  added, to avoid the "fake shutdown/test infrastructure" the task
  brief warns against. They were reviewed by hand instead.

To verify on a machine with a JDK 21, Gradle (or the completed
wrapper), and network access:

```sh
./gradlew build
# or, without a wrapper yet:
gradle build
```

This should compile `:core` and `:platform:java`, resolve
`paper-api:1.21.11-R0.1-SNAPSHOT` from PaperMC's repository, and
produce a shaded plugin jar under `platform/java/build/libs/`. This is
the top item for whoever/whatever picks up next — run it, fix whatever
it finds (most likely candidates: a Bukkit API signature that drifted
from what was hand-reviewed against documentation, or a Shadow-plugin
version mismatch), and record the actual result here.

## Prompt 08 — Java as Sole Production Language (added)

- **Architecture decision (reverses Prompt 05):** Java is now the only
  production language for this project. See
  `docs/decisions/0002-java-as-sole-production-language.md`.
- `dotnet-core/` is **deprecated and reference-only** — not deleted, not
  modified beyond documentation, not extended with new modules, not on
  any build/ship path. `dotnet-core/README.md` carries a deprecation
  notice.
- No C#↔Java bridge was built (the one Prompt 05 deferred is now moot for
  production purposes).
- No migration happened this prompt: `CastelSlayer.Modules.Progression`,
  `.Inventory`, and `.Equipment` (Prompts 05–07, C#) still have **no**
  Java counterpart. Those systems currently have no authoritative
  production implementation.
- No new gameplay logic was implemented this prompt — documentation/
  decision-record change only. Files changed: `docs/decisions/0002-java-as-sole-production-language.md`
  (new), `ARCHITECTURE.md`, `PROJECT_MAP.md`, `dotnet-core/README.md`,
  this file, `CHANGELOG.md`.
- Everything under "What Exists — C# Core" and the three Prompt 05–07
  sections below is now historical/reference only — kept as-is for
  record-keeping, not as a description of current production status.

## Prompt 07 — Equipment & Item Definition (added)

- New C# module `dotnet-core/src/CastelSlayer.Modules.Equipment` (details in
  its `MODULE.md`): immutable, self-validating `ItemDefinition` (Inventory's
  `ItemId`, name, `ItemCategory`, `MaxStackSize`, optional slot; equippable
  exactly when it has a slot), a domain `EquipmentSlot` enum (Head, Chest,
  Legs, Feet, MainHand, OffHand — not Minecraft's), and `ItemEquipment`
  (`Equip` / `Unequip` / `GetEquipped` / `IsSlotOccupied` / `IsEquipped` /
  `GetSlots`). Refusals are result values (`EquipStatus`: NotEquippable,
  InvalidSlot, IncompatibleSlot, AlreadyEquipped, SlotOccupied;
  `UnequipStatus`: SlotEmpty, InvalidSlot), never exceptions. An occupied slot
  is never overwritten; `Unequip` returns the removed item in its result.
- Boundaries: Equipment references Inventory for `ItemId` only (documented
  exception, `dotnet-core/docs/decisions/0003-equipment-module-boundary.md`).
  Inventory code is unchanged. Equipment never touches `ItemInventory`, and
  has no stats dependency or bonuses. No Minecraft/Java/Fabric code.
- Tests: `dotnet-core/tests/CastelSlayer.Tests/Modules/Equipment/` — 50 test
  methods; the test project now references the Equipment module.
- **Not compiled or run** — still no .NET SDK here (`dotnet` not found; the
  install script host returns 403). Validated statically only: manual
  compile-correctness review, a bracket/namespace/duplicate-test-name script,
  and hand-tracing of the trickier tests. Expect the runner to report 103
  methods by `[Test]` count (53 existing + 50 new). Earlier notes said 54
  existing; a grep of the current tests finds 53 (Progression's
  `LevelingServiceTests` has 9, not 10) — a small doc discrepancy, not
  investigated further.
- Left for later prompts: Inventory ↔ Equipment transactions (all-or-nothing
  moves; until then a caller must put an unequipped item somewhere), stat
  bonuses via Progression's `AttributeModifier`, item database/registry (and
  the permanent home of `ItemDefinition`), multi-slot items, promoting `ItemId`
  out of Inventory's internal namespace, events, persistence, loot, durability,
  enchantments, class/race restrictions, GUI, Java/Fabric mapping of slots.
- Prompt 08 can start. Its main risk is unchanged: none of the C# has been
  built yet, so a compile error in Prompts 05–07 would surface on first build.

## Prompt 06 — Inventory Foundation (added)

- New C# module `dotnet-core/src/CastelSlayer.Modules.Inventory` (details in
  its `MODULE.md`): `ItemInventory` with fixed slots, `ItemStack` limited to
  `MaxStackSize`, `AddItem` (fills existing stacks, then empty slots, reports
  overflow), `RemoveItem` (removes only what exists, reports shortfall),
  `HasItem`. Server authority: slots are private, callers see read-only
  `InventorySlot` snapshots. No dependency on Core, Character, Minecraft, or
  any other module.
- Tests: `dotnet-core/tests/CastelSlayer.Tests/Modules/Inventory/` — 27 test
  methods (`ItemStackTests`, `ItemInventoryTests`), covering the 10 required
  cases plus input-validation and edge cases.
- **Not compiled or run** — still no .NET SDK here. The add/remove algorithm
  was only cross-checked with a throwaway Python port of the same logic.
  Verify with the `dotnet test` / `dotnet run` commands in the C# "Known
  Limitation" section below; expect the harness to report 27 more passing
  methods (54 total including Progression's 27).
- Left for later prompts: ownership binding (`CharacterId`), events,
  `Public/Contracts` query interface, persistence, equipment, loot, trading,
  shop, crafting, item database/effects/durability, GUI.

## Architecture Decision Made In Prompt 05 (reversed in Prompt 08)

Prompt 05's brief made authoritative gameplay logic C#-first, with
Java/Fabric reduced to the Minecraft integration/platform layer. **This
was reversed in Prompt 08 — Java is now the sole production language and
`dotnet-core/` is deprecated/reference-only; see "Prompt 08" above and
`docs/decisions/0002-java-as-sole-production-language.md`.** The rest of
this section describes the reversed decision, kept for historical
record. See `dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md`
for the full original reasoning. Short version:

- A new `dotnet-core/` tree holds the C# Core, mirroring the existing
  `core/` + `modules/<name>/public|internal` shape in C#.
- The existing Java `core/` and `modules/character/` (Prompts 01–04,
  below) are **not migrated** — they remain as-is, are now legacy
  pending a future migration decision, and should not receive new
  gameplay logic.
- New gameplay modules go in `dotnet-core/src/CastelSlayer.Modules.<Name>/`
  from now on. This prompt added exactly one: `CastelSlayer.Modules.Progression`.
- The C# Core ↔ Java/Fabric integration mechanism (how the two runtimes
  will actually talk once platform/ needs to call into C#) is
  **explicitly deferred**, not built — building it now would be the
  "fake networking infrastructure" the brief rules out, and this
  environment has no network access to evaluate/fetch any candidate
  library anyway.

## What Exists — C# Core (Prompt 05, new)

- **`dotnet-core/src/CastelSlayer.Core`:** `Domain/CharacterId.cs` (C#
  analog of the Java `character.contracts.CharacterId` — same
  UUID/GUID concept, no shared code), `Events/IGameEvent.cs` (marker
  interface, analog of Java `core.events.GameEvent`),
  `Contracts/IEventBus.cs` (interface only, analog of Java
  `core.contracts.IEventBus` — no concrete implementation, by design;
  see the decision record).
- **`dotnet-core/src/CastelSlayer.Modules.Progression`** (Stats,
  Attributes, Progression — full detail in its own `MODULE.md`):
  - `Internal/Domain`: `AttributeType`, `DerivedStatType`,
    `ModifierOperation`, `AttributeModifier`, `CharacterAttributes`
    (base values + modifiers + effective-value calculation),
    `ProgressionState` (immutable Level/TotalXp), `CharacterStatsProfile`
    (aggregate root: `CharacterId` + `CharacterAttributes` + `ProgressionState`).
  - `Internal/Services`: `IProgressionCurve` / `DefaultProgressionCurve`
    (triangular-number XP curve, 100 XP per level-step, default max
    level 60), `DerivedStatCalculator` (pure formulas: MaxHealth,
    MaxMana, PhysicalPower, MagicPower, Defense, Speed),
    `AttributeModifierService` (validated Apply/Remove), `LevelingService`
    (the sole authoritative XP-gain/level-up path — returns events
    rather than publishing them, so it stays a pure, unit-testable
    function; caller is responsible for publishing to `IEventBus`).
  - `Public/Contracts`: `ICharacterStatsQuery` — declared as the future
    read surface for other modules, **no implementation yet**
    (deliberately — nothing consumes it this prompt).
  - `Public/Events`: `CharacterLeveledUp`.
  - No dependency on any other module, on any Minecraft/Fabric type, or
    on the Java `character` module — buildable/testable standalone
    (requirement 11).
- **Tests (Prompt 05):** `dotnet-core/tests/CastelSlayer.Tests/Support/`
  — a hand-rolled `TestAttribute`/`Assert`/`TestRunner` harness (C#
  analog of the Java side's `tests/support`, same reason: no network
  access to fetch a real test framework via NuGet). Real tests under
  `dotnet-core/tests/CastelSlayer.Tests/Modules/Progression/`:
  `CharacterAttributesTests` (10 methods), `DerivedStatCalculatorTests`
  (3 methods), `LevelingServiceTests` (10 methods — initial state,
  sub-threshold gain, invalid XP, exact-threshold level-up, one-XP-short
  boundary, multi-level gain, max-level discard, XP capping at the level
  cap, null-profile rejection), `CharacterStatsProfileTests` (4 methods).
- Top-level docs (`PROJECT_MAP.md`, `ARCHITECTURE.md`, this file,
  `CHANGELOG.md`) updated to document the split; `dotnet-core/README.md`
  and `dotnet-core/src/CastelSlayer.Modules.Progression/MODULE.md` added.

## Known Limitation — C# Not Compiled Or Run Here Either

Same situation as the Java side (see below): this environment has no
.NET SDK and no network access to install one (confirmed —
`apt-get install dotnet-sdk-8.0` fails with `403 Forbidden` for every
package, identical failure mode to the JDK attempt already recorded
below). All C# files were written and manually reviewed for
compile-correctness (types, record/struct syntax, `internal` visibility
+ the `InternalsVisibleTo` needed for tests to reach `Internal/`
members, nullable-reference annotations) but **none of it has actually
been compiled or run**.

To verify on a machine with the .NET 8 SDK installed:

```sh
cd dotnet-core
dotnet test tests/CastelSlayer.Tests/CastelSlayer.Tests.csproj
# or, using the hand-rolled runner directly:
dotnet run --project tests/CastelSlayer.Tests/CastelSlayer.Tests.csproj
```

This is a top item for whoever/whatever picks up next, alongside the
pre-existing Java verification item below.

## What Exists — Legacy Java Core (Prompts 01–04, unchanged this prompt)

- Full directory skeleton from Prompts 01–02 (unchanged): `core/`,
  `modules/` (10 modules), `platform/` (java, bedrock, shared),
  `integrations/` (empty), `docs/`, `tests/`, `database/` (placeholder).
- **Tech-stack decision (Prompt 03):** Java 17, no build tool yet — see
  `docs/decisions/0001-jvm-language-and-source-layout.md`. Source lives
  directly in the folders `PROJECT_MAP.md` already defined (no
  `src/main/java` wrapper); package names mirror folder names
  (`core/domain` → `package core.domain;`, `modules/character/public/
  contracts` → `package character.contracts;`, dropping the
  `public`/`internal` segment since `public` is a reserved Java
  keyword — that boundary stays a directory + code-review convention).
- **`core/domain` (Prompt 03), real code:** `PlayerId`, `EntityId`,
  `EntityKind`, `EntityRef`, `WorldId`, `AreaId`, `Location`,
  `ClientEdition`, `PlayerIdentity` — foundational IDs, a
  kind-agnostic entity reference, and platform-neutral world/location
  types. All immutable value types (Java records), validated in their
  compact constructors.
- **`core/events` (Prompt 03):** `GameEvent` marker interface,
  `PlayerJoinedWorld`, `PlayerLeftWorld`.
- **`core/contracts` (Prompt 03):** all six Prompt-01/02 contracts
  (`IEventBus`, `IPersistenceGateway`, `IPlatformPresenter`,
  `IContentValidator`, `IVisibilityProvider`, `IConfigProvider`) are
  now real Java interfaces, plus their supporting DTOs
  (`Subscription`, `ClientInputEvent`, `VisibleEntity`,
  `VisibleObject`, `VisibleWorldState`, `ContentKind`,
  `ContentProposal`, `ValidationOutcome`, `ValidationResult`). Each
  original `.md` design doc is kept as supplementary rationale and now
  points at its `.java` file.
- **`core/services`:** still empty, on purpose — see
  `core/services/README.md`.
- **`modules/character` (Prompt 04), real code — see
  `modules/character/MODULE.md` for full detail:**
  - `public/contracts`: `CharacterId`, `CharacterSummary`,
    `ICharacterDirectory`.
  - `public/events`: `CharacterCreated`, `CharacterRetired`.
  - `internal/domain`: `PlayerCharacter` (the identity/lifecycle
    aggregate — no race/class/progression fields by design),
    `CharacterState`.
  - `internal/services`: `CharacterFactory` (validated creation +
    event publication), `CharacterNameRules`, `CharacterDirectoryService`
    (`ICharacterDirectory` impl backed by `IPersistenceGateway` — the
    module's one explicit persistence boundary).
- **Tests (Prompts 03–04):** a dependency-free `tests/support/` harness
  (`@Test`, `Assertions`, `TestRunner`, `InMemoryEventBus`,
  `InMemoryPersistenceGateway`) plus real tests under
  `tests/core/{domain,events,contracts}/` (10 test methods) and
  `tests/modules/character/{domain,services}/` (10 test methods).
- Top-level docs (`README.md`, `PROJECT_MAP.md`, `ARCHITECTURE.md`,
  `DESIGN_PRINCIPLES.md`, `DEVELOPMENT_RULES.md`, this file,
  `CHANGELOG.md`) updated to match the above.

## Known Limitation — Tests Are Written But Not Executed Here

This sandbox has only a JRE (`java`), not a JDK — there is no `javac`,
and no network access to install one or fetch Maven/Gradle/JUnit (both
confirmed while doing this work: `apt-get install openjdk-21-jdk-headless`
fails with `403 Forbidden`, no proxy/mirror reachable). All 52 `.java`
files were written and manually reviewed line-by-line for
compile-correctness (types, generics, record canonical/compact
constructors, `@Override` signatures matching their interfaces), and
passed a scripted brace/paren-balance and package-declaration sanity
check, but **none of it has actually been compiled or run yet.**

To verify on a machine with a full JDK 17+ installed:

```sh
mkdir -p target/classes target/test-classes
find core modules/character -name '*.java' > /tmp/main-sources.txt
javac --release 17 -d target/classes @/tmp/main-sources.txt

find tests/support tests/core tests/modules/character -name '*.java' > /tmp/test-sources.txt
javac --release 17 -d target/test-classes -cp target/classes @/tmp/test-sources.txt

java -cp target/classes:target/test-classes support.TestRunner \
  core.domain.PlayerIdTest core.domain.EntityRefTest core.domain.LocationTest \
  core.domain.PlayerIdentityTest core.events.PlayerJoinedWorldTest \
  core.contracts.InMemoryEventBusTest core.contracts.InMemoryPersistenceGatewayTest \
  character.domain.PlayerCharacterTest character.services.CharacterFactoryTest \
  character.services.CharacterDirectoryServiceTest
```

This is the top item for whoever/whatever picks up next: run the above,
fix anything the manual review missed, and record the actual result
here.

## What Does NOT Exist Yet

- Compiled/run confirmation of the Java code, including the new Paper
  plugin (see "Known Limitation — Paper Plugin Not Compiled" above) or
  the C# code (see the C# Known Limitation section below).
- A composition root for the C# side — nothing yet needs one
  (`Progression`'s services are constructed directly by tests). The
  Java side now has one (`platform/java`'s `bootstrap.CompositionRoot`,
  Prompt 09/10) — see the top section above and
  `docs/decisions/0003-paper-platform-and-composition-root.md`.
- A C# Core ↔ Java/Fabric integration mechanism — moot as of Prompt 08;
  see "Architecture Decision Made In Prompt 05 (reversed in Prompt 08)"
  above and `docs/decisions/0002-java-as-sole-production-language.md`.
- Java implementations of `Progression`/`Inventory`/`Equipment` — the C#
  versions built under the since-reversed Prompt 05 decision are
  deprecated/reference-only and were not migrated by Prompt 08 or
  Prompt 09/10.
- The persistence engine and the concrete config source behind
  `IConfigProvider` (Java) / a C#-side equivalent — still undecided.
  `IPersistenceGateway` and `IConfigProvider` (Java) are interfaces
  only; the in-memory test doubles in `tests/support/` remain test
  infrastructure, not candidate production implementations. Because of
  this, `character.contracts.ICharacterDirectory` still has no
  production implementation either, so `platform/java` cannot yet
  resolve a connecting player's `CharacterId` — see
  `identity.PlayerIdentityMapper`'s Javadoc. The C# Core has no
  persistence or config story at all.
- Race, class, appearance, equipment, skills, buffs, professions, guild,
  reputation, knowledge, housing, history — all future systems meant to
  attach to a character by id — `Progression`'s own `MODULE.md` →
  "Forbidden Responsibilities" (C# side) lists what it must not do.
- Combat, quest, npc, economy, world-state, ai-director — no module
  (Java or C#) exists for any of these yet. (`inventory` now has a C#
  Foundation only — see "Prompt 06" above.)
- Java Edition ↔ `modules/character` wiring — `platform/java` does not
  call `ICharacterDirectory` yet (deliberately, see above).
- `platform/bedrock` and any Java/Bedrock bridge — untouched; Prompt
  09/10 only picked the Java Edition/Paper loader.
- A completed Gradle wrapper (`gradlew`/`gradlew.bat` +
  `gradle-wrapper.jar`) — blocked on network access, same as the C# SDK
  below.
- A real .NET SDK for the C# side — blocked on network access in this
  environment (see the C# "Known Limitation" section above), not a
  design choice. JUnit 5 for the Java side is similarly still blocked —
  `tests/support/`'s hand-rolled harness remains the only test
  infrastructure in use.

## Assumptions Carried Forward

- Targeting both Java Edition and Bedrock Edition.
- Preset Race system with a Resource-Pack-based body model and
  flat-skin fallback (unaffected by Prompts 03–04 — no race system
  exists yet).
- In-process, single-server event bus and synchronous dispatch
  (`InMemoryEventBus` in `tests/support/` demonstrates this shape but
  is a test double, not the production bus).
- Module boundary enforcement (`internal/` invisibility) is a
  convention + code-review rule, not compiler-enforced — this remains
  true even now that real code exists, since there's no build tool yet
  to add a hard boundary to.
- A player has exactly one active character at a time
  (`ICharacterDirectory#findActiveForPlayer` returns a single
  `Optional`) — a deliberate prototype-scope constraint, not an
  oversight; see `modules/character/MODULE.md`.

## Ready For The Next Prompt

- **Get a real build environment:** a JDK with `javac` (this sandbox has
  only a JRE), Gradle (or the completed wrapper), and network access —
  or hand the repo to a machine that has all three — and run
  `./gradlew build` (or `gradle build`); fix whatever it finds. This is
  the top item; nothing Java-side has been compiled here yet, including
  everything from Prompt 09/10. A .NET SDK is still not needed for
  production purposes; `dotnet-core/` remains reference-only.
- **Complete the Gradle wrapper**
  (`gradle wrapper --gradle-version 8.10.2`) once on a machine with
  Gradle and network access, and commit the generated
  `gradlew`/`gradlew.bat`/`gradle-wrapper.jar`.
- **Wire persistence** (choose and implement `IPersistenceGateway`) —
  this unblocks two things at once: `character.contracts.ICharacterDirectory`
  gets a real backing, and `platform/java` can then resolve a
  connecting player's `character.contracts.CharacterId` in
  `identity.PlayerIdentityMapper` instead of leaving it unimplemented.
  Record the engine choice in `docs/decisions/`.
- **Decide a config source** for `IConfigProvider` — still open; nothing
  in `platform/java` reads config yet since nothing tunable exists.
- Rebuild `Progression`, `Inventory`, and `Equipment` gameplay logic in
  Java under `modules/`, module by module — the C# versions under
  `dotnet-core/` may be consulted as reference (domain modeling, edge
  cases, test coverage) but are not ported mechanically. Any of these
  should attach to `character.contracts.CharacterId`, mirroring how the
  deprecated C# `Progression` attached to `CastelSlayer.Core.Domain.CharacterId`.
  Add each new module as a Gradle subproject the same way (Phase 11 did
  this for character/progression/inventory/equipment; see
  `docs/decisions/0003-...` Phase 11 amendment).
- Decide whether/how `modules/character` (Java) gains race/class/stats —
  as of Prompt 08 this is moot as a C#-porting question, since new work
  happens in Java directly.
- Once persistence exists, revisit whether `CompositionRoot` should wire
  `ICharacterDirectory`/`CharacterFactory`/`CharacterDirectoryService`
  and whether `PlayerConnectionListener` should start resolving
  characters on join (still deliberately not done this phase).
- The Minecraft version/loader, build tool, and composition-root
  location questions this section used to list are now decided — see
  `docs/decisions/0003-paper-platform-and-composition-root.md` — as is
  a concrete production `IEventBus` (`core.services.InProcessEventBus`).
  `platform/bedrock` and any Java/Bedrock bridge remain fully open.

