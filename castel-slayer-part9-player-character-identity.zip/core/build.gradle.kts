// :core has no external dependencies and must never depend on Paper/Bukkit — see
// ARCHITECTURE.md's dependency-direction matrix. This build file exists only to make
// :core's existing source layout (core/domain, core/events, core/contracts,
// core/services — see docs/decisions/0001-jvm-language-and-source-layout.md)
// compilable and consumable as a Gradle project dependency; the folder layout itself
// is unchanged.

plugins {
    java
}

sourceSets {
    main {
        java {
            setSrcDirs(listOf("domain", "events", "contracts", "services"))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
    test {
        java {
            // tests/core mirrors core/; tests/support is the shared harness.
            setSrcDirs(listOf(rootProject.file("tests/core"), rootProject.file("tests/support")))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}
