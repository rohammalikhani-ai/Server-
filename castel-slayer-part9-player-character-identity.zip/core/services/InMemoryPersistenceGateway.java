package core.services;

import core.contracts.IPersistenceGateway;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;
import java.util.function.Predicate;

/**
 * The development/testing {@link IPersistenceGateway}: everything lives in this
 * process's memory and is gone when the server stops. It is <b>not</b> a production
 * database (none has been chosen — see {@code CURRENT_STATE.md}); it exists so the
 * character runtime can run, and be tested, end to end without one. A real
 * gateway will live in the {@code persistence} module and replace this at the
 * composition root, with no change to any caller.
 *
 * <p>Deterministic by construction: each collection is kept sorted by key, so
 * {@link #query} always returns results in key order regardless of insertion order or
 * JVM hash seeds.
 *
 * <p>Values are stored by reference, not copied. That is only safe because everything
 * passed through an {@link IPersistenceGateway} must be an <em>immutable</em>
 * module-owned DTO or {@code core.domain} value (see the interface's contract) — never
 * a live, mutable aggregate. {@code load} additionally checks the stored value against the
 * requested {@code type} and reports a mismatch as a {@link core.contracts.PersistenceException}
 * rather than a bare {@code ClassCastException}.
 *
 * <p>Methods are {@code synchronized}: cheap insurance (the server is single-threaded
 * for gameplay today), not a concurrency design.
 */
public final class InMemoryPersistenceGateway implements IPersistenceGateway {

    private final Map<String, Map<String, Object>> store = new TreeMap<>();

    @Override
    public synchronized <T> void save(String collection, String key, T value) {
        Objects.requireNonNull(collection, "collection");
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(value, "value");
        store.computeIfAbsent(collection, c -> new TreeMap<>()).put(key, value);
    }

    @Override
    public synchronized <T> Optional<T> load(String collection, String key, Class<T> type) {
        Objects.requireNonNull(collection, "collection");
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(type, "type");
        Map<String, Object> bucket = store.get(collection);
        if (bucket == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(cast(collection, key, bucket.get(key), type));
    }

    @Override
    public synchronized void delete(String collection, String key) {
        Objects.requireNonNull(collection, "collection");
        Objects.requireNonNull(key, "key");
        Map<String, Object> bucket = store.get(collection);
        if (bucket != null) {
            bucket.remove(key);
        }
    }

    @Override
    public synchronized <T> List<T> query(String collection, Class<T> type, Predicate<T> filter) {
        Objects.requireNonNull(collection, "collection");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(filter, "filter");
        Map<String, Object> bucket = store.get(collection);
        if (bucket == null) {
            return List.of();
        }
        List<T> result = new ArrayList<>();
        for (Map.Entry<String, Object> entry : bucket.entrySet()) {
            T typed = cast(collection, entry.getKey(), entry.getValue(), type);
            if (filter.test(typed)) {
                result.add(typed);
            }
        }
        return result;
    }

    private static <T> T cast(String collection, String key, Object value, Class<T> type) {
        if (value == null || type.isInstance(value)) {
            return type.cast(value);
        }
        throw new core.contracts.PersistenceException("'" + collection + "/" + key + "' holds a "
                + value.getClass().getName() + ", not a " + type.getName());
    }
}
