package core.services;

import core.contracts.IEventBus;
import core.contracts.Subscription;
import core.events.GameEvent;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * The production {@link IEventBus}: in-process, single-server, synchronous dispatch
 * (see {@code CURRENT_STATE.md} → "Assumptions Carried Forward" — a multi-server bus
 * is out of scope until the project actually needs one). Shaped identically to
 * {@code tests/support/InMemoryEventBus}, which this supersedes as the thing modules
 * actually run against; that class remains a test double only.
 *
 * <p>Only the composition root may construct this (see {@code ARCHITECTURE.md} →
 * "Composition Root"). As of {@code docs/decisions/0003-paper-platform-and-composition-root.md}
 * that is {@code platform/java}'s {@code bootstrap.CompositionRoot}. No module may
 * construct this directly.
 *
 * <p>A subscriber's failure is caught and reported to stderr, never allowed to break
 * the publisher or other subscribers — {@code core} has no logging abstraction yet
 * (no {@code core.contracts} interface for it), so this is deliberately the simplest
 * thing that satisfies {@link IEventBus}'s "must never throw on behalf of a
 * subscriber's failure" contract without inventing one.
 */
public final class InProcessEventBus implements IEventBus {

    private final Map<Class<?>, List<Consumer<?>>> handlers = new ConcurrentHashMap<>();

    @Override
    public <T extends GameEvent> void publish(T event) {
        List<Consumer<?>> subs = handlers.get(event.getClass());
        if (subs == null) {
            return;
        }
        for (Consumer<?> raw : subs) {
            @SuppressWarnings("unchecked")
            Consumer<T> handler = (Consumer<T>) raw;
            try {
                handler.accept(event);
            } catch (RuntimeException ex) {
                System.err.println("[core.services.InProcessEventBus] subscriber threw handling "
                        + event.getClass().getSimpleName() + ": " + ex);
            }
        }
    }

    @Override
    public <T extends GameEvent> Subscription subscribe(Class<T> eventType, Consumer<T> handler) {
        List<Consumer<?>> subs = handlers.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>());
        subs.add(handler);
        return new HandleSubscription(eventType, handler);
    }

    @Override
    public void unsubscribe(Subscription subscription) {
        if (!(subscription instanceof HandleSubscription handle)) {
            return;
        }
        List<Consumer<?>> subs = handlers.get(handle.eventType());
        if (subs != null) {
            subs.remove(handle.handler());
        }
    }

    private record HandleSubscription(Class<?> eventType, Consumer<?> handler) implements Subscription {
    }
}
