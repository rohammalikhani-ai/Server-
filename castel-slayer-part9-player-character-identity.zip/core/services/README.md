# core/services

`ARCHITECTURE.md` describes this directory as cross-cutting,
server-authoritative services (validation, authority/permission
checks, and engine-wide contract implementations) that don't belong to
one feature module.

## What's here

- **`InProcessEventBus.java`** (Prompt 09/10) — the production
  `core.contracts.IEventBus`: in-process, single-server, synchronous
  dispatch. Added when `platform/java`'s composition root needed a real
  bus to publish `PlayerJoinedWorld`/`PlayerLeftWorld` — see
  `docs/decisions/0003-paper-platform-and-composition-root.md`. Only a
  composition root may construct it (currently
  `platform/java`'s `bootstrap.CompositionRoot`); no module may
  construct it directly. `tests/support/InMemoryEventBus` remains a
  separate, smaller test double used by `core`/module unit tests that
  don't want a real bus's lifecycle.

## What's still empty on purpose

An authority-check service (e.g. for Gold/Items) is not added yet. Per
`DEVELOPMENT_RULES.md` ("never create a manager/service for a feature
that isn't being built yet"), it becomes justified once `economy`/
`inventory` exist, not before. The extension point is already in place
at the contract level: `core/contracts/IContentValidator.java` is
where AI/externally-sourced content gets gated (DESIGN_PRINCIPLES rule
9); a concrete authority-check service will live here once a module
needs to call it. Likewise, no `core.contracts.IPersistenceGateway` or
`IConfigProvider` implementation lives here yet — no persistence engine
or config source has been chosen (see `CURRENT_STATE.md`).
