package core.events;

import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;
import java.util.Objects;

/** Published when a player's presence in a world ends (e.g. on logout or world change). */
public record PlayerLeftWorld(PlayerId playerId, WorldId worldId, Instant occurredAt) implements GameEvent {

    public PlayerLeftWorld {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(worldId, "worldId");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
