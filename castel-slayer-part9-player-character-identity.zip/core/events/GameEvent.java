package core.events;

import java.time.Instant;

/**
 * Marker interface for every event published through {@code core.contracts.IEventBus}.
 * Per DEVELOPMENT_RULES "Event Conventions": events are immutable data, no behavior —
 * implementations should be {@code record}s. An event carries only what a subscriber
 * needs to react, never a full dump of the publisher's internal state.
 */
public interface GameEvent {
    /** When this event occurred, server time. */
    Instant occurredAt();
}
