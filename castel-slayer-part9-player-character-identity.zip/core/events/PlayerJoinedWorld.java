package core.events;

import core.domain.PlayerId;
import core.domain.WorldId;
import java.time.Instant;
import java.util.Objects;

/** Published when a player's presence becomes active in a world (e.g. on login or world change). */
public record PlayerJoinedWorld(PlayerId playerId, WorldId worldId, Instant occurredAt) implements GameEvent {

    public PlayerJoinedWorld {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(worldId, "worldId");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
