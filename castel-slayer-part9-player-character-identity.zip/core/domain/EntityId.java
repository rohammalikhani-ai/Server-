package core.domain;

import java.util.Objects;
import java.util.UUID;

/**
 * Identifies any non-player world entity — an NPC, an item instance, a projectile, a
 * structure, etc. Kept separate from {@link PlayerId} so a method signature or event
 * field makes it obvious whether it accepts only players or any entity.
 *
 * <p>For code paths that must accept either a player or a non-player entity uniformly
 * (e.g. "who dealt this damage"), see {@link EntityRef}.
 */
public record EntityId(UUID value) {

    public EntityId {
        Objects.requireNonNull(value, "value");
    }

    public static EntityId random() {
        return new EntityId(UUID.randomUUID());
    }

    public static EntityId of(UUID value) {
        return new EntityId(value);
    }

    @Override
    public String toString() {
        return value.toString();
    }
}
