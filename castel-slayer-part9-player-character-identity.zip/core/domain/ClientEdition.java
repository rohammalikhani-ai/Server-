package core.domain;

/**
 * Which Minecraft edition a player is connected through. Purely informational —
 * server-authoritative rules never branch on this to change what a player is allowed
 * to do (DESIGN_PRINCIPLES rule 6: one game logic, multiple presentations). Platform
 * adapters use it to decide how to present the same state.
 */
public enum ClientEdition {
    JAVA,
    BEDROCK,
    UNKNOWN
}
