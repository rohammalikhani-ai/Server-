package core.domain;

import java.util.Objects;

/**
 * Basic, platform-neutral identity facts about a connected player: who they are and
 * which client edition they're on. This is not gameplay state — no level, no
 * location, no inventory. See the {@code character} module for the
 * player-owns-a-character layer built on top of this.
 */
public record PlayerIdentity(PlayerId id, String displayName, ClientEdition edition) {

    public PlayerIdentity {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(edition, "edition");
        Objects.requireNonNull(displayName, "displayName");
        displayName = displayName.trim();
        if (displayName.isEmpty()) {
            throw new IllegalArgumentException("displayName must not be blank");
        }
    }
}
