package core.domain;

/**
 * What kind of thing an {@link EntityRef} points at. Deliberately small and generic —
 * modules that need richer typing (e.g. "goblin" vs. "dragon") own that distinction
 * themselves; this enum only distinguishes categories that core-level code needs to
 * reason about generically (e.g. "is the source of this damage a player").
 */
public enum EntityKind {
    PLAYER,
    NPC,
    ITEM_INSTANCE,
    PROJECTILE,
    STRUCTURE,
    OTHER
}
