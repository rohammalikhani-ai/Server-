package core.domain;

import java.util.Objects;

/**
 * Identifies a named area/zone within a {@link WorldId} — finer-grained than a whole
 * world (e.g. {@code "castel_capital_market_district"}). Used primarily by
 * {@code world-state}'s visibility/phasing lookups (see
 * {@code core.contracts.IVisibilityProvider}); most gameplay code only needs a
 * {@link Location}.
 */
public record AreaId(String key) {

    public AreaId {
        Objects.requireNonNull(key, "key");
        key = key.trim();
        if (key.isEmpty()) {
            throw new IllegalArgumentException("AreaId key must not be blank");
        }
    }

    public static AreaId of(String key) {
        return new AreaId(key);
    }

    @Override
    public String toString() {
        return key;
    }
}
