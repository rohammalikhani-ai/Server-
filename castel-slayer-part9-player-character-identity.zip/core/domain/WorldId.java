package core.domain;

import java.util.Objects;

/**
 * Identifies a Minecraft world/dimension by a platform-neutral key (e.g.
 * {@code "overworld"}, {@code "castel_capital"}) rather than a Minecraft-specific
 * type, so {@code core} and {@code modules} never import platform types.
 */
public record WorldId(String key) {

    public WorldId {
        Objects.requireNonNull(key, "key");
        key = key.trim();
        if (key.isEmpty()) {
            throw new IllegalArgumentException("WorldId key must not be blank");
        }
    }

    public static WorldId of(String key) {
        return new WorldId(key);
    }

    @Override
    public String toString() {
        return key;
    }
}
