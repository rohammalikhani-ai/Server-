package core.domain;

import java.util.Objects;

/**
 * A platform-neutral position: a world plus coordinates. Shaped like a simplified
 * Minecraft location (world + x/y/z + yaw/pitch) without depending on any Minecraft
 * type, so platform adapters do that translation in exactly one place.
 */
public record Location(WorldId world, double x, double y, double z, float yaw, float pitch) {

    public Location {
        Objects.requireNonNull(world, "world");
        requireFinite(x, "x");
        requireFinite(y, "y");
        requireFinite(z, "z");
        requireFinite(yaw, "yaw");
        requireFinite(pitch, "pitch");
    }

    /** Convenience constructor for callers that don't care about facing direction. */
    public Location(WorldId world, double x, double y, double z) {
        this(world, x, y, z, 0f, 0f);
    }

    private static void requireFinite(double value, String name) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            throw new IllegalArgumentException(name + " must be a finite number, was " + value);
        }
    }

    private static void requireFinite(float value, String name) {
        if (Float.isNaN(value) || Float.isInfinite(value)) {
            throw new IllegalArgumentException(name + " must be a finite number, was " + value);
        }
    }
}
