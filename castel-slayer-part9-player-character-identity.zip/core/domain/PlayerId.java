package core.domain;

import java.util.Objects;
import java.util.UUID;

/**
 * The persistent, platform-neutral identity of a real player account.
 *
 * <p>A {@code PlayerId} identifies the account, not a character or its gameplay
 * state — see the {@code character} module for the character/progression layer that
 * attaches to a player. It is stable across Java and Bedrock clients: Bedrock players
 * are expected to reach the server through a bridge (e.g. Geyser/Floodgate) that
 * already synthesizes a UUID, so no separate Bedrock-specific identity type is needed
 * here (see {@link ClientEdition} for edition-specific presentation metadata instead).
 *
 * <p>Immutable value type. Two {@code PlayerId}s are equal iff their underlying UUIDs
 * are equal.
 */
public record PlayerId(UUID value) {

    public PlayerId {
        Objects.requireNonNull(value, "value");
    }

    /** Creates a new, random {@code PlayerId}. Used when a brand-new account is provisioned. */
    public static PlayerId random() {
        return new PlayerId(UUID.randomUUID());
    }

    /** Wraps an existing UUID (e.g. one supplied by the platform adapter at login). */
    public static PlayerId of(UUID value) {
        return new PlayerId(value);
    }

    @Override
    public String toString() {
        return value.toString();
    }
}
