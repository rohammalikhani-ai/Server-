package core.domain;

import java.util.Objects;
import java.util.UUID;

/**
 * A uniform, platform-neutral reference to "a thing in the world" — a player, an NPC,
 * an item instance, etc. — for code that must not care which. Events and other
 * cross-cutting concerns can hold one {@code EntityRef} field instead of a union of
 * {@link PlayerId}/{@link EntityId} types.
 *
 * <p>{@code EntityRef} carries only a kind and an id; it is not a lookup — resolving
 * it back into a concrete domain object is the owning module's job.
 */
public record EntityRef(EntityKind kind, UUID id) {

    public EntityRef {
        Objects.requireNonNull(kind, "kind");
        Objects.requireNonNull(id, "id");
    }

    public static EntityRef ofPlayer(PlayerId playerId) {
        Objects.requireNonNull(playerId, "playerId");
        return new EntityRef(EntityKind.PLAYER, playerId.value());
    }

    public static EntityRef of(EntityKind kind, EntityId entityId) {
        Objects.requireNonNull(kind, "kind");
        Objects.requireNonNull(entityId, "entityId");
        if (kind == EntityKind.PLAYER) {
            throw new IllegalArgumentException("Use EntityRef.ofPlayer(PlayerId) for PLAYER-kind refs");
        }
        return new EntityRef(kind, entityId.value());
    }

    /** True if this ref points at a player (i.e. {@code id} is a {@link PlayerId}'s underlying UUID). */
    public boolean isPlayer() {
        return kind == EntityKind.PLAYER;
    }

    /** Reconstructs the {@link PlayerId} this ref points at. Only valid when {@link #isPlayer()}. */
    public PlayerId asPlayerId() {
        if (!isPlayer()) {
            throw new IllegalStateException("EntityRef of kind " + kind + " is not a player");
        }
        return PlayerId.of(id);
    }
}
