package core.contracts;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/** The result of validating one {@link ContentProposal}. */
public record ValidationResult(ValidationOutcome outcome, Optional<Object> payload, List<String> reasons) {
    public ValidationResult {
        Objects.requireNonNull(outcome, "outcome");
        Objects.requireNonNull(payload, "payload");
        reasons = List.copyOf(reasons);
        if (outcome == ValidationOutcome.REJECTED && payload.isPresent()) {
            throw new IllegalArgumentException("A rejected result must not carry a payload");
        }
        if (outcome != ValidationOutcome.REJECTED && payload.isEmpty()) {
            throw new IllegalArgumentException(outcome + " result must carry a payload");
        }
    }

    public static ValidationResult approved(Object payload) {
        return new ValidationResult(ValidationOutcome.APPROVED, Optional.of(payload), List.of());
    }

    public static ValidationResult repaired(Object payload, List<String> reasons) {
        return new ValidationResult(ValidationOutcome.REPAIRED, Optional.of(payload), reasons);
    }

    public static ValidationResult rejected(List<String> reasons) {
        return new ValidationResult(ValidationOutcome.REJECTED, Optional.empty(), reasons);
    }
}
