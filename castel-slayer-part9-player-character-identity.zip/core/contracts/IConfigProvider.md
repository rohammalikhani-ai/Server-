# IConfigProvider

**Owner:** core
**Status:** implemented — see `IConfigProvider.java` in this directory (Prompt 03). This document remains as design rationale and open questions.

## Purpose

The single way any module or platform adapter reads configuration
values, without knowing or caring what the underlying config source
is (a file, a plugin config object, environment variables, etc.).
Added in Prompt 02 as part of the configuration strategy.

## Contract (language-agnostic sketch)

```
interface IConfigProvider {
    getString(key: string, default: string): string
    getInt(key: string, default: int): int
    getBool(key: string, default: bool): bool
    getList(key: string, default: List<string>): List<string>
}
```

## Rules

- Keys are namespaced by owning module: `<module-name>.<key>`, e.g.
  `economy.startingGold`, `combat.baseCritChance`,
  `character.defaultRace`. Core-level, cross-cutting keys (not owned
  by one module) use `core.<key>`.
- No module or platform file reads a raw config file, environment
  variable, or plugin config object directly — always through this
  interface. This is what keeps the concrete config source swappable
  without touching module code (DESIGN_PRINCIPLES rule 4).
- Every config key a module depends on, and its default, is
  documented in that module's `MODULE.md` under a "Configuration"
  section once the module is implemented — there is no single global
  schema file to keep in sync by hand.
- Defaults passed to `get*` calls must be safe/sane values a
  prototype can run with; a missing key must never crash startup.

## Consumed By

Every module and platform adapter that needs a tunable value instead
of a hard-coded one.

## Open Questions (for later prompts)

- Concrete config source (a config file format, Minecraft
  plugin-config, or something else) — deferred until the tech stack
  is chosen; record the choice in `docs/decisions/` when it happens.
- Hot-reload vs. read-once-at-startup — not decided; default
  assumption for the prototype is read-once-at-startup unless a
  system specifically needs live tuning.
