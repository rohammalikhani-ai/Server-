package core.contracts;

import core.domain.AreaId;
import core.domain.PlayerId;

/**
 * Answers "what can this player see right now" so two players sharing a location can
 * see different entities/objects/states based on quest/faction/reputation/event
 * conditions (DESIGN_PRINCIPLES rule 7). Implemented by {@code world-state}; queried
 * by {@link IPlatformPresenter} — never bypassed by reading raw state directly.
 */
public interface IVisibilityProvider {

    VisibleWorldState getVisibleWorldState(PlayerId playerId, AreaId areaId);
}
