package core.contracts;

import java.util.List;
import java.util.Map;

/**
 * What {@link IVisibilityProvider} returns for one player: everything (and only
 * what) that player is currently allowed to perceive. Consumed by
 * {@link IPlatformPresenter} — platform adapters never read raw core/module state.
 */
public record VisibleWorldState(List<VisibleEntity> entities, List<VisibleObject> objects, Map<String, Boolean> flags) {

    public VisibleWorldState {
        entities = List.copyOf(entities);
        objects = List.copyOf(objects);
        flags = Map.copyOf(flags);
    }
}
