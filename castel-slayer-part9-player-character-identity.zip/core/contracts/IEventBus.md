# IEventBus

**Owner:** core
**Status:** implemented — see the `.java` file in this directory (Prompt 03). This document remains as design rationale and open questions.

## Purpose

The single channel modules use to communicate without depending on
each other directly (DESIGN_PRINCIPLES rule 10).

## Contract (language-agnostic sketch)

```
interface IEventBus {
    publish(event: DomainEvent): void
    subscribe<T extends DomainEvent>(eventType: Class<T>, handler: (T) => void): Subscription
    unsubscribe(subscription: Subscription): void
}

interface DomainEvent {
    occurredAt: Timestamp
    // concrete events defined per-module in core/events, e.g.:
    // PlayerDefeatedEnemy, PlayerJoinedWorld, ItemAcquired, QuestCompleted
}
```

## Rules

- Publishing an event must never throw on behalf of a subscriber's
  failure — one bad handler cannot break the publisher.
- Events are data, not commands. A subscriber reacts; it does not
  return a value to the publisher (use a contract in
  `core/contracts` for synchronous request/response instead).
- Event payloads use `core/domain` types only — never platform or
  module-internal types.

## Consumed By

Every module, for both publishing and subscribing.

## Open Questions (for later prompts)

- In-process only for the prototype, or built with a future
  multi-server/sharded deployment in mind? Default assumption for
  the prototype: in-process, synchronous dispatch, single server
  process. Revisit if/when the world needs to scale beyond one
  server.
