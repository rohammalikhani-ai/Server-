# IContentValidator

**Owner:** core
**Status:** implemented — see the `.java` file in this directory (Prompt 03). This document remains as design rationale and open questions.

## Purpose

What any AI-proposed or externally-sourced content (a quest, a line
of dialogue, an encounter/dungeon layout) must pass through before it
can affect authoritative state. AI proposes; this validates; only
approved content is committed (DESIGN_PRINCIPLES rule 9).

## Contract (language-agnostic sketch)

```
interface IContentValidator {
    validate(proposal: ContentProposal): ValidationResult
}

interface ContentProposal {
    kind: "quest" | "dialogue" | "encounter" | ...
    payload: unknown          // schema-checked per kind
    proposedBy: "ai-director" | "designer" | ...
}

interface ValidationResult {
    outcome: "approved" | "rejected" | "repaired"
    payload?: unknown         // present if approved or repaired
    reasons: List<string>     // why rejected/repaired, for logging
}
```

## Rules

- Checks at minimum: schema validity, game-rule consistency (e.g. no
  reward the economy can't sustain), and lore consistency.
- A "repaired" result means the validator corrected a fixable issue
  (e.g. clamped an out-of-range reward) — the original proposal and
  the repair reason are both logged.
- Nothing downstream (persistence, economy, quest) accepts
  AI-proposed content that hasn't passed through this interface.

## Consumed By

`ai-director` (submits proposals through it); `quest`, `npc`,
`economy` (only accept AI-originated content that arrives already
validated).

## Open Questions (for later prompts)

- Concrete schema definitions per content kind — deferred until the
  `ai-director` module's scope is defined (not part of the prototype
  unless a later prompt pulls it in early).
