package core.contracts;

import core.events.GameEvent;
import java.util.function.Consumer;

/**
 * The single channel modules use to communicate without depending on each other
 * directly (DESIGN_PRINCIPLES rule 10). See {@code IEventBus.md} in this directory
 * for the original design rationale and open questions (in-process vs. multi-server).
 */
public interface IEventBus {

    /**
     * Publishes an event to every current subscriber of its exact runtime type. Must
     * never throw on behalf of a subscriber's failure — one bad handler cannot break
     * the publisher or other subscribers.
     */
    <T extends GameEvent> void publish(T event);

    /** Subscribes to every event of exactly {@code eventType} published from now on. */
    <T extends GameEvent> Subscription subscribe(Class<T> eventType, Consumer<T> handler);

    /** Cancels a previously created subscription. Safe to call more than once. */
    void unsubscribe(Subscription subscription);
}
