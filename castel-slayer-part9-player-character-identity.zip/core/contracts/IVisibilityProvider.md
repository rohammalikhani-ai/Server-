# IVisibilityProvider

**Owner:** core (implemented by `world-state`)
**Status:** implemented — see the `.java` file in this directory (Prompt 03). This document remains as design rationale and open questions.

## Purpose

Answers "what can this player see right now" so that two players
sharing a location can see different entities/objects/states based on
quest/faction/reputation/event conditions (DESIGN_PRINCIPLES rule 7 —
story phasing / personal visibility).

## Contract (language-agnostic sketch)

```
interface IVisibilityProvider {
    getVisibleWorldState(playerId: PlayerId, areaId: AreaId): VisibleWorldState
}

interface VisibleWorldState {
    entities: List<VisibleEntity>
    objects: List<VisibleObject>
    flags: Map<string, boolean>   // area/story flags relevant to this player
}
```

## Rules

- Platform presenters (`IPlatformPresenter`) always fetch state
  through this interface — never read raw core/module state directly
  — so phasing is enforced in one place, not re-implemented per
  client.
- Visibility rules are computed from data other modules own (quest
  state, faction/reputation, world events) via events/contracts, not
  by `world-state` reaching into those modules' internals.

## Consumed By

`platform/java`, `platform/bedrock` (via the core dispatch layer);
`world-state` (implements it).

## Open Questions (for later prompts)

- How fine-grained phasing needs to be for the prototype (per-quest
  only, vs. also per-faction/reputation) — prototype scope likely
  starts with quest-state phasing only and extends later.
