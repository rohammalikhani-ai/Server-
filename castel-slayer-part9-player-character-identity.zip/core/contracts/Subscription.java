package core.contracts;

/** Handle returned by {@link IEventBus#subscribe} so a caller can later unsubscribe. */
public interface Subscription {
}
