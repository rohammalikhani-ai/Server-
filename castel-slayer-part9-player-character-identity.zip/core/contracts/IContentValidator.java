package core.contracts;

/**
 * Gate for AI-proposed or externally-sourced content before it can affect
 * authoritative state (DESIGN_PRINCIPLES rule 9). {@code ai-director} only proposes;
 * this validates; nothing downstream accepts unvalidated content. See
 * {@code IContentValidator.md} in this directory for rationale and open questions.
 */
public interface IContentValidator {
    ValidationResult validate(ContentProposal proposal);
}
