# IPlatformPresenter

**Owner:** core
**Status:** implemented — see the `.java` file in this directory (Prompt 03). This document remains as design rationale and open questions.

## Purpose

What a `platform/java` or `platform/bedrock` adapter must implement to
receive authoritative core state and forward client input back
(DESIGN_PRINCIPLES rule 6 — one game logic, multiple client
presentations).

## Contract (language-agnostic sketch)

```
interface IPlatformPresenter {
    presentState(playerId: PlayerId, state: VisibleWorldState): void
    onClientInput(playerId: PlayerId, input: ClientInputEvent): void
}

// VisibleWorldState is produced by world-state's IVisibilityProvider —
// a presenter never queries raw core state directly, only what the
// player is allowed to see.
```

## Rules

- `ClientInputEvent` is untrusted. A presenter forwards it as a
  *request*; it never mutates authoritative state itself
  (DESIGN_PRINCIPLES rule 9).
- `platform/java` and `platform/bedrock` each implement this
  independently and may render the same `VisibleWorldState`
  differently (different models/UI/animations), but must not alter
  what data they received.
- No `core` or `modules` code may depend on `platform/java` or
  `platform/bedrock` types — only the reverse.

## Consumed By

`platform/java`, `platform/bedrock` (implement it); `world-state` and
the core dispatch layer (call it to push state / receive input).

## Open Questions (for later prompts)

- Concrete Bedrock bridge/proxy choice (e.g. Geyser + Floodgate vs.
  an alternative) — not yet decided, see `docs/decisions/`.
- Minecraft version/loader (Fabric vs. Paper/plugin vs. hybrid) — not
  yet decided.
