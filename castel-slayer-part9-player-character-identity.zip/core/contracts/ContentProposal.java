package core.contracts;

import java.util.Objects;

/** A piece of AI-proposed or externally-sourced content awaiting validation. */
public record ContentProposal(ContentKind kind, Object payload, String proposedBy) {
    public ContentProposal {
        Objects.requireNonNull(kind, "kind");
        Objects.requireNonNull(payload, "payload");
        Objects.requireNonNull(proposedBy, "proposedBy");
        if (proposedBy.isBlank()) {
            throw new IllegalArgumentException("proposedBy must not be blank");
        }
    }
}
