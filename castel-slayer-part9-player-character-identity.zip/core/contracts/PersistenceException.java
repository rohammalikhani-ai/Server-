package core.contracts;

/**
 * Thrown by an {@link IPersistenceGateway} implementation when a save, load, delete
 * or query <em>fails</em> (I/O error, connection lost, unreadable stored value, ...).
 *
 * <p>This is deliberately distinct from "nothing is stored under that key", which is
 * reported as {@code Optional.empty()} by {@link IPersistenceGateway#load}. A caller
 * that must treat "does not exist" and "could not be read" differently (e.g. the
 * character runtime loader) can therefore tell them apart without knowing which
 * storage engine is behind the gateway.
 *
 * <p>Unchecked, like the rest of this codebase's programmer/infrastructure errors.
 */
public class PersistenceException extends RuntimeException {

    public PersistenceException(String message) {
        super(message);
    }

    public PersistenceException(String message, Throwable cause) {
        super(message, cause);
    }
}
