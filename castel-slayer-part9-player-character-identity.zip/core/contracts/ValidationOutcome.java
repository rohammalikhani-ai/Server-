package core.contracts;

public enum ValidationOutcome {
    APPROVED,
    REJECTED,
    REPAIRED
}
