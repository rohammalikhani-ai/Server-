package core.contracts;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * How any module saves/loads state without knowing which database engine is behind
 * it. Only the {@code persistence} module may implement this against a real
 * database; every other module depends on the interface. See
 * {@code IPersistenceGateway.md} in this directory for rationale and open questions.
 *
 * <p>{@code collection} groups records the way a table/collection name would (e.g.
 * {@code "characters"}); {@code key} identifies one record within it. Values passed
 * through must be {@code core.domain} types or module-owned DTOs — never a raw
 * ORM/driver type leaking upward. They must also be <em>immutable snapshots</em>, not
 * live mutable aggregates: an implementation may keep the reference it was given
 * (as {@code core.services.InMemoryPersistenceGateway} does) or serialize it, and callers
 * must not be able to tell the difference.
 *
 * <p>Failure vs. absence: {@link #load} reports "nothing stored under that key" as
 * {@code Optional.empty()}. An implementation that <em>fails</em> (I/O error, unreadable
 * value, ...) throws {@link PersistenceException} instead of returning empty, so a caller
 * that needs to can distinguish "does not exist" from "could not be read". Never
 * return empty to mean "failed".
 */
public interface IPersistenceGateway {

    <T> void save(String collection, String key, T value);

    <T> Optional<T> load(String collection, String key, Class<T> type);

    void delete(String collection, String key);

    <T> List<T> query(String collection, Class<T> type, Predicate<T> filter);
}
