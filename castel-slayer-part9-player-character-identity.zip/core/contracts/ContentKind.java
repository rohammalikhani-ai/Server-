package core.contracts;

/** What kind of content a {@link ContentProposal} carries. Extend as ai-director grows. */
public enum ContentKind {
    QUEST,
    DIALOGUE,
    ENCOUNTER
}
