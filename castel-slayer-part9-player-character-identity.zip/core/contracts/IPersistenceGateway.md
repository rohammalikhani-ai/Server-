# IPersistenceGateway

**Owner:** core
**Status:** implemented — see the `.java` file in this directory (Prompt 03). This document remains as design rationale and open questions.

## Purpose

How any module saves/loads state without knowing which database
engine is behind it (DESIGN_PRINCIPLES rules 4 and 10). Only the
`persistence` module is allowed to implement this against a real
database; every other module depends on the interface.

## Contract (language-agnostic sketch)

```
interface IPersistenceGateway {
    save<T>(collection: string, key: string, value: T): void
    load<T>(collection: string, key: string): T | null
    delete(collection: string, key: string): void
    query<T>(collection: string, filter: QueryFilter): List<T>
}
```

## Rules

- No module outside `persistence` may talk to a database driver
  directly.
- Values passed through must be `core/domain` types or module-owned
  DTOs — never raw ORM/driver types leaking upward.
- Writes that affect authoritative state (gold, items, ownership)
  must go through the server-side validation in `core/services`
  *before* reaching this gateway, not after.

## Consumed By

`persistence` module (implements it); `character`, `inventory`,
`quest`, `economy`, `progression`, `world-state` (consume it for
their own state).

## Open Questions (for later prompts)

- Which concrete database/engine (see `docs/decisions/`, currently
  empty — no choice made yet). `database/` stays a placeholder until
  this is decided.
