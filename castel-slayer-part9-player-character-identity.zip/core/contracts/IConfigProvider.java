package core.contracts;

import java.util.List;

/**
 * The single way any module or platform adapter reads configuration, without
 * knowing the underlying source. Keys are namespaced by owning module:
 * {@code <module-name>.<key>} (e.g. {@code economy.startingGold}); cross-cutting
 * keys not owned by one module use {@code core.<key>}. A missing key must never
 * crash startup — callers always supply a safe default. See {@code
 * IConfigProvider.md} in this directory for rationale and open questions.
 */
public interface IConfigProvider {
    String getString(String key, String defaultValue);
    int getInt(String key, int defaultValue);
    boolean getBool(String key, boolean defaultValue);
    List<String> getList(String key, List<String> defaultValue);
}
