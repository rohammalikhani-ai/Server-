package core.contracts;

import core.domain.Location;
import java.util.Objects;

/**
 * One non-entity world object a player can currently perceive (a chest, a quest
 * marker, a phased structure, etc). Identified loosely by {@code objectKey} since the
 * concrete object taxonomy belongs to whichever module owns it (world-state, npc,
 * quest, ...), not to core.
 */
public record VisibleObject(String objectKey, Location at) {
    public VisibleObject {
        Objects.requireNonNull(objectKey, "objectKey");
        objectKey = objectKey.trim();
        if (objectKey.isEmpty()) {
            throw new IllegalArgumentException("objectKey must not be blank");
        }
        Objects.requireNonNull(at, "at");
    }
}
