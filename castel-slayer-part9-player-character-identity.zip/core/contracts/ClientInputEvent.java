package core.contracts;

/**
 * A single piece of untrusted input forwarded from a client. Deliberately opaque at
 * this layer (a {@code kind} tag plus a {@code payload}) — concrete input shapes are
 * defined by whichever module interprets them; a presenter's job is only to relay,
 * never to interpret or apply them (DESIGN_PRINCIPLES rule 9).
 */
public record ClientInputEvent(String kind, Object payload) {
    public ClientInputEvent {
        if (kind == null || kind.isBlank()) {
            throw new IllegalArgumentException("kind must not be blank");
        }
    }
}
