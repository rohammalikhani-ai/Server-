package core.contracts;

import core.domain.EntityRef;
import core.domain.Location;
import java.util.Objects;

/** One entity a player can currently perceive, and where it is. */
public record VisibleEntity(EntityRef ref, Location at) {
    public VisibleEntity {
        Objects.requireNonNull(ref, "ref");
        Objects.requireNonNull(at, "at");
    }
}
