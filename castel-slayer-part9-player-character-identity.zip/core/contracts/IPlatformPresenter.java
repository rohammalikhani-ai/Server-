package core.contracts;

import core.domain.PlayerId;

/**
 * What a {@code platform/java} or {@code platform/bedrock} adapter implements to
 * receive authoritative, already-visibility-filtered state and forward client input
 * back (DESIGN_PRINCIPLES rule 6). See {@code IPlatformPresenter.md} in this
 * directory for rationale and open questions (Bedrock bridge, MC version/loader).
 */
public interface IPlatformPresenter {

    void presentState(PlayerId playerId, VisibleWorldState state);

    /** {@code input} is untrusted; a presenter forwards it as a request, never mutates state itself. */
    void onClientInput(PlayerId playerId, ClientInputEvent input);
}
