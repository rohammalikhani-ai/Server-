# DEVELOPMENT RULES

## Before Changing Code

1. Read `PROJECT_MAP.md`.
2. Read `CURRENT_STATE.md`.
3. Read the `MODULE.md` for every module you're about to touch.
4. Read only the source files relevant to the task — not the whole
   codebase.

## While Working

- Respect the boundaries in `ARCHITECTURE.md` and the rules in
  `DESIGN_PRINCIPLES.md`. If a task seems to require breaking one,
  stop and raise it rather than working around it silently.
- If a task is too large for one session, split it into complete
  smaller tasks *before* starting implementation. Never leave a
  system half-built — a module should be either "not started" or
  "complete for its current scope," never mid-collapse.
- New external dependency → add an adapter under `integrations/`
  behind a `core/contracts` interface, and add a decision record
  under `docs/decisions/`.
- New module → create its `MODULE.md` immediately, even before the
  code is finished, and add a row for it in `PROJECT_MAP.md`.
- Never create a manager/service/class for a feature that isn't being
  built yet "to save time later" — extension points belong in
  `core/contracts` or a module's `public/contracts` as an interface
  with no implementation, not as a stub class with fake logic.

## Naming Conventions

- **Folders:** `kebab-case` (e.g. `world-state`, `ai-director`).
- **Types/classes:** `PascalCase`, one primary type per file, file
  name matches the type name.
- **Interfaces:** prefixed with `I` (`IEventBus`,
  `IPersistenceGateway`, `IInventoryQuery`, ...) regardless of
  whether they live in `core/contracts` or a module's
  `public/contracts`.
- **Services:** `<Noun><Role>` — e.g. `GoldService`,
  `ContentValidator`, `DamageResolver`. Avoid a generic `Manager`
  suffix; name the class after what it actually does.
- **Events:** `<Subject><PastTenseVerb>[<Object>]`, PascalCase, no
  redundant `Event` suffix — e.g. `PlayerDefeatedEnemy`,
  `ItemAcquired`, `QuestCompleted`. Past tense because an event
  describes something that already happened, never a command.
- **Config keys:** lowercase, dot-namespaced by owning module —
  `<module-name>.<key>`, e.g. `economy.startingGold`,
  `combat.baseCritChance`. Cross-cutting keys not owned by one module
  use `core.<key>`.
- **Tests:** mirror the source path under `tests/`, with a `Test`
  suffix on the file/type name — e.g. `modules/economy/internal/...`
  is tested from `tests/modules/economy/...Test`.

## Module Boundaries & Public/Private Code Rules

Every module is split into `public/` (its entire external surface —
`contracts/` and `events/`) and `internal/` (`domain/`, `services/` —
everything else). Full rules and the dependency direction matrix are
in `ARCHITECTURE.md`; the short version:

- Nothing outside `modules/<name>/` may import from
  `modules/<name>/internal/`. Not even convenience one-offs.
- If another module needs something from this module, add it to
  `public/contracts` or `public/events` — don't reach into
  `internal/` as a shortcut.
- A module's own tests (`tests/modules/<name>/`) may see into that
  module's `internal/`. Tests exercising cross-module behavior use
  the same `public/` surface real consumers would use.
- `core/contracts` stays small and foundational (currently 6
  interfaces — see `ARCHITECTURE.md`). Module-specific contracts
  belong in that module's own `public/contracts`.

## Event Conventions

- Events are immutable data — no behavior, no mutable fields.
- An event carries only what a subscriber needs to react, not a full
  dump of the publishing module's internal state.
- A module's own events live in `modules/<name>/public/events/`.
  Only genuinely cross-cutting events needed by core services
  regardless of module (e.g. `PlayerJoinedWorld`) live in
  `core/events`.
- Publishing an event is fire-and-forget: the publisher does not get
  a return value from subscribers. If a synchronous answer is needed,
  use a contract instead (see `ARCHITECTURE.md` → Communication
  Between Modules).
- Once a module has consumers depending on an event's shape, don't
  mutate that shape — add a new event type instead. (No formal
  versioning scheme yet; this is a placeholder rule until the
  prototype has enough real consumers to need one.)

## Configuration Strategy

- All tunable values are read through `IConfigProvider` — never a raw
  config file, environment variable, or plugin-config object read
  directly from module/platform code.
- Keys are namespaced per module (see Naming Conventions above).
- Each module documents the config keys it uses and their defaults in
  its own `MODULE.md` once implemented.
- The concrete config source is not chosen yet (see
  `core/contracts/IConfigProvider.md` → Open Questions).

## External Dependency Wrapping

- Every external mod/plugin/library/framework gets its own folder:
  `integrations/<tool-name>/`.
- That folder must contain: an adapter implementing a `core/contracts`
  or module `public/contracts` interface, and a `README.md` stating
  what it wraps, why it was chosen, its license, the pinned version,
  and any Java/Bedrock/Geyser implications.
- No file in `core/`, `modules/`, or `platform/` imports an external
  library's types directly — only the integration adapter may.
- A decision record must exist in `docs/decisions/` before the
  integration is added (see `DESIGN_PRINCIPLES.md` rule 5).

## Testing Rules

- `tests/` mirrors the `core/`, `modules/`, `platform/`, and
  `integrations/` layout 1:1.
- A module's tests may use its `internal/` layer directly for unit
  tests; tests that exercise how two modules interact go through
  events/contracts, the same as production code would.
- No test is written against a system that doesn't exist yet — tests
  land alongside the code they cover, not ahead of it as scaffolding.

## After Changing Code

1. Run/describe whatever tests apply (see `tests/`).
2. Update the relevant `MODULE.md` file(s), including its
   Configuration section if config keys changed.
3. Update `CURRENT_STATE.md` to reflect what now exists.
4. Add an entry to `CHANGELOG.md`.
5. Update `PROJECT_MAP.md` if directory purposes changed.

## Prompt Sequencing

This project is built across multiple prompts/sessions. Each prompt
should end with a short report: what was created, architecture
decisions made, dependencies/assumptions taken on, tests/checks
performed, and what's ready for the next prompt — so the next session
(human or AI) can pick up cleanly from `CURRENT_STATE.md` without
re-deriving context from scratch.
