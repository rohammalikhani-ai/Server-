# CHANGELOG

## Gameplay Part 9 — Player & Character Identity Boundary

- Most of Part 9's ask already existed in `:modules:character` from earlier work: `core.domain.PlayerId`,
  `character.contracts.CharacterId` (its own type, never reused from `core.domain`),
  `character.domain.PlayerCharacter` (the `CharacterId owned-by PlayerId` aggregate, `ownerId` a
  `final` field — a character can never silently switch owners), `character.contracts.CharacterSnapshot`
  / `CharacterDirectoryService` (persistence over `IPersistenceGateway`), and
  `character.services.CharacterLifecycleService` (`create`/`retire`). This addition adds only the
  genuine gap: rename.
- New: `character.domain.PlayerCharacter.rename(String validatedName, Instant at)` — changes the
  display name and bumps `updatedAt`; `CharacterId`, owner `PlayerId`, and lifecycle state are
  untouched (a retired character can still be renamed — the two are independent).
- New: `character.contracts.ICharacterLifecycle.rename(CharacterId, String)` +
  `CharacterLifecycleService.rename` — validates via the same `CharacterNameRules.validate`
  `CharacterFactory` already uses, persists, then publishes the new
  `character.events.CharacterRenamed(characterId, previousName, newName, occurredAt)`, matching
  `create`'s/`retire`'s persist-then-publish ordering exactly. An invalid name or unknown
  `CharacterId` renames and publishes nothing.
- Entity Identity relationship (Gameplay Part 8's `core.domain.EntityRef`): documented only, no new
  code. A played character's runtime `EntityRef` is reached via its owning `PlayerId`
  (`CharacterSummary.ownerId()` -> `EntityRef.ofPlayer(...)`) — no second identity system was
  introduced. No Minecraft entity-binding code was written.
- Not built: login/session/authentication, multi-character-per-player, display-name uniqueness
  policy, chat/cosmetics/moderation.
- External dependency check: re-examined; nothing changed since `character.MODULE.md`'s existing
  conclusion (plain `UUID`-backed records + `IPersistenceGateway` is sufficient). Nothing adopted.
- Tests: +9 (547 -> 556) — `PlayerCharacterTest` +4 (rename changes name/bumps `updatedAt`/leaves
  identity untouched; blank-name rejection; null validation; renaming a retired character);
  `CharacterLifecycleServiceTest` +5 (persist + `CharacterRenamed` publication; `CharacterId`/owner
  stability; invalid name persists/publishes nothing; unknown id is empty and publishes nothing;
  renaming a retired character).
- Verified with `javac` 21 + `support.TestRunner`: focused character-module run 31 tests, 0 failed;
  combat-focused run unaffected, 291 tests, 0 failed; full suite 556 tests, 0 failed (baseline 547,
  0 failed). Gradle/Paper not run.

## Gameplay Part 8 — Entity Identity & Health State Boundary

- Identity decision: no new identity type. `core.domain.EntityRef` (already used by
  `RespawnLifecycleStore` since Part 7) already satisfies every Part 8 requirement — immutable,
  value-based, UUID-backed, never display-name-based, already future-compatible with
  `PlayerId`/`CharacterId` via `EntityRef.ofPlayer`. `HealthSnapshot`/`HealthStore`/
  `HealthResolutionService` all key off it.
- New `combat.contracts.HealthSnapshot` (`schemaVersion`, `revision`, `entity`, `current`, `max`,
  `savedAt`) — this module's persistence model for `combat.domain.Health`, plain JDK/`core.domain`
  data only, the `Health` counterpart of `RespawnLifecycleSnapshot`.
- New `combat.services.HealthSnapshotMapper` — validated, non-repairing `Health <-> HealthSnapshot`
  mapping. `restore` checks schema version, revision, timestamp, then the same
  finite/`max > 0`/`0 <= current <= max` invariants `Health`'s own constructor enforces — checked
  explicitly rather than by constructing a `Health` and catching its exception, so recovery cannot
  crash on untrusted stored data.
- New `combat.services.HealthStore(IPersistenceGateway, Clock)` — `load`/`save`/`discard`, this
  module's only class touching `IPersistenceGateway` for health (collection `"entity-health"`).
  Reuses the exact same optimistic-revision contract `RespawnLifecycleStore` established in Part 7
  (1 on first save, +1 per later save, mismatch -> `VersionConflict`) and the same three-way
  `NotFound`/`Failed`/`Corrupt` load / `Saved`/`VersionConflict`/`Blocked` save results — no new
  persistence pattern invented.
- New `combat.services.HealthResolutionService(HealthStore)` — the small application/domain service
  Part 8 asks for: `resolve(EntityRef) -> HealthResolutionResult` (`Resolved`/`NotFound`/`Corrupt`/
  `Failed`). Deliberately never fabricates a default `Health` for `NotFound` — that is an
  undecided gameplay rule, left as a documented future extension point
  (`resolveOrDefault(EntityRef, Supplier<Health>)`), not guessed at here.
- Persists exactly: entity identity, `current`/`max` HP, plus schema/revision/timestamp
  bookkeeping. Deliberately does not persist alive/dead (still derived) or touch the respawn
  lifecycle's own collection. `DamageApplicationService` is unchanged — wiring its output through
  `HealthStore.save` is future integration work, not built here.
- Checked the same optimistic-versioning question Part 7 already answered against Spring Data's
  `@Version` pattern; nothing new adopted (see `modules/combat/MODULE.md` → "External dependency
  check (Gameplay Part 8)"). No `integrations/` adapter or decision record needed.
- Tests: +54 (493 -> 547) — new `tests/modules/combat/contracts/HealthSnapshotTest.java` (5); new
  `tests/modules/combat/services/HealthSnapshotMapperTest.java` (15, covering round-trips,
  incompatible schema versions, invalid revisions/timestamps/HP values including non-finite, and
  determinism); new `tests/modules/combat/services/HealthStoreTest.java` (28, covering save/load/
  round-trip, revision conflicts including a two-racing-callers scenario, write/read failure
  propagation, corrupt/incompatible stored data, blocked-record protection, `discard`,
  determinism, no leakage, and null/inconsistent-value validation); new
  `tests/modules/combat/services/HealthResolutionServiceTest.java` (6, covering all four outcome
  cases plus null validation).
- Verified with `javac` 21 + `support.TestRunner`: focused combat-module run 291 tests, 0 failed
  (baseline 237, 0 failed); full suite 547 tests, 0 failed (baseline 493, 0 failed). Gradle/Paper
  not run.

## Gameplay Part 7 — Combat: Respawn Persistence

- New `combat.contracts.RespawnLifecycleSnapshot` (`schemaVersion`, `revision`, `entity`, `status`
  name, `destination`, `savedAt`) — this module's persistence model for `RespawnLifecycleState`,
  plain JDK/`core.domain` data only, the counterpart of `character.contracts.CharacterSnapshot`.
- New `combat.services.RespawnLifecycleSnapshotMapper` — validated, non-repairing `State <->
  Snapshot` mapping. `toSnapshot` cannot produce what `restore` would refuse (revision >= 1,
  `savedAt` not pre-epoch, enforced at construction); `restore` checks schema version, revision,
  timestamp, status name (exact match), and destination-matches-status in order, reporting the
  first failure as a specific `RespawnRecoveryFailure` rather than coercing anything.
- New `combat.services.RespawnLifecycleStore(IPersistenceGateway, Clock)` — `load`/`save`/
  `discard`, this module's only class touching `IPersistenceGateway` (reused unchanged; no new
  repository abstraction). `save` takes the caller's last-read revision and writes only if it
  still matches the stored one (optimistic concurrency: 1 on first save, +1 per later save;
  mismatch -> `VersionConflict`, nothing written). `load` returns `NotFound`/`Failed`/`Corrupt`
  three ways, never conflating "does not exist" with "could not be read" or "unreadable content";
  `save` never overwrites a `Blocked` (corrupt/identity-mismatched) existing record — `discard` is
  the explicit way to clear one.
- Persists exactly: entity identity, lifecycle status, the decided destination while one exists,
  plus schema/revision/timestamp bookkeeping. Deliberately does not persist `Health`, the killer,
  or the `EntityDied`/`EntityRespawned` events themselves. No production database chosen — still
  `core.services.InMemoryPersistenceGateway` only, per the task's constraints.
- Checked Spring Data's `@Version` optimistic-locking pattern (Apache-2.0) as a shape reference
  only (see `modules/combat/MODULE.md` → "Respawn persistence external dependency check"); not
  adopted — a full ORM/repository framework for a ~15-line need. No `integrations/` adapter or
  decision record needed.
- Tests: +54 (439 -> 493) — new `tests/modules/combat/contracts/RespawnLifecycleSnapshotTest.java`
  (5); new `tests/modules/combat/services/RespawnLifecycleSnapshotMapperTest.java` (15, covering
  round-trips for every lifecycle status, incompatible schema versions, invalid revisions/
  timestamps/statuses/destinations, and determinism); new
  `tests/modules/combat/services/RespawnLifecycleStoreTest.java` (34, covering save/load/round-trip,
  revision conflicts including a two-racing-callers scenario, write/read failure propagation,
  corrupt/incompatible stored data, blocked-record protection, `discard`, determinism, no mutation
  leakage, full save-at-every-step-then-resume-after-restart compatibility with the Part 6
  lifecycle, and null validation).
- Verified with `javac` 21 + `support.TestRunner`: focused combat-module run 237 tests, 0 failed
  (baseline 183, 0 failed); full suite 493 tests, 0 failed (baseline 439, 0 failed). Gradle/Paper
  not run.

## Gameplay Part 6 — Combat: Respawn Lifecycle Boundary

- New `combat.domain.RespawnLifecycleStatus` (`ALIVE`, `DEAD`, `RESPAWN_ELIGIBLE`,
  `RESPAWN_DECIDED`, `RESPAWN_EXECUTION_REQUESTED`) and `combat.domain.RespawnLifecycleState`
  (immutable per-entity value; transition methods `died()`/`eligible()`/`decided(point)`/
  `executionRequested()`/`respawned()`/`executionFailed()` each require their own starting status
  and throw `IllegalStateException` otherwise — so e.g. an alive entity simply cannot call
  `eligible()`/`decided()`/`respawned()`).
- New `combat.services.RespawnLifecycleService` — five separate steps (`recordDeath`,
  `evaluateEligibility`, `decideDestination`, `requestExecution`, `completeExecution`) plus
  `execute` (steps 4-5 around a synchronous `IRespawnExecutor`), each returning a
  `RespawnLifecycleResult` (`APPLIED`/`DUPLICATE`/`DENIED`/`REJECTED`/`EXECUTION_FAILED`).
  Repeated death events, repeated execution requests, and repeated success reports are all
  `DUPLICATE`: state unchanged, no re-invocation of `IRespawnExecutor`, no second
  `EntityRespawned`. A reported execution failure returns to `RESPAWN_DECIDED` — exactly the
  pre-request state — never a silent mutation; an executor exception propagates untouched.
- New `combat.contracts.IRespawnExecutor`, `RespawnExecutionRequest`, `RespawnExecutionResult`
  (sealed `Succeeded`/`Failed`) — the explicit execution boundary. No implementation in this
  module (a platform adapter's job); no Bukkit `Player`/`ServerPlayer`/`World`/Minecraft
  `Location`/`Chunk`/teleport/bed/respawn-screen/packet type anywhere in `combat`.
- New `combat.events.EntityRespawned` (`entity`, `destination`, `occurredAt`) — this module's
  second published event, returned (not bus-published) exactly once on a confirmed `Succeeded`
  result, same pattern as `EntityDied`.
- No `core.contracts.IEventBus` dependency, no global mutable event bus, no hidden static state
  anywhere in this addition (verified explicitly — see `modules/combat/MODULE.md`).
- Checked Spring Statemachine and Squirrel Foundation (both Apache-2.0) before implementing (see
  `modules/combat/MODULE.md` → "Respawn lifecycle external dependency check"); neither adopted —
  full state-machine frameworks for a five-state, one-path-plus-one-retry-loop lifecycle this
  project's existing immutable-value-with-transitions style already covers. No `integrations/`
  adapter or decision record needed.
- Tests: +61 (378 -> 439) — new `tests/modules/combat/domain/RespawnLifecycleStateTest.java` (10);
  new `tests/modules/combat/contracts/RespawnExecutionContractsTest.java` (5); new
  `tests/modules/combat/events/EntityRespawnedTest.java` (4); new
  `tests/modules/combat/services/RespawnLifecycleResultTest.java` (4); new
  `tests/modules/combat/services/RespawnLifecycleServiceTest.java` (38, covering every step,
  every duplicate/reject/fail case, the full `execute` boundary, retry-after-failure, and the
  complete `Damage -> EntityDied -> lifecycle -> EntityRespawned` integration path).
- Verified with `javac` 21 + `support.TestRunner`: focused combat-module run 183 tests, 0 failed
  (baseline 122, 0 failed); full suite 439 tests, 0 failed (baseline 378, 0 failed). Gradle/Paper
  not run.

## Gameplay Part 5 — Combat: Respawn Foundation

- New `combat.contracts.RespawnPoint` (wraps `core.domain.Location`; invalid destinations are
  unrepresentable — `Location`'s constructor rejects them before a `RespawnPoint` can exist),
  `IRespawnPointProvider` (extension point, no implementation — per `DEVELOPMENT_RULES.md`),
  `RespawnDenialReason` (`ENTITY_ALIVE`, `KIND_NOT_RESPAWNABLE`, `NO_RESPAWN_POINT`),
  `RespawnRequest` (with `RespawnRequest.from(EntityDied)`), and `RespawnDecision` (sealed
  `Granted`/`Denied`).
- New `combat.domain.RespawnEligibility` and `combat.services.RespawnDecisionService`
  (`IRespawnPointProvider`, `Set<EntityKind>`) — pure and stateless. Eligibility reuses
  `Health.isAlive()` unchanged (no duplicated dead-definition) then checks the injected
  respawnable-kinds set (no "player" assumption; an empty set is valid — nobody respawns);
  destination comes only from the provider, never consulted for an ineligible entity; `decide`
  composes both into one `RespawnDecision`.
- No teleport, no revival, no Bukkit/Paper dependency, no respawn timers, no death penalties. Does
  not duplicate `Health`, `EntityDied`, or `DamageApplicationService` — all reused unchanged.
- Checked Bukkit/Paper `PlayerRespawnEvent`/`PlayerPostRespawnEvent` before implementing (see
  `modules/combat/MODULE.md` → "Respawn external dependency check"); not adopted — Minecraft-
  coupled lifecycle events, not a respawn-rules domain model. No `integrations/` adapter or
  decision record needed.
- Tests: +36 (342 -> 378) — new `tests/modules/combat/contracts/RespawnPointTest.java` (5),
  `RespawnRequestTest.java` (4), `RespawnDecisionTest.java` (4); new
  `tests/modules/combat/domain/RespawnEligibilityTest.java` (3); new
  `tests/modules/combat/services/RespawnDecisionServiceTest.java` (20, covering granted/denied for
  every reason, non-player-kind configurability, provider-not-consulted-when-ineligible,
  determinism, defensive copying, provider failure propagation, null validation, and the full
  `DamageResult -> DamageApplicationService -> EntityDied -> RespawnRequest -> RespawnDecision`
  integration path).
- Verified with `javac` 21 + `support.TestRunner`: focused combat-module run 122 tests, 0 failed
  (baseline 86, 0 failed); full suite 378 tests, 0 failed (baseline 342, 0 failed). Gradle/Paper
  not run.

## Gameplay Part 4 — Combat: Death Transition/Event

- New `combat.events.EntityDied` (`target`, `source`: both `core.domain.EntityRef`; `occurredAt`) —
  this module's first published event, in the existing `:modules:combat/public/events` (no new
  module, no build change, no new dependency).
- New `combat.services.DamageApplicationResult` (`Health health`, `List<EntityDied> events`) and a
  new method `DamageApplicationService.applyDetectingDeath(DamageResult, Health) ->
  DamageApplicationResult`, additive alongside the existing, unchanged
  `apply(DamageResult, Health) -> Health`. Detects death by comparing `targetHealth.isAlive()`
  before the call to the resulting `Health.isDead()` after it — reuses `Health.apply(...)` and its
  `current == 0` dead definition unchanged; does not duplicate or redesign `Health`.
- Exactly one `EntityDied` on an alive-to-dead transition (lethal damage, including overkill);
  none for non-lethal damage, zero damage, or further damage to an already-dead target (no
  duplicate event). `DamageType`, `DamageRequest`, `DamageCalculator`, `DamageResult`, and `Health`
  are all unchanged from Parts 1-3.
- No event bus dependency added to `DamageApplicationService` and no global mutable event bus
  introduced anywhere — the event is returned to the caller, who decides how/whether to publish it
  (the same pattern `progression.services.LevelingService`/`LevelingResult` already established for
  `CharacterLeveledUp`). New constructor `DamageApplicationService(Clock)` added alongside the
  existing no-arg one (now delegating to it with `Clock.systemUTC()`), purely to timestamp
  `EntityDied.occurredAt()` deterministically.
- No Bukkit/Paper/Minecraft dependency, no automatic respawn, no persistence, no player/NPC
  assumption (both event fields are `EntityRef`, not `PlayerId`).
- Checked for public Java/domain death-event patterns first (see `modules/combat/MODULE.md` →
  "Death event external dependency check"): Bukkit/Paper `EntityDeathEvent`, Forge/NeoForge
  `LivingDeathEvent` (Minecraft-coupled, forbidden), `tfredrich/Domain-Eventing` (Apache-2.0, a
  competing event-bus abstraction with internal queueing), `banq/jdonframework` (Apache-2.0, full
  CQRS/event-sourcing/saga framework, far more than this needs). None adopted; implemented
  internally, consistent with this project's existing `GameEvent`/`IEventBus` conventions.
- Tests: +27 (315 -> 342) — 17 new methods in the existing
  `tests/modules/combat/services/DamageApplicationServiceTest.java` (lethal/overkill/non-lethal/zero
  damage, already-dead no-duplicate, exact-zero HP, one-HP-remaining non-death, immutability,
  determinism, null inputs, null `Clock`, and the complete `DamageRequest -> DamageCalculator ->
  DamageResult -> DamageApplicationService -> Death detection/event` path with and without a kill);
  new `tests/modules/combat/services/DamageApplicationResultTest.java` (4); new
  `tests/modules/combat/events/EntityDiedTest.java` (6).
- Verified with `javac` 21 + `support.TestRunner`: focused combat-module run 86 tests, 0 failed
  (baseline 59, 0 failed); full suite (excluding the three Bukkit-dependent `platform/java` files)
  342 tests, 0 failed (baseline 315, 0 failed). Gradle/Paper not run.

## Gameplay Part 3 — Combat: Damage Application / Orchestration

- New `combat.services.DamageApplicationService` (`apply(DamageResult, Health) -> Health`), inside
  the existing `:modules:combat` (no new module, no build change, no new dependency). Orchestrates
  `DamageResult + Target Health -> Apply Damage -> New Health` by delegating to the existing,
  unchanged `Health.apply(DamageResult)` and adding the module's usual null-safety at the boundary.
  `DamageCalculator`, `DamageRequest`, `DamageResult`, and `Health`'s behavior are all unchanged.
- Deliberately does not resolve, store, or persist a target's `Health` by identity — the caller
  supplies `targetHealth` directly and the result is handed back, nothing more. No death events,
  healing, weapons, armor, or any other combat rule was added.
- Checked for public Java combat-orchestration/damage-application libraries first (see
  `modules/combat/MODULE.md` → "Damage application external dependency check"); nothing suitable
  found, implemented internally.
- Tests: +13 (302 -> 315) — `tests/modules/combat/services/DamageApplicationServiceTest.java`,
  including the complete `DamageRequest -> DamageCalculator -> DamageResult ->
  DamageApplicationService -> Health` path.
- Verified with `javac` 21 + `support.TestRunner`: focused combat-module run 59 tests, 0 failed
  (baseline 46, 0 failed); full suite 315 tests, 0 failed (baseline 302, 0 failed). Gradle/Paper
  not run.

## Gameplay Part 2 — Combat: Health/HP

- New `combat.domain.Health` (immutable record: current HP, max HP, alive/dead,
  `apply(DamageResult)`), inside the existing `:modules:combat` (no new module, no build
  change, no new dependency). Integrates with the existing `DamageResult`; `DamageRequest`,
  `DamageCalculator` and `DamageResult` are unchanged.
- Invariants enforced at construction: max finite and > 0; `0 <= current <= max`. Damage floors
  HP at zero; zero damage changes nothing; dead is `current == 0` and stays dead.
- Checked for public Java RPG health/HP libraries first (see `modules/combat/MODULE.md`);
  none suitable, nothing adopted.
- Tests: +22 (280 -> 302) — `tests/modules/combat/domain/HealthTest.java`.
- Verified with `javac` 21 + `support.TestRunner`: 302 tests, 0 failed. Gradle/Paper not run.

## Gameplay Part 1 — Combat: Damage Model

- New `:modules:combat` (first real code in this module — was an empty scaffold):
  `combat.domain.DamageType` (Physical/Magical/Fire/Frost/Lightning/Poison/Shadow/Holy),
  `combat.domain.DamageRequest`, `combat.domain.DamageResult`, and
  `combat.services.DamageCalculator` implementing
  `Attacker -> DamageRequest -> DamageCalculator -> DamageResult`.
- `source`/`target` reuse the existing `core.domain.EntityRef` (not `PlayerId` or
  `CharacterId` directly) so a damage source/target can be a player, NPC, or other
  entity uniformly; no new identity type was created (`PlayerId` stays the sole
  player-identity boundary).
- Deterministic and side-effect free: no randomness, final `amount` is clamped to a
  minimum of zero in `DamageResult` itself, zero damage is a valid result. No
  Health/HP, weapons, armor, resistance, crit, or abilities — out of scope for Part 1.
- Checked for a public/GitHub RPG-damage-model library first (see
  `modules/combat/MODULE.md` → "External dependency check"); nothing suitable found,
  implemented internally.
- Tests: +24 (250 → 274) — `tests/modules/combat/domain/{DamageTypeTest,
  DamageRequestTest, DamageResultTest}.java`,
  `tests/modules/combat/services/DamageCalculatorTest.java`.
- Registered `:modules:combat` in `settings.gradle.kts` with a `build.gradle.kts`
  depending only on `:core` (mirrors `:modules:inventory`'s pattern).
- Verified with `javac` 21 + `support.TestRunner` (274 tests, 0 failed). Gradle/Paper
  were not run in this environment.

## CharacterRuntime ownership review (post Phase 14)

- **Scope:** `CharacterRuntime` only (CharacterId ownership/isolation of Progression, Inventory, Equipment). No other
  system, module or doc-level design was changed; no plugin/library was adopted (none applies to a pure in-memory
  ownership invariant).
- **Found & fixed (1 defect):** `CharacterRuntimeService.load(id)` trusted `ICharacterDirectory.findById(id)` to answer
  with the same character. A directory that answered with a different character (corrupt record, faulty adapter) and a
  character with no saved runtime state produced `Loaded` with a runtime for the **wrong** character. It now returns
  `CharacterLoadResult.Failed` instead. `CharacterRuntime`, `CharacterRuntimeFactory`, `CharacterRuntimeSnapshot` and the
  modules' ownership checks were already correct and are unchanged.
- **Tests:** +5 (249 → 254): wrong-directory-answer regression, load(A)/load(B) ownership, cross-assembly in every
  direction, exact-instance exposure, mismatch message, and the missing progression case of the snapshot-envelope test.
- **Project status (as reported by the project owner):** the project has been tested and has shown no errors so far.
  Not independently verified: the assistant's own run was `javac` + `support.TestRunner` only (254 tests, 0 failed);
  Gradle and the Paper layer were not run in that environment.

## Master Phase 12–14 — Character Runtime Foundation

- **Ownership:** `ItemInventory(CharacterId, capacity)` and `ItemEquipment(CharacterId)` now require an immutable
  owner; `CharacterStatsProfile` was already character-owned. Tests prove two characters share nothing.
- **ItemId consolidated:** removed `inventory.domain.ItemId`; `inventory.contracts.ItemId` is the only item id.
  Equipment no longer touches `inventory.domain` (the id-translation test helper is gone).
- **Persistence model:** public snapshots per module (`InventorySnapshot`, `EquipmentSnapshot`,
  `CharacterProgressionSnapshot`, `CharacterSnapshot`) plus `toSnapshot`/`fromSnapshot`; `PersistenceException`
  separates "could not read" from "does not exist"; `core.services.InMemoryPersistenceGateway` is the dev store.
- **New `:application:runtime` module:** `CharacterRuntime`, `CharacterRuntimeFactory`, `CharacterRuntimeService`
  (load/save), `PlayerSession`, `SessionManager`, `CharacterSelector`, `PlayerSessionService`,
  `PlayerSessionLifecycle` (`PlayerJoinedWorld` → join, `PlayerLeftWorld` → quit + save).
- **Composition root** assembles the above; the plugin saves active sessions on disable and logs outcomes.
- `CharacterRetired` now has a publisher (`CharacterLifecycleService`). `CharacterLeveledUp` is still only returned, not published (deferred).
- Verified with `javac` + `support.TestRunner` (see `CURRENT_STATE.md`); **Gradle was not run**, Paper layer checked only against stubs.

## Phase 11 — Gradle Multi-Module Integration & Build Graph

- Registered `:modules:character`, `:modules:progression`,
  `:modules:inventory`, `:modules:equipment` in `settings.gradle.kts`, each
  with a new `build.gradle.kts` pointing at the existing `internal/` +
  `public/` folders (nothing moved, no Java changed). Dependencies follow
  actual imports only.
- Added test source sets (`tests/<mirror>` + `tests/support`) for `:core`,
  the four modules, and `:platform:java`; root `build.gradle.kts` gains a
  `harnessTest` task running the custom `support.TestRunner`, and `test`
  delegates to it.
- Not executed under Gradle (no Gradle/wrapper/network here); emulated with
  `javac` + `TestRunner` instead — see `CURRENT_STATE.md` → "Phase 11".

## Prompt 09/10 — Paper Platform Foundation & Composition Root

- **Architecture decision:** added `docs/decisions/0003-paper-platform-and-composition-root.md`
  — Minecraft Java Edition 1.21.11 via Paper is the first loader; Gradle
  (Kotlin DSL) multi-project build (`:core`, `:platform:java`); Java
  language level raised 17 → 21 (amends `0001`); composition root lives
  in `platform/java`'s `bootstrap` package; Paper/Bukkit is the platform
  layer itself, not an `integrations/`-wrapped dependency.
- Added root `settings.gradle.kts`/`build.gradle.kts`,
  `core/build.gradle.kts` (source set pointed at the existing
  `core/{domain,events,contracts,services}` folders — no code moved),
  `platform/java/build.gradle.kts` (Paper API, Shadow plugin, `plugin.yml`
  version filtering), and `gradle/wrapper/gradle-wrapper.properties`.
- Added `core/services/InProcessEventBus.java` — the first production
  `core.contracts.IEventBus` — plus `tests/core/services/InProcessEventBusTest.java`
  (5 methods). Updated `core/services/README.md`.
- Added the Paper plugin under `platform/java/src/main/java/castelslayer/platform/paper/`:
  `CastelSlayerPlugin` (entrypoint), `bootstrap/CompositionRoot` +
  `CoreRuntime`, `identity/PlayerIdentityMapper` (Bukkit `Player` →
  `core.domain.PlayerId`/`PlayerIdentity`; does not resolve
  `character.contracts.CharacterId` — persistence is out of scope this
  phase), `listeners/PlayerConnectionListener` (join/quit →
  `core.events.PlayerJoinedWorld`/`PlayerLeftWorld`), empty `commands/`.
  Added `src/main/resources/plugin.yml`.
- Added `tests/platform/java/bootstrap/CompositionRootTest.java` (2
  methods) — the only new platform code testable without a live Bukkit
  classpath.
- No gameplay, commands, NPCs, items, quests, economy, AI, Geyser,
  Floodgate, MythicMobs, ItemsAdder, ModelEngine, WorldGuard, or
  database/persistence code was added, per the task brief.
- **Not compiled or run:** this sandbox has a JRE but no `javac`, no
  Gradle, and no network access to PaperMC's/Maven Central's
  repositories. Every file was reviewed by hand instead; see
  `CURRENT_STATE.md` → "Known Limitation — Paper Plugin Not Compiled,
  Gradle Not Run Here" for the exact verification command to run
  elsewhere.
- Updated `ARCHITECTURE.md`, `PROJECT_MAP.md`, `CURRENT_STATE.md` to
  match.

## Prompt 08 — Java as Sole Production Language

- **Architecture decision (reverses Prompt 05):** Java is now the only
  production language for this project. Added
  `docs/decisions/0002-java-as-sole-production-language.md`.
- `dotnet-core/` marked **deprecated, reference-only** — not deleted, not
  modified beyond a deprecation notice in `dotnet-core/README.md`, not
  extended with new modules, not on any build/ship path.
- No C#↔Java bridge was built; no C# module was migrated to Java; no new
  gameplay logic was implemented. Documentation-only change.
- Updated to reflect the reversal: `ARCHITECTURE.md`, `PROJECT_MAP.md`,
  `CURRENT_STATE.md`.

## Prompt 07 — Equipment & Item Definition (C# Core)

- Added `dotnet-core/src/CastelSlayer.Modules.Equipment` (see its `MODULE.md`):
  `ItemDefinition` (immutable; equippable exactly when it has a slot; equippable
  items must have `MaxStackSize` 1), `ItemCategory`, `EquipmentSlot` (Head,
  Chest, Legs, Feet, MainHand, OffHand) + `EquipmentSlots`, `ItemEquipment`
  (`Equip` / `Unequip` / queries / read-only `GetSlots` snapshot),
  `EquipResult`/`EquipStatus`, `UnequipResult`/`UnequipStatus`,
  `EquipmentSlotState`. Occupied slots are refused, never overwritten;
  unequipped items are returned, never discarded.
- Reuses Inventory's `ItemId`; Inventory itself is unchanged. Recorded the
  narrow Equipment → Inventory reference as an exception in
  `dotnet-core/docs/decisions/0003-equipment-module-boundary.md` and a short
  note in `ARCHITECTURE.md`.
- Added 50 test methods under `dotnet-core/tests/CastelSlayer.Tests/Modules/Equipment/`;
  test project now references the Equipment module.
- Deliberately not built: Inventory ↔ Equipment transactions, stat bonuses,
  item database/registry, loot, crafting, trading, shops, economy, durability,
  enchantments, upgrades, class/race restrictions, persistence, networking,
  GUI, Java/Fabric equipment code.
- Not compiled or run: no .NET SDK in the authoring environment.

## Prompt 06 — Inventory Foundation (C# Core)

- Added `dotnet-core/src/CastelSlayer.Modules.Inventory` (see its
  `MODULE.md`): `ItemId`, `Item` (id + `MaxStackSize`), `ItemStack`
  (validated `1..MaxStackSize`), `InventorySlot` (read-only snapshot),
  `ItemInventory` (fixed slots; `AddItem` / `RemoveItem` / `HasItem` /
  `CountOf`), and `AddItemResult` / `RemoveItemResult`. Overflow on add and
  shortfall on remove are reported, never lost or driven negative.
- Added 27 test methods under
  `dotnet-core/tests/CastelSlayer.Tests/Modules/Inventory/`; test project now
  references the Inventory module.
- Deliberately not built: equipment, loot, trading, shop, crafting,
  persistence, item database, effects, durability, enchantments, GUI,
  networking, race/class integration.
- Not compiled or run: no .NET SDK in the authoring environment (same
  limitation as Prompt 05).

## Prompt 05 — C# Core Migration Decision + Stats, Attributes & Progression

- **Architecture decision:** authoritative gameplay logic moves to a new
  C# Core (`dotnet-core/`); Java/Fabric becomes the Minecraft
  integration/platform layer only. Recorded in
  `dotnet-core/docs/decisions/0002-csharp-core-migration-boundary.md`,
  along with what is and isn't migrated and why the C#↔Java interop
  mechanism is deferred rather than built now. `ARCHITECTURE.md` and
  `PROJECT_MAP.md` updated to document the split; the pre-existing Java
  `core/`/`modules/character/` are unchanged and now labeled legacy,
  migration-pending.
- Added `dotnet-core/src/CastelSlayer.Core`: `Domain/CharacterId.cs`,
  `Events/IGameEvent.cs`, `Contracts/IEventBus.cs` (interface only).
- Added `dotnet-core/src/CastelSlayer.Modules.Progression` — the
  prototype Stats/Attributes/Progression system (see its own
  `MODULE.md` for full detail): base attributes with per-type
  validation (`CharacterAttributes`), a modifier system supporting flat
  and percent-additive contributions from any future source
  (`AttributeModifier`, `AttributeModifierService`), derived-stat
  formulas (`DerivedStatCalculator`: MaxHealth, MaxMana, PhysicalPower,
  MagicPower, Defense, Speed), and server-authoritative level/XP
  progression via a pluggable curve (`ProgressionState`,
  `IProgressionCurve`/`DefaultProgressionCurve`, `LevelingService`),
  observable through a `CharacterLeveledUp` event. `ICharacterStatsQuery`
  declared as a public extension point for future consumers, with no
  implementation yet.
- Added `dotnet-core/tests/CastelSlayer.Tests`: a hand-rolled
  `TestAttribute`/`Assert`/`TestRunner` harness (C# analog of the Java
  side's `tests/support`, same reason — no network access to fetch a
  real test framework), plus 27 test methods across
  `CharacterAttributesTests`, `DerivedStatCalculatorTests`,
  `LevelingServiceTests`, and `CharacterStatsProfileTests` covering
  initial state, XP gain, invalid XP, single and multi-level level-ups,
  XP boundary conditions, max-level capping, attribute
  modification/removal, derived-stat calculation, and invalid-state
  rejection (duplicate/unknown modifiers, out-of-range attributes,
  empty character id, null arguments).
- **Known limitation, recorded in `CURRENT_STATE.md`:** this
  environment has no .NET SDK and no network access to install one
  (`apt-get install dotnet-sdk-8.0` fails with `403 Forbidden`, same
  failure mode as the JDK issue already recorded for Prompts 03–04) —
  all C# code was written and manually reviewed but not compiled or
  executed. Verification command is in `CURRENT_STATE.md`.
- No races, classes, equipment, skills, buffs, professions, or combat
  implemented — only the extension points (`AttributeModifier`,
  `AttributeType`, `DerivedStatType`) they will attach through, per the
  brief's scope limits.

## Prompt 01 — Foundation & Master Architecture

- Created project skeleton: `core/`, `modules/` (10 placeholders),
  `platform/` (java, bedrock, shared), `integrations/`, `docs/`,
  `tests/`, `database/` (placeholder).
- Added top-level docs: `README.md`, `PROJECT_MAP.md`,
  `ARCHITECTURE.md`, `DESIGN_PRINCIPLES.md`, `DEVELOPMENT_RULES.md`,
  `CURRENT_STATE.md`, `CHANGELOG.md` (this file).
- Defined five core extension-point contracts as design docs (no
  implementation yet): `IEventBus`, `IPersistenceGateway`,
  `IPlatformPresenter`, `IContentValidator`, `IVisibilityProvider`.
- Added `docs/master-architecture-100-sections.md` as a placeholder
  linking to the existing long-term spec, and an empty
  `docs/decisions/` directory for future decision records.
- No gameplay code, tech stack, or Minecraft-integration choices made
  yet — intentionally deferred to Prompt 02 per `CURRENT_STATE.md`.

## Prompt 02 — Project Structure & Development Contract

- Restructured every module in `modules/` into a `public/{contracts,
  events}` + `internal/{domain,services}` split, and added a matching
  `tests/` tree mirroring `core/`, `modules/`, `platform/`, and
  `integrations/` 1:1.
- Added a sixth core contract, `IConfigProvider`, and its design doc
  in `core/contracts/`.
- Rewrote `ARCHITECTURE.md` to add: an explicit dependency-direction
  matrix per layer, the public/internal module structure and its
  rules, a description of the composition root's job (location still
  undecided), and a configuration-strategy section.
- Rewrote `DEVELOPMENT_RULES.md` to add: naming conventions (folders,
  types, interfaces, services, events, config keys, tests), event
  conventions, module boundary / public-private rules, the
  configuration strategy, external-dependency wrapping rules, and
  testing rules.
- Updated `PROJECT_MAP.md` to reflect the new module shape, the full
  current list of `core/contracts` interfaces, and the mirrored
  `tests/` layout.
- No gameplay code, tech stack, or Minecraft-integration choices made
  — still deferred, per `CURRENT_STATE.md`.

## Prompt 03 — Core Domain & Interfaces

- Decided the tech stack (first real technical choice; recorded in
  `docs/decisions/0001-jvm-language-and-source-layout.md`): Java 17, no
  build tool yet (no network access in this environment), source lives
  directly in the existing `core/`/`modules/<n>/public|internal` folder
  layout, package names mirror folder names (`public`/`internal` are
  directory-only conventions, not package segments, since `public` is
  a reserved keyword).
- Added `core/domain`: `PlayerId`, `EntityId`, `EntityKind`,
  `EntityRef`, `WorldId`, `AreaId`, `Location`, `ClientEdition`,
  `PlayerIdentity`.
- Added `core/events`: `GameEvent`, `PlayerJoinedWorld`,
  `PlayerLeftWorld`.
- Implemented all six existing `core/contracts` design docs as real
  Java interfaces (`IEventBus`, `IPersistenceGateway`,
  `IPlatformPresenter`, `IContentValidator`, `IVisibilityProvider`,
  `IConfigProvider`) plus their supporting DTOs; each `.md` now points
  at its `.java` file and remains as design rationale.
- Documented `core/services` as intentionally still empty
  (`core/services/README.md`) — no cross-cutting authority service is
  justified yet.
- Added `tests/support/`: a dependency-free `@Test`/`Assertions`/
  `TestRunner` harness and `InMemoryEventBus`/`InMemoryPersistenceGateway`
  test doubles, needed because this environment cannot fetch JUnit.
- Added focused tests under `tests/core/{domain,events,contracts}/`.
- No gameplay code — `character` and every other feature module
  untouched this prompt.

## Prompt 04 — Player & Character Foundation

- Implemented the `character` module's foundation on top of Core (see
  `modules/character/MODULE.md`):
  - `public/contracts`: `CharacterId`, `CharacterSummary`,
    `ICharacterDirectory`.
  - `public/events`: `CharacterCreated`, `CharacterRetired`.
  - `internal/domain`: `PlayerCharacter` (identity + lifecycle only —
    no race/class/progression fields, by design) and `CharacterState`.
  - `internal/services`: `CharacterFactory` (validated creation,
    publishes `CharacterCreated`), `CharacterNameRules`,
    `CharacterDirectoryService` (`ICharacterDirectory` implementation
    backed by `IPersistenceGateway` — the module's explicit and only
    persistence boundary).
- Added focused tests under `tests/modules/character/{domain,services}/`
  covering creation, active/retired state transitions (including
  rejecting a double-retire), directory save/find round trips, and
  retired-character exclusion from `findActiveForPlayer`.
- Updated `PROJECT_MAP.md` and `CURRENT_STATE.md` to reflect Prompts
  03–04.
- **Known limitation, recorded in `CURRENT_STATE.md`:** this sandbox
  has no `javac`/JDK and no network access to install one — all code
  was written and manually reviewed but not compiled or executed here.
  Exact verification commands are in `CURRENT_STATE.md`.
