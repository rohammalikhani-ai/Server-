namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// A place on a character where one item can be equipped. A domain-level
/// model — deliberately NOT Minecraft's <c>EquipmentSlot</c>; a future
/// platform adapter maps between the two.
/// <para>
/// Numeric values are explicit and start at 1, so <c>default(EquipmentSlot)</c>
/// (0) and any other out-of-range cast is never a valid slot. To add a slot
/// (e.g. Ring, Neck), add a member with the next unused value —
/// <see cref="EquipmentSlots.All"/> and <see cref="ItemEquipment"/> pick it up
/// without further changes. Never renumber existing members.
/// </para>
/// </summary>
public enum EquipmentSlot
{
    Head = 1,
    Chest = 2,
    Legs = 3,
    Feet = 4,
    MainHand = 5,
    OffHand = 6,
}
