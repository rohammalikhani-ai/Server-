namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>Helpers over the <see cref="EquipmentSlot"/> set.</summary>
public static class EquipmentSlots
{
    /// <summary>Every valid slot, in ascending value order (Head first, OffHand last).</summary>
    public static IReadOnlyList<EquipmentSlot> All { get; } = Array.AsReadOnly(Enum.GetValues<EquipmentSlot>());

    /// <summary>
    /// False for values that are not a declared slot — <c>default</c>, or an
    /// integer cast to <see cref="EquipmentSlot"/> (e.g. from untrusted input).
    /// </summary>
    public static bool IsValid(EquipmentSlot slot) => Enum.IsDefined(slot);
}
