namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>Why an equip attempt succeeded or was refused. Values start at 1 (0 is never a real outcome).</summary>
public enum EquipStatus
{
    /// <summary>The item is now equipped in the requested slot.</summary>
    Success = 1,

    /// <summary>The item has no equipment slot, so it can never be equipped.</summary>
    NotEquippable = 2,

    /// <summary>The requested slot is not a declared <see cref="EquipmentSlot"/>.</summary>
    InvalidSlot = 3,

    /// <summary>The item is equippable, but not in the requested slot.</summary>
    IncompatibleSlot = 4,

    /// <summary>The slot already holds a different item; nothing was replaced.</summary>
    SlotOccupied = 5,

    /// <summary>An item with the same <see cref="CastelSlayer.Modules.Inventory.Internal.Domain.ItemId"/> is already equipped; it can be equipped at most once.</summary>
    AlreadyEquipped = 6,
}
