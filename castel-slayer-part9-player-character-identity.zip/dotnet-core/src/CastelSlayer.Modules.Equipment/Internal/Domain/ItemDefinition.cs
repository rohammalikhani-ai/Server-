using CastelSlayer.Modules.Inventory.Internal.Domain;

namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// An immutable description of one kind of item: identity, name, category,
/// stack size, and — for equippable items — the one slot it goes in.
/// <para>
/// Always valid: every rule is checked in the constructor, and every
/// property is get-only (so a <c>with</c> expression cannot bypass validation).
/// Rules:
/// <list type="bullet">
/// <item><description><see cref="Name"/> is not blank; <see cref="Category"/> is a declared category.</description></item>
/// <item><description><see cref="MaxStackSize"/> is at least 1.</description></item>
/// <item><description>An item is equippable exactly when it has a <see cref="Slot"/>; that slot must be a declared <see cref="EquipmentSlot"/>. There is no separate flag that could disagree with the slot.</description></item>
/// <item><description>An equippable item has <c>MaxStackSize == 1</c> — equipment holds a single item, not a stack.</description></item>
/// </list>
/// </para>
/// <para>
/// This is not an item database or registry (out of scope); it is only the
/// value the Equipment domain needs. The <see cref="ItemId"/> is the one
/// defined by the Inventory module (Prompt 06), so the same id identifies an
/// item in both places. Inventory's own <c>Item</c> (id + max stack size)
/// is unchanged; a caller that needs one builds it from this definition.
/// </para>
/// </summary>
public sealed record ItemDefinition
{
    public ItemId Id { get; }

    public string Name { get; }

    public ItemCategory Category { get; }

    public int MaxStackSize { get; }

    /// <summary>The slot this item is worn/held in, or null when it cannot be equipped.</summary>
    public EquipmentSlot? Slot { get; }

    /// <summary>True exactly when <see cref="Slot"/> is set.</summary>
    public bool IsEquippable => Slot is not null;

    /// <param name="id">Item identity (Inventory's <see cref="ItemId"/>).</param>
    /// <param name="name">Display/identity name; must not be blank.</param>
    /// <param name="category">A declared <see cref="ItemCategory"/>.</param>
    /// <param name="maxStackSize">Largest stack size; at least 1, and exactly 1 for equippable items.</param>
    /// <param name="slot">The slot the item equips into; null for non-equippable items.</param>
    /// <exception cref="ArgumentNullException"><paramref name="id"/> or <paramref name="name"/> is null.</exception>
    /// <exception cref="ArgumentException">Blank name, or an equippable item with a stack size other than 1.</exception>
    /// <exception cref="ArgumentOutOfRangeException">Undeclared category or slot, or stack size below 1.</exception>
    public ItemDefinition(
        ItemId id,
        string name,
        ItemCategory category,
        int maxStackSize = 1,
        EquipmentSlot? slot = null)
    {
        ArgumentNullException.ThrowIfNull(id);
        ArgumentNullException.ThrowIfNull(name);

        if (string.IsNullOrWhiteSpace(name))
        {
            throw new ArgumentException("Item name cannot be empty or whitespace.", nameof(name));
        }

        if (!Enum.IsDefined(category))
        {
            throw new ArgumentOutOfRangeException(nameof(category), category, "Category is not a defined ItemCategory.");
        }

        if (maxStackSize < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(maxStackSize), maxStackSize, "MaxStackSize must be at least 1.");
        }

        if (slot is { } declaredSlot)
        {
            if (!EquipmentSlots.IsValid(declaredSlot))
            {
                throw new ArgumentOutOfRangeException(nameof(slot), declaredSlot, "Slot is not a defined EquipmentSlot.");
            }

            if (maxStackSize != 1)
            {
                throw new ArgumentException("An equippable item must have MaxStackSize 1.", nameof(maxStackSize));
            }
        }

        Id = id;
        Name = name;
        Category = category;
        MaxStackSize = maxStackSize;
        Slot = slot;
    }
}
