using CastelSlayer.Modules.Inventory.Internal.Domain;

namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// What a character currently has equipped: at most one <see cref="ItemDefinition"/>
/// per <see cref="EquipmentSlot"/>. The only place equipped state changes —
/// state is private and callers see read-only <see cref="EquipmentSlotState"/>
/// snapshots, so nothing (client, AI, another module) can edit it directly.
/// <para>
/// Invariants, holding after every call (including refused ones):
/// <list type="bullet">
/// <item><description>Every equipped item is equippable and sits in the slot its definition names.</description></item>
/// <item><description>A slot holds at most one item.</description></item>
/// <item><description>A given <see cref="ItemId"/> is equipped at most once.</description></item>
/// </list>
/// </para>
/// <para>
/// Nothing here replaces or discards an item: equipping into an occupied slot
/// is refused, and unequipping hands the item back in the result. This class
/// does not touch <c>ItemInventory</c>; moving items between the two (with
/// all-or-nothing guarantees) is a later prompt's transaction. It also knows
/// nothing about Stats — a future integration reads <see cref="GetSlots"/>
/// and applies modifiers on its side.
/// </para>
/// <para>
/// Named <c>ItemEquipment</c> (not <c>Equipment</c>) for the same reason as
/// <c>ItemInventory</c>: a type named after its own module namespace makes the
/// simple name ambiguous (CS0118). Not thread-safe; the caller (a future
/// single-threaded authority) owns synchronisation.
/// </para>
/// </summary>
public sealed class ItemEquipment
{
    private readonly Dictionary<EquipmentSlot, ItemDefinition> _equipped = new();

    /// <summary>Number of slots that currently hold an item.</summary>
    public int EquippedCount => _equipped.Count;

    /// <summary>
    /// Equips <paramref name="item"/> into <paramref name="slot"/>, or explains why not.
    /// Checks run in this order and the first failure wins:
    /// not equippable → invalid slot → incompatible slot → already equipped → slot occupied.
    /// </summary>
    /// <exception cref="ArgumentNullException"><paramref name="item"/> is null (a programming error, not a gameplay outcome).</exception>
    public EquipResult Equip(ItemDefinition item, EquipmentSlot slot)
    {
        ArgumentNullException.ThrowIfNull(item);

        if (!item.IsEquippable)
        {
            return EquipResult.Create(EquipStatus.NotEquippable, item, slot);
        }

        if (!EquipmentSlots.IsValid(slot))
        {
            return EquipResult.Create(EquipStatus.InvalidSlot, item, slot);
        }

        if (item.Slot != slot)
        {
            return EquipResult.Create(EquipStatus.IncompatibleSlot, item, slot);
        }

        foreach (var equippedItem in _equipped.Values)
        {
            if (equippedItem.Id == item.Id)
            {
                return EquipResult.Create(EquipStatus.AlreadyEquipped, item, slot, equippedItem);
            }
        }

        if (_equipped.TryGetValue(slot, out var occupant))
        {
            return EquipResult.Create(EquipStatus.SlotOccupied, item, slot, occupant);
        }

        _equipped.Add(slot, item);
        return EquipResult.Create(EquipStatus.Success, item, slot);
    }

    /// <summary>
    /// Removes and returns whatever is in <paramref name="slot"/>, or explains why nothing was removed.
    /// </summary>
    public UnequipResult Unequip(EquipmentSlot slot)
    {
        if (!EquipmentSlots.IsValid(slot))
        {
            return UnequipResult.Create(UnequipStatus.InvalidSlot, slot);
        }

        if (!_equipped.Remove(slot, out var removed))
        {
            return UnequipResult.Create(UnequipStatus.SlotEmpty, slot);
        }

        return UnequipResult.Create(UnequipStatus.Success, slot, removed);
    }

    /// <summary>The item in <paramref name="slot"/>, or null when it is empty.</summary>
    /// <exception cref="ArgumentOutOfRangeException"><paramref name="slot"/> is not a declared slot.</exception>
    public ItemDefinition? GetEquipped(EquipmentSlot slot)
    {
        RequireValidSlot(slot);

        return _equipped.GetValueOrDefault(slot);
    }

    /// <exception cref="ArgumentOutOfRangeException"><paramref name="slot"/> is not a declared slot.</exception>
    public bool IsSlotOccupied(EquipmentSlot slot)
    {
        RequireValidSlot(slot);

        return _equipped.ContainsKey(slot);
    }

    /// <summary>True if an item with this id is equipped in any slot.</summary>
    public bool IsEquipped(ItemId itemId)
    {
        ArgumentNullException.ThrowIfNull(itemId);

        foreach (var equippedItem in _equipped.Values)
        {
            if (equippedItem.Id == itemId)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// A read-only snapshot of every slot (empty ones included), in
    /// <see cref="EquipmentSlots.All"/> order. Later changes to this equipment
    /// do not alter a snapshot already handed out, and the list cannot be modified.
    /// </summary>
    public IReadOnlyList<EquipmentSlotState> GetSlots()
    {
        var snapshot = new EquipmentSlotState[EquipmentSlots.All.Count];
        for (int i = 0; i < snapshot.Length; i++)
        {
            var slot = EquipmentSlots.All[i];
            snapshot[i] = new EquipmentSlotState(slot, _equipped.GetValueOrDefault(slot));
        }

        return Array.AsReadOnly(snapshot);
    }

    private static void RequireValidSlot(EquipmentSlot slot)
    {
        if (!EquipmentSlots.IsValid(slot))
        {
            throw new ArgumentOutOfRangeException(nameof(slot), slot, "Slot is not a defined EquipmentSlot.");
        }
    }
}
