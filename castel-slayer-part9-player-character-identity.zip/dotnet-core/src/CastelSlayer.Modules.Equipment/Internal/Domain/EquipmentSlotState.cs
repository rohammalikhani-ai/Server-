namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// A read-only view of one equipment slot: either empty (<see cref="Item"/> is
/// null) or holding one <see cref="ItemDefinition"/>. A snapshot value —
/// holding one never lets a caller change the equipment; only
/// <see cref="ItemEquipment"/>'s own methods can.
/// </summary>
/// <param name="Slot">Which slot this describes.</param>
/// <param name="Item">The equipped item, or null when the slot is empty.</param>
public readonly record struct EquipmentSlotState(EquipmentSlot Slot, ItemDefinition? Item)
{
    public bool IsEmpty => Item is null;
}
