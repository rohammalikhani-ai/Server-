namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// Outcome of <see cref="ItemEquipment.Unequip"/>. On success the removed item
/// is handed back in <see cref="Item"/> — it is never discarded, so the caller
/// (in future, the Inventory ↔ Equipment transaction) must place it somewhere.
/// Refusals never change the equipment. Only <see cref="ItemEquipment"/> can create one.
/// </summary>
public sealed record UnequipResult
{
    public UnequipStatus Status { get; }

    /// <summary>The slot the caller asked about (may be an undeclared value when <see cref="Status"/> is <see cref="UnequipStatus.InvalidSlot"/>).</summary>
    public EquipmentSlot RequestedSlot { get; }

    /// <summary>The item that was removed; non-null exactly when <see cref="IsSuccess"/>.</summary>
    public ItemDefinition? Item { get; }

    public bool IsSuccess => Status == UnequipStatus.Success;

    private UnequipResult(UnequipStatus status, EquipmentSlot requestedSlot, ItemDefinition? item)
    {
        Status = status;
        RequestedSlot = requestedSlot;
        Item = item;
    }

    internal static UnequipResult Create(UnequipStatus status, EquipmentSlot requestedSlot, ItemDefinition? item = null)
        => new(status, requestedSlot, item);
}
