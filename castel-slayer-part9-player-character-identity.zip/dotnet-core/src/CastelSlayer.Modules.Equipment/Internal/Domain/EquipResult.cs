namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// Outcome of <see cref="ItemEquipment.Equip"/>. A refused equip is a normal
/// gameplay outcome, reported here rather than thrown. Refusals never change
/// the equipment. Only <see cref="ItemEquipment"/> can create one.
/// </summary>
public sealed record EquipResult
{
    public EquipStatus Status { get; }

    /// <summary>The item the caller tried to equip. It is still the caller's on any refusal.</summary>
    public ItemDefinition Item { get; }

    /// <summary>The slot the caller asked for (may be an undeclared value when <see cref="Status"/> is <see cref="EquipStatus.InvalidSlot"/>).</summary>
    public EquipmentSlot RequestedSlot { get; }

    /// <summary>
    /// The item in the way: the current occupant for <see cref="EquipStatus.SlotOccupied"/>,
    /// or the already-equipped copy for <see cref="EquipStatus.AlreadyEquipped"/>. Null otherwise.
    /// </summary>
    public ItemDefinition? BlockingItem { get; }

    public bool IsSuccess => Status == EquipStatus.Success;

    private EquipResult(EquipStatus status, ItemDefinition item, EquipmentSlot requestedSlot, ItemDefinition? blockingItem)
    {
        Status = status;
        Item = item;
        RequestedSlot = requestedSlot;
        BlockingItem = blockingItem;
    }

    internal static EquipResult Create(
        EquipStatus status,
        ItemDefinition item,
        EquipmentSlot requestedSlot,
        ItemDefinition? blockingItem = null)
        => new(status, item, requestedSlot, blockingItem);
}
