namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>
/// Coarse item category. Deliberately small: only what is needed to describe
/// an item today. Values start at 1 so an uninitialised (0) category is invalid.
/// A category does not by itself make an item equippable — see
/// <see cref="ItemDefinition.IsEquippable"/>.
/// </summary>
public enum ItemCategory
{
    Weapon = 1,
    Armor = 2,
    Consumable = 3,
    Material = 4,
    Miscellaneous = 5,
}
