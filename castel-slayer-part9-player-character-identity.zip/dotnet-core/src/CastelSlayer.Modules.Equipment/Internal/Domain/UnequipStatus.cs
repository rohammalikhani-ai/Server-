namespace CastelSlayer.Modules.Equipment.Internal.Domain;

/// <summary>Why an unequip attempt succeeded or was refused. Values start at 1.</summary>
public enum UnequipStatus
{
    /// <summary>The slot's item was removed and is returned in the result.</summary>
    Success = 1,

    /// <summary>The slot holds nothing.</summary>
    SlotEmpty = 2,

    /// <summary>The slot is not a declared <see cref="EquipmentSlot"/>.</summary>
    InvalidSlot = 3,
}
