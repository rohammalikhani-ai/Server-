# equipment (C# Core)

## Purpose

Prompt 07 Foundation: what a character has equipped, as pure server-side
domain state — one item per slot, with validated equip/unequip. Nothing more;
this is not the final equipment system.

## Files

```
CastelSlayer.Modules.Equipment/
├── MODULE.md
├── CastelSlayer.Modules.Equipment.csproj   one project reference: Inventory (for ItemId only)
└── Internal/Domain/
    ├── EquipmentSlot.cs        enum: Head, Chest, Legs, Feet, MainHand, OffHand (values start at 1)
    ├── EquipmentSlots.cs       All (ordered) + IsValid(slot)
    ├── ItemCategory.cs         enum: Weapon, Armor, Consumable, Material, Miscellaneous
    ├── ItemDefinition.cs       immutable, self-validating item description
    ├── ItemEquipment.cs        the aggregate: Equip / Unequip / GetEquipped / IsSlotOccupied / IsEquipped / GetSlots
    ├── EquipmentSlotState.cs   read-only snapshot of one slot (Slot + optional ItemDefinition)
    ├── EquipStatus.cs          Success, NotEquippable, InvalidSlot, IncompatibleSlot, SlotOccupied, AlreadyEquipped
    ├── EquipResult.cs          status + item + requested slot + blocking item
    ├── UnequipStatus.cs        Success, SlotEmpty, InvalidSlot
    └── UnequipResult.cs        status + requested slot + removed item
```

The aggregate is `ItemEquipment`, not `Equipment`, for the same reason
Inventory's is `ItemInventory`: a type named after its module namespace is
ambiguous for siblings and tests (CS0118).

## ItemDefinition

`ItemId` (Inventory's, Prompt 06), `Name`, `Category`, `MaxStackSize`, and an
optional `Slot`. Always valid — every rule is checked in the constructor and
all properties are get-only (a `with` expression cannot bypass validation):

- Name is not blank; category and slot (when given) are declared enum values;
  `MaxStackSize >= 1`.
- **Equippable ⇔ it has a slot** (`IsEquippable` is derived), so there is no
  flag that can disagree with the slot.
- An equippable item must have `MaxStackSize == 1` (equipment holds one item,
  not a stack). Default `MaxStackSize` is 1.
- One slot per item. Items that fit several slots (e.g. a one-handed weapon in
  either hand) are not modelled yet.

This is not an item database/registry. Definitions are handed in by the caller.
Placement is provisional: when an Item Database prompt arrives, the definition
(and `ItemCategory`) will likely move to the module that owns items, and
Equipment will keep only the slot rules.

## ItemEquipment behavior

`Equip(item, slot)` checks in this order; the first failure wins and nothing
changes on any failure:

1. `NotEquippable` — the item has no slot.
2. `InvalidSlot` — `slot` is not a declared value (`default`, or an int cast).
3. `IncompatibleSlot` — the item's slot differs from the requested one.
4. `AlreadyEquipped` — an item with the same `ItemId` is already equipped.
5. `SlotOccupied` — the slot holds a different item. **Never replaces**; the
   caller must `Unequip` first. `EquipResult.BlockingItem` names the occupant.

`Unequip(slot)` returns `Success` with the removed `ItemDefinition` in the
result (never discarded), `SlotEmpty`, or `InvalidSlot`.

Gameplay refusals are result values. Exceptions are for programmer errors only:
null arguments, and the query methods (`GetEquipped`, `IsSlotOccupied`) given an
undeclared slot.

Invariants after every call: each equipped item is equippable and sits in the
slot its definition names; a slot holds at most one item; an `ItemId` is
equipped at most once. (The last rule is deliberate now and must be revisited if
dual-wielding two identical items is ever introduced.)

## Authority and read-only state

State is private. `GetSlots()` returns a fresh read-only snapshot of all six
slots (empty ones included, in `EquipmentSlots.All` order); it can't be used to
modify the equipment, and earlier snapshots don't change later. Definitions are
immutable. Only `Equip`/`Unequip` on the authoritative instance change state,
and results can only be created by `ItemEquipment`.

## Inventory boundary

Inventory stores `ItemStack`s; Equipment stores equipped `ItemDefinition`s.
Equipment does not reference `ItemInventory`, and `Equip`/`Unequip` never move
items in or out of it. The only shared type is `ItemId`, so one id identifies
an item in both places. Consequence for callers until the transaction prompt:
`Unequip` hands the item back in its result and *the caller is responsible for
putting it somewhere*; ignoring the result loses it. Moving an item between the
two containers atomically is a later prompt.

## Stats boundary

No stat bonuses, and no reference to Progression. A future integration reads
`GetSlots()` and applies `AttributeModifier`s through Progression's existing
extension points, on its side.

## Dependencies

`CastelSlayer.Modules.Inventory` (project reference) for `ItemId` only. Nothing
else: no Core, Progression, Character, Minecraft/Fabric/Geyser/Bukkit types.
`ItemId` sits in Inventory's `Internal.Domain` namespace (there is no `Public/`
layer yet), so this is a documented exception to the "other modules' public
surface only" rule — see `docs/decisions/0003-equipment-module-boundary.md`.

## Not implemented (deliberately)

Item database/registry, loot, crafting, trading, shops, economy, durability,
enchantments, upgrades/affixes, stat bonuses, class/race restrictions,
persistence, events, networking, GUI, Java/Fabric equipment code, multi-slot
items, automatic Inventory ↔ Equipment transactions, swap-on-equip.

## Tests

`dotnet-core/tests/CastelSlayer.Tests/Modules/Equipment/` — 50 test methods:
`ItemDefinitionTests` (12), `EquipmentSlotTests` (5), `ItemEquipmentTests` (28),
`EquipmentInventoryCompatibilityTests` (5), run by the hand-rolled
`Support/TestRunner`. Not compiled or run in the authoring environment (no .NET
SDK) — see root `CURRENT_STATE.md`.
