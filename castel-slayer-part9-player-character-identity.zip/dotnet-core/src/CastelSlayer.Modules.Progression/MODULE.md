# progression (C# Core)

## Purpose

Owns a character's base attributes, active stat modifiers, derived
statistics, and level/XP progression. This is the first module built in
the new C# Core (see `docs/decisions/0002-csharp-core-migration-boundary.md`);
it deliberately does not implement races, classes, equipment, skills,
buffs, professions, or combat — only the extension points they will need
(requirement 10).

## Responsibilities

- Storing a character's base attribute values and validating them
  (`Internal/Domain/CharacterAttributes.cs`).
- Accepting and removing stat contributions ("modifiers") from any future
  source (equipment, buffs, class, profession, race) without knowing what
  that source is (`Internal/Domain/AttributeModifier.cs`,
  `Internal/Services/AttributeModifierService.cs`).
- Computing derived statistics (MaxHealth, MaxMana, PhysicalPower,
  MagicPower, Defense, Speed) from effective attribute values
  (`Internal/Services/DerivedStatCalculator.cs`).
- Owning a character's level and total XP as the single authoritative
  place XP is accumulated and levels are crossed
  (`Internal/Domain/ProgressionState.cs`, `Internal/Services/LevelingService.cs`,
  `Internal/Services/IProgressionCurve.cs` / `DefaultProgressionCurve.cs`).
- Publishing `CharacterLeveledUp` so other systems can react to a level-up
  without coupling to this module directly (`Public/Events/CharacterLeveledUp.cs`).

## Files

```
CastelSlayer.Modules.Progression/
├── MODULE.md                                   (this file)
├── CastelSlayer.Modules.Progression.csproj
├── AssemblyInfo.cs                              InternalsVisibleTo("CastelSlayer.Tests") only
├── Public/
│   ├── Contracts/
│   │   └── ICharacterStatsQuery.cs              extension point, no implementation yet
│   └── Events/
│       └── CharacterLeveledUp.cs
└── Internal/
    ├── Domain/
    │   ├── AttributeType.cs                     Strength/Dexterity/Intelligence/Vitality/Wisdom/Luck
    │   ├── DerivedStatType.cs                    MaxHealth/MaxMana/PhysicalPower/MagicPower/Defense/Speed
    │   ├── ModifierOperation.cs                  Flat / PercentAdditive
    │   ├── AttributeModifier.cs                  one contribution from an external source
    │   ├── CharacterAttributes.cs                base values + active modifiers + effective-value calc
    │   ├── ProgressionState.cs                   immutable Level + TotalXp
    │   └── CharacterStatsProfile.cs              aggregate root: CharacterId + Attributes + Progression
    └── Services/
        ├── IProgressionCurve.cs                  pluggable leveling-cost formula
        ├── DefaultProgressionCurve.cs             concrete prototype curve (triangular, 100 XP/level step)
        ├── DerivedStatCalculator.cs               pure attribute -> derived-stat formulas
        ├── AttributeModifierService.cs            validated Apply/Remove entry point
        └── LevelingService.cs                     the only place XP is accumulated / levels crossed
```

Tests mirror this under `dotnet-core/tests/CastelSlayer.Tests/Modules/Progression/`.

## Integration With Character

`CharacterStatsProfile` is keyed by `CastelSlayer.Core.Domain.CharacterId`,
the C# analog of the existing Java `character.contracts.CharacterId`
(same underlying UUID/GUID — see
`docs/decisions/0002-csharp-core-migration-boundary.md`). This module does
**not** reference the Java `character` module's `PlayerCharacter`
aggregate, `ICharacterDirectory`, or any other Java type — the C# Core
must not depend on Java (requirement/ARCHITECTURE.md dependency
direction). It only needs a valid id; whatever wires a stats profile to a
real, existing character (checking the id is genuine, loading/saving
across the C#↔Java boundary) is integration-layer work explicitly out of
scope for this prompt (rule: "do not create fake networking or database
infrastructure just for this prompt") — see the decision record's "What
Is Deferred" section.

`CharacterStatsProfile` itself stays intentionally thin (identity + state
only) so it cannot become a God Object as future systems attach — all
actual logic lives in the `Internal/Services/*` classes, mirroring how
the Java `character` module already separates `PlayerCharacter` (data)
from `CharacterFactory`/`CharacterDirectoryService` (logic).

## Dependencies

- `CastelSlayer.Core.Domain`: `CharacterId`.
- `CastelSlayer.Core.Events`: `IGameEvent` (implemented by `CharacterLeveledUp`).
- `CastelSlayer.Core.Contracts`: none directly — `LevelingService` returns
  events rather than depending on `IEventBus` itself; whatever composes
  this module is responsible for publishing `LevelingResult.Events`.
- No dependency on any other module, and no dependency on any
  Minecraft/Fabric/Geyser type (this module has no reference to them at
  all — it is pure C#, buildable and testable without starting Minecraft,
  per requirement 11).

## Public Interfaces Exposed

- `Public.Events.CharacterLeveledUp` — subscribe via `Core.Contracts.IEventBus`
  (once a concrete bus exists) to react to a character's level changing.
- `Public.Contracts.ICharacterStatsQuery` — declared now as the intended
  read surface for other modules; **no implementation exists yet**
  (deliberately — see the interface's own doc comment and
  DEVELOPMENT_RULES.md "never create a manager/service/class for a
  feature that isn't being built yet").

Everything else (`CharacterAttributes`, `CharacterStatsProfile`,
`ProgressionState`, the services) is `Internal` and must not be
referenced from outside this module's own code or its own tests.

## Interfaces Consumed

None yet. `LevelingService` takes an `IProgressionCurve` by constructor
injection (currently always `DefaultProgressionCurve` at call sites) so
the leveling formula can change later without touching the service.

## Configuration

None yet — `DefaultProgressionCurve`'s XP-per-level-step (100) and
default max level (60) are constructor parameters/constants, not
`IConfigProvider` keys, since no config source exists in the C# Core yet
(see the decision record). If/when one does, these would become
`progression.xpPerLevelStep` / `progression.maxLevel`.

## Validation / Invalid-State Rules

- `CharacterAttributes` requires a value for every `AttributeType`
  (0–999 inclusive) at construction; missing or out-of-range values throw.
- `CharacterAttributes.GetEffectiveValue` never returns a negative number
  (floored at 0) regardless of how negative a modifier is.
- Adding a modifier whose `(Source, ModifierId)` pair is already active
  throws `InvalidOperationException` — a source must remove its existing
  modifier before reapplying, so nothing can silently double-stack.
- Removing a modifier that isn't active throws `InvalidOperationException`.
- `ProgressionState` rejects `Level < 1` or `TotalXp < 0`.
- `LevelingService.GainXp` rejects `amount <= 0` — XP gains must be a
  positive, server-computed amount (requirement 7: never trust
  client-provided XP/level/stats).
- XP gained once a character is already at `IProgressionCurve.MaxLevel`
  is discarded (no error, no-op level-wise) rather than accumulating
  unbounded `TotalXp`.

## Tests

`dotnet-core/tests/CastelSlayer.Tests/Modules/Progression/`:

- `CharacterAttributesTests.cs` — base-value storage/validation, flat and
  percent modifier math, floor-at-zero, duplicate/unknown modifier
  rejection, removal.
- `DerivedStatCalculatorTests.cs` — formula correctness against known
  inputs, modifiers reflected in derived stats, never-negative outputs.
- `LevelingServiceTests.cs` — initial state, sub-threshold gain, invalid
  (zero/negative) XP, exact-threshold single level-up, one-XP-short
  boundary, multi-level gain in one call, max-level XP discard, XP
  capping when a gain crosses into the max level, null-profile rejection.
- `CharacterStatsProfileTests.cs` — `CreateNew` vs. `Reconstitute`, null
  attributes rejected, empty-GUID `CharacterId` rejected.

See `dotnet-core/tests/CastelSlayer.Tests/Support/TestAttribute.cs` for
why these run through a hand-rolled harness instead of xUnit/NUnit, and
`CURRENT_STATE.md` for their execution status in this environment (not
run — no network access to fetch the .NET SDK; see
`docs/decisions/0002-csharp-core-migration-boundary.md`).

## Forbidden Responsibilities

This module must **not**:

- Implement races, classes, equipment, skills, buffs/debuffs,
  professions, or combat — it only defines the modifier/event seams they
  will attach through.
- Trust or accept a client-supplied XP, level, or stat value anywhere.
- Reference any Minecraft/Fabric/Geyser/Bukkit/Spigot/Paper type, or any
  Java `character` module type.
- Persist anything — no `IPersistenceGateway`-equivalent exists in the
  C# Core yet; that is explicitly deferred (see the decision record).
