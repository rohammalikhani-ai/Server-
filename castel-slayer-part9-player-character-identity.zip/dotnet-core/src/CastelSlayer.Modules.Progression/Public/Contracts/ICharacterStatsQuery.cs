using CastelSlayer.Core.Domain;
using CastelSlayer.Modules.Progression.Internal.Domain;

namespace CastelSlayer.Modules.Progression.Public.Contracts;

/// <summary>
/// The read-only surface other modules (combat, equipment, quest, ...) are
/// meant to depend on once they need a character's level or derived stats —
/// never <c>Internal/Domain/CharacterStatsProfile.cs</c> or any other
/// internal type directly (ARCHITECTURE.md → module public/internal split).
///
/// This is an extension point only for now: no implementation exists yet.
/// Per DEVELOPMENT_RULES.md ("never create a manager/service/class for a
/// feature that isn't being built yet"), a concrete
/// persistence-/registry-backed implementation is deliberately deferred to
/// whichever future prompt actually needs another module to query stats
/// (requirement 10: only the extension points required are created now,
/// not the systems that would consume them).
/// </summary>
public interface ICharacterStatsQuery
{
    /// <summary>True and the current level if <paramref name="characterId"/> has a stats profile.</summary>
    bool TryGetLevel(CharacterId characterId, out int level);

    /// <summary>True and the current derived value if <paramref name="characterId"/> has a stats profile.</summary>
    bool TryGetDerivedStat(CharacterId characterId, DerivedStatType stat, out int value);
}
