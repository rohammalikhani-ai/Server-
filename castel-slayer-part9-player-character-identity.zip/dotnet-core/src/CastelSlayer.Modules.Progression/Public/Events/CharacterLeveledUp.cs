using CastelSlayer.Core.Domain;
using CastelSlayer.Core.Events;

namespace CastelSlayer.Modules.Progression.Public.Events;

/// <summary>
/// Published when a character's level increases (by one or more levels in a
/// single XP gain). Other systems (combat unlocking a skill slot, quest
/// tracking a "reach level N" objective, etc.) observe level-ups through
/// this event instead of coupling directly to the Stats module
/// (requirement 9).
/// </summary>
/// <param name="CharacterId">The character that leveled up.</param>
/// <param name="FromLevel">Level before this XP gain.</param>
/// <param name="ToLevel">Level after this XP gain (may be more than one level higher).</param>
public sealed record CharacterLeveledUp(CharacterId CharacterId, int FromLevel, int ToLevel) : IGameEvent;
