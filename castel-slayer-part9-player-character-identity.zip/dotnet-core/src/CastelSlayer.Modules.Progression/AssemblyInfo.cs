using System.Runtime.CompilerServices;

// The Stats module's own tests (tests/Modules/Progression, mirroring the
// Java side's rule that a module's own tests may see into its internal/
// layer — DEVELOPMENT_RULES.md "Testing Rules") need to call internal
// members such as CharacterAttributes.AddModifier directly. No other
// assembly is granted this visibility.
[assembly: InternalsVisibleTo("CastelSlayer.Tests")]
