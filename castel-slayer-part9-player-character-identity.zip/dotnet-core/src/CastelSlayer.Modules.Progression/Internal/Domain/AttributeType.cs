namespace CastelSlayer.Modules.Progression.Internal.Domain;

/// <summary>
/// The minimum base attribute set a character has, independent of any future
/// race/class/equipment system. Race, class, equipment, buffs, etc. do not
/// add new members here — they contribute <see cref="AttributeModifier"/>s
/// against these same types (requirement 5: don't hardcode every future
/// race/class into the system).
/// </summary>
public enum AttributeType
{
    Strength,
    Dexterity,
    Intelligence,
    Vitality,
    Wisdom,
    Luck
}
