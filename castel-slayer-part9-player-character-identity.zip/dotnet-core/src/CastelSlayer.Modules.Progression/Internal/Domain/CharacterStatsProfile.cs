using System;
using CastelSlayer.Core.Domain;

namespace CastelSlayer.Modules.Progression.Internal.Domain;

/// <summary>
/// The Stats module's aggregate root for one character: which
/// <see cref="Core.Domain.CharacterId"/> it belongs to, its
/// <see cref="CharacterAttributes"/>, and its <see cref="ProgressionState"/>.
///
/// This is intentionally thin — it holds state and identity only. Every
/// piece of actual logic (levelling formulas, modifier validation, derived
/// stat formulas) lives in <c>Internal/Services/*</c>, so this class cannot
/// grow into a God Object as more systems (equipment, buffs, classes) start
/// contributing to a character's stats (requirement 2).
///
/// Mirrors the shape of the existing Java <c>character.internal.domain.PlayerCharacter</c>
/// aggregate (identity + state, logic delegated to services) rather than
/// introducing a new pattern.
/// </summary>
public sealed class CharacterStatsProfile
{
    public CharacterId CharacterId { get; }
    public CharacterAttributes Attributes { get; }
    public ProgressionState Progression { get; private set; }

    private CharacterStatsProfile(CharacterId characterId, CharacterAttributes attributes, ProgressionState progression)
    {
        CharacterId = characterId;
        Attributes = attributes ?? throw new ArgumentNullException(nameof(attributes));
        Progression = progression ?? throw new ArgumentNullException(nameof(progression));
    }

    /// <summary>Creates a brand-new profile for a freshly-created character: level 1, zero XP.</summary>
    public static CharacterStatsProfile CreateNew(CharacterId characterId, CharacterAttributes attributes)
        => new(characterId, attributes, ProgressionState.Initial);

    /// <summary>
    /// Reconstitutes a profile from previously-persisted state (e.g. loaded
    /// through <c>core.contracts.IPersistenceGateway</c> on the platform
    /// side). Takes an explicit <see cref="ProgressionState"/> rather than
    /// starting at level 1, unlike <see cref="CreateNew"/>.
    /// </summary>
    public static CharacterStatsProfile Reconstitute(CharacterId characterId, CharacterAttributes attributes, ProgressionState progression)
        => new(characterId, attributes, progression);

    /// <summary>
    /// Replaces this profile's progression state. Internal: only
    /// <c>Internal/Services/LevelingService.cs</c> should call this, after
    /// validating and computing the new state itself.
    /// </summary>
    internal void ReplaceProgression(ProgressionState newState)
    {
        Progression = newState ?? throw new ArgumentNullException(nameof(newState));
    }
}
