using System;

namespace CastelSlayer.Modules.Progression.Internal.Domain;

/// <summary>
/// A character's level/XP as of a point in time. Immutable — advancing it
/// always produces a new <see cref="ProgressionState"/> (via
/// <c>Internal/Services/LevelingService.cs</c>), never a mutation in place,
/// so the progression formulas stay pure and unit-testable in isolation
/// (requirement 8: keep progression formulas isolated and unit-testable).
/// </summary>
/// <param name="Level">1-based character level.</param>
/// <param name="TotalXp">Total XP accumulated over the character's lifetime (not "XP into this level").</param>
public sealed record ProgressionState(int Level, long TotalXp)
{
    public const int MinLevel = 1;

    public ProgressionState
    {
        if (Level < MinLevel)
        {
            throw new ArgumentOutOfRangeException(nameof(Level), Level, $"Level must be >= {MinLevel}.");
        }

        if (TotalXp < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(TotalXp), TotalXp, "TotalXp cannot be negative.");
        }
    }

    public static ProgressionState Initial => new(MinLevel, 0);
}
