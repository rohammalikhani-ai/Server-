namespace CastelSlayer.Modules.Progression.Internal.Domain;

/// <summary>
/// Statistics computed from a character's effective attributes (base values
/// plus every active <see cref="AttributeModifier"/>), never stored or set
/// directly. See <c>Internal/Services/DerivedStatCalculator.cs</c> for the
/// (prototype, tunable) formulas.
/// </summary>
public enum DerivedStatType
{
    MaxHealth,
    MaxMana,
    PhysicalPower,
    MagicPower,
    Defense,
    Speed
}
