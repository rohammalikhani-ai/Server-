using System;
using System.Collections.Generic;
using System.Linq;

namespace CastelSlayer.Modules.Progression.Internal.Domain;

/// <summary>
/// A character's base attribute values plus every currently active
/// <see cref="AttributeModifier"/>. Deliberately separate from
/// <see cref="CharacterStatsProfile"/> and <see cref="ProgressionState"/>
/// (requirement 6: separate base values, modifiers, and derived statistics)
/// so each stays small and independently testable instead of one aggregate
/// growing into a God Object.
///
/// Mutation (<see cref="AddModifier"/>/<see cref="RemoveModifier"/>) is
/// internal: only <c>Internal/Services/AttributeModifierService.cs</c> (this
/// assembly) is meant to call it, keeping validation/business rules in the
/// service layer rather than scattered across callers.
/// </summary>
public sealed class CharacterAttributes
{
    public const int MinBaseValue = 0;
    public const int MaxBaseValue = 999;

    private readonly Dictionary<AttributeType, int> _base;
    private readonly Dictionary<string, AttributeModifier> _modifiers = new();

    public CharacterAttributes(IReadOnlyDictionary<AttributeType, int> baseValues)
    {
        ArgumentNullException.ThrowIfNull(baseValues);

        foreach (AttributeType type in Enum.GetValues<AttributeType>())
        {
            if (!baseValues.TryGetValue(type, out int value))
            {
                throw new ArgumentException(
                    $"Base attributes must specify a value for every {nameof(AttributeType)} " +
                    $"(missing {type}).", nameof(baseValues));
            }

            if (value < MinBaseValue || value > MaxBaseValue)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(baseValues),
                    value,
                    $"{type} base value must be between {MinBaseValue} and {MaxBaseValue}.");
            }
        }

        _base = new Dictionary<AttributeType, int>(baseValues);
    }

    public int GetBaseValue(AttributeType type) => _base[type];

    public IReadOnlyCollection<AttributeModifier> Modifiers => _modifiers.Values;

    /// <summary>
    /// Registers a new modifier. Throws if a modifier with the same
    /// <see cref="AttributeModifier.Key"/> (source + modifier id) is already
    /// active — callers must remove the existing one first, so a source can
    /// never silently double-apply (requirement 12: invalid-state protection).
    /// </summary>
    internal void AddModifier(AttributeModifier modifier)
    {
        ArgumentNullException.ThrowIfNull(modifier);

        if (!_modifiers.TryAdd(modifier.Key, modifier))
        {
            throw new InvalidOperationException(
                $"A modifier with source '{modifier.Source}' and id '{modifier.ModifierId}' is already active.");
        }
    }

    /// <summary>
    /// Removes a previously-applied modifier. Throws if no such modifier is
    /// active, so callers cannot silently no-op on a mistaken source/id.
    /// </summary>
    internal void RemoveModifier(string source, string modifierId)
    {
        string key = $"{source}:{modifierId}";
        if (!_modifiers.Remove(key))
        {
            throw new InvalidOperationException(
                $"No active modifier with source '{source}' and id '{modifierId}'.");
        }
    }

    /// <summary>
    /// The attribute value after every active modifier is applied: all
    /// <see cref="ModifierOperation.Flat"/> modifiers are added to the base
    /// value first, then every <see cref="ModifierOperation.PercentAdditive"/>
    /// modifier is summed and applied as a single percentage against that
    /// flat-adjusted value. Result is floored to an integer and clamped to a
    /// minimum of zero — deterministic and side-effect free.
    /// </summary>
    public int GetEffectiveValue(AttributeType type)
    {
        double value = GetBaseValue(type);

        double flatSum = _modifiers.Values
            .Where(m => m.Attribute == type && m.Operation == ModifierOperation.Flat)
            .Sum(m => m.Value);
        value += flatSum;

        double percentSum = _modifiers.Values
            .Where(m => m.Attribute == type && m.Operation == ModifierOperation.PercentAdditive)
            .Sum(m => m.Value);
        value *= 1.0 + percentSum / 100.0;

        int result = (int)Math.Floor(value);
        return Math.Max(result, 0);
    }
}
