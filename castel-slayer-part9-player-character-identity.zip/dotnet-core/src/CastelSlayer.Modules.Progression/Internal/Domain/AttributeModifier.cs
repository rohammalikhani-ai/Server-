using System;

namespace CastelSlayer.Modules.Progression.Internal.Domain;

/// <summary>
/// A single contribution to one <see cref="AttributeType"/> from some source
/// outside the Stats module — equipment, a buff, a class bonus, a profession
/// perk, etc. The Stats module knows nothing about what a "source" is beyond
/// this opaque string; that is exactly the seam future modules (equipment,
/// buffs, classes, ...) attach through without Stats depending on them
/// (requirement 6).
/// </summary>
/// <param name="ModifierId">
/// Unique, together with <paramref name="Source"/>, so the same source can
/// apply more than one distinct modifier and each can be individually
/// removed (e.g. a weapon granting both a Strength and a Dexterity bonus).
/// </param>
/// <param name="Source">
/// Opaque identifier for whatever granted this modifier, e.g.
/// <c>"equipment:iron-sword"</c>, <c>"buff:blessing-of-vigor"</c>. Used only
/// for lookup/removal — Stats never interprets it.
/// </param>
public sealed record AttributeModifier(
    string ModifierId,
    string Source,
    AttributeType Attribute,
    ModifierOperation Operation,
    double Value)
{
    public AttributeModifier
    {
        if (string.IsNullOrWhiteSpace(ModifierId))
        {
            throw new ArgumentException("ModifierId cannot be null or empty.", nameof(ModifierId));
        }

        if (string.IsNullOrWhiteSpace(Source))
        {
            throw new ArgumentException("Source cannot be null or empty.", nameof(Source));
        }
    }

    /// <summary>The compound key this modifier is stored/looked up under.</summary>
    public string Key => $"{Source}:{ModifierId}";
}
