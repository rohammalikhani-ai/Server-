using System;
using CastelSlayer.Modules.Progression.Internal.Domain;

namespace CastelSlayer.Modules.Progression.Internal.Services;

/// <summary>
/// The entry point every future contributor (equipment, buffs, classes,
/// professions, races) is expected to go through to add or remove a stat
/// contribution — none of those systems should touch
/// <see cref="CharacterAttributes"/>'s internal methods directly, even
/// though they could (both are in this assembly). Keeping the call path
/// here means validation/logging/future authority-checks have one place to
/// live, matching requirement 9 (server-authoritative, no scattered
/// mutation paths) applied to stat modifiers specifically.
/// </summary>
public sealed class AttributeModifierService
{
    /// <exception cref="InvalidOperationException">
    /// A modifier with the same source + modifier id is already active on
    /// this profile.
    /// </exception>
    public void ApplyModifier(CharacterStatsProfile profile, AttributeModifier modifier)
    {
        ArgumentNullException.ThrowIfNull(profile);
        ArgumentNullException.ThrowIfNull(modifier);

        profile.Attributes.AddModifier(modifier);
    }

    /// <exception cref="InvalidOperationException">
    /// No modifier with this source + modifier id is currently active.
    /// </exception>
    public void RemoveModifier(CharacterStatsProfile profile, string source, string modifierId)
    {
        ArgumentNullException.ThrowIfNull(profile);

        profile.Attributes.RemoveModifier(source, modifierId);
    }
}
