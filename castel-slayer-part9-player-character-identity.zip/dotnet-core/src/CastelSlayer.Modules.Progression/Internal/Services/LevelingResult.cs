using System.Collections.Generic;
using CastelSlayer.Modules.Progression.Internal.Domain;
using CastelSlayer.Modules.Progression.Public.Events;

namespace CastelSlayer.Modules.Progression.Internal.Services;

/// <summary>
/// The outcome of one <see cref="LevelingService.GainXp"/> call. Carries the
/// events that occurred rather than publishing them directly, so
/// <see cref="LevelingService"/> stays a pure function with no
/// <c>Core.Contracts.IEventBus</c> dependency (requirement 8: isolated,
/// unit-testable formulas) — the caller decides how/whether to publish them.
/// </summary>
public sealed record LevelingResult(
    ProgressionState NewState,
    int LevelsGained,
    IReadOnlyList<CharacterLeveledUp> Events);
