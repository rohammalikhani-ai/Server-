using System;
using System.Collections.Generic;
using CastelSlayer.Modules.Progression.Internal.Domain;

namespace CastelSlayer.Modules.Progression.Internal.Services;

/// <summary>
/// Computes <see cref="DerivedStatType"/> values from a character's
/// effective attributes. Pure and deterministic — same attributes always
/// produce the same derived stats, no hidden state, no randomness.
///
/// The formulas below are prototype placeholders (requirement 8: do not
/// over-engineer; real balancing is future work) but are wired through a
/// single method so a future prompt can retune them without touching
/// anything that calls <see cref="Calculate"/>.
/// </summary>
public sealed class DerivedStatCalculator
{
    public IReadOnlyDictionary<DerivedStatType, int> Calculate(CharacterAttributes attributes)
    {
        ArgumentNullException.ThrowIfNull(attributes);

        int strength = attributes.GetEffectiveValue(AttributeType.Strength);
        int dexterity = attributes.GetEffectiveValue(AttributeType.Dexterity);
        int intelligence = attributes.GetEffectiveValue(AttributeType.Intelligence);
        int vitality = attributes.GetEffectiveValue(AttributeType.Vitality);
        int wisdom = attributes.GetEffectiveValue(AttributeType.Wisdom);
        int luck = attributes.GetEffectiveValue(AttributeType.Luck);

        return new Dictionary<DerivedStatType, int>
        {
            [DerivedStatType.MaxHealth] = 50 + vitality * 10 + strength * 2,
            [DerivedStatType.MaxMana] = 20 + intelligence * 8 + wisdom * 4,
            [DerivedStatType.PhysicalPower] = strength * 2 + dexterity,
            [DerivedStatType.MagicPower] = intelligence * 2 + wisdom,
            [DerivedStatType.Defense] = vitality + strength / 2,
            [DerivedStatType.Speed] = dexterity + luck / 2
        };
    }
}
