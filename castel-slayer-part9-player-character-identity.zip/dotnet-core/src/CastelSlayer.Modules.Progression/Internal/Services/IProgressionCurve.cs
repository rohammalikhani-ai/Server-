namespace CastelSlayer.Modules.Progression.Internal.Services;

/// <summary>
/// Defines how much cumulative XP a level requires. Kept behind an
/// interface so the actual balancing formula can change (or become
/// race/class/config-driven later) without touching
/// <see cref="LevelingService"/> — the leveling algorithm itself
/// (accumulate XP, cross thresholds, cap at max level) is formula-agnostic.
/// </summary>
public interface IProgressionCurve
{
    /// <summary>The highest level a character can reach; XP gained at this level is capped, not accumulated further.</summary>
    int MaxLevel { get; }

    /// <summary>
    /// The total (cumulative, lifetime) XP a character must have to be at
    /// exactly <paramref name="level"/>. Must be non-decreasing in
    /// <paramref name="level"/>, and 0 for <see cref="Domain.ProgressionState.MinLevel"/>.
    /// </summary>
    long TotalXpRequiredForLevel(int level);
}
