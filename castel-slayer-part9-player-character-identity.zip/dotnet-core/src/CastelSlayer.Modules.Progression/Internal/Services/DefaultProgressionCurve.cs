using System;
using CastelSlayer.Modules.Progression.Internal.Domain;

namespace CastelSlayer.Modules.Progression.Internal.Services;

/// <summary>
/// The prototype's default leveling curve: reaching level <c>L+1</c> from
/// level <c>L</c> costs <c>100 * L</c> XP, so cumulative XP required for
/// level <c>L</c> is <c>100 * (L - 1) * L / 2</c> (a triangular number).
/// Deliberately simple and easy to hand-verify; real balancing is future
/// work and can swap in a different <see cref="IProgressionCurve"/> without
/// changing <see cref="LevelingService"/>.
/// </summary>
public sealed class DefaultProgressionCurve : IProgressionCurve
{
    private const long XpPerLevelStep = 100;

    public int MaxLevel { get; }

    public DefaultProgressionCurve(int maxLevel = 60)
    {
        if (maxLevel < ProgressionState.MinLevel)
        {
            throw new ArgumentOutOfRangeException(
                nameof(maxLevel), maxLevel, $"maxLevel must be >= {ProgressionState.MinLevel}.");
        }

        MaxLevel = maxLevel;
    }

    public long TotalXpRequiredForLevel(int level)
    {
        if (level < ProgressionState.MinLevel || level > MaxLevel)
        {
            throw new ArgumentOutOfRangeException(
                nameof(level), level, $"level must be between {ProgressionState.MinLevel} and {MaxLevel}.");
        }

        long stepsCompleted = level - 1;
        return XpPerLevelStep * stepsCompleted * (stepsCompleted + 1) / 2;
    }
}
