using System;
using System.Collections.Generic;
using CastelSlayer.Modules.Progression.Internal.Domain;
using CastelSlayer.Modules.Progression.Public.Events;

namespace CastelSlayer.Modules.Progression.Internal.Services;

/// <summary>
/// The single, authoritative place XP is accumulated and levels are crossed
/// (requirement 8: do not spread level/XP calculations across multiple
/// modules). Only ever called with server-side amounts computed by other
/// core systems (e.g. combat's kill-reward calculation) — this service, and
/// everything that calls it, must never accept an XP/level value supplied
/// directly by a client (requirement 7).
/// </summary>
public sealed class LevelingService
{
    private readonly IProgressionCurve _curve;

    public LevelingService(IProgressionCurve curve)
    {
        _curve = curve ?? throw new ArgumentNullException(nameof(curve));
    }

    /// <summary>
    /// Applies an XP gain to <paramref name="profile"/>, advancing zero or
    /// more levels, and returns the result. Mutates
    /// <paramref name="profile"/>'s progression state as a side effect (via
    /// its internal <c>ReplaceProgression</c>) — <paramref name="profile"/>
    /// is the one piece of mutable state this service owns changing;
    /// everything else here is pure computation.
    /// </summary>
    /// <exception cref="ArgumentOutOfRangeException">
    /// <paramref name="amount"/> is not positive. XP gains must be a
    /// positive amount; use a dedicated correction path (not this method)
    /// for any future admin/debug adjustment.
    /// </exception>
    public LevelingResult GainXp(CharacterStatsProfile profile, long amount)
    {
        ArgumentNullException.ThrowIfNull(profile);

        if (amount <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(amount), amount, "XP gained must be a positive amount.");
        }

        ProgressionState state = profile.Progression;

        if (state.Level >= _curve.MaxLevel)
        {
            // Already at the level cap: XP has nothing left to buy. Discard
            // rather than accumulating unbounded TotalXp past what any
            // level will ever require.
            return new LevelingResult(state, 0, Array.Empty<CharacterLeveledUp>());
        }

        long newTotalXp = state.TotalXp + amount;
        int newLevel = state.Level;

        while (newLevel < _curve.MaxLevel && newTotalXp >= _curve.TotalXpRequiredForLevel(newLevel + 1))
        {
            newLevel++;
        }

        if (newLevel == _curve.MaxLevel)
        {
            // Cap accumulated XP at exactly what the max level requires, so
            // TotalXp never carries an unbounded, meaningless overflow once
            // there is nowhere left to spend it.
            long capXp = _curve.TotalXpRequiredForLevel(_curve.MaxLevel);
            if (newTotalXp > capXp)
            {
                newTotalXp = capXp;
            }
        }

        var newState = new ProgressionState(newLevel, newTotalXp);
        profile.ReplaceProgression(newState);

        int levelsGained = newLevel - state.Level;
        IReadOnlyList<CharacterLeveledUp> events = levelsGained > 0
            ? new[] { new CharacterLeveledUp(profile.CharacterId, state.Level, newLevel) }
            : Array.Empty<CharacterLeveledUp>();

        return new LevelingResult(newState, levelsGained, events);
    }
}
