namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// Stable identifier of an item type (e.g. <c>"health_potion"</c>). Two stacks
/// hold "the same item" when their <see cref="ItemId"/>s are equal. This is
/// only an identifier — there is deliberately no item database behind it yet
/// (Prompt 06 scope).
/// </summary>
public sealed record ItemId
{
    public string Value { get; }

    public ItemId(string value)
    {
        ArgumentNullException.ThrowIfNull(value);

        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException("ItemId cannot be empty or whitespace.", nameof(value));
        }

        Value = value;
    }

    public override string ToString() => Value;
}
