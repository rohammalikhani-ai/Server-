namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// The minimal item model the Inventory Foundation needs: an identity and how
/// many of it fit in one stack. Not an item definition — no name, type,
/// effects, durability, etc. (all explicitly out of scope for Prompt 06).
/// </summary>
/// <param name="Id">Which item type this is.</param>
/// <param name="MaxStackSize">Largest quantity allowed in a single stack; must be at least 1.</param>
public sealed record Item(ItemId Id, int MaxStackSize)
{
    public Item
    {
        ArgumentNullException.ThrowIfNull(Id);

        if (MaxStackSize < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(MaxStackSize), MaxStackSize, "MaxStackSize must be at least 1.");
        }
    }
}
