namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// A read-only view of one slot: either empty (<see cref="Stack"/> is null) or
/// holding one <see cref="ItemStack"/>. It is a snapshot value — holding one
/// never lets a caller change the inventory; only <see cref="ItemInventory"/>'s
/// own methods can (server authority over item ownership).
/// </summary>
/// <param name="Index">Zero-based position of the slot within its inventory.</param>
/// <param name="Stack">The stack in the slot, or null when the slot is empty.</param>
public readonly record struct InventorySlot(int Index, ItemStack? Stack)
{
    public bool IsEmpty => Stack is null;
}
