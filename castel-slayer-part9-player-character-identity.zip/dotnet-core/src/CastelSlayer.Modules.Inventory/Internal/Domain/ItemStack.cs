namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// A quantity of one <see cref="Item"/>. Immutable, and always valid:
/// <c>1 &lt;= Quantity &lt;= Item.MaxStackSize</c>. An empty stack is
/// represented by the absence of a stack (an empty <see cref="InventorySlot"/>),
/// never by a zero-quantity stack.
/// </summary>
public sealed record ItemStack(Item Item, int Quantity)
{
    public ItemStack
    {
        ArgumentNullException.ThrowIfNull(Item);

        if (Quantity < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(Quantity), Quantity, "Quantity must be at least 1.");
        }

        if (Quantity > Item.MaxStackSize)
        {
            throw new ArgumentOutOfRangeException(
                nameof(Quantity), Quantity, $"Quantity cannot exceed the item's MaxStackSize ({Item.MaxStackSize}).");
        }
    }

    /// <summary>How many more of the item this stack can still take.</summary>
    public int FreeSpace => Item.MaxStackSize - Quantity;

    /// <summary>Returns a copy of this stack with a different (still validated) quantity.</summary>
    public ItemStack WithQuantity(int quantity) => new(Item, quantity);
}
