namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// Outcome of <see cref="ItemInventory.RemoveItem"/>. Removal takes only what
/// is actually present; anything asked for beyond that is reported in
/// <see cref="ShortfallQuantity"/> and never drives a stack negative.
/// </summary>
public sealed record RemoveItemResult
{
    public int RequestedQuantity { get; }
    public int RemovedQuantity { get; }

    public RemoveItemResult(int requestedQuantity, int removedQuantity)
    {
        if (requestedQuantity < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(requestedQuantity), requestedQuantity, "Requested quantity must be at least 1.");
        }

        if (removedQuantity < 0 || removedQuantity > requestedQuantity)
        {
            throw new ArgumentOutOfRangeException(nameof(removedQuantity), removedQuantity, "Removed quantity must be between 0 and the requested quantity.");
        }

        RequestedQuantity = requestedQuantity;
        RemovedQuantity = removedQuantity;
    }

    /// <summary>How much of the request could not be removed because it was not in the inventory.</summary>
    public int ShortfallQuantity => RequestedQuantity - RemovedQuantity;

    public bool IsFullyRemoved => ShortfallQuantity == 0;
}
