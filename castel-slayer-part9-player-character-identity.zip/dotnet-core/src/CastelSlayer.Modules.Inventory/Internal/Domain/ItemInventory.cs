namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// A fixed number of slots, each empty or holding one <see cref="ItemStack"/>.
/// This is the only place item quantities change: slots are private and
/// exposed only as read-only <see cref="InventorySlot"/> snapshots, so no
/// caller (client, AI, other module) can edit ownership directly — they must
/// go through <see cref="AddItem"/> / <see cref="RemoveItem"/>.
/// <para>
/// Named <c>ItemInventory</c> rather than <c>Inventory</c> on purpose: a type
/// called <c>Inventory</c> inside the <c>CastelSlayer.Modules.Inventory</c>
/// namespace makes the simple name ambiguous for every sibling module and
/// test namespace (CS0118).
/// </para>
/// <para>
/// No Minecraft, character, persistence, or networking dependency lives here.
/// Not thread-safe; the caller (a future single-threaded authority) owns
/// synchronisation.
/// </para>
/// </summary>
public sealed class ItemInventory
{
    private readonly ItemStack?[] _slots;

    /// <param name="capacity">Number of slots; must be at least 1.</param>
    public ItemInventory(int capacity)
    {
        if (capacity < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(capacity), capacity, "Capacity must be at least 1.");
        }

        _slots = new ItemStack?[capacity];
    }

    public int Capacity => _slots.Length;

    public InventorySlot GetSlot(int index)
    {
        if (index < 0 || index >= _slots.Length)
        {
            throw new ArgumentOutOfRangeException(nameof(index), index, $"Slot index must be between 0 and {_slots.Length - 1}.");
        }

        return new InventorySlot(index, _slots[index]);
    }

    /// <summary>A snapshot of every slot, in index order.</summary>
    public IReadOnlyList<InventorySlot> GetSlots()
    {
        var snapshot = new InventorySlot[_slots.Length];
        for (int i = 0; i < _slots.Length; i++)
        {
            snapshot[i] = new InventorySlot(i, _slots[i]);
        }

        return snapshot;
    }

    /// <summary>Total quantity of the given item across all slots (0 if none).</summary>
    public long CountOf(ItemId itemId)
    {
        ArgumentNullException.ThrowIfNull(itemId);

        long total = 0;
        foreach (var stack in _slots)
        {
            if (stack is not null && stack.Item.Id == itemId)
            {
                total += stack.Quantity;
            }
        }

        return total;
    }

    /// <summary>True if the inventory holds at least <paramref name="quantity"/> of the item.</summary>
    /// <exception cref="ArgumentOutOfRangeException"><paramref name="quantity"/> is less than 1.</exception>
    public bool HasItem(ItemId itemId, int quantity = 1)
    {
        ArgumentNullException.ThrowIfNull(itemId);
        RequireValidQuantity(quantity);

        return CountOf(itemId) >= quantity;
    }

    /// <summary>
    /// Adds as much of the request as fits: first tops up existing stacks of the
    /// same item (in slot order), then fills empty slots (in slot order). What
    /// does not fit is returned in <see cref="AddItemResult.RemainingQuantity"/>
    /// and is not lost — the caller still holds it.
    /// </summary>
    /// <exception cref="ArgumentOutOfRangeException"><paramref name="quantity"/> is less than 1.</exception>
    /// <exception cref="ArgumentException">
    /// The inventory already holds the same <see cref="ItemId"/> with a different
    /// <see cref="Item.MaxStackSize"/> — two conflicting definitions of one item.
    /// </exception>
    public AddItemResult AddItem(Item item, int quantity)
    {
        ArgumentNullException.ThrowIfNull(item);
        RequireValidQuantity(quantity);
        EnsureNoConflictingDefinition(item);

        int remaining = quantity;

        // Pass 1: top up existing stacks of this item.
        for (int i = 0; i < _slots.Length && remaining > 0; i++)
        {
            var stack = _slots[i];
            if (stack is null || stack.Item != item || stack.FreeSpace == 0)
            {
                continue;
            }

            int toAdd = Math.Min(stack.FreeSpace, remaining);
            _slots[i] = stack.WithQuantity(stack.Quantity + toAdd);
            remaining -= toAdd;
        }

        // Pass 2: open new stacks in empty slots.
        for (int i = 0; i < _slots.Length && remaining > 0; i++)
        {
            if (_slots[i] is not null)
            {
                continue;
            }

            int toAdd = Math.Min(item.MaxStackSize, remaining);
            _slots[i] = new ItemStack(item, toAdd);
            remaining -= toAdd;
        }

        return new AddItemResult(quantity, quantity - remaining);
    }

    /// <summary>
    /// Removes up to <paramref name="quantity"/> of the item, taking from the
    /// lowest slot index first and emptying any slot that reaches zero. If less
    /// than requested is present, only what is present is removed and the
    /// difference is reported in <see cref="RemoveItemResult.ShortfallQuantity"/>.
    /// </summary>
    /// <exception cref="ArgumentOutOfRangeException"><paramref name="quantity"/> is less than 1.</exception>
    public RemoveItemResult RemoveItem(ItemId itemId, int quantity)
    {
        ArgumentNullException.ThrowIfNull(itemId);
        RequireValidQuantity(quantity);

        int remaining = quantity;

        for (int i = 0; i < _slots.Length && remaining > 0; i++)
        {
            var stack = _slots[i];
            if (stack is null || stack.Item.Id != itemId)
            {
                continue;
            }

            if (stack.Quantity > remaining)
            {
                _slots[i] = stack.WithQuantity(stack.Quantity - remaining);
                remaining = 0;
            }
            else
            {
                remaining -= stack.Quantity;
                _slots[i] = null;
            }
        }

        return new RemoveItemResult(quantity, quantity - remaining);
    }

    private static void RequireValidQuantity(int quantity)
    {
        if (quantity < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(quantity), quantity, "Quantity must be at least 1.");
        }
    }

    private void EnsureNoConflictingDefinition(Item item)
    {
        foreach (var stack in _slots)
        {
            if (stack is not null && stack.Item.Id == item.Id && stack.Item != item)
            {
                throw new ArgumentException(
                    $"Item '{item.Id}' conflicts with the definition already in this inventory (different MaxStackSize).",
                    nameof(item));
            }
        }
    }
}
