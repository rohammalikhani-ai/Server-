namespace CastelSlayer.Modules.Inventory.Internal.Domain;

/// <summary>
/// Outcome of <see cref="ItemInventory.AddItem"/>. Whatever did not fit is
/// reported in <see cref="RemainingQuantity"/> — the caller still owns it;
/// the inventory never silently discards items.
/// </summary>
public sealed record AddItemResult
{
    public int RequestedQuantity { get; }
    public int AddedQuantity { get; }

    public AddItemResult(int requestedQuantity, int addedQuantity)
    {
        if (requestedQuantity < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(requestedQuantity), requestedQuantity, "Requested quantity must be at least 1.");
        }

        if (addedQuantity < 0 || addedQuantity > requestedQuantity)
        {
            throw new ArgumentOutOfRangeException(nameof(addedQuantity), addedQuantity, "Added quantity must be between 0 and the requested quantity.");
        }

        RequestedQuantity = requestedQuantity;
        AddedQuantity = addedQuantity;
    }

    /// <summary>The part of the request that did NOT fit and is still with the caller.</summary>
    public int RemainingQuantity => RequestedQuantity - AddedQuantity;

    public bool IsFullyAdded => RemainingQuantity == 0;
}
