# inventory (C# Core)

## Purpose

Prompt 06 Foundation: a small, server-authoritative, slot-based item
container. Nothing more — this is not the final game inventory.

## Files

```
CastelSlayer.Modules.Inventory/
├── MODULE.md
├── CastelSlayer.Modules.Inventory.csproj     no project/package references
└── Internal/Domain/
    ├── ItemId.cs            string id, non-blank
    ├── Item.cs              ItemId + MaxStackSize (>= 1) — minimal, not an item definition
    ├── ItemStack.cs         Item + Quantity, always 1..MaxStackSize
    ├── InventorySlot.cs     read-only snapshot: Index + optional ItemStack
    ├── ItemInventory.cs     fixed-capacity slots; AddItem / RemoveItem / HasItem / CountOf
    ├── AddItemResult.cs     requested / added / remaining
    └── RemoveItemResult.cs  requested / removed / shortfall
```

The aggregate is named `ItemInventory`, not `Inventory`: a type named
`Inventory` inside the `CastelSlayer.Modules.Inventory` namespace makes the
simple name ambiguous (CS0118) for sibling modules and tests.

## Behavior

- **AddItem(item, qty):** tops up existing stacks of the same item (slot
  order), then fills empty slots. Whatever does not fit comes back in
  `AddItemResult.RemainingQuantity`; the caller still holds it, nothing is lost.
- **RemoveItem(itemId, qty):** removes only what is present (lowest slot
  first) and reports `ShortfallQuantity` for the rest. Emptied slots become
  empty — a zero-quantity stack never exists. Callers that need
  all-or-nothing check `HasItem` first or test `IsFullyRemoved`.
- **HasItem(itemId, qty = 1):** true if total held across stacks >= qty.
- **Invalid input** (qty < 1, null arguments, bad index, capacity < 1) throws
  and leaves the inventory unchanged. Adding an item whose `ItemId` is already
  held with a different `MaxStackSize` throws (two conflicting definitions).

## Authority

Slots are private; callers only see `InventorySlot` snapshots. The only way
to change quantities is `AddItem`/`RemoveItem` on the authoritative instance.
Clients and AI must never be handed a mutable reference or call these from
untrusted input without server-side checks.

## Dependencies

None. No Minecraft/Fabric/Geyser/Bukkit types, no Character/Player reference,
no other module, no `CastelSlayer.Core` reference.

## Not implemented (deliberately)

Equipment, loot, trading, shop, crafting, persistence, item database, item
effects, durability, enchantments, GUI, race/class integration, networking,
inventory ownership/`CharacterId` binding, events, `Public/` contracts. Add a
`Public/Contracts` query interface only when a second module actually needs one.

## Tests

`dotnet-core/tests/CastelSlayer.Tests/Modules/Inventory/`:
`ItemStackTests` (8) and `ItemInventoryTests` (19), run by the hand-rolled
`Support/TestRunner`. Not compiled or run in the authoring environment
(no .NET SDK) — see root `CURRENT_STATE.md`.
