namespace CastelSlayer.Core.Events;

/// <summary>
/// Marker interface for every event flowing through <see cref="Contracts.IEventBus"/>.
/// C# analog of the Java <c>core.events.GameEvent</c> marker interface. Events are
/// immutable data — no behavior, no mutable fields (see DEVELOPMENT_RULES.md →
/// "Event Conventions", which applies equally to this C# Core).
/// </summary>
public interface IGameEvent
{
}
