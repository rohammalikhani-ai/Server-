using System;
using CastelSlayer.Core.Events;

namespace CastelSlayer.Core.Contracts;

/// <summary>
/// The single channel C# Core modules use to communicate without depending on
/// each other directly (DESIGN_PRINCIPLES.md rule 10). C# analog of the Java
/// <c>core.contracts.IEventBus</c>. Domain/service code (e.g.
/// <c>LevelingService</c>) does not depend on this directly — it stays a pure
/// function returning events; whatever composes it is responsible for
/// publishing the returned events to an <see cref="IEventBus"/> implementation.
/// No concrete implementation is provided yet — see
/// <c>docs/decisions/0002-csharp-core-migration-boundary.md</c> for why a
/// real (in-process or cross-runtime) bus is deferred rather than stubbed.
/// </summary>
public interface IEventBus
{
    /// <summary>
    /// Publishes an event to every current subscriber of its exact runtime type.
    /// Must never throw on behalf of a subscriber's failure.
    /// </summary>
    void Publish<TEvent>(TEvent gameEvent) where TEvent : IGameEvent;

    /// <summary>Subscribes to every event of exactly <typeparamref name="TEvent"/> published from now on.</summary>
    IDisposable Subscribe<TEvent>(Action<TEvent> handler) where TEvent : IGameEvent;
}
