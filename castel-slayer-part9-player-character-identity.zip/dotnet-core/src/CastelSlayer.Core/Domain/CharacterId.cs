using System;

namespace CastelSlayer.Core.Domain;

/// <summary>
/// Identifies a character across the C# Core / Minecraft integration boundary.
/// This is the C# analog of the existing <c>character.contracts.CharacterId</c>
/// (Java, <c>modules/character/public/contracts/CharacterId.java</c>) — same
/// underlying UUID/GUID concept, so an id minted on either side of the
/// boundary is valid on the other without translation. It is intentionally
/// redefined here rather than referenced across languages: the C# Core must
/// not depend on Java types (see <c>docs/decisions/0002-csharp-core-migration-boundary.md</c>).
/// </summary>
public readonly record struct CharacterId
{
    public Guid Value { get; }

    public CharacterId(Guid value)
    {
        if (value == Guid.Empty)
        {
            throw new ArgumentException("CharacterId cannot be an empty GUID.", nameof(value));
        }

        Value = value;
    }

    public static CharacterId Random() => new(Guid.NewGuid());

    /// <summary>
    /// Parses the canonical string form of a character id (as produced by
    /// <c>ToString()</c> here or by the Java <c>CharacterId.toString()</c>).
    /// </summary>
    public static CharacterId Parse(string value) => new(Guid.Parse(value));

    public override string ToString() => Value.ToString();
}
