using System;
using System.Collections.Generic;

namespace CastelSlayer.Tests.Support;

/// <summary>Minimal assertion helpers — the C# analog of the Java harness's <c>Assertions</c> class.</summary>
public static class Assert
{
    public static void True(bool condition, string message)
    {
        if (!condition)
        {
            throw new TestFailedException(message);
        }
    }

    public static void False(bool condition, string message) => True(!condition, message);

    public static void Equal<T>(T expected, T actual, string message)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
        {
            throw new TestFailedException($"{message} (expected {expected}, was {actual})");
        }
    }

    public static void Throws<TException>(Action action, string message) where TException : Exception
    {
        try
        {
            action();
        }
        catch (TException)
        {
            return;
        }
        catch (Exception ex)
        {
            throw new TestFailedException($"{message} (expected {typeof(TException).Name}, threw {ex.GetType().Name})");
        }

        throw new TestFailedException($"{message} (expected {typeof(TException).Name}, nothing was thrown)");
    }
}

public sealed class TestFailedException : Exception
{
    public TestFailedException(string message) : base(message)
    {
    }
}
