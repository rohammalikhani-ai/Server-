using System;

namespace CastelSlayer.Tests.Support;

/// <summary>
/// Marks a parameterless public method as a test case for
/// <see cref="TestRunner"/>. C# analog of the Java side's hand-rolled
/// <c>tests/support</c> harness (<c>@Test</c>/<c>Assertions</c>/<c>TestRunner</c>)
/// — same reason: no network access in this environment to restore a real
/// test framework (xUnit/NUnit/MSTest) via NuGet. See
/// <c>docs/decisions/0002-csharp-core-migration-boundary.md</c>.
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class TestAttribute : Attribute
{
}
