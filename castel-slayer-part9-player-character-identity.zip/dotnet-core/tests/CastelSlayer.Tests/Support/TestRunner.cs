using System;
using System.Linq;
using System.Reflection;

namespace CastelSlayer.Tests.Support;

/// <summary>
/// Discovers every public, parameterless, <see cref="TestAttribute"/>-marked
/// method on every public type in this assembly, runs each in a fresh
/// instance of its declaring type, and reports pass/fail. Entry point for
/// <c>dotnet run</c> once a real SDK is available in this environment (see
/// <c>CURRENT_STATE.md</c> — not run here yet, no network access to fetch
/// the .NET SDK).
/// </summary>
public static class TestRunner
{
    public static int Main(string[] args)
    {
        var testMethods = Assembly.GetExecutingAssembly()
            .GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.IsPublic)
            .SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .Where(m => m.GetCustomAttribute<TestAttribute>() != null)
                .Select(m => (Type: t, Method: m)))
            .OrderBy(tm => tm.Type.FullName)
            .ThenBy(tm => tm.Method.Name)
            .ToList();

        int passed = 0;
        int failed = 0;

        foreach (var (type, method) in testMethods)
        {
            string name = $"{type.Name}.{method.Name}";
            try
            {
                object instance = Activator.CreateInstance(type)!;
                method.Invoke(instance, Array.Empty<object>());
                Console.WriteLine($"PASS  {name}");
                passed++;
            }
            catch (TargetInvocationException ex) when (ex.InnerException is not null)
            {
                Console.WriteLine($"FAIL  {name}: {ex.InnerException.Message}");
                failed++;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"FAIL  {name}: {ex.Message}");
                failed++;
            }
        }

        Console.WriteLine($"\n{passed} passed, {failed} failed, {testMethods.Count} total");
        return failed == 0 ? 0 : 1;
    }
}
