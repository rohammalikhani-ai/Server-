using System;
using CastelSlayer.Modules.Inventory.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Inventory;

public sealed class ItemStackTests
{
    private static Item Potion(int maxStackSize = 10) => new(new ItemId("potion"), maxStackSize);

    [Test]
    public void ValidStackIsCreated()
    {
        var stack = new ItemStack(Potion(10), 4);

        Assert.Equal(4, stack.Quantity, "Quantity is kept");
        Assert.Equal(new ItemId("potion"), stack.Item.Id, "Item is kept");
        Assert.Equal(6, stack.FreeSpace, "FreeSpace is MaxStackSize - Quantity");
    }

    [Test]
    public void StackAtExactlyMaxStackSizeIsValid()
    {
        var stack = new ItemStack(Potion(10), 10);

        Assert.Equal(0, stack.FreeSpace, "A full stack has no free space");
    }

    [Test]
    public void ZeroQuantityIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemStack(Potion(), 0),
            "Quantity 0 is not a valid stack");
    }

    [Test]
    public void NegativeQuantityIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemStack(Potion(), -3),
            "Negative quantity is not a valid stack");
    }

    [Test]
    public void QuantityAboveMaxStackSizeIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemStack(Potion(10), 11),
            "Quantity above MaxStackSize is not a valid stack");
    }

    [Test]
    public void NullItemIsRejected()
    {
        Assert.Throws<ArgumentNullException>(
            () => new ItemStack(null!, 1),
            "A stack needs an item");
    }

    [Test]
    public void InvalidMaxStackSizeIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new Item(new ItemId("potion"), 0),
            "MaxStackSize 0 is invalid");
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new Item(new ItemId("potion"), -1),
            "Negative MaxStackSize is invalid");
    }

    [Test]
    public void BlankItemIdIsRejected()
    {
        Assert.Throws<ArgumentException>(
            () => new ItemId("   "),
            "Whitespace ItemId is invalid");
        Assert.Throws<ArgumentNullException>(
            () => new ItemId(null!),
            "Null ItemId is invalid");
    }
}
