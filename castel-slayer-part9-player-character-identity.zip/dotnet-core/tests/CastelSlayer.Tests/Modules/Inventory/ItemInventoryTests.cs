using System;
using CastelSlayer.Modules.Inventory.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Inventory;

public sealed class ItemInventoryTests
{
    private static readonly ItemId PotionId = new("potion");
    private static readonly ItemId ArrowId = new("arrow");

    private static Item Potion(int maxStackSize = 10) => new(PotionId, maxStackSize);

    private static Item Arrow(int maxStackSize = 64) => new(ArrowId, maxStackSize);

    [Test]
    public void InventoryIsCreatedWithTheGivenCapacity()
    {
        var inventory = new ItemInventory(5);

        Assert.Equal(5, inventory.Capacity, "Capacity matches the constructor argument");
        Assert.Equal(5, inventory.GetSlots().Count, "One slot per unit of capacity");
        foreach (var slot in inventory.GetSlots())
        {
            Assert.True(slot.IsEmpty, "A new inventory starts with every slot empty");
        }
    }

    [Test]
    public void ZeroOrNegativeCapacityIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new ItemInventory(0), "Capacity 0 is invalid");
        Assert.Throws<ArgumentOutOfRangeException>(() => new ItemInventory(-1), "Negative capacity is invalid");
    }

    [Test]
    public void AddItemPlacesItIntoAnEmptySlot()
    {
        var inventory = new ItemInventory(3);

        var result = inventory.AddItem(Potion(), 4);

        Assert.True(result.IsFullyAdded, "Everything fits");
        Assert.Equal(4, result.AddedQuantity, "All four were added");
        Assert.Equal(0, result.RemainingQuantity, "Nothing left over");
        Assert.Equal(4, inventory.GetSlot(0).Stack!.Quantity, "The first empty slot received the stack");
        Assert.True(inventory.GetSlot(1).IsEmpty, "No other slot was touched");
    }

    [Test]
    public void AddItemFillsAnExistingStackUpToMaxStackSize()
    {
        var inventory = new ItemInventory(3);
        inventory.AddItem(Potion(10), 6);

        var result = inventory.AddItem(Potion(10), 4);

        Assert.True(result.IsFullyAdded, "The existing stack had room for all four");
        Assert.Equal(10, inventory.GetSlot(0).Stack!.Quantity, "Existing stack is topped up to MaxStackSize");
        Assert.True(inventory.GetSlot(1).IsEmpty, "No new stack was opened while the old one had room");
    }

    [Test]
    public void AddItemTopsUpExistingStackBeforeUsingEmptySlots()
    {
        var inventory = new ItemInventory(3);
        inventory.AddItem(Potion(10), 8);

        var result = inventory.AddItem(Potion(10), 5);

        Assert.True(result.IsFullyAdded, "Everything fits");
        Assert.Equal(10, inventory.GetSlot(0).Stack!.Quantity, "The existing stack is filled first");
        Assert.Equal(3, inventory.GetSlot(1).Stack!.Quantity, "The rest goes into an empty slot");
    }

    [Test]
    public void AddItemUsesMultipleSlotsWhenNeeded()
    {
        var inventory = new ItemInventory(4);

        var result = inventory.AddItem(Potion(10), 25);

        Assert.True(result.IsFullyAdded, "Three slots are enough for 25 with max 10");
        Assert.Equal(10, inventory.GetSlot(0).Stack!.Quantity, "Slot 0 is full");
        Assert.Equal(10, inventory.GetSlot(1).Stack!.Quantity, "Slot 1 is full");
        Assert.Equal(5, inventory.GetSlot(2).Stack!.Quantity, "Slot 2 holds the rest");
        Assert.True(inventory.GetSlot(3).IsEmpty, "Slot 3 stays empty");
        Assert.Equal(25L, inventory.CountOf(PotionId), "Total is preserved");
    }

    [Test]
    public void AddItemDoesNotLoseTheOverflowWhenThereIsNotEnoughRoom()
    {
        var inventory = new ItemInventory(2);

        var result = inventory.AddItem(Potion(10), 25);

        Assert.False(result.IsFullyAdded, "Not everything fits");
        Assert.Equal(20, result.AddedQuantity, "Two full stacks were stored");
        Assert.Equal(5, result.RemainingQuantity, "The overflow is reported back to the caller");
        Assert.Equal(25, result.AddedQuantity + result.RemainingQuantity, "Added + remaining equals requested: nothing vanished");
        Assert.Equal(20L, inventory.CountOf(PotionId), "The inventory holds exactly what was reported as added");
    }

    [Test]
    public void AddItemToAFullInventoryAddsNothingAndReportsEverythingRemaining()
    {
        var inventory = new ItemInventory(1);
        inventory.AddItem(Potion(10), 10);

        var result = inventory.AddItem(Potion(10), 3);

        Assert.Equal(0, result.AddedQuantity, "Nothing was added");
        Assert.Equal(3, result.RemainingQuantity, "The whole request is reported back");
        Assert.Equal(10L, inventory.CountOf(PotionId), "The inventory is unchanged");
    }

    [Test]
    public void AddItemKeepsDifferentItemsInSeparateStacks()
    {
        var inventory = new ItemInventory(3);
        inventory.AddItem(Potion(10), 3);

        inventory.AddItem(Arrow(64), 20);

        Assert.Equal(3L, inventory.CountOf(PotionId), "Potions are untouched");
        Assert.Equal(20L, inventory.CountOf(ArrowId), "Arrows got their own stack");
        Assert.Equal(ArrowId, inventory.GetSlot(1).Stack!.Item.Id, "Arrows opened slot 1 rather than merging into potions");
    }

    [Test]
    public void AddItemRejectsInvalidQuantity()
    {
        var inventory = new ItemInventory(2);

        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.AddItem(Potion(), 0), "Adding 0 is rejected");
        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.AddItem(Potion(), -2), "Adding a negative amount is rejected");
        Assert.Throws<ArgumentNullException>(() => inventory.AddItem(null!, 1), "Adding a null item is rejected");
        Assert.Equal(0L, inventory.CountOf(PotionId), "Rejected calls leave the inventory unchanged");
    }

    [Test]
    public void AddItemRejectsAConflictingDefinitionOfTheSameItemId()
    {
        var inventory = new ItemInventory(3);
        inventory.AddItem(Potion(10), 5);

        Assert.Throws<ArgumentException>(
            () => inventory.AddItem(Potion(20), 5),
            "The same ItemId with a different MaxStackSize is a conflicting definition");
        Assert.Equal(5L, inventory.CountOf(PotionId), "The rejected add changed nothing");
    }

    [Test]
    public void RemoveItemReducesTheCorrectAmount()
    {
        var inventory = new ItemInventory(3);
        inventory.AddItem(Potion(10), 25);

        var result = inventory.RemoveItem(PotionId, 12);

        Assert.True(result.IsFullyRemoved, "There was enough to remove");
        Assert.Equal(12, result.RemovedQuantity, "Exactly the requested amount was removed");
        Assert.Equal(13L, inventory.CountOf(PotionId), "25 - 12 = 13 remain");
        Assert.True(inventory.GetSlot(0).IsEmpty, "Slot 0 (10) was emptied first");
        Assert.Equal(8, inventory.GetSlot(1).Stack!.Quantity, "Slot 1 was reduced from 10 to 8");
        Assert.Equal(5, inventory.GetSlot(2).Stack!.Quantity, "Slot 2 is untouched");
    }

    [Test]
    public void RemovingAStackCompletelyEmptiesItsSlot()
    {
        var inventory = new ItemInventory(2);
        inventory.AddItem(Potion(10), 4);

        var result = inventory.RemoveItem(PotionId, 4);

        Assert.True(result.IsFullyRemoved, "The whole stack was removed");
        Assert.True(inventory.GetSlot(0).IsEmpty, "A zero-quantity stack is never left behind; the slot is empty");
        Assert.False(inventory.HasItem(PotionId), "The item is gone");
    }

    [Test]
    public void RemoveItemMoreThanAvailableRemovesOnlyWhatExistsAndStaysValid()
    {
        var inventory = new ItemInventory(2);
        inventory.AddItem(Potion(10), 7);

        var result = inventory.RemoveItem(PotionId, 20);

        Assert.False(result.IsFullyRemoved, "The request could not be fully satisfied");
        Assert.Equal(7, result.RemovedQuantity, "Only the 7 that existed were removed");
        Assert.Equal(13, result.ShortfallQuantity, "The shortfall is reported");
        Assert.Equal(0L, inventory.CountOf(PotionId), "Nothing is left");
        foreach (var slot in inventory.GetSlots())
        {
            Assert.True(slot.IsEmpty, "Every slot is a valid empty slot, never a negative or zero stack");
        }
    }

    [Test]
    public void RemoveItemOfAnAbsentItemRemovesNothing()
    {
        var inventory = new ItemInventory(2);
        inventory.AddItem(Arrow(64), 5);

        var result = inventory.RemoveItem(PotionId, 1);

        Assert.Equal(0, result.RemovedQuantity, "There were no potions to remove");
        Assert.Equal(1, result.ShortfallQuantity, "The whole request is a shortfall");
        Assert.Equal(5L, inventory.CountOf(ArrowId), "Other items are unaffected");
    }

    [Test]
    public void RemoveItemRejectsInvalidQuantity()
    {
        var inventory = new ItemInventory(2);
        inventory.AddItem(Potion(10), 5);

        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.RemoveItem(PotionId, 0), "Removing 0 is rejected");
        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.RemoveItem(PotionId, -1), "Removing a negative amount is rejected");
        Assert.Throws<ArgumentNullException>(() => inventory.RemoveItem(null!, 1), "Removing a null item id is rejected");
        Assert.Equal(5L, inventory.CountOf(PotionId), "Rejected calls leave the inventory unchanged");
    }

    [Test]
    public void HasItemReportsWhetherEnoughIsPresentAcrossStacks()
    {
        var inventory = new ItemInventory(3);
        inventory.AddItem(Potion(10), 15);

        Assert.True(inventory.HasItem(PotionId), "Default quantity is 1");
        Assert.True(inventory.HasItem(PotionId, 15), "Exactly the held amount counts, even split over two stacks");
        Assert.False(inventory.HasItem(PotionId, 16), "One more than held does not");
        Assert.False(inventory.HasItem(ArrowId), "An item that is not present is not held");
    }

    [Test]
    public void HasItemRejectsInvalidQuantity()
    {
        var inventory = new ItemInventory(1);

        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.HasItem(PotionId, 0), "Checking for 0 is rejected");
        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.HasItem(PotionId, -1), "Checking for a negative amount is rejected");
    }

    [Test]
    public void GetSlotRejectsAnOutOfRangeIndex()
    {
        var inventory = new ItemInventory(2);

        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.GetSlot(-1), "Negative index is rejected");
        Assert.Throws<ArgumentOutOfRangeException>(() => inventory.GetSlot(2), "Index == Capacity is rejected");
    }
}
