using System.Collections.Generic;
using CastelSlayer.Modules.Progression.Internal.Domain;
using CastelSlayer.Modules.Progression.Internal.Services;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Progression;

public sealed class DerivedStatCalculatorTests
{
    [Test]
    public void DerivedStatsAreComputedFromBaseAttributesWithNoModifiers()
    {
        var attributes = new CharacterAttributes(new Dictionary<AttributeType, int>
        {
            [AttributeType.Strength] = 10,
            [AttributeType.Dexterity] = 4,
            [AttributeType.Intelligence] = 6,
            [AttributeType.Vitality] = 8,
            [AttributeType.Wisdom] = 2,
            [AttributeType.Luck] = 3
        });

        var derived = new DerivedStatCalculator().Calculate(attributes);

        Assert.Equal(50 + 8 * 10 + 10 * 2, derived[DerivedStatType.MaxHealth], "MaxHealth");
        Assert.Equal(20 + 6 * 8 + 2 * 4, derived[DerivedStatType.MaxMana], "MaxMana");
        Assert.Equal(10 * 2 + 4, derived[DerivedStatType.PhysicalPower], "PhysicalPower");
        Assert.Equal(6 * 2 + 2, derived[DerivedStatType.MagicPower], "MagicPower");
        Assert.Equal(8 + 10 / 2, derived[DerivedStatType.Defense], "Defense");
        Assert.Equal(4 + 3 / 2, derived[DerivedStatType.Speed], "Speed");
    }

    [Test]
    public void DerivedStatsReflectActiveModifiers()
    {
        var attributes = new CharacterAttributes(new Dictionary<AttributeType, int>
        {
            [AttributeType.Strength] = 10,
            [AttributeType.Dexterity] = 10,
            [AttributeType.Intelligence] = 10,
            [AttributeType.Vitality] = 10,
            [AttributeType.Wisdom] = 10,
            [AttributeType.Luck] = 10
        });
        attributes.AddModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.Strength, ModifierOperation.Flat, 10));

        var baseline = new DerivedStatCalculator().Calculate(attributes);

        // Strength effective value is now 20 instead of 10, so PhysicalPower
        // (2*Strength + Dexterity) must reflect the modifier, not the base value.
        Assert.Equal(20 * 2 + 10, baseline[DerivedStatType.PhysicalPower], "PhysicalPower reflects modifier");
    }

    [Test]
    public void DerivedStatsAreNeverNegative()
    {
        var attributes = new CharacterAttributes(new Dictionary<AttributeType, int>
        {
            [AttributeType.Strength] = 0,
            [AttributeType.Dexterity] = 0,
            [AttributeType.Intelligence] = 0,
            [AttributeType.Vitality] = 0,
            [AttributeType.Wisdom] = 0,
            [AttributeType.Luck] = 0
        });

        var derived = new DerivedStatCalculator().Calculate(attributes);

        foreach (var kvp in derived)
        {
            Assert.True(kvp.Value >= 0, $"{kvp.Key} must not be negative, was {kvp.Value}");
        }
    }
}
