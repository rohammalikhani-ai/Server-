using System;
using System.Collections.Generic;
using CastelSlayer.Core.Domain;
using CastelSlayer.Modules.Progression.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Progression;

public sealed class CharacterStatsProfileTests
{
    private static CharacterAttributes NewAttributes() => new(new Dictionary<AttributeType, int>
    {
        [AttributeType.Strength] = 5,
        [AttributeType.Dexterity] = 5,
        [AttributeType.Intelligence] = 5,
        [AttributeType.Vitality] = 5,
        [AttributeType.Wisdom] = 5,
        [AttributeType.Luck] = 5
    });

    [Test]
    public void CreateNewStartsAtInitialProgressionState()
    {
        var profile = CharacterStatsProfile.CreateNew(CharacterId.Random(), NewAttributes());

        Assert.Equal(ProgressionState.Initial, profile.Progression, "CreateNew starts at ProgressionState.Initial");
    }

    [Test]
    public void ReconstituteUsesTheSuppliedProgressionState()
    {
        var characterId = CharacterId.Random();
        var savedState = new ProgressionState(12, 4500);

        var profile = CharacterStatsProfile.Reconstitute(characterId, NewAttributes(), savedState);

        Assert.Equal(characterId, profile.CharacterId, "CharacterId round-trips through Reconstitute");
        Assert.Equal(savedState, profile.Progression, "Reconstitute preserves the supplied progression state");
    }

    [Test]
    public void NullAttributesAreRejected()
    {
        Assert.Throws<ArgumentNullException>(
            () => CharacterStatsProfile.CreateNew(CharacterId.Random(), null!),
            "Null attributes should throw");
    }

    [Test]
    public void EmptyCharacterIdIsRejected()
    {
        Assert.Throws<ArgumentException>(
            () => new CharacterId(Guid.Empty),
            "An empty GUID is not a valid CharacterId");
    }
}
