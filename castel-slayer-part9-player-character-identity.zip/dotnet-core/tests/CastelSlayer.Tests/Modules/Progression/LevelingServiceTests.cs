using System;
using System.Collections.Generic;
using CastelSlayer.Core.Domain;
using CastelSlayer.Modules.Progression.Internal.Domain;
using CastelSlayer.Modules.Progression.Internal.Services;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Progression;

public sealed class LevelingServiceTests
{
    private static CharacterAttributes NewAttributes() => new(new Dictionary<AttributeType, int>
    {
        [AttributeType.Strength] = 5,
        [AttributeType.Dexterity] = 5,
        [AttributeType.Intelligence] = 5,
        [AttributeType.Vitality] = 5,
        [AttributeType.Wisdom] = 5,
        [AttributeType.Luck] = 5
    });

    private static CharacterStatsProfile NewProfile() =>
        CharacterStatsProfile.CreateNew(CharacterId.Random(), NewAttributes());

    private static LevelingService NewService(int maxLevel = 60) =>
        new(new DefaultProgressionCurve(maxLevel));

    [Test]
    public void NewCharacterStartsAtLevelOneWithZeroXp()
    {
        var profile = NewProfile();
        Assert.Equal(1, profile.Progression.Level, "Initial level");
        Assert.Equal(0L, profile.Progression.TotalXp, "Initial XP");
    }

    [Test]
    public void GainingXpBelowNextLevelThresholdDoesNotLevelUp()
    {
        var profile = NewProfile();
        var service = NewService();

        // Level 1 -> 2 costs 100 XP (DefaultProgressionCurve step 1).
        var result = service.GainXp(profile, 50);

        Assert.Equal(1, result.NewState.Level, "Level after sub-threshold XP gain");
        Assert.Equal(50L, result.NewState.TotalXp, "TotalXp after sub-threshold XP gain");
        Assert.Equal(0, result.LevelsGained, "LevelsGained after sub-threshold XP gain");
        Assert.Equal(0, result.Events.Count, "No level-up event should be published");
    }

    [Test]
    public void InvalidXpAmountIsRejected()
    {
        var profile = NewProfile();
        var service = NewService();

        Assert.Throws<ArgumentOutOfRangeException>(
            () => service.GainXp(profile, 0),
            "Gaining zero XP should throw");
        Assert.Throws<ArgumentOutOfRangeException>(
            () => service.GainXp(profile, -10),
            "Gaining negative XP should throw");
    }

    [Test]
    public void ExactThresholdXpTriggersOneLevelUp()
    {
        var profile = NewProfile();
        var service = NewService();

        // Exactly the cost of level 1 -> 2.
        var result = service.GainXp(profile, 100);

        Assert.Equal(2, result.NewState.Level, "Level after exact-threshold XP gain");
        Assert.Equal(1, result.LevelsGained, "LevelsGained after exact-threshold XP gain");
        Assert.Equal(1, result.Events.Count, "One level-up event expected");
        Assert.Equal(1, result.Events[0].FromLevel, "Event FromLevel");
        Assert.Equal(2, result.Events[0].ToLevel, "Event ToLevel");
    }

    [Test]
    public void OneXpBelowThresholdDoesNotLevelUp()
    {
        var profile = NewProfile();
        var service = NewService();

        var result = service.GainXp(profile, 99);

        Assert.Equal(1, result.NewState.Level, "Level one XP below threshold");
        Assert.Equal(0, result.LevelsGained, "LevelsGained one XP below threshold");
    }

    [Test]
    public void LargeXpGainCrossesMultipleLevels()
    {
        var profile = NewProfile();
        var service = NewService();

        // Level 1->2 costs 100, 2->3 costs 200 (cumulative 300), 3->4 costs 300 (cumulative 600).
        var result = service.GainXp(profile, 650);

        Assert.Equal(4, result.NewState.Level, "Level after large XP gain crossing several thresholds");
        Assert.Equal(3, result.LevelsGained, "LevelsGained after large XP gain");
        Assert.Equal(1, result.Events.Count, "A multi-level gain still publishes a single summarizing event");
        Assert.Equal(1, result.Events[0].FromLevel, "Multi-level event FromLevel");
        Assert.Equal(4, result.Events[0].ToLevel, "Multi-level event ToLevel");
        Assert.Equal(650L, result.NewState.TotalXp, "TotalXp is preserved exactly when below the level cap");
    }

    [Test]
    public void XpGainAtMaxLevelIsDiscarded()
    {
        var profile = NewProfile();
        var service = NewService(maxLevel: 2);

        service.GainXp(profile, 100); // now at level 2 == max level
        var result = service.GainXp(profile, 9999);

        Assert.Equal(2, result.NewState.Level, "Level stays at the cap");
        Assert.Equal(0, result.LevelsGained, "No further levels can be gained at the cap");
        Assert.Equal(0, result.Events.Count, "No level-up event once already at max level");
        Assert.Equal(100L, result.NewState.TotalXp, "TotalXp does not grow once at max level");
    }

    [Test]
    public void XpGainThatWouldCrossIntoMaxLevelCapsTotalXp()
    {
        var profile = NewProfile();
        var service = NewService(maxLevel: 2);

        // Level 1 -> 2 costs exactly 100; gaining far more than that in one
        // call must still land exactly at the level-2 requirement, not carry
        // the extra 900 forward with nowhere to spend it.
        var result = service.GainXp(profile, 1000);

        Assert.Equal(2, result.NewState.Level, "Level caps at MaxLevel");
        Assert.Equal(100L, result.NewState.TotalXp, "TotalXp is capped at the max level's requirement");
    }

    [Test]
    public void NullProfileIsRejected()
    {
        var service = NewService();
        Assert.Throws<ArgumentNullException>(() => service.GainXp(null!, 10), "Null profile should throw");
    }
}
