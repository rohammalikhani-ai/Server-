using System;
using System.Collections.Generic;
using CastelSlayer.Modules.Progression.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Progression;

public sealed class CharacterAttributesTests
{
    private static IReadOnlyDictionary<AttributeType, int> AllTens() => new Dictionary<AttributeType, int>
    {
        [AttributeType.Strength] = 10,
        [AttributeType.Dexterity] = 10,
        [AttributeType.Intelligence] = 10,
        [AttributeType.Vitality] = 10,
        [AttributeType.Wisdom] = 10,
        [AttributeType.Luck] = 10
    };

    [Test]
    public void InitialBaseValuesAreStoredExactly()
    {
        var attributes = new CharacterAttributes(AllTens());
        Assert.Equal(10, attributes.GetBaseValue(AttributeType.Strength), "Strength base value");
        Assert.Equal(10, attributes.GetBaseValue(AttributeType.Luck), "Luck base value");
    }

    [Test]
    public void MissingAttributeTypeIsRejected()
    {
        var incomplete = new Dictionary<AttributeType, int>
        {
            [AttributeType.Strength] = 10
            // every other AttributeType intentionally omitted
        };

        Assert.Throws<ArgumentException>(
            () => new CharacterAttributes(incomplete),
            "Constructing with a missing attribute type should throw");
    }

    [Test]
    public void OutOfRangeBaseValueIsRejected()
    {
        var values = new Dictionary<AttributeType, int>(AllTens())
        {
            [AttributeType.Strength] = -1
        };

        Assert.Throws<ArgumentOutOfRangeException>(
            () => new CharacterAttributes(values),
            "Negative base value should throw");
    }

    [Test]
    public void EffectiveValueWithNoModifiersEqualsBaseValue()
    {
        var attributes = new CharacterAttributes(AllTens());
        Assert.Equal(10, attributes.GetEffectiveValue(AttributeType.Strength), "Effective value with no modifiers");
    }

    [Test]
    public void FlatModifierIsAddedToBaseValue()
    {
        var attributes = new CharacterAttributes(AllTens());
        attributes.AddModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.Strength, ModifierOperation.Flat, 5));

        Assert.Equal(15, attributes.GetEffectiveValue(AttributeType.Strength), "Strength after +5 flat modifier");
    }

    [Test]
    public void PercentModifierAppliesAfterFlatModifiers()
    {
        var attributes = new CharacterAttributes(AllTens());
        attributes.AddModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.Strength, ModifierOperation.Flat, 10));
        attributes.AddModifier(new AttributeModifier("m2", "buff:might", AttributeType.Strength, ModifierOperation.PercentAdditive, 50));

        // base 10 + flat 10 = 20, then *1.5 = 30
        Assert.Equal(30, attributes.GetEffectiveValue(AttributeType.Strength), "Strength after flat +10 then +50%");
    }

    [Test]
    public void EffectiveValueNeverGoesNegative()
    {
        var attributes = new CharacterAttributes(AllTens());
        attributes.AddModifier(new AttributeModifier("m1", "curse:weaken", AttributeType.Strength, ModifierOperation.Flat, -1000));

        Assert.Equal(0, attributes.GetEffectiveValue(AttributeType.Strength), "Effective value floors at zero");
    }

    [Test]
    public void DuplicateModifierKeyIsRejected()
    {
        var attributes = new CharacterAttributes(AllTens());
        attributes.AddModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.Strength, ModifierOperation.Flat, 5));

        Assert.Throws<InvalidOperationException>(
            () => attributes.AddModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.Dexterity, ModifierOperation.Flat, 1)),
            "Adding a modifier with an already-active source+id should throw");
    }

    [Test]
    public void RemovingUnknownModifierIsRejected()
    {
        var attributes = new CharacterAttributes(AllTens());

        Assert.Throws<InvalidOperationException>(
            () => attributes.RemoveModifier("equipment:sword", "m1"),
            "Removing a modifier that was never added should throw");
    }

    [Test]
    public void RemovedModifierNoLongerAffectsEffectiveValue()
    {
        var attributes = new CharacterAttributes(AllTens());
        attributes.AddModifier(new AttributeModifier("m1", "equipment:sword", AttributeType.Strength, ModifierOperation.Flat, 5));
        attributes.RemoveModifier("equipment:sword", "m1");

        Assert.Equal(10, attributes.GetEffectiveValue(AttributeType.Strength), "Strength after modifier removed");
    }
}
