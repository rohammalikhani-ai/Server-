using System;
using System.Collections.Generic;
using CastelSlayer.Modules.Equipment.Internal.Domain;
using CastelSlayer.Modules.Inventory.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Equipment;

public sealed class ItemEquipmentTests
{
    private static ItemDefinition Helmet(string id = "iron_helmet") =>
        new(new ItemId(id), "Iron Helmet", ItemCategory.Armor, slot: EquipmentSlot.Head);

    private static ItemDefinition Chestplate(string id = "iron_chestplate") =>
        new(new ItemId(id), "Iron Chestplate", ItemCategory.Armor, slot: EquipmentSlot.Chest);

    private static ItemDefinition Sword(string id = "iron_sword") =>
        new(new ItemId(id), "Iron Sword", ItemCategory.Weapon, slot: EquipmentSlot.MainHand);

    private static ItemDefinition Shield(string id = "wooden_shield") =>
        new(new ItemId(id), "Wooden Shield", ItemCategory.Armor, slot: EquipmentSlot.OffHand);

    private static ItemDefinition Potion() =>
        new(new ItemId("health_potion"), "Health Potion", ItemCategory.Consumable, maxStackSize: 20);

    // ---- initial state -------------------------------------------------

    [Test]
    public void NewEquipmentIsEmptyInEverySlot()
    {
        var equipment = new ItemEquipment();

        Assert.Equal(0, equipment.EquippedCount, "Nothing equipped yet");
        foreach (var slot in EquipmentSlots.All)
        {
            Assert.False(equipment.IsSlotOccupied(slot), slot + " starts empty");
            Assert.True(equipment.GetEquipped(slot) is null, slot + " has no item");
        }
    }

    // ---- equip: success ------------------------------------------------

    [Test]
    public void EquipEquippableItemInItsSlotSucceeds()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet();

        var result = equipment.Equip(helmet, EquipmentSlot.Head);

        Assert.True(result.IsSuccess, "Equip succeeds");
        Assert.Equal(EquipStatus.Success, result.Status, "Status is Success");
        Assert.Equal(helmet, result.Item, "Result carries the item");
        Assert.Equal(EquipmentSlot.Head, result.RequestedSlot, "Result carries the slot");
        Assert.True(result.BlockingItem is null, "Nothing blocked it");
        Assert.Equal(helmet, equipment.GetEquipped(EquipmentSlot.Head)!, "Slot now holds the helmet");
        Assert.True(equipment.IsSlotOccupied(EquipmentSlot.Head), "Slot is occupied");
        Assert.True(equipment.IsEquipped(helmet.Id), "Item id reports equipped");
        Assert.Equal(1, equipment.EquippedCount, "One item equipped");
    }

    [Test]
    public void EquipIntoEachSlotSucceeds()
    {
        var equipment = new ItemEquipment();
        var items = new List<ItemDefinition>();
        foreach (var slot in EquipmentSlots.All)
        {
            items.Add(new ItemDefinition(new ItemId("item_" + slot), "Item " + slot, ItemCategory.Armor, slot: slot));
        }

        foreach (var item in items)
        {
            Assert.True(equipment.Equip(item, item.Slot!.Value).IsSuccess, item.Name + " equips");
        }

        Assert.Equal(EquipmentSlots.All.Count, equipment.EquippedCount, "Every slot is filled");
    }

    // ---- equip: failures -----------------------------------------------

    [Test]
    public void EquipNonEquippableItemIsRefused()
    {
        var equipment = new ItemEquipment();
        var potion = Potion();

        var result = equipment.Equip(potion, EquipmentSlot.MainHand);

        Assert.False(result.IsSuccess, "A potion cannot be equipped");
        Assert.Equal(EquipStatus.NotEquippable, result.Status, "Status is NotEquippable");
        Assert.Equal(potion, result.Item, "Result still references the item");
        Assert.Equal(0, equipment.EquippedCount, "Nothing was equipped");
        Assert.False(equipment.IsEquipped(potion.Id), "Potion is not equipped");
    }

    [Test]
    public void NotEquippableIsReportedEvenWhenTheSlotIsInvalidToo()
    {
        var equipment = new ItemEquipment();

        var result = equipment.Equip(Potion(), (EquipmentSlot)99);

        Assert.Equal(EquipStatus.NotEquippable, result.Status, "Item property is checked before the slot");
    }

    [Test]
    public void EquipIntoInvalidSlotIsRefused()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet();

        var undeclared = equipment.Equip(helmet, (EquipmentSlot)99);
        var defaultSlot = equipment.Equip(helmet, default);

        Assert.Equal(EquipStatus.InvalidSlot, undeclared.Status, "Out-of-range slot is InvalidSlot");
        Assert.Equal((EquipmentSlot)99, undeclared.RequestedSlot, "Requested slot value is reported as given");
        Assert.Equal(EquipStatus.InvalidSlot, defaultSlot.Status, "default(EquipmentSlot) is InvalidSlot");
        Assert.Equal(0, equipment.EquippedCount, "Nothing was equipped");
    }

    [Test]
    public void EquipIntoIncompatibleSlotIsRefused()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet();

        var result = equipment.Equip(helmet, EquipmentSlot.Feet);

        Assert.False(result.IsSuccess, "A helmet does not go on the feet");
        Assert.Equal(EquipStatus.IncompatibleSlot, result.Status, "Status is IncompatibleSlot");
        Assert.Equal(EquipmentSlot.Feet, result.RequestedSlot, "Requested slot is reported");
        Assert.Equal(0, equipment.EquippedCount, "Nothing was equipped");
        Assert.False(equipment.IsSlotOccupied(EquipmentSlot.Feet), "Feet stay empty");
        Assert.False(equipment.IsSlotOccupied(EquipmentSlot.Head), "Head stays empty too");
    }

    [Test]
    public void EquipIntoOccupiedSlotIsRefusedAndKeepsTheOriginalItem()
    {
        var equipment = new ItemEquipment();
        var first = Helmet("iron_helmet");
        var second = Helmet("gold_helmet");
        equipment.Equip(first, EquipmentSlot.Head);

        var result = equipment.Equip(second, EquipmentSlot.Head);

        Assert.False(result.IsSuccess, "Occupied slot refuses a second item");
        Assert.Equal(EquipStatus.SlotOccupied, result.Status, "Status is SlotOccupied");
        Assert.Equal(first, result.BlockingItem!, "Result names the occupant");
        Assert.Equal(second, result.Item, "The new item is still the caller's");
        Assert.Equal(first, equipment.GetEquipped(EquipmentSlot.Head)!, "The original item is untouched");
        Assert.False(equipment.IsEquipped(second.Id), "The refused item is not equipped");
        Assert.Equal(1, equipment.EquippedCount, "Still one item equipped");
    }

    [Test]
    public void EquippingTheSameItemTwiceIsRefusedAsAlreadyEquipped()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet();
        equipment.Equip(helmet, EquipmentSlot.Head);

        var result = equipment.Equip(helmet, EquipmentSlot.Head);

        Assert.Equal(EquipStatus.AlreadyEquipped, result.Status, "Same item id twice is AlreadyEquipped");
        Assert.Equal(helmet, result.BlockingItem!, "Result names the equipped copy");
        Assert.Equal(1, equipment.EquippedCount, "Still one item equipped");
    }

    [Test]
    public void ConflictingDefinitionWithSameIdCannotSneakIntoAnotherSlot()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet("relic");
        var sameIdOtherSlot = new ItemDefinition(new ItemId("relic"), "Relic Plate", ItemCategory.Armor, slot: EquipmentSlot.Chest);
        equipment.Equip(helmet, EquipmentSlot.Head);

        var result = equipment.Equip(sameIdOtherSlot, EquipmentSlot.Chest);

        Assert.Equal(EquipStatus.AlreadyEquipped, result.Status, "One ItemId can be equipped at most once");
        Assert.False(equipment.IsSlotOccupied(EquipmentSlot.Chest), "Chest stays empty");
        Assert.Equal(1, equipment.EquippedCount, "Still one item equipped");
    }

    [Test]
    public void NullItemIsRejectedWithAnException()
    {
        var equipment = new ItemEquipment();

        Assert.Throws<ArgumentNullException>(
            () => equipment.Equip(null!, EquipmentSlot.Head),
            "A null item is a programming error, not a gameplay outcome");
    }

    // ---- unequip -------------------------------------------------------

    [Test]
    public void UnequipReturnsTheEquippedItemAndEmptiesTheSlot()
    {
        var equipment = new ItemEquipment();
        var sword = Sword();
        equipment.Equip(sword, EquipmentSlot.MainHand);

        var result = equipment.Unequip(EquipmentSlot.MainHand);

        Assert.True(result.IsSuccess, "Unequip succeeds");
        Assert.Equal(UnequipStatus.Success, result.Status, "Status is Success");
        Assert.Equal(sword, result.Item!, "The item is handed back, not destroyed");
        Assert.Equal(EquipmentSlot.MainHand, result.RequestedSlot, "Slot is reported");
        Assert.False(equipment.IsSlotOccupied(EquipmentSlot.MainHand), "Slot is now empty");
        Assert.False(equipment.IsEquipped(sword.Id), "Item is no longer equipped");
        Assert.Equal(0, equipment.EquippedCount, "Nothing equipped");
    }

    [Test]
    public void UnequipEmptySlotIsRefused()
    {
        var equipment = new ItemEquipment();

        var result = equipment.Unequip(EquipmentSlot.Legs);

        Assert.False(result.IsSuccess, "Nothing to unequip");
        Assert.Equal(UnequipStatus.SlotEmpty, result.Status, "Status is SlotEmpty");
        Assert.True(result.Item is null, "No item is returned");
    }

    [Test]
    public void UnequipInvalidSlotIsRefused()
    {
        var equipment = new ItemEquipment();
        equipment.Equip(Helmet(), EquipmentSlot.Head);

        var result = equipment.Unequip((EquipmentSlot)42);

        Assert.Equal(UnequipStatus.InvalidSlot, result.Status, "Status is InvalidSlot");
        Assert.Equal((EquipmentSlot)42, result.RequestedSlot, "Requested slot value is reported as given");
        Assert.True(result.Item is null, "No item is returned");
        Assert.Equal(1, equipment.EquippedCount, "Existing equipment is untouched");
    }

    [Test]
    public void UnequipTwiceSecondCallReportsEmptySlot()
    {
        var equipment = new ItemEquipment();
        equipment.Equip(Helmet(), EquipmentSlot.Head);

        var first = equipment.Unequip(EquipmentSlot.Head);
        var second = equipment.Unequip(EquipmentSlot.Head);

        Assert.True(first.IsSuccess, "First unequip succeeds");
        Assert.Equal(UnequipStatus.SlotEmpty, second.Status, "The item cannot be unequipped twice");
    }

    [Test]
    public void SlotCanBeRefilledAfterUnequip()
    {
        var equipment = new ItemEquipment();
        var old = Helmet("iron_helmet");
        var replacement = Helmet("gold_helmet");
        equipment.Equip(old, EquipmentSlot.Head);
        equipment.Unequip(EquipmentSlot.Head);

        var result = equipment.Equip(replacement, EquipmentSlot.Head);

        Assert.True(result.IsSuccess, "Explicit unequip then equip replaces the item");
        Assert.Equal(replacement, equipment.GetEquipped(EquipmentSlot.Head)!, "New item is in the slot");
        Assert.False(equipment.IsEquipped(old.Id), "Old item is gone");
    }

    [Test]
    public void ItemCanBeReEquippedAfterUnequip()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet();
        equipment.Equip(helmet, EquipmentSlot.Head);
        equipment.Unequip(EquipmentSlot.Head);

        var result = equipment.Equip(helmet, EquipmentSlot.Head);

        Assert.True(result.IsSuccess, "AlreadyEquipped no longer applies once unequipped");
    }

    // ---- multiple slots ------------------------------------------------

    [Test]
    public void SlotsAreIndependentOfEachOther()
    {
        var equipment = new ItemEquipment();
        var helmet = Helmet();
        var chest = Chestplate();
        var sword = Sword();
        equipment.Equip(helmet, EquipmentSlot.Head);
        equipment.Equip(chest, EquipmentSlot.Chest);
        equipment.Equip(sword, EquipmentSlot.MainHand);

        Assert.Equal(3, equipment.EquippedCount, "Three items equipped");
        Assert.Equal(helmet, equipment.GetEquipped(EquipmentSlot.Head)!, "Head holds the helmet");
        Assert.Equal(chest, equipment.GetEquipped(EquipmentSlot.Chest)!, "Chest holds the chestplate");
        Assert.Equal(sword, equipment.GetEquipped(EquipmentSlot.MainHand)!, "MainHand holds the sword");
        Assert.False(equipment.IsSlotOccupied(EquipmentSlot.OffHand), "OffHand is untouched");

        equipment.Unequip(EquipmentSlot.Chest);

        Assert.Equal(2, equipment.EquippedCount, "Only the chestplate left");
        Assert.True(equipment.IsEquipped(helmet.Id), "Helmet unaffected by unequipping the chestplate");
        Assert.True(equipment.IsEquipped(sword.Id), "Sword unaffected by unequipping the chestplate");
    }

    [Test]
    public void MainHandAndOffHandHoldDifferentItems()
    {
        var equipment = new ItemEquipment();

        Assert.True(equipment.Equip(Sword(), EquipmentSlot.MainHand).IsSuccess, "Sword in main hand");
        Assert.True(equipment.Equip(Shield(), EquipmentSlot.OffHand).IsSuccess, "Shield in off hand");
        Assert.Equal(2, equipment.EquippedCount, "Both hands are used");
    }

    [Test]
    public void RefusalInOneSlotDoesNotDisturbOtherSlots()
    {
        var equipment = new ItemEquipment();
        equipment.Equip(Helmet(), EquipmentSlot.Head);
        equipment.Equip(Sword(), EquipmentSlot.MainHand);

        equipment.Equip(Helmet("gold_helmet"), EquipmentSlot.Head);
        equipment.Equip(Potion(), EquipmentSlot.Chest);
        equipment.Unequip(EquipmentSlot.Feet);

        Assert.Equal(2, equipment.EquippedCount, "Refusals changed nothing");
        Assert.Equal(new ItemId("iron_helmet"), equipment.GetEquipped(EquipmentSlot.Head)!.Id, "Original helmet kept");
        Assert.Equal(new ItemId("iron_sword"), equipment.GetEquipped(EquipmentSlot.MainHand)!.Id, "Sword kept");
    }

    // ---- read-only state -----------------------------------------------

    [Test]
    public void GetSlotsListsEverySlotInOrderIncludingEmptyOnes()
    {
        var equipment = new ItemEquipment();
        var chest = Chestplate();
        equipment.Equip(chest, EquipmentSlot.Chest);

        var slots = equipment.GetSlots();

        Assert.Equal(EquipmentSlots.All.Count, slots.Count, "One entry per declared slot");
        for (int i = 0; i < slots.Count; i++)
        {
            Assert.Equal(EquipmentSlots.All[i], slots[i].Slot, "Entries follow EquipmentSlots.All order");
        }

        Assert.True(slots[0].IsEmpty, "Head is empty");
        Assert.False(slots[1].IsEmpty, "Chest is filled");
        Assert.Equal(chest, slots[1].Item!, "Chest snapshot holds the chestplate");
    }

    [Test]
    public void SnapshotCannotBeUsedToModifyEquipment()
    {
        var equipment = new ItemEquipment();
        var slots = equipment.GetSlots();

        Assert.Throws<NotSupportedException>(
            () => ((IList<EquipmentSlotState>)slots)[0] = new EquipmentSlotState(EquipmentSlot.Head, Helmet()),
            "The returned list is read-only");

        Assert.Equal(0, equipment.EquippedCount, "Equipment is unchanged");
        Assert.False(equipment.IsSlotOccupied(EquipmentSlot.Head), "Head is still empty");
    }

    [Test]
    public void EarlierSnapshotDoesNotChangeWhenEquipmentChanges()
    {
        var equipment = new ItemEquipment();
        var before = equipment.GetSlots();

        equipment.Equip(Helmet(), EquipmentSlot.Head);

        Assert.True(before[0].IsEmpty, "The old snapshot still shows an empty Head");
        Assert.False(equipment.GetSlots()[0].IsEmpty, "A fresh snapshot shows the helmet");
    }

    [Test]
    public void EquippedItemsAreImmutableDefinitions()
    {
        var equipment = new ItemEquipment();
        equipment.Equip(Helmet(), EquipmentSlot.Head);

        var item = equipment.GetEquipped(EquipmentSlot.Head)!;

        // Every ItemDefinition property is get-only; the only way to "change" one is to
        // build a new definition, which does not alter what is equipped.
        var other = new ItemDefinition(item.Id, "Renamed", item.Category, slot: item.Slot);
        Assert.Equal("Iron Helmet", equipment.GetEquipped(EquipmentSlot.Head)!.Name, "Equipped item keeps its own definition");
        Assert.False(item == other, "A different definition is a different value");
    }

    // ---- invalid state protection ---------------------------------------

    [Test]
    public void QueriesRejectInvalidSlotsWithAnException()
    {
        var equipment = new ItemEquipment();

        Assert.Throws<ArgumentOutOfRangeException>(() => equipment.GetEquipped((EquipmentSlot)99), "GetEquipped rejects an undeclared slot");
        Assert.Throws<ArgumentOutOfRangeException>(() => equipment.IsSlotOccupied(default), "IsSlotOccupied rejects default(EquipmentSlot)");
    }

    [Test]
    public void IsEquippedRejectsNullId()
    {
        var equipment = new ItemEquipment();

        Assert.Throws<ArgumentNullException>(() => equipment.IsEquipped(null!), "A null ItemId is a programming error");
    }

    [Test]
    public void IsEquippedIsFalseForUnknownIds()
    {
        var equipment = new ItemEquipment();
        equipment.Equip(Helmet(), EquipmentSlot.Head);

        Assert.False(equipment.IsEquipped(new ItemId("something_else")), "Unknown id is not equipped");
    }

    [Test]
    public void EveryEquippedItemAlwaysSitsInItsOwnSlotAfterAMixOfOperations()
    {
        var equipment = new ItemEquipment();
        var attempts = new (ItemDefinition Item, EquipmentSlot Slot)[]
        {
            (Helmet(), EquipmentSlot.Head),
            (Helmet(), EquipmentSlot.Chest),          // incompatible
            (Chestplate(), EquipmentSlot.Chest),
            (Helmet("gold_helmet"), EquipmentSlot.Head), // occupied
            (Potion(), EquipmentSlot.OffHand),        // not equippable
            (Shield(), (EquipmentSlot)77),            // invalid slot
            (Shield(), EquipmentSlot.OffHand),
            (Sword(), EquipmentSlot.MainHand),
        };

        foreach (var (item, slot) in attempts)
        {
            equipment.Equip(item, slot);
        }

        equipment.Unequip(EquipmentSlot.Chest);
        equipment.Unequip(EquipmentSlot.Feet);

        var seenIds = new HashSet<ItemId>();
        foreach (var state in equipment.GetSlots())
        {
            if (state.Item is null)
            {
                continue;
            }

            Assert.Equal(state.Slot, state.Item.Slot!.Value, "Item sits in the slot its definition names");
            Assert.True(seenIds.Add(state.Item.Id), "No ItemId appears twice");
        }

        Assert.Equal(seenIds.Count, equipment.EquippedCount, "Count matches the visible items");
        Assert.Equal(3, equipment.EquippedCount, "Helmet, shield and sword remain");
    }
}
