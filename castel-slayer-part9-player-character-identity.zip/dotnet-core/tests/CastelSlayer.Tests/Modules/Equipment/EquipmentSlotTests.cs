using System.Linq;
using CastelSlayer.Modules.Equipment.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Equipment;

public sealed class EquipmentSlotTests
{
    [Test]
    public void AllContainsExactlyTheSixInitialSlots()
    {
        Assert.Equal(6, EquipmentSlots.All.Count, "Six initial slots");
        foreach (var expected in new[]
        {
            EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs,
            EquipmentSlot.Feet, EquipmentSlot.MainHand, EquipmentSlot.OffHand,
        })
        {
            Assert.True(EquipmentSlots.All.Contains(expected), expected + " is a slot");
        }
    }

    [Test]
    public void AllHasNoDuplicates()
    {
        Assert.Equal(EquipmentSlots.All.Count, EquipmentSlots.All.Distinct().Count(), "No slot is listed twice");
    }

    [Test]
    public void DeclaredSlotsAreValid()
    {
        foreach (var slot in EquipmentSlots.All)
        {
            Assert.True(EquipmentSlots.IsValid(slot), slot + " is valid");
        }
    }

    [Test]
    public void DefaultAndOutOfRangeSlotsAreInvalid()
    {
        Assert.False(EquipmentSlots.IsValid(default), "default(EquipmentSlot) is invalid");
        Assert.False(EquipmentSlots.IsValid((EquipmentSlot)7), "One past the last slot is invalid");
        Assert.False(EquipmentSlots.IsValid((EquipmentSlot)(-1)), "Negative value is invalid");
        Assert.False(EquipmentSlots.IsValid((EquipmentSlot)999), "Large value is invalid");
    }

    [Test]
    public void AllIsInAscendingValueOrder()
    {
        Assert.Equal(EquipmentSlot.Head, EquipmentSlots.All[0], "Head first");
        Assert.Equal(EquipmentSlot.OffHand, EquipmentSlots.All[EquipmentSlots.All.Count - 1], "OffHand last");
    }
}
