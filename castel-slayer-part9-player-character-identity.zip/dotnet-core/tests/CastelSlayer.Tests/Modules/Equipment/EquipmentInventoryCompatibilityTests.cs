using CastelSlayer.Modules.Equipment.Internal.Domain;
using CastelSlayer.Modules.Inventory.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Equipment;

/// <summary>
/// Checks that Equipment reuses Inventory's <see cref="ItemId"/> and that the
/// two stay separate: no automatic transfer in either direction (Prompt 07).
/// </summary>
public sealed class EquipmentInventoryCompatibilityTests
{
    private static ItemDefinition Sword() =>
        new(new ItemId("iron_sword"), "Iron Sword", ItemCategory.Weapon, slot: EquipmentSlot.MainHand);

    [Test]
    public void DefinitionIdIsTheInventoryItemId()
    {
        ItemId id = Sword().Id;

        Assert.Equal(new ItemId("iron_sword"), id, "Same value equals the Inventory ItemId");
        Assert.Equal(id.GetHashCode(), new ItemId("iron_sword").GetHashCode(), "Same value hashes the same");
    }

    [Test]
    public void SameItemIdIdentifiesTheItemInBothInventoryAndEquipment()
    {
        var def = Sword();
        var inventory = new ItemInventory(capacity: 4);
        var equipment = new ItemEquipment();

        // Building an Inventory Item from a definition is the caller's job for now.
        inventory.AddItem(new Item(def.Id, def.MaxStackSize), 1);
        equipment.Equip(def, EquipmentSlot.MainHand);

        Assert.True(inventory.HasItem(def.Id), "Inventory finds the item by its ItemId");
        Assert.True(equipment.IsEquipped(def.Id), "Equipment finds the item by the same ItemId");
    }

    [Test]
    public void EquippingDoesNotTouchTheInventory()
    {
        var def = Sword();
        var inventory = new ItemInventory(capacity: 4);
        inventory.AddItem(new Item(def.Id, def.MaxStackSize), 1);
        var equipment = new ItemEquipment();

        equipment.Equip(def, EquipmentSlot.MainHand);

        Assert.Equal(1L, inventory.CountOf(def.Id), "No automatic Inventory -> Equipment transaction: the stack is still in the inventory");
    }

    [Test]
    public void UnequippingDoesNotAddToTheInventory()
    {
        var def = Sword();
        var inventory = new ItemInventory(capacity: 4);
        var equipment = new ItemEquipment();
        equipment.Equip(def, EquipmentSlot.MainHand);

        var result = equipment.Unequip(EquipmentSlot.MainHand);

        Assert.True(result.IsSuccess, "Unequip succeeds");
        Assert.Equal(0L, inventory.CountOf(def.Id), "No automatic Equipment -> Inventory transaction: the caller receives the item in the result");
        Assert.Equal(def, result.Item!, "The removed item is available to the caller");
    }

    [Test]
    public void DefinitionStackSizeMatchesWhatInventoryAccepts()
    {
        var potion = new ItemDefinition(new ItemId("health_potion"), "Health Potion", ItemCategory.Consumable, maxStackSize: 20);
        var inventory = new ItemInventory(capacity: 2);

        var result = inventory.AddItem(new Item(potion.Id, potion.MaxStackSize), 25);

        Assert.True(result.IsFullyAdded, "25 potions fit in two stacks of up to 20");
        Assert.Equal(25L, inventory.CountOf(potion.Id), "All 25 are in the inventory");
    }
}
