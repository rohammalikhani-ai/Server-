using System;
using CastelSlayer.Modules.Equipment.Internal.Domain;
using CastelSlayer.Modules.Inventory.Internal.Domain;
using CastelSlayer.Tests.Support;

namespace CastelSlayer.Tests.Modules.Equipment;

public sealed class ItemDefinitionTests
{
    [Test]
    public void ValidNonEquippableDefinitionIsCreated()
    {
        var def = new ItemDefinition(new ItemId("health_potion"), "Health Potion", ItemCategory.Consumable, maxStackSize: 20);

        Assert.Equal(new ItemId("health_potion"), def.Id, "Id is kept");
        Assert.Equal("Health Potion", def.Name, "Name is kept");
        Assert.Equal(ItemCategory.Consumable, def.Category, "Category is kept");
        Assert.Equal(20, def.MaxStackSize, "MaxStackSize is kept");
        Assert.False(def.IsEquippable, "No slot means not equippable");
        Assert.True(def.Slot is null, "No slot is kept as null");
    }

    [Test]
    public void ValidEquippableDefinitionIsCreated()
    {
        var def = new ItemDefinition(new ItemId("iron_helmet"), "Iron Helmet", ItemCategory.Armor, slot: EquipmentSlot.Head);

        Assert.True(def.IsEquippable, "A definition with a slot is equippable");
        Assert.Equal(EquipmentSlot.Head, def.Slot!.Value, "Slot is kept");
        Assert.Equal(1, def.MaxStackSize, "MaxStackSize defaults to 1");
    }

    [Test]
    public void NonEquippableItemDefaultsToStackSizeOne()
    {
        var def = new ItemDefinition(new ItemId("key"), "Rusty Key", ItemCategory.Miscellaneous);

        Assert.Equal(1, def.MaxStackSize, "MaxStackSize defaults to 1");
        Assert.False(def.IsEquippable, "Default is not equippable");
    }

    [Test]
    public void EveryDeclaredSlotCanBeUsedByADefinition()
    {
        foreach (var slot in EquipmentSlots.All)
        {
            var def = new ItemDefinition(new ItemId("thing_" + slot), "Thing", ItemCategory.Armor, slot: slot);

            Assert.Equal(slot, def.Slot!.Value, "Slot " + slot + " is accepted");
        }
    }

    [Test]
    public void NullIdIsRejected()
    {
        Assert.Throws<ArgumentNullException>(
            () => new ItemDefinition(null!, "Name", ItemCategory.Material),
            "A definition needs an id");
    }

    [Test]
    public void NullNameIsRejected()
    {
        Assert.Throws<ArgumentNullException>(
            () => new ItemDefinition(new ItemId("a"), null!, ItemCategory.Material),
            "A definition needs a name");
    }

    [Test]
    public void BlankNameIsRejected()
    {
        Assert.Throws<ArgumentException>(
            () => new ItemDefinition(new ItemId("a"), "", ItemCategory.Material),
            "Empty name is invalid");
        Assert.Throws<ArgumentException>(
            () => new ItemDefinition(new ItemId("a"), "   ", ItemCategory.Material),
            "Whitespace name is invalid");
    }

    [Test]
    public void UndeclaredCategoryIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemDefinition(new ItemId("a"), "Name", default),
            "default(ItemCategory) is not a declared category");
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemDefinition(new ItemId("a"), "Name", (ItemCategory)99),
            "An out-of-range category is invalid");
    }

    [Test]
    public void ZeroOrNegativeMaxStackSizeIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemDefinition(new ItemId("a"), "Name", ItemCategory.Material, maxStackSize: 0),
            "MaxStackSize 0 is invalid");
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemDefinition(new ItemId("a"), "Name", ItemCategory.Material, maxStackSize: -5),
            "Negative MaxStackSize is invalid");
    }

    [Test]
    public void UndeclaredSlotIsRejected()
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemDefinition(new ItemId("a"), "Name", ItemCategory.Armor, slot: (EquipmentSlot)0),
            "default(EquipmentSlot) is not a declared slot");
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new ItemDefinition(new ItemId("a"), "Name", ItemCategory.Armor, slot: (EquipmentSlot)99),
            "An out-of-range slot is invalid");
    }

    [Test]
    public void EquippableItemMustNotBeStackable()
    {
        Assert.Throws<ArgumentException>(
            () => new ItemDefinition(new ItemId("a"), "Name", ItemCategory.Armor, maxStackSize: 5, slot: EquipmentSlot.Chest),
            "An equippable item with MaxStackSize > 1 is invalid");
    }

    [Test]
    public void DefinitionsWithSameValuesAreEqual()
    {
        var a = new ItemDefinition(new ItemId("iron_sword"), "Iron Sword", ItemCategory.Weapon, slot: EquipmentSlot.MainHand);
        var b = new ItemDefinition(new ItemId("iron_sword"), "Iron Sword", ItemCategory.Weapon, slot: EquipmentSlot.MainHand);
        var c = new ItemDefinition(new ItemId("iron_sword"), "Iron Sword", ItemCategory.Weapon, slot: EquipmentSlot.OffHand);

        Assert.Equal(a, b, "Value equality holds for identical definitions");
        Assert.False(a == c, "A different slot makes a different definition");
    }
}
