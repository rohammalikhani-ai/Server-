# 0003 — Equipment as its own module; sharing `ItemId` with Inventory

## Context

Prompt 07 asks for an Equipment foundation that (a) reuses the `ItemId` from
Prompt 06's Inventory, (b) keeps Inventory (stores `ItemStack`s) and Equipment
(stores equipped items) separate, (c) must not rewrite Inventory without a real
compatibility problem, and (d) stays independent of Stats.

`ItemId` currently lives in `CastelSlayer.Modules.Inventory.Internal.Domain`.
The module rules (ARCHITECTURE.md) say a module may depend only on another
module's `Public/` surface. Inventory has no `Public/` layer yet.

## Decision

1. Equipment is a new module, `CastelSlayer.Modules.Equipment`, not a folder
   inside Inventory. Rewriting Inventory is not needed.
2. Equipment takes a project reference on Inventory and uses **only** `ItemId`
   from it. This is a deliberate, narrow exception to the public-surface rule:
   `ItemId` is already a public C# type, and moving it now would touch
   Inventory and its tests for no functional gain.
3. Equipment does not reference `ItemInventory`/`Item`/`ItemStack`, Progression,
   or Character. Tests (which may see everything) exercise the compatibility.
4. `ItemDefinition`, `ItemCategory` and `EquipmentSlot` live in Equipment for
   now, because the definition's only behavior today is describing equippability.

## Consequences

- Equipment cannot be built without Inventory's assembly, though it uses one type.
- **Follow-up (not done here):** promote `ItemId` to `CastelSlayer.Core.Domain`
  (like `CharacterId`) or an Inventory `Public/` layer, then drop the project
  reference. Do it in the prompt that introduces an Item Database or the
  Inventory ↔ Equipment transaction, whichever comes first. That prompt should
  also decide the permanent home of `ItemDefinition` and reconcile it with
  Inventory's `Item` (id + max stack size), whose `MaxStackSize` it overlaps.
- Neither module knows about the other's containers, so the future transaction
  must live in a third place (a service/composition layer), not in either module.
