# 0002 — C# Core Migration & Cross-Language Boundary

## Context

Prompts 01–04 established a Java-only stack: `core/`, `modules/character/`
are real, reviewed (not yet compiled — see `CURRENT_STATE.md`) Java 17
source, with a documented decision (`0001-jvm-language-and-source-layout.md`)
to keep everything JVM-side and defer a build tool.

Prompt 05's brief is an explicit, named "IMPORTANT ARCHITECTURE DECISION":
all authoritative game logic (stats, progression, inventory, combat,
quests, NPCs, loot, economy, world state, persistence/domain rules, etc.)
must live in C#, with Java/Fabric reduced to the Minecraft
integration/platform layer only. It also explicitly anticipates hitting
already-existing Java core code and instructs: don't blindly duplicate
it in C#, identify a coherent migration/boundary strategy instead — while
separately ruling out redesigning the whole project or building fake
networking/persistence infrastructure just for this prompt.

This record is that strategy.

## Decision

1. **New C# Core is additive, not a rewrite-in-place.** A new top-level
   `dotnet-core/` tree is introduced, mirroring the existing
   `core/` + `modules/<name>/public|internal` conventions
   (`PROJECT_MAP.md`, `ARCHITECTURE.md`) in C# instead of Java:
   `dotnet-core/src/CastelSlayer.Core/{Domain,Events,Contracts}` and
   `dotnet-core/src/CastelSlayer.Modules.<Name>/{Public,Internal}`. The
   existing `core/` and `modules/character/` Java source is **not**
   deleted, ported, or modified by this prompt.

2. **Going forward, new authoritative gameplay modules are built in C#
   under `dotnet-core/`,** per the brief. This prompt builds exactly one:
   `CastelSlayer.Modules.Progression` (Stats/Attributes/Progression —
   see `dotnet-core/src/CastelSlayer.Modules.Progression/MODULE.md`).

3. **The existing Java `core/` and `modules/character/` are not migrated
   by this prompt.** Migrating already-built, tested-on-paper Java
   domain logic into C# is a project-wide restructuring in its own
   right — exactly what the brief separately forbids ("do not redesign
   the entire project", "the task is too large for one session, split
   it into complete smaller tasks before implementation"). They remain
   as-is, and are now explicitly labeled **legacy Java core, migration
   pending** in `CURRENT_STATE.md` and `PROJECT_MAP.md`. A future prompt
   should decide, module by module, whether to:
   - port it to `dotnet-core/` (most modules — race, class, equipment,
     combat, quest, npc, economy, world-state, persistence — once a
     prompt actually builds their gameplay logic), or
   - leave it as thin, Minecraft-facing glue if a module turns out to be
     genuinely presentation-layer rather than gameplay logic.
   `modules/character`'s existing scope (identity/lifecycle join point:
   `PlayerId` ↔ `CharacterId`, active/retired state) is small and
   already deliberately free of any race/class/stats/progression
   fields (see its own `MODULE.md` → "Forbidden Responsibilities") — it
   is a reasonable candidate to either stay a thin Java identity record
   or be ported wholesale later; this prompt does not decide that, it
   only avoids depending on it.

4. **The C# Core does not depend on the Java Core, and vice versa.**
   `CastelSlayer.Modules.Progression` references characters only by
   `CastelSlayer.Core.Domain.CharacterId` — a new C# type, not a binding
   to Java's `character.contracts.CharacterId` — deliberately shaped as
   the same concept (a UUID/GUID) so an id minted on either side is
   valid on the other without translation, once something actually
   wires the two runtimes together (see "What Is Deferred" below).

5. **Communication between the C# Core and the Java/Fabric platform
   layer is a future decision, not built now.** The eventual shape
   (per the brief's architecture diagram — C# Core → Minecraft
   Integration Layer → Java/Fabric + Geyser/Floodgate → clients) needs
   *some* adapter that lets the Java-side Minecraft integration call
   into the C# Core's authoritative logic and receive results/events
   back. Candidate mechanisms (gRPC over localhost, a lightweight
   JSON-over-TCP/named-pipe protocol, or embedding via a JVM↔CLR
   interop layer) are **not chosen or implemented here** — building
   that now, before any real integration-layer prompt needs it, would
   be exactly the "fake networking infrastructure just for this
   prompt" the brief rules out, and this environment currently has no
   network access to evaluate/fetch any of the candidate libraries
   anyway. What *is* defined now is the boundary shape those future
   adapters must respect: the C# Core exposes its modules' `Public/`
   surface (contracts + events) exactly as `core/contracts` does on the
   Java side, and nothing on the Java side may reach into a C# module's
   `Internal/` any more than a Java module may reach into another
   Java module's `internal/`.

## What Is Deferred (explicitly, not forgotten)

- Choosing and implementing the actual C# ↔ Java/Fabric IPC/interop
  mechanism.
- A C# equivalent of `IPersistenceGateway` (`Progression` has no
  persistence in this prompt — `CharacterStatsProfile.Reconstitute`
  exists as the shape a future persistence adapter would rebuild from,
  but nothing calls it yet).
- A C# equivalent of `IConfigProvider`.
- A C# `IEventBus` *implementation* (the interface exists in
  `CastelSlayer.Core.Contracts`; `LevelingService` deliberately returns
  events rather than depending on it — see its own doc comments).
- A decision on whether/how `modules/character` (Java) is ported.
- A composition root for the C# side (mirrors the Java side's own
  not-yet-decided composition root — see `CURRENT_STATE.md`).

## Consequences

- Two source trees now exist side by side (`core/`+`modules/` in Java,
  `dotnet-core/` in C#) until a future prompt migrates the Java gameplay
  modules or decides not to. This is visible, documented duplication of
  *tree structure* (not of gameplay logic — no logic was duplicated;
  `Progression` is new, not a port of anything that existed in Java),
  which is the coherent reading of requirement 14 given requirements
  forbidding a full redesign in one prompt.
- Neither this environment's Java toolchain (no `javac`) nor a .NET SDK
  (no network access to install one — confirmed: `apt-get install
  dotnet-sdk-8.0` fails with `403 Forbidden`, same failure mode already
  recorded for the JDK in `CURRENT_STATE.md`) can compile/run anything
  here. `dotnet-core`'s C# was written and manually reviewed the same
  way Prompts 03–04's Java was — see `dotnet-core/CURRENT_STATE.md`-
  equivalent notes in this repo's root `CURRENT_STATE.md`.
