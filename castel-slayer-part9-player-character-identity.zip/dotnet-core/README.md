# dotnet-core

> **DEPRECATED — reference-only, as of Prompt 08.** Java is now the sole
> production language for this project; see the root
> `docs/decisions/0002-java-as-sole-production-language.md`. This tree is
> **not** deleted and **not** modified beyond this notice, but it is not on
> any build or ship path: do not add new modules here, do not treat
> anything below as authoritative, and do not build a C#↔Java bridge for
> it. It remains only as prior art that a future Java rebuild of
> `Progression`/`Inventory`/`Equipment` may optionally consult. The
> sections below describe the tree as it stood under the since-reversed
> Prompt 05 decision, kept for historical accuracy.

The C# Core: authoritative, engine-agnostic game logic, per the Prompt 05
architecture decision (**superseded — see the notice above**). See
`docs/decisions/0002-csharp-core-migration-boundary.md` (in this folder)
for why this existed alongside the pre-existing Java `core/`/`modules/`
tree, what was and wasn't migrated, and what the Java/Fabric integration
boundary would have looked like once built.

## Layout

Mirrors the root project's `core/` + `modules/<name>/public|internal`
convention (see the root `PROJECT_MAP.md`), in C#:

```
dotnet-core/
├── docs/decisions/          Decision records specific to the C# Core.
├── src/
│   ├── CastelSlayer.Core/                  Engine-agnostic domain/events/contracts.
│   ├── CastelSlayer.Modules.Progression/   Stats/Attributes/Progression (Prompt 05).
│   ├── CastelSlayer.Modules.Inventory/     Inventory Foundation (Prompt 06).
│   └── CastelSlayer.Modules.Equipment/     Equipment Foundation (Prompt 07); reuses Inventory's ItemId only.
└── tests/
    └── CastelSlayer.Tests/      Mirrors src/ 1:1; Support/ is the hand-rolled
                                  test harness (no network access to fetch a
                                  real framework — see Support/TestAttribute.cs).
```

No `.sln` file yet — five `.csproj` files (`CastelSlayer.Core`,
`CastelSlayer.Modules.Progression`, `CastelSlayer.Modules.Inventory`,
`CastelSlayer.Modules.Equipment`, `CastelSlayer.Tests`), no external
NuGet package references, so nothing here requires network access to
build once a .NET SDK is present. None of it has been compiled or run in
this environment (no SDK, no network to install one) — see the root
`CURRENT_STATE.md` for the verification command to run once a real SDK
is available.

## Start Here

Read the root project's `PROJECT_MAP.md`, `ARCHITECTURE.md`,
`DESIGN_PRINCIPLES.md`, and `DEVELOPMENT_RULES.md` first — they still
govern this tree (module public/internal split, event/contract-only
cross-module communication, server authority, etc.). Then read
`docs/decisions/0002-csharp-core-migration-boundary.md` for what's
specific to the C# Core, and the relevant module's `MODULE.md` (e.g.
`src/CastelSlayer.Modules.Progression/MODULE.md`, `src/CastelSlayer.Modules.Equipment/MODULE.md`).
