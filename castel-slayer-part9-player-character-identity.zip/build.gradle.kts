// Root build file. No production code lives at the root — this only centralizes
// config that every subproject (`:core`, `:modules:*`, `:platform:java`) shares.
// See docs/decisions/0003-paper-platform-and-composition-root.md.

subprojects {
    apply(plugin = "java")

    group = "com.castelslayer"
    version = "0.1.0-SNAPSHOT"

    configure<JavaPluginExtension> {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(21))
        }
    }

    tasks.withType<JavaCompile>().configureEach {
        options.encoding = "UTF-8"
    }

    // Tests in this repo use the hand-rolled harness in tests/support (`support.Test`
    // annotation + `support.TestRunner`), not JUnit — see
    // docs/decisions/0001-jvm-language-and-source-layout.md. Gradle's stock `Test` task
    // can't discover them, so `harnessTest` runs `support.TestRunner` over every
    // `*Test` class found in the project's compiled test output, and `test` (and
    // therefore `check`/`build`) delegates to it. Projects with no test classes skip it.
    val testSourceSet = extensions.getByType<JavaPluginExtension>().sourceSets.getByName("test")

    fun discoverTestClasses(classesDirs: FileCollection): List<String> =
        classesDirs.files
            .filter { it.isDirectory }
            .flatMap { dir ->
                dir.walkTopDown()
                    .filter { it.isFile && it.name.endsWith("Test.class") && !it.name.contains('$') }
                    .map { it.relativeTo(dir).path.removeSuffix(".class").replace(File.separatorChar, '.') }
                    .toList()
            }
            .filter { !it.startsWith("support.") }
            .sorted()

    val harnessTest = tasks.register<JavaExec>("harnessTest") {
        description = "Runs support.TestRunner over this project's compiled *Test classes."
        group = "verification"
        classpath = testSourceSet.runtimeClasspath
        mainClass.set("support.TestRunner")
        val classesDirs = testSourceSet.output.classesDirs
        onlyIf { discoverTestClasses(classesDirs).isNotEmpty() }
        doFirst { setArgs(discoverTestClasses(classesDirs)) }
    }

    tasks.named<Test>("test") {
        enabled = false
        dependsOn(harnessTest)
    }
}
