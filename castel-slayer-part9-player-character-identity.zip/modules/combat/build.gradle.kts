// :modules:combat — depends on :core only, for core.domain.EntityRef (attacker/target).
// Deliberately does NOT depend on :modules:character: a damage source/target can be a
// player, an NPC, or any other in-world entity, so this module uses the generic
// core.domain.EntityRef rather than character.contracts.CharacterId (see
// combat.domain.DamageRequest's Javadoc).
// Source layout is unchanged: modules/combat/internal/ and modules/combat/public/ are the
// source roots (packages are declared per sub-folder, e.g. internal/domain -> `combat.domain`),
// same approach as :core's build file. Tests live outside the module under tests/.

plugins {
    java
}

sourceSets {
    main {
        java {
            setSrcDirs(listOf("internal", "public"))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/modules/combat"), rootProject.file("tests/support")))
            // tests/support's InMemoryEventBus / InMemoryPersistenceGateway implement :core
            // contracts, and this module's tests use neither — see :modules:inventory's
            // build file for the same reasoning.
            exclude("InMemoryEventBus.java", "InMemoryPersistenceGateway.java")
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    implementation(project(":core"))
}
