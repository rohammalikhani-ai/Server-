package combat.contracts;

/**
 * Why an entity was <em>not</em> given a respawn destination. A closed set so callers can
 * {@code switch} on it exhaustively; new reasons are added here, never encoded as free text.
 */
public enum RespawnDenialReason {
    /** The entity's health says it is alive — a living entity cannot be respawned as if dead. */
    ENTITY_ALIVE,
    /** This kind of entity is not configured as respawnable (e.g. a projectile or a structure). */
    KIND_NOT_RESPAWNABLE,
    /** The entity may respawn, but no {@link RespawnPoint} is available for it. */
    NO_RESPAWN_POINT
}
