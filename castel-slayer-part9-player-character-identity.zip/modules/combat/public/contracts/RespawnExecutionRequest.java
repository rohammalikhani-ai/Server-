package combat.contracts;

import core.domain.EntityRef;
import java.time.Instant;
import java.util.Objects;

/**
 * The command that crosses the execution boundary: "bring {@code entity} back at
 * {@code destination}". Everything an {@link IRespawnExecutor} needs and nothing it does not —
 * no health, no penalties, no platform types. {@code requestedAt} is supplied by the lifecycle
 * service's clock, never read here.
 */
public record RespawnExecutionRequest(EntityRef entity, RespawnPoint destination, Instant requestedAt) {

    public RespawnExecutionRequest {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(destination, "destination");
        Objects.requireNonNull(requestedAt, "requestedAt");
    }
}
