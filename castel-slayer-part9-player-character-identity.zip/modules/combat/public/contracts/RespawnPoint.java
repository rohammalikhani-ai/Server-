package combat.contracts;

import core.domain.Location;
import java.util.Objects;

/**
 * A place an entity may be brought back to after it dies: a neutral, immutable wrapper around
 * {@link Location}. That is the whole concept — it deliberately says nothing about <em>why</em> the
 * place was chosen (a bed, a checkpoint, a world default, a graveyard) or <em>who</em> chose it;
 * those are rules, and rules are what {@link IRespawnPointProvider} implementations own. A future
 * "bed" or "guild hall" rule therefore produces the same {@code RespawnPoint}, and nothing
 * downstream needs to change.
 *
 * <p>Validity is enforced at construction and can never be bypassed: a non-null {@link Location},
 * which itself rejects a blank world and non-finite coordinates/rotation. An invalid destination
 * is therefore not representable — it is rejected where it is created, not "handled" later.
 * Nothing here knows about Bukkit/Paper/Minecraft types; a platform adapter translates the
 * {@link Location} in exactly one place.
 */
public record RespawnPoint(Location location) {

    public RespawnPoint {
        Objects.requireNonNull(location, "location");
    }
}
