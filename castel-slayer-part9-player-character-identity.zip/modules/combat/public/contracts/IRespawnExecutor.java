package combat.contracts;

/**
 * The execution boundary: the only place "actually bring this entity back" happens, and it happens
 * <em>outside</em> the core. The core decides "entity X may respawn at Y"
 * ({@link RespawnDecision.Granted}) and hands a {@link RespawnExecutionRequest} across this
 * interface; how the entity is revived and moved (teleport, respawn screen, chunk loading, bed
 * mechanics, packets, ...) is the implementer's business and is invisible to the core.
 *
 * <p>Extension point with <b>no implementation in this module</b> — a platform adapter implements
 * it (see {@code DEVELOPMENT_RULES.md}: interfaces, not stub classes).
 *
 * <p>Contract for implementers:
 * <ul>
 *   <li>Return {@link RespawnExecutionResult.Failed} for an expected inability to respawn; return
 *       {@link RespawnExecutionResult.Succeeded} only if the entity really is at the requested
 *       destination. The result must be for the requested entity, and a success must name the
 *       requested destination — the lifecycle service rejects anything else.</li>
 *   <li>Never return {@code null}. Throwing is for unexpected errors; the exception propagates to
 *       the caller, and core state is unchanged (states are immutable values the caller still
 *       holds).</li>
 *   <li>Should be idempotent per request where the platform allows, since a duplicate delivery
 *       (e.g. after a restart) cannot be ruled out by the core alone.</li>
 * </ul>
 */
public interface IRespawnExecutor {

    RespawnExecutionResult execute(RespawnExecutionRequest request);
}
