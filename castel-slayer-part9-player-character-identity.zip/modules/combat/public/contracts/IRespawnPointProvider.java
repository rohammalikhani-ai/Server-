package combat.contracts;

import core.domain.EntityRef;
import java.util.Optional;

/**
 * Extension point: "where would this entity respawn, if it may?". Answers with a
 * {@link RespawnPoint} or {@code Optional.empty()} when the entity has none.
 *
 * <p>Deliberately an interface with <b>no implementation in this module</b> (see
 * {@code DEVELOPMENT_RULES.md}: extension points are interfaces, not stub classes). Real sources —
 * a saved bed/checkpoint, a per-world default, a quest-driven location — belong to whichever module
 * owns that concept and are wired in at the composition root. Implementations must be
 * deterministic for the same inputs and must not return {@code null} (use {@code Optional.empty()}).
 */
public interface IRespawnPointProvider {

    Optional<RespawnPoint> findRespawnPoint(EntityRef entity);
}
