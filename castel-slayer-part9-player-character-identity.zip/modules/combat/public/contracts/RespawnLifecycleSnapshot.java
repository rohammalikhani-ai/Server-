package combat.contracts;

import core.domain.EntityRef;
import core.domain.Location;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/**
 * The combat module's persistence model for one entity's respawn lifecycle: an immutable record of
 * plain data (JDK types and {@code core.domain} values only) that crosses
 * {@code core.contracts.IPersistenceGateway}. It is <b>not</b> the domain state
 * ({@code combat.domain.RespawnLifecycleState}) — that is rebuilt from it only through validated
 * recovery ({@code combat.services.RespawnLifecycleSnapshotMapper}) — so a gateway (memory, JSON, SQL,
 * ...) never sees, and gameplay code never receives, a live domain object; same pattern as
 * {@code character.contracts.CharacterSnapshot}.
 *
 * <p>The record only guarantees structure (no {@code null} anywhere). Whether the <em>content</em> is
 * acceptable — known schema, known status, a destination consistent with the status, sane revision
 * and timestamp — is decided at recovery, which reports a specific reason instead of silently
 * "fixing" data. That is deliberate: a snapshot decoded from an external store may be wrong, and it
 * must still be representable so it can be diagnosed.
 *
 * <p>What is stored: identity, lifecycle status, the decided destination while one exists, plus the
 * two pieces of bookkeeping consistency needs. What is <em>not</em>: health, the killer, the
 * {@code EntityDied}/{@code EntityRespawned} events, penalties or anything platform-specific.
 *
 * @param schemaVersion the version of <em>this record's format</em> ({@link #CURRENT_SCHEMA_VERSION}); a
 *                      different value is refused at recovery rather than guessed at
 * @param revision      the optimistic-concurrency counter of the stored record: 1 for the first save, +1 for
 *                      every later one; a save must state the revision it read (see {@code RespawnLifecycleStore})
 * @param entity        whose lifecycle this is
 * @param status        the lifecycle status as its name (e.g. {@code "RESPAWN_DECIDED"}), not the internal
 *                      enum, so the stored form does not depend on an internal type
 * @param destination   the decided destination; present exactly for the statuses that carry one
 * @param savedAt       when this revision was written (audit/diagnostic; not used for ordering decisions)
 */
public record RespawnLifecycleSnapshot(int schemaVersion, long revision, EntityRef entity, String status,
                                       Optional<Location> destination, Instant savedAt) {

    /** The only schema version this code writes and reads. */
    public static final int CURRENT_SCHEMA_VERSION = 1;

    public RespawnLifecycleSnapshot {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(destination, "destination");
        Objects.requireNonNull(savedAt, "savedAt");
    }
}
