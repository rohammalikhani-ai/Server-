package combat.contracts;

import core.domain.EntityRef;
import java.time.Instant;
import java.util.Objects;

/**
 * The immutable answer to a {@link RespawnRequest}: either {@link Granted} (with a destination) or
 * {@link Denied} (with a reason). A sealed pair, so a granted decision can never lack a
 * destination and a denied one can never carry one — the illegal combinations do not exist.
 *
 * <p>A decision is only a statement — "entity X may respawn at Y" / "may not, because Z". It does
 * not move, revive, penalise or reward anyone; carrying it out belongs to
 * {@link IRespawnExecutor}, outside the core boundary. {@code decidedAt} is the request's
 * timestamp (no clock is read), keeping decisions deterministic.
 */
public sealed interface RespawnDecision {

    EntityRef entity();

    Instant decidedAt();

    /** The entity is allowed to respawn at {@code destination}. */
    record Granted(EntityRef entity, RespawnPoint destination, Instant decidedAt) implements RespawnDecision {
        public Granted {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(destination, "destination");
            Objects.requireNonNull(decidedAt, "decidedAt");
        }
    }

    /** The entity is not allowed to respawn now, for {@code reason}. */
    record Denied(EntityRef entity, RespawnDenialReason reason, Instant decidedAt) implements RespawnDecision {
        public Denied {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(decidedAt, "decidedAt");
        }
    }
}
