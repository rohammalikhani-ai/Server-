package combat.contracts;

import core.domain.EntityRef;
import java.time.Instant;
import java.util.Objects;

/**
 * What an {@link IRespawnExecutor} reports back: {@link Succeeded} (the entity is back, at
 * {@code destination}) or {@link Failed} (it is not, and why). Sealed and immutable, like
 * {@link RespawnDecision}. Failure is an ordinary returned value — the executor's <em>expected</em>
 * "could not do it" (chunk unavailable, entity gone, ...) — so it can never be mistaken for success.
 */
public sealed interface RespawnExecutionResult {

    EntityRef entity();

    Instant completedAt();

    /** The entity was brought back at {@code destination}. */
    record Succeeded(EntityRef entity, RespawnPoint destination, Instant completedAt)
            implements RespawnExecutionResult {
        public Succeeded {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(destination, "destination");
            Objects.requireNonNull(completedAt, "completedAt");
        }
    }

    /** The entity was not brought back; {@code reason} is a non-blank, human-readable explanation. */
    record Failed(EntityRef entity, String reason, Instant completedAt) implements RespawnExecutionResult {
        public Failed {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(completedAt, "completedAt");
            if (reason.isBlank()) {
                throw new IllegalArgumentException("reason must not be blank");
            }
        }
    }
}
