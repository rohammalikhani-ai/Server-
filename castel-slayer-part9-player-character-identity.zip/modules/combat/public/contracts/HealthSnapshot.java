package combat.contracts;

import core.domain.EntityRef;
import java.time.Instant;
import java.util.Objects;

/**
 * The combat module's persistence model for one entity's {@code combat.domain.Health}: an
 * immutable record of plain data (JDK types and {@code core.domain} values only) that crosses
 * {@code core.contracts.IPersistenceGateway}. It is <b>not</b> the domain value itself — a
 * {@code Health} is rebuilt from it only through validated recovery
 * ({@code combat.services.HealthSnapshotMapper}) — so a gateway (memory, JSON, SQL, ...) never
 * sees, and gameplay code never receives, a live {@code Health} straight out of storage without
 * having its invariants re-checked. Same pattern, same reasoning, as
 * {@code RespawnLifecycleSnapshot} (Gameplay Part 7) and {@code character.contracts.CharacterSnapshot}.
 *
 * <p>The record only guarantees structure (no {@code null} anywhere). Whether the <em>content</em>
 * is acceptable — known schema, a sane revision and timestamp, and {@code current}/{@code max}
 * values {@code combat.domain.Health}'s own constructor would accept — is decided at recovery,
 * which reports a specific reason instead of silently "fixing" data. That is deliberate: a
 * snapshot decoded from an external store may be wrong, and it must still be representable so it
 * can be diagnosed.
 *
 * <p>What is stored: whose health this is, {@code current}/{@code max} HP, plus the
 * schema/revision/timestamp bookkeeping {@code HealthStore}'s optimistic-revision saves need. What
 * is <em>not</em>: alive/dead (derived, not stored — see {@code combat.domain.Health#isAlive()}),
 * who last damaged this entity, {@code EntityDied}/respawn state, or anything platform-specific.
 *
 * @param schemaVersion the version of <em>this record's format</em> ({@link #CURRENT_SCHEMA_VERSION}); a
 *                      different value is refused at recovery rather than guessed at
 * @param revision      the optimistic-concurrency counter of the stored record: 1 for the first save, +1 for
 *                      every later one; a save must state the revision it read (see {@code combat.services.HealthStore})
 * @param entity        whose health this is
 * @param current       current HP, as read from {@code Health#current()}; validated at recovery, not here
 * @param max           maximum HP, as read from {@code Health#max()}; validated at recovery, not here
 * @param savedAt       when this revision was written (audit/diagnostic; not used for ordering decisions)
 */
public record HealthSnapshot(int schemaVersion, long revision, EntityRef entity, double current, double max,
                              Instant savedAt) {

    /** The only schema version this code writes and reads. */
    public static final int CURRENT_SCHEMA_VERSION = 1;

    public HealthSnapshot {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(savedAt, "savedAt");
    }
}
