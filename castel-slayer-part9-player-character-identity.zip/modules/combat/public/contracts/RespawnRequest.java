package combat.contracts;

import combat.events.EntityDied;
import core.domain.EntityRef;
import java.time.Instant;
import java.util.Objects;

/**
 * "This entity is dead and would like to be respawned." The input to a respawn decision.
 *
 * <p>Carries only what a decision needs: who, and when the request arose. The timestamp is data
 * supplied by the caller, never read from a clock here, so a decision derived from a request is
 * fully deterministic. {@link #from(EntityDied)} is the bridge from the death pipeline:
 * {@code Damage -> Health dead -> EntityDied -> RespawnRequest}.
 */
public record RespawnRequest(EntityRef entity, Instant requestedAt) {

    public RespawnRequest {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(requestedAt, "requestedAt");
    }

    /** The request implied by a death: the entity that died, at the moment it died. */
    public static RespawnRequest from(EntityDied died) {
        Objects.requireNonNull(died, "died");
        return new RespawnRequest(died.target(), died.occurredAt());
    }
}
