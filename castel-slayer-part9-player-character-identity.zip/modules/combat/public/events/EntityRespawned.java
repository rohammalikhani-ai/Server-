package combat.events;

import combat.contracts.RespawnPoint;
import core.domain.EntityRef;
import core.events.GameEvent;
import java.time.Instant;
import java.util.Objects;

/**
 * Produced exactly once when an entity's respawn execution has been confirmed successful — the
 * counterpart of {@link EntityDied} at the other end of the lifecycle:
 * {@code EntityDied ... EntityRespawned}. Minimal on purpose: who, where, when. No health, no
 * penalties, no reason for the respawn.
 *
 * <p>Returned to the caller inside {@code combat.services.RespawnLifecycleResult#events()}, never
 * published by the module itself — the same "caller decides how to publish" pattern as
 * {@code EntityDied}, with no {@code IEventBus} dependency and no global bus.
 */
public record EntityRespawned(EntityRef entity, RespawnPoint destination, Instant occurredAt) implements GameEvent {

    public EntityRespawned {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(destination, "destination");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
