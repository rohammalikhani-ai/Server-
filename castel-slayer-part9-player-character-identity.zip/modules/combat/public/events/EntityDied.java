package combat.events;

import core.domain.EntityRef;
import core.events.GameEvent;
import java.time.Instant;
import java.util.Objects;

/**
 * Published exactly once when applying a {@code combat.domain.DamageResult} to a
 * target's {@code combat.domain.Health} transitions that target from alive
 * ({@code current > 0}) to dead ({@code current == 0}). The Gameplay Part 4
 * counterpart of Parts 1-3's {@code Attacker -> DamageRequest -> DamageCalculator ->
 * DamageResult -> DamageApplicationService -> Health} pipeline:
 *
 * <pre>
 * Alive Health --[lethal DamageResult]--&gt; DamageApplicationService --&gt; dead Health
 *                                                  |
 *                                                  +--&gt; EntityDied
 * </pre>
 *
 * <p>{@code target} and {@code source} are {@link EntityRef} — the same "who dealt
 * this, who received it" pair already carried by {@code DamageResult}, not
 * {@code core.domain.PlayerId} or any module-specific identity type, so this event
 * makes no assumption about whether either side is a player, an NPC, or any other
 * in-world entity (the same reasoning {@code DamageRequest}/{@code DamageResult}
 * already document for their own {@code source}/{@code target} fields).
 *
 * <p>Deliberately minimal: only the two identities a subscriber needs to react (who
 * died, who/what killed them) plus {@code occurredAt}, mirroring
 * {@code core.events.PlayerJoinedWorld}'s "two identifiers + timestamp" shape. No HP
 * values, no {@code DamageType}, no damage amount, and no snapshot of the target's
 * final {@code Health} — none of that is necessary for "an entity died just
 * happened"; a subscriber that needs more re-derives it from its own state (requirement
 * 8: future-proof, not over-engineered).
 *
 * <p>Says nothing about what happens next: no respawn, no loot, no XP, no
 * persistence. Those are later Gameplay Parts' concerns, reacting to this event
 * through whatever mechanism the caller chooses to publish it with — this type does
 * not publish itself and holds no reference to an event bus.
 */
public record EntityDied(EntityRef target, EntityRef source, Instant occurredAt) implements GameEvent {

    public EntityDied {
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
