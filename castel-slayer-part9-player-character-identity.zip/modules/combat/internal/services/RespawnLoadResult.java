package combat.services;

import combat.domain.RespawnLifecycleState;
import core.domain.EntityRef;
import java.util.Objects;

/**
 * The outcome of {@link RespawnLifecycleStore#load}. Four cases kept apart on purpose, exactly as
 * {@code CharacterLoadResult} keeps its own apart — "I could not read it" must never look like "it
 * does not exist":
 * <ul>
 *   <li>{@link Loaded} — a valid state and the revision it was stored at;</li>
 *   <li>{@link NotFound} — nothing stored for this entity (a normal answer: it has no lifecycle record yet);</li>
 *   <li>{@link Corrupt} — something is stored but failed validation ({@code reason} says how);</li>
 *   <li>{@link Failed} — the store itself could not be read ({@code cause} is the original
 *       {@link core.contracts.PersistenceException}).</li>
 * </ul>
 */
public sealed interface RespawnLoadResult {

    EntityRef entity();

    record Loaded(EntityRef entity, RespawnLifecycleState state, long revision) implements RespawnLoadResult {
        public Loaded {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(state, "state");
            if (!entity.equals(state.entity())) {
                throw new IllegalArgumentException("loaded state belongs to " + state.entity() + ", not " + entity);
            }
            if (revision < 1) {
                throw new IllegalArgumentException("a stored revision is at least 1 (was " + revision + ")");
            }
        }
    }

    record NotFound(EntityRef entity) implements RespawnLoadResult {
        public NotFound {
            Objects.requireNonNull(entity, "entity");
        }
    }

    record Corrupt(EntityRef entity, RespawnRecoveryFailure reason, String detail) implements RespawnLoadResult {
        public Corrupt {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(detail, "detail");
        }
    }

    record Failed(EntityRef entity, String reason, Throwable cause) implements RespawnLoadResult {
        public Failed {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(cause, "cause");
        }
    }
}
