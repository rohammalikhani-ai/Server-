package combat.services;

import combat.domain.RespawnLifecycleState;
import java.util.Objects;

/**
 * The outcome of validated recovery: either the rebuilt {@link RespawnLifecycleState} with the
 * revision it was stored at, or a {@link Rejected} with the specific reason. Recovery never
 * returns a "best effort" state for bad data.
 */
public sealed interface RespawnRecoveryResult {

    record Recovered(RespawnLifecycleState state, long revision) implements RespawnRecoveryResult {
        public Recovered {
            Objects.requireNonNull(state, "state");
        }
    }

    record Rejected(RespawnRecoveryFailure reason, String detail) implements RespawnRecoveryResult {
        public Rejected {
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(detail, "detail");
        }
    }
}
