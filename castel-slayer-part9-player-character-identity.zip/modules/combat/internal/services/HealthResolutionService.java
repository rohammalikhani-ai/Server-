package combat.services;

import core.domain.EntityRef;
import java.util.Objects;

/**
 * The small application/domain service Gameplay Part 8 asks for: resolving
 * {@code combat.domain.Health} for a stable {@link EntityRef} identity, without conflating "known
 * entity, valid state", "unknown entity", "corrupt stored state" and "storage failure" the way a
 * bare {@code Optional<Health>} would.
 *
 * <p>Thin by design: {@link #resolve} is a 1:1 re-mapping of {@link HealthStore#load}'s
 * {@link HealthLoadResult} into {@link HealthResolutionResult} (dropping the {@code revision},
 * which is {@link HealthStore#save}'s write-concern, not a resolution concern). Two classes exist
 * instead of one only because "the persistence boundary" ({@code HealthStore}, which also knows how
 * to {@code save}/{@code discard} and carries the revision contract) and "the read-only resolution
 * facade other code depends on" are different responsibilities — the same separation
 * {@code combat.contracts.ICharacterDirectory} draws from {@code character.services.CharacterDirectoryService}
 * in the {@code character} module, and {@code combat.public} draws from {@code combat.internal}
 * generally.
 *
 * <p><b>Deliberately does not create a default {@code Health} for {@link HealthResolutionResult.NotFound}.</b>
 * Whether — and at what value — a not-yet-recorded entity should get a starting {@code Health} is a
 * gameplay rule (e.g. "new players start at 20 HP"), not an identity/persistence concern, and Part 8
 * is explicitly a foundation/boundary part, not a full player system. The extension point for that
 * rule is exactly here: a future overload such as {@code resolveOrDefault(EntityRef, Supplier<Health>)}
 * would call {@link #resolve} and only substitute a value on {@link HealthResolutionResult.NotFound},
 * still leaving {@link HealthResolutionResult.Corrupt}/{@link HealthResolutionResult.Failed} alone
 * (a corrupt or unreadable record must never be silently treated as "no health yet"). No such
 * overload exists yet — this class does not guess at what a future gameplay rule should be.
 */
public final class HealthResolutionService {

    private final HealthStore store;

    public HealthResolutionService(HealthStore store) {
        this.store = Objects.requireNonNull(store, "store");
    }

    /** Resolves {@code entity}'s current health. Never throws for storage or data problems. */
    public HealthResolutionResult resolve(EntityRef entity) {
        Objects.requireNonNull(entity, "entity");
        return switch (store.load(entity)) {
            case HealthLoadResult.Loaded l -> new HealthResolutionResult.Resolved(l.entity(), l.health());
            case HealthLoadResult.NotFound n -> new HealthResolutionResult.NotFound(n.entity());
            case HealthLoadResult.Corrupt c -> new HealthResolutionResult.Corrupt(c.entity(), c.reason(), c.detail());
            case HealthLoadResult.Failed f -> new HealthResolutionResult.Failed(f.entity(), f.reason(), f.cause());
        };
    }
}
