package combat.services;

import combat.contracts.RespawnLifecycleSnapshot;
import combat.contracts.RespawnPoint;
import combat.domain.RespawnLifecycleState;
import combat.domain.RespawnLifecycleStatus;
import core.domain.Location;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/**
 * The two-way, pure boundary between domain state and its persistence snapshot:
 *
 * <pre>
 * RespawnLifecycleState --toSnapshot--&gt; RespawnLifecycleSnapshot --(gateway)--&gt; storage
 * storage --(gateway)--&gt; RespawnLifecycleSnapshot --restore (validated)--&gt; RespawnLifecycleState
 * </pre>
 *
 * <p>{@link #toSnapshot} can only produce a snapshot that {@link #restore} accepts (it rejects a
 * revision or timestamp restore would refuse), so this code never writes data it would later call
 * corrupt. {@link #restore} checks, in this order, and reports the first failure with a specific
 * {@link RespawnRecoveryFailure}: schema version, revision, timestamp, status, destination
 * consistency. It never repairs anything — no trimming, no case folding, no defaulting, no
 * dropping of a stray destination. Anything the rebuilt state's own constructor would reject is
 * therefore already ruled out here, so recovery cannot throw for bad data.
 *
 * <p>Deterministic and stateless: the same snapshot always restores to an equal state.
 */
public final class RespawnLifecycleSnapshotMapper {

    public RespawnLifecycleSnapshot toSnapshot(RespawnLifecycleState state, long revision, Instant savedAt) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(savedAt, "savedAt");
        if (revision < 1) {
            throw new IllegalArgumentException("revision must be at least 1 (was " + revision + ")");
        }
        if (savedAt.isBefore(Instant.EPOCH)) {
            throw new IllegalArgumentException("savedAt must not be before the Unix epoch (was " + savedAt + ")");
        }
        return new RespawnLifecycleSnapshot(RespawnLifecycleSnapshot.CURRENT_SCHEMA_VERSION, revision, state.entity(),
                state.status().name(), state.destination().map(RespawnPoint::location), savedAt);
    }

    public RespawnRecoveryResult restore(RespawnLifecycleSnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        if (snapshot.schemaVersion() != RespawnLifecycleSnapshot.CURRENT_SCHEMA_VERSION) {
            return rejected(RespawnRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION, "schema version "
                    + snapshot.schemaVersion() + " is not supported (this code reads version "
                    + RespawnLifecycleSnapshot.CURRENT_SCHEMA_VERSION + ")");
        }
        if (snapshot.revision() < 1) {
            return rejected(RespawnRecoveryFailure.INVALID_REVISION, "revision " + snapshot.revision() + " is below 1");
        }
        if (snapshot.savedAt().isBefore(Instant.EPOCH)) {
            return rejected(RespawnRecoveryFailure.INVALID_TIMESTAMP, "savedAt " + snapshot.savedAt()
                    + " is before the Unix epoch");
        }
        RespawnLifecycleStatus status;
        try {
            status = RespawnLifecycleStatus.valueOf(snapshot.status());
        } catch (IllegalArgumentException e) {
            return rejected(RespawnRecoveryFailure.INVALID_LIFECYCLE_STATE,
                    "'" + snapshot.status() + "' is not a lifecycle status");
        }
        Optional<Location> destination = snapshot.destination();
        if (status.carriesDestination() != destination.isPresent()) {
            return rejected(RespawnRecoveryFailure.INVALID_DESTINATION, "status " + status
                    + (status.carriesDestination() ? " requires a destination" : " must not have a destination"));
        }
        return new RespawnRecoveryResult.Recovered(
                new RespawnLifecycleState(snapshot.entity(), status, destination.map(RespawnPoint::new)),
                snapshot.revision());
    }

    private static RespawnRecoveryResult rejected(RespawnRecoveryFailure reason, String detail) {
        return new RespawnRecoveryResult.Rejected(reason, detail);
    }
}
