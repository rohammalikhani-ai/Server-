package combat.services;

import combat.domain.Health;
import combat.events.EntityDied;
import java.util.List;
import java.util.Objects;

/**
 * The outcome of one {@link DamageApplicationService#applyDetectingDeath} call.
 * Carries the {@link EntityDied} event (if any) that occurred rather than
 * publishing it directly, so {@link DamageApplicationService} stays free of any
 * {@code core.contracts.IEventBus} dependency — the same pattern
 * {@code progression.services.LevelingResult} uses for {@code CharacterLeveledUp}.
 * The caller decides how, whether, and through what channel to publish {@code events()}.
 *
 * <p>{@code events} holds zero or one {@link EntityDied}: this Gameplay Part
 * detects a single alive-to-dead transition per call, never more. A {@link List} is
 * used anyway (rather than an {@code Optional<EntityDied>}) to match the plural,
 * extensible shape {@code LevelingResult#events()} already established for
 * "events produced by this call," so callers that already know how to consume that
 * shape need no special case here.
 */
public record DamageApplicationResult(Health health, List<EntityDied> events) {

    public DamageApplicationResult {
        Objects.requireNonNull(health, "health");
        Objects.requireNonNull(events, "events");
        events = List.copyOf(events);
    }
}
