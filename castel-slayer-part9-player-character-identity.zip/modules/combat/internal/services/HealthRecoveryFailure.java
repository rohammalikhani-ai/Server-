package combat.services;

/** Why a stored {@code HealthSnapshot} could not be turned back into a valid {@code combat.domain.Health}. Closed set. */
public enum HealthRecoveryFailure {
    /** {@code schemaVersion} is not the one this code understands (older or, more importantly, newer). */
    UNSUPPORTED_SCHEMA_VERSION,
    /** {@code revision} is below 1. */
    INVALID_REVISION,
    /** {@code savedAt} is before the Unix epoch. */
    INVALID_TIMESTAMP,
    /**
     * {@code current}/{@code max} would be rejected by {@code combat.domain.Health}'s own
     * constructor: non-finite, {@code max <= 0}, {@code current < 0}, or {@code current > max}.
     */
    INVALID_HEALTH_VALUES,
    /** The record is stored under one entity's key but describes another. */
    IDENTITY_MISMATCH
}
