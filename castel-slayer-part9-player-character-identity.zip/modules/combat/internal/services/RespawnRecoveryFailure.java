package combat.services;

/** Why a stored respawn-lifecycle record could not be turned back into domain state. Closed set. */
public enum RespawnRecoveryFailure {
    /** {@code schemaVersion} is not the one this code understands (older or, more importantly, newer). */
    UNSUPPORTED_SCHEMA_VERSION,
    /** {@code revision} is below 1. */
    INVALID_REVISION,
    /** {@code savedAt} is before the Unix epoch. */
    INVALID_TIMESTAMP,
    /** {@code status} is not exactly the name of a lifecycle status (no trimming, no case folding). */
    INVALID_LIFECYCLE_STATE,
    /** The destination is missing for a status that needs one, or present for one that must not have it. */
    INVALID_DESTINATION,
    /** The record is stored under one entity's key but describes another. */
    IDENTITY_MISMATCH
}
