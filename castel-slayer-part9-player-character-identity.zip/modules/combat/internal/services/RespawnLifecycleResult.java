package combat.services;

import combat.contracts.RespawnDenialReason;
import combat.contracts.RespawnExecutionRequest;
import combat.domain.RespawnLifecycleState;
import combat.events.EntityRespawned;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * The outcome of one {@link RespawnLifecycleService} operation: the resulting state (always
 * present — for anything other than {@link RespawnLifecycleOutcome#APPLIED} it is simply the
 * state that was passed in) plus the details of what happened. Returned, never published or
 * stored, in the same style as {@link DamageApplicationResult}.
 *
 * <p>The constructor keeps the details consistent with the outcome: a {@code denialReason} exists
 * only for {@code DENIED}; a {@code detail} (non-blank) exists exactly for {@code REJECTED} and
 * {@code EXECUTION_FAILED}; an {@code executionRequest} or any {@code events} exist only for
 * {@code APPLIED}. Use the factories rather than the constructor.
 */
public record RespawnLifecycleResult(RespawnLifecycleState state, RespawnLifecycleOutcome outcome,
                                     Optional<RespawnDenialReason> denialReason, Optional<String> detail,
                                     Optional<RespawnExecutionRequest> executionRequest,
                                     List<EntityRespawned> events) {

    public RespawnLifecycleResult {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(outcome, "outcome");
        Objects.requireNonNull(denialReason, "denialReason");
        Objects.requireNonNull(detail, "detail");
        Objects.requireNonNull(executionRequest, "executionRequest");
        Objects.requireNonNull(events, "events");
        events = List.copyOf(events);

        require(denialReason.isPresent() == (outcome == RespawnLifecycleOutcome.DENIED),
                "denialReason is present exactly for DENIED");
        boolean needsDetail = outcome == RespawnLifecycleOutcome.REJECTED
                || outcome == RespawnLifecycleOutcome.EXECUTION_FAILED;
        require(detail.isPresent() == needsDetail, "detail is present exactly for REJECTED and EXECUTION_FAILED");
        require(detail.map(d -> !d.isBlank()).orElse(true), "detail must not be blank");
        require(outcome == RespawnLifecycleOutcome.APPLIED || (executionRequest.isEmpty() && events.isEmpty()),
                "executionRequest and events are only produced by APPLIED");
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new IllegalArgumentException(message);
        }
    }

    public static RespawnLifecycleResult applied(RespawnLifecycleState state) {
        return new RespawnLifecycleResult(state, RespawnLifecycleOutcome.APPLIED, Optional.empty(), Optional.empty(),
                Optional.empty(), List.of());
    }

    public static RespawnLifecycleResult applied(RespawnLifecycleState state, RespawnExecutionRequest request) {
        Objects.requireNonNull(request, "request");
        return new RespawnLifecycleResult(state, RespawnLifecycleOutcome.APPLIED, Optional.empty(), Optional.empty(),
                Optional.of(request), List.of());
    }

    public static RespawnLifecycleResult applied(RespawnLifecycleState state, EntityRespawned event) {
        Objects.requireNonNull(event, "event");
        return new RespawnLifecycleResult(state, RespawnLifecycleOutcome.APPLIED, Optional.empty(), Optional.empty(),
                Optional.empty(), List.of(event));
    }

    public static RespawnLifecycleResult duplicate(RespawnLifecycleState unchanged) {
        return new RespawnLifecycleResult(unchanged, RespawnLifecycleOutcome.DUPLICATE, Optional.empty(),
                Optional.empty(), Optional.empty(), List.of());
    }

    public static RespawnLifecycleResult denied(RespawnLifecycleState unchanged, RespawnDenialReason reason) {
        Objects.requireNonNull(reason, "reason");
        return new RespawnLifecycleResult(unchanged, RespawnLifecycleOutcome.DENIED, Optional.of(reason),
                Optional.empty(), Optional.empty(), List.of());
    }

    public static RespawnLifecycleResult rejected(RespawnLifecycleState unchanged, String detail) {
        Objects.requireNonNull(detail, "detail");
        return new RespawnLifecycleResult(unchanged, RespawnLifecycleOutcome.REJECTED, Optional.empty(),
                Optional.of(detail), Optional.empty(), List.of());
    }

    public static RespawnLifecycleResult executionFailed(RespawnLifecycleState restored, String reason) {
        Objects.requireNonNull(reason, "reason");
        return new RespawnLifecycleResult(restored, RespawnLifecycleOutcome.EXECUTION_FAILED, Optional.empty(),
                Optional.of(reason), Optional.empty(), List.of());
    }
}
