package combat.services;

import combat.contracts.HealthSnapshot;
import combat.domain.Health;
import core.domain.EntityRef;
import java.time.Instant;
import java.util.Objects;

/**
 * The two-way, pure boundary between {@code combat.domain.Health} and its persistence snapshot,
 * mirroring {@code RespawnLifecycleSnapshotMapper}'s (Gameplay Part 7) shape exactly:
 *
 * <pre>
 * Health --toSnapshot--&gt; HealthSnapshot --(gateway)--&gt; storage
 * storage --(gateway)--&gt; HealthSnapshot --restore (validated)--&gt; Health
 * </pre>
 *
 * <p>{@link #toSnapshot} can only produce a snapshot that {@link #restore} accepts (it rejects a
 * revision or timestamp {@link #restore} would refuse), so this code never writes data it would
 * later call corrupt. {@link #restore} checks, in this order, and reports the first failure with a
 * specific {@link HealthRecoveryFailure}: schema version, revision, timestamp, then the same
 * {@code current}/{@code max} invariants {@code combat.domain.Health}'s own constructor enforces
 * (finite, {@code max > 0}, {@code 0 <= current <= max}) — checked here explicitly, not by
 * constructing a {@code Health} and catching its exception, so recovery never depends on a
 * domain-object side effect to detect bad data. It never repairs anything — no clamping
 * {@code current} to {@code max}, no flooring a negative value, no defaulting a non-finite max.
 *
 * <p>Deterministic and stateless: the same snapshot always restores to an equal {@code Health}.
 */
public final class HealthSnapshotMapper {

    public HealthSnapshot toSnapshot(Health health, EntityRef entity, long revision, Instant savedAt) {
        Objects.requireNonNull(health, "health");
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(savedAt, "savedAt");
        if (revision < 1) {
            throw new IllegalArgumentException("revision must be at least 1 (was " + revision + ")");
        }
        if (savedAt.isBefore(Instant.EPOCH)) {
            throw new IllegalArgumentException("savedAt must not be before the Unix epoch (was " + savedAt + ")");
        }
        return new HealthSnapshot(HealthSnapshot.CURRENT_SCHEMA_VERSION, revision, entity,
                health.current(), health.max(), savedAt);
    }

    public HealthRecoveryResult restore(HealthSnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        if (snapshot.schemaVersion() != HealthSnapshot.CURRENT_SCHEMA_VERSION) {
            return rejected(HealthRecoveryFailure.UNSUPPORTED_SCHEMA_VERSION, "schema version "
                    + snapshot.schemaVersion() + " is not supported (this code reads version "
                    + HealthSnapshot.CURRENT_SCHEMA_VERSION + ")");
        }
        if (snapshot.revision() < 1) {
            return rejected(HealthRecoveryFailure.INVALID_REVISION, "revision " + snapshot.revision() + " is below 1");
        }
        if (snapshot.savedAt().isBefore(Instant.EPOCH)) {
            return rejected(HealthRecoveryFailure.INVALID_TIMESTAMP, "savedAt " + snapshot.savedAt()
                    + " is before the Unix epoch");
        }
        double current = snapshot.current();
        double max = snapshot.max();
        if (Double.isNaN(max) || Double.isInfinite(max) || max <= 0
                || Double.isNaN(current) || Double.isInfinite(current) || current < 0 || current > max) {
            return rejected(HealthRecoveryFailure.INVALID_HEALTH_VALUES,
                    "current=" + current + ", max=" + max + " is not a value combat.domain.Health accepts");
        }
        return new HealthRecoveryResult.Recovered(new Health(current, max), snapshot.revision());
    }

    private static HealthRecoveryResult rejected(HealthRecoveryFailure reason, String detail) {
        return new HealthRecoveryResult.Rejected(reason, detail);
    }
}
