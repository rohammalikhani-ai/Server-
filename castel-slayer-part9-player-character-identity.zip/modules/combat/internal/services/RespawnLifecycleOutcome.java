package combat.services;

/** What a {@link RespawnLifecycleService} operation did. See {@link RespawnLifecycleResult}. */
public enum RespawnLifecycleOutcome {
    /** The transition happened; {@code state()} is the new state. */
    APPLIED,
    /** The step had already happened (repeat death, repeat request, repeat completion); nothing changed. */
    DUPLICATE,
    /** The entity may not respawn (see {@code denialReason()}); the state is unchanged. */
    DENIED,
    /** The operation is not valid here (wrong entity, wrong state, inconsistent input); nothing changed. */
    REJECTED,
    /** The execution boundary reported failure; the state is back at RESPAWN_DECIDED, unchanged from before the request. */
    EXECUTION_FAILED
}
