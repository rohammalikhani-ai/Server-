package combat.services;

import combat.domain.DamageResult;
import combat.domain.Health;
import combat.events.EntityDied;
import java.time.Clock;
import java.util.List;
import java.util.Objects;

/**
 * The Gameplay Part 3 orchestration seam: applies an already-calculated
 * {@link DamageResult} to a target's {@link Health} and returns the updated value.
 * Gameplay Part 4 adds {@link #applyDetectingDeath(DamageResult, Health)} alongside it:
 * the same application, plus detecting the alive-to-dead transition and returning the
 * resulting {@link EntityDied} event, if any.
 *
 * <pre>
 * DamageResult + Target Health
 *         &darr;
 *    Apply Damage
 *         &darr;
 *     New Health  (+ EntityDied, if this application killed the target)
 * </pre>
 *
 * <p>This closes the loop the module's earlier Parts left open:
 * {@code Attacker -> DamageRequest -> DamageCalculator -> DamageResult} (Part 1), then
 * {@code DamageResult -> Health.apply(...) -> new Health} (Part 2, {@link Health}
 * itself). {@link Health#apply(DamageResult)} already contains every damage-application
 * rule (floors at zero, never exceeds max, zero damage/already-dead is a no-op,
 * immutable) — this service does not duplicate or re-implement that logic, nor does it
 * duplicate {@link Health}'s own {@code current == 0} dead definition:
 * {@link #applyDetectingDeath(DamageResult, Health)} detects death purely by comparing
 * {@code targetHealth.isAlive()} before the call to the returned {@link Health#isDead()}
 * after it. What it adds is the explicit orchestration step and this module's usual
 * null-safety at the boundary (the same {@link Objects#requireNonNull} pattern
 * {@code combat.services.DamageCalculator} and {@code combat.domain.Health} both use),
 * so callers have one obvious place to invoke "apply this result to this health" without
 * reaching into {@link Health} directly.
 *
 * <p>Deliberately does <b>not</b> know which {@code Health} belongs to a
 * {@link DamageResult#target()}, and does not look one up, store one, or publish
 * anything: the caller resolves and supplies {@code targetHealth} and does whatever it
 * wants with the returned value(s), including {@code events()} from
 * {@link #applyDetectingDeath}. There is no event bus dependency here and no global
 * mutable subscriber state — the caller decides how, whether, and through what channel
 * (e.g. {@code core.contracts.IEventBus}) to publish an {@link EntityDied}, the same
 * way {@code progression.services.LevelingService} returns
 * {@code progression.events.CharacterLeveledUp} instead of publishing it itself. Mapping
 * a target reference to its stored {@code Health} is target-health storage — explicitly
 * out of scope for this Part (see {@code MODULE.md}). No respawn, healing,
 * regeneration, armor, resistance, or any other combat rule is added here; those stay
 * {@link Health}'s and {@code DamageCalculator}'s concerns, respectively, for future
 * Gameplay Parts to extend.
 *
 * <p>Stateless and deterministic: no mutable field, no {@code Random}, no shared
 * mutable state. The injected {@link Clock} is the one exception, used only to
 * timestamp an {@link EntityDied}'s {@code occurredAt()} (the same reason
 * {@code progression.services.LevelingService} takes one) — with the same clock,
 * calling either method with the same arguments always returns an equal result, and
 * {@code targetHealth} is never mutated (it can't be — {@link Health} is immutable).
 */
public final class DamageApplicationService {

    private final Clock clock;

    /** Uses the system UTC clock to timestamp any {@link EntityDied} events. */
    public DamageApplicationService() {
        this(Clock.systemUTC());
    }

    /** Uses {@code clock} to timestamp any {@link EntityDied} events (e.g. a fixed clock in tests). */
    public DamageApplicationService(Clock clock) {
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /**
     * Applies {@code damageResult} to {@code targetHealth} and returns the resulting
     * {@link Health}. Equivalent to {@code targetHealth.apply(damageResult)}; provided
     * as the named orchestration step for callers outside this module's domain package.
     *
     * @throws NullPointerException if either argument is {@code null}
     */
    public Health apply(DamageResult damageResult, Health targetHealth) {
        Objects.requireNonNull(damageResult, "damageResult");
        Objects.requireNonNull(targetHealth, "targetHealth");
        return targetHealth.apply(damageResult);
    }

    /**
     * Applies {@code damageResult} to {@code targetHealth} exactly as {@link #apply}
     * does, and additionally detects whether this specific application is what killed
     * the target: {@code targetHealth} was alive ({@code current > 0}) and the
     * resulting {@link Health} is dead ({@code current == 0}). When it is, the
     * returned {@link DamageApplicationResult#events()} holds exactly one
     * {@link EntityDied} — {@code target} and {@code source} taken from
     * {@code damageResult}, {@code occurredAt} from this service's {@link Clock} — and
     * otherwise it is empty. In particular:
     *
     * <ul>
     *   <li>non-lethal damage (target stays alive): no event;</li>
     *   <li>zero damage: {@link Health#apply} is a no-op, so no transition, no event;</li>
     *   <li>a target that was already dead before this call: still dead after, but
     *       {@code targetHealth.isAlive()} was already {@code false}, so no
     *       <em>duplicate</em> event is produced;</li>
     *   <li>damage that brings HP to exactly zero, or past it (overkill, floored at
     *       zero by {@link Health}): one event, since either way the target is now
     *       dead and was not before.</li>
     * </ul>
     *
     * @throws NullPointerException if either argument is {@code null}
     */
    public DamageApplicationResult applyDetectingDeath(DamageResult damageResult, Health targetHealth) {
        Objects.requireNonNull(damageResult, "damageResult");
        Objects.requireNonNull(targetHealth, "targetHealth");

        boolean wasAlive = targetHealth.isAlive();
        Health newHealth = targetHealth.apply(damageResult);

        List<EntityDied> events = (wasAlive && newHealth.isDead())
                ? List.of(new EntityDied(damageResult.target(), damageResult.source(), clock.instant()))
                : List.of();

        return new DamageApplicationResult(newHealth, events);
    }
}
