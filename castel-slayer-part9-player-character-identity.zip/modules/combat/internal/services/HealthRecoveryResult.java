package combat.services;

import combat.domain.Health;
import java.util.Objects;

/**
 * The outcome of {@link HealthSnapshotMapper#restore}, mirroring {@code RespawnRecoveryResult}'s
 * shape exactly (Gameplay Part 7's mapper result). Kept separate from {@link HealthLoadResult} —
 * this is the pure mapping outcome (no entity identity, no I/O concerns); {@code HealthStore}
 * wraps it into the identity- and I/O-aware {@link HealthLoadResult} the rest of the module sees.
 */
public sealed interface HealthRecoveryResult {

    record Recovered(Health health, long revision) implements HealthRecoveryResult {
        public Recovered {
            Objects.requireNonNull(health, "health");
            if (revision < 1) {
                throw new IllegalArgumentException("a recovered revision is at least 1 (was " + revision + ")");
            }
        }
    }

    record Rejected(HealthRecoveryFailure reason, String detail) implements HealthRecoveryResult {
        public Rejected {
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(detail, "detail");
        }
    }
}
