package combat.services;

import combat.contracts.IRespawnExecutor;
import combat.contracts.RespawnDenialReason;
import combat.contracts.RespawnExecutionRequest;
import combat.contracts.RespawnExecutionResult;
import combat.contracts.RespawnPoint;
import combat.domain.Health;
import combat.domain.RespawnEligibility;
import combat.domain.RespawnLifecycleState;
import combat.domain.RespawnLifecycleStatus;
import combat.events.EntityDied;
import combat.events.EntityRespawned;
import java.time.Clock;
import java.util.Objects;
import java.util.Optional;

/**
 * The Gameplay Part 6 lifecycle boundary. It drives one entity's {@link RespawnLifecycleState}
 * through the five separate steps the pipeline is made of, each a distinct method so each can be
 * tested, retried, persisted (Part 7) or skipped on its own:
 *
 * <pre>
 * 1 recordDeath          EntityDied + Health   ALIVE -&gt; DEAD                       (death detection stays in
 *                                                                                 DamageApplicationService)
 * 2 evaluateEligibility  Health                DEAD -&gt; RESPAWN_ELIGIBLE          (or DENIED, still DEAD)
 * 3 decideDestination                          RESPAWN_ELIGIBLE -&gt; RESPAWN_DECIDED (or DENIED, unchanged)
 * 4 requestExecution                           RESPAWN_DECIDED -&gt; RESPAWN_EXECUTION_REQUESTED + request
 * 5 completeExecution    RespawnExecutionResult  REQUESTED -&gt; ALIVE + EntityRespawned
 *                                                or -&gt; RESPAWN_DECIDED (failure, retryable)
 * </pre>
 * {@link #execute} is steps 4-5 around a synchronous {@link IRespawnExecutor}; a platform that
 * executes asynchronously calls 4 and 5 itself.
 *
 * <p>Rules and destinations are not here: eligibility and destination come from the
 * {@link RespawnDecisionService} (Part 5) — nothing is duplicated. Nothing here teleports or
 * revives; the only door to the world is {@link IRespawnExecutor}, implemented outside the core.
 *
 * <p>Uniform handling of the awkward cases, all returned as {@link RespawnLifecycleResult}s, none
 * as exceptions (exceptions are for {@code null} arguments):
 * <ul>
 *   <li><b>Repeat of a step already taken</b> — a second death, a second execution request, a repeated
 *       success report — is {@link RespawnLifecycleOutcome#DUPLICATE}: state unchanged, no second event,
 *       and (for requests) the executor is <em>not</em> called again.</li>
 *   <li><b>Wrong entity, wrong-state or inconsistent input</b> (an alive entity asked to respawn, an
 *       {@code EntityDied} whose {@code Health} is alive, an executor result for another entity or
 *       destination) is {@link RespawnLifecycleOutcome#REJECTED}: state unchanged.</li>
 *   <li><b>Failure never mutates silently:</b> states are immutable, so the caller's old value is
 *       intact; a reported failure returns to RESPAWN_DECIDED, equal to the pre-request state.
 *       An exception thrown by an executor propagates untouched — it is never turned into
 *       success, and the caller still holds its pre-request state.</li>
 * </ul>
 *
 * <p>Stateless and deterministic: no mutable field, no static state, no event bus. The only clock use
 * is stamping {@link RespawnExecutionRequest#requestedAt()} (injectable, as in
 * {@link DamageApplicationService}); every other timestamp comes from the inputs.
 *
 * <p>Known limitation: because states are plain values, two callers holding the <em>same</em> stale
 * state can each advance it independently. Preventing that across saves is what Part 7's revision
 * check on the persisted record is for.
 */
public final class RespawnLifecycleService {

    private final RespawnDecisionService decisions;
    private final Clock clock;

    public RespawnLifecycleService(RespawnDecisionService decisions) {
        this(decisions, Clock.systemUTC());
    }

    public RespawnLifecycleService(RespawnDecisionService decisions, Clock clock) {
        this.decisions = Objects.requireNonNull(decisions, "decisions");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /** Step 1: ALIVE -&gt; DEAD, driven by an {@link EntityDied} that {@code health} confirms. */
    public RespawnLifecycleResult recordDeath(RespawnLifecycleState state, EntityDied died, Health health) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(died, "died");
        Objects.requireNonNull(health, "health");
        if (!died.target().equals(state.entity())) {
            return RespawnLifecycleResult.rejected(state, "EntityDied is for " + died.target()
                    + " but the lifecycle belongs to " + state.entity());
        }
        if (!state.isAlive()) {
            return RespawnLifecycleResult.duplicate(state);
        }
        if (health.isAlive()) {
            return RespawnLifecycleResult.rejected(state, "EntityDied reported but the entity's Health is alive");
        }
        return RespawnLifecycleResult.applied(state.died());
    }

    /** Step 2: DEAD -&gt; RESPAWN_ELIGIBLE, or DENIED with the reason (state stays DEAD). */
    public RespawnLifecycleResult evaluateEligibility(RespawnLifecycleState state, Health health) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(health, "health");
        switch (state.status()) {
            case ALIVE:
                return RespawnLifecycleResult.rejected(state, "entity is alive; there is nothing to respawn");
            case RESPAWN_ELIGIBLE:
            case RESPAWN_DECIDED:
            case RESPAWN_EXECUTION_REQUESTED:
                return RespawnLifecycleResult.duplicate(state);
            default:
                RespawnEligibility eligibility = decisions.evaluateEligibility(state.entity(), health);
                return eligibility.isEligible()
                        ? RespawnLifecycleResult.applied(state.eligible())
                        : RespawnLifecycleResult.denied(state, eligibility.denialReason().orElseThrow());
        }
    }

    /** Step 3: RESPAWN_ELIGIBLE -&gt; RESPAWN_DECIDED, or DENIED(NO_RESPAWN_POINT) (state unchanged). */
    public RespawnLifecycleResult decideDestination(RespawnLifecycleState state) {
        Objects.requireNonNull(state, "state");
        switch (state.status()) {
            case ALIVE:
            case DEAD:
                return RespawnLifecycleResult.rejected(state, "entity is not yet eligible (status " + state.status() + ")");
            case RESPAWN_DECIDED:
            case RESPAWN_EXECUTION_REQUESTED:
                return RespawnLifecycleResult.duplicate(state);
            default:
                Optional<RespawnPoint> point = decisions.resolveDestination(state.entity());
                return point.isPresent()
                        ? RespawnLifecycleResult.applied(state.decided(point.get()))
                        : RespawnLifecycleResult.denied(state, RespawnDenialReason.NO_RESPAWN_POINT);
        }
    }

    /**
     * Step 4: RESPAWN_DECIDED -&gt; RESPAWN_EXECUTION_REQUESTED. The {@code APPLIED} result carries the
     * {@link RespawnExecutionRequest} to hand to the execution boundary. A second request while one is
     * outstanding is {@code DUPLICATE} and carries no request, so the platform is never asked twice.
     */
    public RespawnLifecycleResult requestExecution(RespawnLifecycleState state) {
        Objects.requireNonNull(state, "state");
        switch (state.status()) {
            case RESPAWN_EXECUTION_REQUESTED:
                return RespawnLifecycleResult.duplicate(state);
            case RESPAWN_DECIDED:
                RespawnExecutionRequest request =
                        new RespawnExecutionRequest(state.entity(), state.destination().orElseThrow(), clock.instant());
                return RespawnLifecycleResult.applied(state.executionRequested(), request);
            default:
                return RespawnLifecycleResult.rejected(state,
                        "no decided destination to execute (status " + state.status() + ")");
        }
    }

    /**
     * Step 5: applies the execution boundary's report. Success -&gt; ALIVE plus one
     * {@link EntityRespawned}; failure -&gt; back to RESPAWN_DECIDED with {@code EXECUTION_FAILED}.
     * A report for another entity, for a state that is not awaiting one, or a success naming a
     * different destination than was requested is {@code REJECTED} with the state untouched. A repeated
     * success for an entity that is already ALIVE is {@code DUPLICATE}: no second event.
     */
    public RespawnLifecycleResult completeExecution(RespawnLifecycleState state, RespawnExecutionResult result) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(result, "result");
        if (!result.entity().equals(state.entity())) {
            return RespawnLifecycleResult.rejected(state, "execution result is for " + result.entity()
                    + " but the lifecycle belongs to " + state.entity());
        }
        if (state.status() == RespawnLifecycleStatus.ALIVE && result instanceof RespawnExecutionResult.Succeeded) {
            return RespawnLifecycleResult.duplicate(state);
        }
        if (state.status() != RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED) {
            return RespawnLifecycleResult.rejected(state,
                    "not awaiting an execution result (status " + state.status() + ")");
        }
        if (result instanceof RespawnExecutionResult.Succeeded succeeded) {
            RespawnPoint requested = state.destination().orElseThrow();
            if (!requested.equals(succeeded.destination())) {
                return RespawnLifecycleResult.rejected(state, "executor reports destination "
                        + succeeded.destination() + " but " + requested + " was requested");
            }
            return RespawnLifecycleResult.applied(state.respawned(),
                    new EntityRespawned(state.entity(), requested, succeeded.completedAt()));
        }
        RespawnExecutionResult.Failed failed = (RespawnExecutionResult.Failed) result;
        return RespawnLifecycleResult.executionFailed(state.executionFailed(), failed.reason());
    }

    /**
     * Steps 4-5 around a synchronous executor: request, call {@code executor} exactly once, complete.
     * If step 4 is not {@code APPLIED} (already requested, nothing decided) that result is returned
     * and the executor is not called. An exception from the executor propagates; {@code state} — the
     * caller's own immutable value — is untouched.
     */
    public RespawnLifecycleResult execute(RespawnLifecycleState state, IRespawnExecutor executor) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(executor, "executor");
        RespawnLifecycleResult requested = requestExecution(state);
        if (requested.outcome() != RespawnLifecycleOutcome.APPLIED) {
            return requested;
        }
        RespawnExecutionResult result = Objects.requireNonNull(
                executor.execute(requested.executionRequest().orElseThrow()),
                "IRespawnExecutor returned null instead of a RespawnExecutionResult");
        return completeExecution(requested.state(), result);
    }
}
