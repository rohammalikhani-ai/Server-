package combat.services;

import combat.domain.Health;
import core.domain.EntityRef;
import java.util.Objects;

/**
 * The outcome of {@link HealthResolutionService#resolve} — the four cases Gameplay Part 8 requires,
 * kept apart on purpose and never conflated:
 * <ul>
 *   <li>{@link Resolved} — a known entity with a valid stored {@link Health};</li>
 *   <li>{@link NotFound} — the entity has no health record at all. Deliberately <em>not</em>
 *       resolved to a default/full-health value here — see {@code HealthResolutionService}'s class
 *       doc for why, and where that would be added later;</li>
 *   <li>{@link Corrupt} — a record exists but failed validation;</li>
 *   <li>{@link Failed} — the underlying store could not be read.</li>
 * </ul>
 */
public sealed interface HealthResolutionResult {

    EntityRef entity();

    record Resolved(EntityRef entity, Health health) implements HealthResolutionResult {
        public Resolved {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(health, "health");
        }
    }

    record NotFound(EntityRef entity) implements HealthResolutionResult {
        public NotFound {
            Objects.requireNonNull(entity, "entity");
        }
    }

    record Corrupt(EntityRef entity, HealthRecoveryFailure reason, String detail) implements HealthResolutionResult {
        public Corrupt {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(detail, "detail");
        }
    }

    record Failed(EntityRef entity, String reason, Throwable cause) implements HealthResolutionResult {
        public Failed {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(cause, "cause");
        }
    }
}
