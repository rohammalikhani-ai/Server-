package combat.services;

import combat.contracts.RespawnLifecycleSnapshot;
import combat.domain.RespawnLifecycleState;
import core.contracts.IPersistenceGateway;
import core.contracts.PersistenceException;
import core.domain.EntityRef;
import java.time.Clock;
import java.util.Objects;
import java.util.Optional;

/**
 * The combat module's persistence boundary for respawn lifecycle state — the counterpart of
 * {@code CharacterDirectoryService} / {@code CharacterRuntimeService}, and, like them, the only class
 * here that touches {@link IPersistenceGateway}. It reuses that existing abstraction unchanged (no
 * second repository interface): whether the data lives in memory, a file or a database is invisible.
 *
 * <pre>
 * RespawnLifecycleState -&gt; RespawnLifecycleSnapshot -&gt; IPersistenceGateway -&gt; adapter -&gt; storage
 * storage -&gt; adapter -&gt; IPersistenceGateway -&gt; RespawnLifecycleSnapshot -&gt; validated recovery -&gt; RespawnLifecycleState
 * </pre>
 *
 * <p><b>This class stores; it decides nothing.</b> Which transitions are legal, who may respawn and where
 * are {@link RespawnLifecycleService}'s and {@link RespawnDecisionService}'s business; neither knows this
 * class exists, and this class never calls them. It validates only what makes <em>a record</em> trustworthy
 * (schema, revision, timestamp, status, destination shape, identity).
 *
 * <h2>Consistency: optimistic revisions</h2>
 * Every stored record carries a {@code revision}: 1 on first save, +1 per save. {@link #save} takes the
 * revision the caller last read (0 = "I expect nothing stored") and writes only if it still matches —
 * otherwise {@link RespawnSaveResult.VersionConflict}. This is what catches two callers advancing the
 * same stale state (e.g. two respawn requests racing). The check-then-write is <em>not</em> atomic at the
 * gateway: {@link IPersistenceGateway} has no conditional write, and inventing a fake one would only
 * pretend. Methods here are {@code synchronized}, which covers the single-process, single-store-instance
 * case this project runs today. A real multi-process adapter needs a native compare-and-set on the
 * gateway — an extension point documented in {@code MODULE.md}, to be added when such an adapter exists.
 *
 * <h2>Failure semantics</h2>
 * A store outage never looks like success or like "not found": {@link #load} returns
 * {@link RespawnLoadResult.Failed} (cause preserved), {@link #save} lets the {@link PersistenceException}
 * propagate (the state was NOT saved). Only {@code PersistenceException} is translated — programming
 * errors are not swallowed. Corrupt or unknown-schema records are reported ({@link RespawnLoadResult.Corrupt})
 * and never overwritten by {@link #save}; removing one is the explicit {@link #discard}.
 *
 * <p>Deterministic: {@code savedAt} comes from the injected {@link Clock}; the same stored snapshot always
 * loads to an equal state.
 */
public final class RespawnLifecycleStore {

    static final String COLLECTION = "respawn-lifecycle";

    private final IPersistenceGateway persistence;
    private final Clock clock;
    private final RespawnLifecycleSnapshotMapper mapper = new RespawnLifecycleSnapshotMapper();

    public RespawnLifecycleStore(IPersistenceGateway persistence) {
        this(persistence, Clock.systemUTC());
    }

    public RespawnLifecycleStore(IPersistenceGateway persistence, Clock clock) {
        this.persistence = Objects.requireNonNull(persistence, "persistence");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /** Loads and validates the stored lifecycle of {@code entity}. Never throws for storage or data problems. */
    public synchronized RespawnLoadResult load(EntityRef entity) {
        Objects.requireNonNull(entity, "entity");
        Optional<RespawnLifecycleSnapshot> found;
        try {
            found = persistence.load(COLLECTION, keyOf(entity), RespawnLifecycleSnapshot.class);
        } catch (PersistenceException e) {
            return new RespawnLoadResult.Failed(entity, "could not read respawn lifecycle of " + entity + ": "
                    + e.getMessage(), e);
        }
        if (found.isEmpty()) {
            return new RespawnLoadResult.NotFound(entity);
        }
        RespawnLifecycleSnapshot snapshot = found.get();
        if (!entity.equals(snapshot.entity())) {
            return new RespawnLoadResult.Corrupt(entity, RespawnRecoveryFailure.IDENTITY_MISMATCH,
                    "record stored for " + entity + " describes " + snapshot.entity());
        }
        return switch (mapper.restore(snapshot)) {
            case RespawnRecoveryResult.Recovered r -> new RespawnLoadResult.Loaded(entity, r.state(), r.revision());
            case RespawnRecoveryResult.Rejected r -> new RespawnLoadResult.Corrupt(entity, r.reason(), r.detail());
        };
    }

    /**
     * Saves {@code state} if the stored revision is still {@code expectedRevision} (0 when the caller
     * expects nothing to be stored yet). Returns {@link RespawnSaveResult.Saved} with the new revision,
     * {@link RespawnSaveResult.VersionConflict} (nothing written) or {@link RespawnSaveResult.Blocked}
     * (nothing written).
     *
     * @throws PersistenceException the store could not be read or written; the state is NOT saved
     * @throws IllegalArgumentException {@code expectedRevision} is negative
     */
    public synchronized RespawnSaveResult save(RespawnLifecycleState state, long expectedRevision) {
        Objects.requireNonNull(state, "state");
        if (expectedRevision < 0) {
            throw new IllegalArgumentException("expectedRevision must not be negative (was " + expectedRevision + ")");
        }
        EntityRef entity = state.entity();
        Optional<RespawnLifecycleSnapshot> existing =
                persistence.load(COLLECTION, keyOf(entity), RespawnLifecycleSnapshot.class);

        long actualRevision = 0;
        if (existing.isPresent()) {
            RespawnLifecycleSnapshot stored = existing.get();
            if (!entity.equals(stored.entity())) {
                return new RespawnSaveResult.Blocked(entity, RespawnRecoveryFailure.IDENTITY_MISMATCH);
            }
            if (mapper.restore(stored) instanceof RespawnRecoveryResult.Rejected rejected) {
                return new RespawnSaveResult.Blocked(entity, rejected.reason());
            }
            actualRevision = stored.revision();
        }
        if (actualRevision != expectedRevision) {
            return new RespawnSaveResult.VersionConflict(entity, expectedRevision, actualRevision);
        }

        long next = expectedRevision + 1;
        persistence.save(COLLECTION, keyOf(entity), mapper.toSnapshot(state, next, clock.instant()));
        return new RespawnSaveResult.Saved(entity, next);
    }

    /**
     * Removes whatever is stored for {@code entity} — the explicit, deliberate way out of a
     * {@link RespawnSaveResult.Blocked} record. Not part of normal operation; not versioned.
     *
     * @throws PersistenceException the store could not be written
     */
    public synchronized void discard(EntityRef entity) {
        Objects.requireNonNull(entity, "entity");
        persistence.delete(COLLECTION, keyOf(entity));
    }

    private static String keyOf(EntityRef entity) {
        return entity.kind().name() + ":" + entity.id();
    }
}
