package combat.services;

import combat.domain.DamageRequest;
import combat.domain.DamageResult;
import java.util.Objects;

/**
 * Turns a {@link DamageRequest} into a {@link DamageResult}: the one required step
 * between "attacker asks to deal damage" and "here is the final amount." Pure and
 * deterministic — same request in, same result out, every time. No {@code Random},
 * no clock, no hidden state, and (requirement: no random damage) nothing here ever
 * introduces variance.
 *
 * <p>This Gameplay Part deliberately does not apply stats, crit, or resistance —
 * those don't exist yet and are out of scope (see the task's "DO NOT IMPLEMENT"
 * list). {@link #calculate} is therefore the identity transform on the validated
 * base amount today, but it is the single seam later Gameplay Parts (armor,
 * resistance, crit) will extend without changing the
 * {@code Attacker -> DamageRequest -> DamageCalculator -> DamageResult} shape or
 * touching {@link DamageRequest}/{@link DamageResult} themselves.
 */
public final class DamageCalculator {

    public DamageResult calculate(DamageRequest request) {
        Objects.requireNonNull(request, "request");

        double finalAmount = Math.max(request.baseAmount(), 0);
        return new DamageResult(request.source(), request.target(), request.type(), finalAmount);
    }
}
