package combat.services;

import combat.domain.Health;
import core.domain.EntityRef;
import java.util.Objects;

/**
 * The outcome of {@link HealthStore#load}, mirroring {@code RespawnLoadResult}'s (Gameplay Part 7)
 * four-way split exactly — "I could not read it" must never look like "it does not exist":
 * <ul>
 *   <li>{@link Loaded} — a valid {@link Health} and the revision it was stored at;</li>
 *   <li>{@link NotFound} — nothing stored for this entity (a normal answer: it has no health
 *       record yet — this is <em>not</em> the same as "dead" or "full health", and callers must
 *       not treat it as either);</li>
 *   <li>{@link Corrupt} — something is stored but failed validation ({@code reason} says how);</li>
 *   <li>{@link Failed} — the store itself could not be read ({@code cause} is the original
 *       {@link core.contracts.PersistenceException}).</li>
 * </ul>
 */
public sealed interface HealthLoadResult {

    EntityRef entity();

    record Loaded(EntityRef entity, Health health, long revision) implements HealthLoadResult {
        public Loaded {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(health, "health");
            if (revision < 1) {
                throw new IllegalArgumentException("a stored revision is at least 1 (was " + revision + ")");
            }
        }
    }

    record NotFound(EntityRef entity) implements HealthLoadResult {
        public NotFound {
            Objects.requireNonNull(entity, "entity");
        }
    }

    record Corrupt(EntityRef entity, HealthRecoveryFailure reason, String detail) implements HealthLoadResult {
        public Corrupt {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(detail, "detail");
        }
    }

    record Failed(EntityRef entity, String reason, Throwable cause) implements HealthLoadResult {
        public Failed {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(cause, "cause");
        }
    }
}
