package combat.services;

import combat.contracts.HealthSnapshot;
import combat.domain.Health;
import core.contracts.IPersistenceGateway;
import core.contracts.PersistenceException;
import core.domain.EntityRef;
import java.time.Clock;
import java.util.Objects;
import java.util.Optional;

/**
 * The combat module's persistence boundary for {@code combat.domain.Health}, resolved and stored
 * by stable {@link EntityRef} identity — the Gameplay Part 8 counterpart of
 * {@code RespawnLifecycleStore} (Gameplay Part 7), and, like it, the only class here that touches
 * {@link IPersistenceGateway}. It reuses that existing abstraction unchanged (no second repository
 * interface, no second generic persistence gateway): whether the data lives in memory, a file or a
 * database is invisible.
 *
 * <pre>
 * Health -&gt; HealthSnapshot -&gt; IPersistenceGateway -&gt; adapter -&gt; storage
 * storage -&gt; adapter -&gt; IPersistenceGateway -&gt; HealthSnapshot -&gt; validated recovery -&gt; Health
 * </pre>
 *
 * <p><b>This class stores; it decides nothing.</b> How damage changes {@code Health}
 * ({@code DamageApplicationService}), whether an entity may respawn, and default/max health for a
 * brand-new entity are not this class's business — it never creates a default {@code Health} for
 * an unknown entity (see {@link HealthLoadResult.NotFound}). It validates only what makes <em>a
 * record</em> trustworthy (schema, revision, timestamp, HP-value shape, identity).
 *
 * <h2>Consistency: optimistic revisions</h2>
 * Every stored record carries a {@code revision}: 1 on first save, +1 per save — the exact same
 * contract {@code RespawnLifecycleStore} established. {@link #save} takes the revision the caller
 * last read (0 = "I expect nothing stored") and writes only if it still matches — otherwise
 * {@link HealthSaveResult.VersionConflict}. This is what catches two callers advancing the same
 * stale read (e.g. two simultaneous damage applications). The check-then-write is <em>not</em>
 * atomic at the gateway: {@link IPersistenceGateway} has no conditional write, and inventing a fake
 * one would only pretend. Methods here are {@code synchronized}, which covers the single-process,
 * single-store-instance case this project runs today, the same limitation
 * {@code RespawnLifecycleStore} documents (and the same future extension point: a real
 * multi-process adapter needs a native compare-and-set on the gateway).
 *
 * <h2>Failure semantics</h2>
 * A store outage never looks like success or like "not found": {@link #load} returns
 * {@link HealthLoadResult.Failed} (cause preserved), {@link #save} lets the
 * {@link PersistenceException} propagate (the state was NOT saved). Only {@code PersistenceException}
 * is translated — programming errors are not swallowed. Corrupt or unknown-schema records are
 * reported ({@link HealthLoadResult.Corrupt}) and never overwritten by {@link #save}; removing one
 * is the explicit {@link #discard}.
 *
 * <p>Deterministic: {@code savedAt} comes from the injected {@link Clock}; the same stored
 * snapshot always loads to an equal {@code Health}.
 */
public final class HealthStore {

    static final String COLLECTION = "entity-health";

    private final IPersistenceGateway persistence;
    private final Clock clock;
    private final HealthSnapshotMapper mapper = new HealthSnapshotMapper();

    public HealthStore(IPersistenceGateway persistence) {
        this(persistence, Clock.systemUTC());
    }

    public HealthStore(IPersistenceGateway persistence, Clock clock) {
        this.persistence = Objects.requireNonNull(persistence, "persistence");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /** Loads and validates the stored health of {@code entity}. Never throws for storage or data problems. */
    public synchronized HealthLoadResult load(EntityRef entity) {
        Objects.requireNonNull(entity, "entity");
        Optional<HealthSnapshot> found;
        try {
            found = persistence.load(COLLECTION, keyOf(entity), HealthSnapshot.class);
        } catch (PersistenceException e) {
            return new HealthLoadResult.Failed(entity, "could not read health of " + entity + ": "
                    + e.getMessage(), e);
        }
        if (found.isEmpty()) {
            return new HealthLoadResult.NotFound(entity);
        }
        HealthSnapshot snapshot = found.get();
        if (!entity.equals(snapshot.entity())) {
            return new HealthLoadResult.Corrupt(entity, HealthRecoveryFailure.IDENTITY_MISMATCH,
                    "record stored for " + entity + " describes " + snapshot.entity());
        }
        return switch (mapper.restore(snapshot)) {
            case HealthRecoveryResult.Recovered r -> new HealthLoadResult.Loaded(entity, r.health(), r.revision());
            case HealthRecoveryResult.Rejected r -> new HealthLoadResult.Corrupt(entity, r.reason(), r.detail());
        };
    }

    /**
     * Saves {@code health} if the stored revision is still {@code expectedRevision} (0 when the
     * caller expects nothing to be stored yet). Returns {@link HealthSaveResult.Saved} with the new
     * revision, {@link HealthSaveResult.VersionConflict} (nothing written) or
     * {@link HealthSaveResult.Blocked} (nothing written).
     *
     * @throws PersistenceException the store could not be read or written; the health is NOT saved
     * @throws IllegalArgumentException {@code expectedRevision} is negative
     */
    public synchronized HealthSaveResult save(EntityRef entity, Health health, long expectedRevision) {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(health, "health");
        if (expectedRevision < 0) {
            throw new IllegalArgumentException("expectedRevision must not be negative (was " + expectedRevision + ")");
        }
        Optional<HealthSnapshot> existing = persistence.load(COLLECTION, keyOf(entity), HealthSnapshot.class);

        long actualRevision = 0;
        if (existing.isPresent()) {
            HealthSnapshot stored = existing.get();
            if (!entity.equals(stored.entity())) {
                return new HealthSaveResult.Blocked(entity, HealthRecoveryFailure.IDENTITY_MISMATCH);
            }
            if (mapper.restore(stored) instanceof HealthRecoveryResult.Rejected rejected) {
                return new HealthSaveResult.Blocked(entity, rejected.reason());
            }
            actualRevision = stored.revision();
        }
        if (actualRevision != expectedRevision) {
            return new HealthSaveResult.VersionConflict(entity, expectedRevision, actualRevision);
        }

        long next = expectedRevision + 1;
        persistence.save(COLLECTION, keyOf(entity), mapper.toSnapshot(health, entity, next, clock.instant()));
        return new HealthSaveResult.Saved(entity, next);
    }

    /**
     * Removes whatever is stored for {@code entity} — the explicit, deliberate way out of a
     * {@link HealthSaveResult.Blocked} record. Not part of normal operation; not versioned.
     *
     * @throws PersistenceException the store could not be written
     */
    public synchronized void discard(EntityRef entity) {
        Objects.requireNonNull(entity, "entity");
        persistence.delete(COLLECTION, keyOf(entity));
    }

    private static String keyOf(EntityRef entity) {
        return entity.kind().name() + ":" + entity.id();
    }
}
