package combat.services;

import core.domain.EntityRef;
import java.util.Objects;

/**
 * The outcome of {@link HealthStore#save}, mirroring {@code RespawnSaveResult}'s (Gameplay Part 7)
 * shape exactly. A storage <em>failure</em> is not one of these: it is a
 * {@link core.contracts.PersistenceException} thrown to the caller, so it cannot be mistaken for
 * any result here.
 * <ul>
 *   <li>{@link Saved} — written; {@code revision} is the new stored revision to pass on the next save;</li>
 *   <li>{@link VersionConflict} — someone else saved first (or the caller's copy is stale); nothing written;</li>
 *   <li>{@link Blocked} — a record exists but is unreadable (unknown schema, corrupt content, wrong
 *       identity); nothing written, because overwriting it would destroy data this code does not
 *       understand.</li>
 * </ul>
 */
public sealed interface HealthSaveResult {

    EntityRef entity();

    record Saved(EntityRef entity, long revision) implements HealthSaveResult {
        public Saved {
            Objects.requireNonNull(entity, "entity");
            if (revision < 1) {
                throw new IllegalArgumentException("a saved revision is at least 1 (was " + revision + ")");
            }
        }
    }

    /** {@code actualRevision} is 0 when nothing is stored. */
    record VersionConflict(EntityRef entity, long expectedRevision, long actualRevision) implements HealthSaveResult {
        public VersionConflict {
            Objects.requireNonNull(entity, "entity");
            if (expectedRevision < 0 || actualRevision < 0) {
                throw new IllegalArgumentException("revisions are not negative");
            }
            if (expectedRevision == actualRevision) {
                throw new IllegalArgumentException("a conflict needs differing revisions");
            }
        }
    }

    record Blocked(EntityRef entity, HealthRecoveryFailure reason) implements HealthSaveResult {
        public Blocked {
            Objects.requireNonNull(entity, "entity");
            Objects.requireNonNull(reason, "reason");
        }
    }
}
