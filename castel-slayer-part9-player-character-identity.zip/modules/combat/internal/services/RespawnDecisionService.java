package combat.services;

import combat.contracts.IRespawnPointProvider;
import combat.contracts.RespawnDecision;
import combat.contracts.RespawnDenialReason;
import combat.contracts.RespawnPoint;
import combat.contracts.RespawnRequest;
import combat.domain.Health;
import combat.domain.RespawnEligibility;
import core.domain.EntityKind;
import core.domain.EntityRef;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * The Gameplay Part 5 respawn rules, as a pure service:
 *
 * <pre>
 * EntityDied -&gt; RespawnRequest -&gt; eligibility -&gt; destination -&gt; RespawnDecision
 * </pre>
 *
 * <p>Two questions, answerable separately or together:
 * <ol>
 *   <li>{@link #evaluateEligibility}: may this entity respawn at all? No if its {@link Health} says
 *       it is alive ({@link RespawnDenialReason#ENTITY_ALIVE}) or if its {@link EntityKind} is not
 *       in the configured respawnable set ({@link RespawnDenialReason#KIND_NOT_RESPAWNABLE}).</li>
 *   <li>{@link #resolveDestination}: where? Asks the injected {@link IRespawnPointProvider}.</li>
 * </ol>
 * {@link #decide} composes the two (eligibility first) into an immutable {@link RespawnDecision}.
 *
 * <p>Nothing is hardcoded about <em>who</em> respawns: not "player", not a world, not a bed. Which
 * {@link EntityKind}s may respawn is constructor data (an empty set is valid: nobody respawns), and
 * destinations come only from the provider. Health logic is not re-implemented — eligibility reads
 * {@link Health#isAlive()}, the one definition of alive/dead.
 *
 * <p>Stateless and deterministic: no clock, no random, no static state; the same inputs and the same
 * provider answers yield equal results. A provider that throws propagates its exception (never
 * swallowed into a denial); a provider that returns a {@code null} {@code Optional} is a
 * programming error and fails fast. Nothing here teleports, revives, penalises or persists.
 */
public final class RespawnDecisionService {

    private final IRespawnPointProvider destinations;
    private final Set<EntityKind> respawnableKinds;

    public RespawnDecisionService(IRespawnPointProvider destinations, Set<EntityKind> respawnableKinds) {
        this.destinations = Objects.requireNonNull(destinations, "destinations");
        Objects.requireNonNull(respawnableKinds, "respawnableKinds");
        this.respawnableKinds = Set.copyOf(respawnableKinds);
    }

    /** Alive entities and non-respawnable kinds are ineligible; everything else is eligible. */
    public RespawnEligibility evaluateEligibility(EntityRef entity, Health health) {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(health, "health");
        if (health.isAlive()) {
            return RespawnEligibility.ineligible(entity, RespawnDenialReason.ENTITY_ALIVE);
        }
        if (!respawnableKinds.contains(entity.kind())) {
            return RespawnEligibility.ineligible(entity, RespawnDenialReason.KIND_NOT_RESPAWNABLE);
        }
        return RespawnEligibility.eligible(entity);
    }

    /** The provider's destination for {@code entity}, or empty when it has none. */
    public Optional<RespawnPoint> resolveDestination(EntityRef entity) {
        Objects.requireNonNull(entity, "entity");
        Optional<RespawnPoint> found = destinations.findRespawnPoint(entity);
        return Objects.requireNonNull(found, "IRespawnPointProvider returned null instead of Optional");
    }

    /**
     * Eligibility, then destination. Denied with the eligibility reason if ineligible; denied with
     * {@link RespawnDenialReason#NO_RESPAWN_POINT} if eligible but the provider has no destination;
     * otherwise granted. The provider is not consulted for an ineligible entity.
     */
    public RespawnDecision decide(RespawnRequest request, Health health) {
        Objects.requireNonNull(request, "request");
        Objects.requireNonNull(health, "health");
        EntityRef entity = request.entity();

        RespawnEligibility eligibility = evaluateEligibility(entity, health);
        if (!eligibility.isEligible()) {
            return new RespawnDecision.Denied(entity, eligibility.denialReason().orElseThrow(), request.requestedAt());
        }
        return resolveDestination(entity)
                .<RespawnDecision>map(point -> new RespawnDecision.Granted(entity, point, request.requestedAt()))
                .orElseGet(() -> new RespawnDecision.Denied(
                        entity, RespawnDenialReason.NO_RESPAWN_POINT, request.requestedAt()));
    }
}
