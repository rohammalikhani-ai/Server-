package combat.domain;

import combat.contracts.RespawnDenialReason;
import core.domain.EntityRef;
import java.util.Objects;
import java.util.Optional;

/**
 * Whether an entity <em>may</em> respawn at all — separate from <em>where</em> (a destination) so
 * the two questions can be answered, and recorded in the lifecycle, one after the other.
 * Immutable; either eligible (no denial) or ineligible with exactly one {@link RespawnDenialReason}.
 */
public record RespawnEligibility(EntityRef entity, Optional<RespawnDenialReason> denialReason) {

    public RespawnEligibility {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(denialReason, "denialReason");
    }

    public static RespawnEligibility eligible(EntityRef entity) {
        return new RespawnEligibility(entity, Optional.empty());
    }

    public static RespawnEligibility ineligible(EntityRef entity, RespawnDenialReason reason) {
        Objects.requireNonNull(reason, "reason");
        return new RespawnEligibility(entity, Optional.of(reason));
    }

    public boolean isEligible() {
        return denialReason.isEmpty();
    }
}
