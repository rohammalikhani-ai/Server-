package combat.domain;

/**
 * Where an entity is in the death-to-respawn lifecycle. Five states, one forward path, one loop:
 *
 * <pre>
 * ALIVE --died--&gt; DEAD --eligible--&gt; RESPAWN_ELIGIBLE --destination--&gt; RESPAWN_DECIDED
 *   ^                                                                        |
 *   |                                                                  execution requested
 *   |                                                                        v
 *   +------------- execution succeeded ------------- RESPAWN_EXECUTION_REQUESTED
 *                                                     |  execution failed -&gt; RESPAWN_DECIDED
 * </pre>
 */
public enum RespawnLifecycleStatus {
    /** Living. The start state, and the state after a confirmed respawn. */
    ALIVE(false),
    /** Death recorded; eligibility not yet evaluated (or evaluated and denied — still dead). */
    DEAD(false),
    /** Eligible to respawn; no destination chosen yet. */
    RESPAWN_ELIGIBLE(false),
    /** A destination has been decided; nothing has been asked of the platform yet. */
    RESPAWN_DECIDED(true),
    /** The execution boundary has been asked to respawn the entity; the outcome is not known yet. */
    RESPAWN_EXECUTION_REQUESTED(true);

    private final boolean carriesDestination;

    RespawnLifecycleStatus(boolean carriesDestination) {
        this.carriesDestination = carriesDestination;
    }

    /** True for exactly the states in which a decided destination is part of the state. */
    public boolean carriesDestination() {
        return carriesDestination;
    }
}
