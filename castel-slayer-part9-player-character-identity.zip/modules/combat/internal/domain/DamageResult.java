package combat.domain;

import core.domain.EntityRef;
import java.util.Objects;

/**
 * The outcome of running a {@link DamageRequest} through {@code combat.services.DamageCalculator}:
 * the final, immutable damage amount to apply, plus who dealt it, to whom, and of what
 * {@link DamageType}. This module stops here — subtracting {@code amount} from a
 * target's health is a future Gameplay Part's job (Health/HP is explicitly out of
 * scope for this one).
 *
 * <p>{@code amount} is clamped to a minimum of zero in its own constructor, not just
 * by the calculator that produces it — the same defense-in-depth pattern
 * {@code progression.domain.CharacterAttributes#effectiveValue} uses (its base value
 * can't be negative either, but the invariant is still enforced at the point where a
 * negative result could otherwise appear, since future Gameplay Parts — resistance,
 * damage reduction — will subtract from this value before it is floored).
 */
public record DamageResult(EntityRef source, EntityRef target, DamageType type, double amount) {

    public DamageResult {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(type, "type");
        if (Double.isNaN(amount) || Double.isInfinite(amount)) {
            throw new IllegalArgumentException("amount must be a finite number (was " + amount + ")");
        }
        amount = Math.max(amount, 0);
    }
}
