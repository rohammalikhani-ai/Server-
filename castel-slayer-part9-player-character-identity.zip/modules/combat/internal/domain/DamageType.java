package combat.domain;

/**
 * The category of a damage instance. Deliberately just a tag at this stage — no
 * resistance/weakness table, no elemental interaction matrix. Those are future
 * Gameplay Parts; this enum only lets a {@link DamageRequest}/{@link DamageResult}
 * say what kind of damage it is (requirement 8: future-proof extension point, not a
 * fake implementation of resistance).
 */
public enum DamageType {
    PHYSICAL,
    MAGICAL,
    FIRE,
    FROST,
    LIGHTNING,
    POISON,
    SHADOW,
    HOLY
}
