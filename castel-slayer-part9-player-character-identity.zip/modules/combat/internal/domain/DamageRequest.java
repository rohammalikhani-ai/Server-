package combat.domain;

import core.domain.EntityRef;
import java.util.Objects;

/**
 * An attacker's request to deal damage to a target, before any calculation happens:
 * {@code Attacker -> DamageRequest -> DamageCalculator -> DamageResult}.
 *
 * <p>{@code source} and {@code target} are {@link EntityRef}, not {@code PlayerId} or
 * {@code character.contracts.CharacterId} directly — combat must accept a player, an
 * NPC, or any other in-world entity uniformly (see {@link EntityRef}'s own Javadoc,
 * which names "who dealt this damage" as its intended use). Resolving a ref back into
 * a concrete player/character/NPC is the caller's job, not this module's.
 *
 * <p>{@code baseAmount} is the raw, pre-calculation damage value the attacker is
 * requesting. It must be zero or positive and finite — negative, {@code NaN}, or
 * infinite amounts are rejected here rather than silently clamped, consistent with
 * how other domain value objects in this project (e.g. {@code inventory.domain.ItemStack},
 * {@code progression.domain.CharacterAttributes}) reject invalid input at construction
 * instead of trusting the caller.
 *
 * <p>Immutable. Two requests are equal iff every field is equal (default record
 * equality) — a request is a value, not an identity.
 */
public record DamageRequest(EntityRef source, EntityRef target, DamageType type, double baseAmount) {

    public DamageRequest {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(type, "type");
        if (Double.isNaN(baseAmount) || Double.isInfinite(baseAmount)) {
            throw new IllegalArgumentException("baseAmount must be a finite number (was " + baseAmount + ")");
        }
        if (baseAmount < 0) {
            throw new IllegalArgumentException("baseAmount must not be negative (was " + baseAmount + ")");
        }
    }
}
