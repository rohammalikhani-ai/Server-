package combat.domain;

import combat.contracts.RespawnPoint;
import core.domain.EntityRef;
import java.util.Objects;
import java.util.Optional;

/**
 * One entity's position in the respawn lifecycle, as an immutable value — the same style as
 * {@link Health}: every transition returns a <em>new</em> state and the receiver is never modified,
 * so a caller that keeps the old value still has it. That is what makes "a failed execution must not
 * silently mutate core state" true by construction, not by discipline.
 *
 * <p>Invariant, enforced in the constructor (so it holds for every instance that can exist,
 * including ones rebuilt from a snapshot): a destination is present exactly in the states whose
 * {@link RespawnLifecycleStatus#carriesDestination()} is true.
 *
 * <p>Transition methods encode only <em>which moves are legal</em>; calling one from the wrong
 * state is a programming error and throws {@link IllegalStateException}. Callers that must answer
 * "is this a duplicate / out-of-order request?" without exceptions go through
 * {@code combat.services.RespawnLifecycleService}, which checks first and returns a result.
 * This type holds no {@link Health} — health stays {@code Health}'s single responsibility.
 */
public record RespawnLifecycleState(EntityRef entity, RespawnLifecycleStatus status,
                                    Optional<RespawnPoint> destination) {

    public RespawnLifecycleState {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(destination, "destination");
        if (status.carriesDestination() != destination.isPresent()) {
            throw new IllegalArgumentException("status " + status + (status.carriesDestination()
                    ? " requires a destination" : " must not carry a destination"));
        }
    }

    /** A living entity — where every lifecycle starts. */
    public static RespawnLifecycleState alive(EntityRef entity) {
        return new RespawnLifecycleState(entity, RespawnLifecycleStatus.ALIVE, Optional.empty());
    }

    public boolean isAlive() {
        return status == RespawnLifecycleStatus.ALIVE;
    }

    /** ALIVE -> DEAD. */
    public RespawnLifecycleState died() {
        requireStatus(RespawnLifecycleStatus.ALIVE, "died");
        return new RespawnLifecycleState(entity, RespawnLifecycleStatus.DEAD, Optional.empty());
    }

    /** DEAD -> RESPAWN_ELIGIBLE. */
    public RespawnLifecycleState eligible() {
        requireStatus(RespawnLifecycleStatus.DEAD, "eligible");
        return new RespawnLifecycleState(entity, RespawnLifecycleStatus.RESPAWN_ELIGIBLE, Optional.empty());
    }

    /** RESPAWN_ELIGIBLE -> RESPAWN_DECIDED, recording the destination. */
    public RespawnLifecycleState decided(RespawnPoint point) {
        Objects.requireNonNull(point, "point");
        requireStatus(RespawnLifecycleStatus.RESPAWN_ELIGIBLE, "decided");
        return new RespawnLifecycleState(entity, RespawnLifecycleStatus.RESPAWN_DECIDED, Optional.of(point));
    }

    /** RESPAWN_DECIDED -> RESPAWN_EXECUTION_REQUESTED (destination kept). */
    public RespawnLifecycleState executionRequested() {
        requireStatus(RespawnLifecycleStatus.RESPAWN_DECIDED, "executionRequested");
        return new RespawnLifecycleState(entity, RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED, destination);
    }

    /** RESPAWN_EXECUTION_REQUESTED -> ALIVE (destination dropped). */
    public RespawnLifecycleState respawned() {
        requireStatus(RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED, "respawned");
        return alive(entity);
    }

    /** RESPAWN_EXECUTION_REQUESTED -> RESPAWN_DECIDED: the same state as before the request, so a retry is possible. */
    public RespawnLifecycleState executionFailed() {
        requireStatus(RespawnLifecycleStatus.RESPAWN_EXECUTION_REQUESTED, "executionFailed");
        return new RespawnLifecycleState(entity, RespawnLifecycleStatus.RESPAWN_DECIDED, destination);
    }

    private void requireStatus(RespawnLifecycleStatus expected, String transition) {
        if (status != expected) {
            throw new IllegalStateException("cannot apply '" + transition + "' in status " + status
                    + " (requires " + expected + ")");
        }
    }
}
