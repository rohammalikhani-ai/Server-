package combat.domain;

import java.util.Objects;

/**
 * A hit-point pool: current HP, maximum HP, and the alive/dead state derived from them.
 * The Gameplay Part 2 counterpart of {@link DamageResult}:
 * {@code DamageResult -> Health.apply(...) -> new Health}.
 *
 * <p>Immutable value object, in the same style as {@link DamageRequest}/{@link DamageResult}.
 * Every "change" ({@link #apply(DamageResult)}) returns a new {@code Health}; the receiver is
 * never modified. Two values are equal iff both {@code current} and {@code max} are equal.
 *
 * <p>Invariants, enforced in the constructor and therefore true for every instance that
 * can exist (so they hold after every operation):
 * <ul>
 *   <li>{@code max} is finite and strictly positive;</li>
 *   <li>{@code current} is finite and {@code 0 <= current <= max}.</li>
 * </ul>
 * Invalid values are rejected with {@link IllegalArgumentException}, never silently clamped —
 * the same policy as {@link DamageRequest#baseAmount()}. (Damage that would drive HP below
 * zero is different: that is a legitimate game event, not invalid input, so
 * {@link #apply(DamageResult)} floors the result at zero.)
 *
 * <p>HP is a {@code double} because {@link DamageResult#amount()} is one; using the same
 * numeric type means no rounding rule has to be invented here. The alive/dead state is
 * derived from {@code current} alone (dead iff {@code current == 0}), so it cannot disagree
 * with the HP value and is fully deterministic.
 *
 * <p>This type does not know who owns it. Deciding which {@code Health} a
 * {@link DamageResult#target()} refers to, and storing the new value back, is combat
 * orchestration — a later Gameplay Part. It also does not heal, regenerate, or publish
 * death events (all out of scope for this Part).
 */
public record Health(double current, double max) {

    public Health {
        if (Double.isNaN(max) || Double.isInfinite(max)) {
            throw new IllegalArgumentException("max HP must be a finite number (was " + max + ")");
        }
        if (max <= 0) {
            throw new IllegalArgumentException("max HP must be greater than zero (was " + max + ")");
        }
        if (Double.isNaN(current) || Double.isInfinite(current)) {
            throw new IllegalArgumentException("current HP must be a finite number (was " + current + ")");
        }
        if (current < 0) {
            throw new IllegalArgumentException("current HP must not be negative (was " + current + ")");
        }
        if (current > max) {
            throw new IllegalArgumentException(
                    "current HP must not exceed max HP (current " + current + ", max " + max + ")");
        }
        // Normalise -0.0 to 0.0 so that equal HP is always equal as a value.
        current = current == 0 ? 0.0 : current;
    }

    /** A new pool at full health: {@code current == max}. Rejects an invalid {@code max}. */
    public static Health full(double max) {
        return new Health(max, max);
    }

    /** True while {@code current > 0}. */
    public boolean isAlive() {
        return current > 0;
    }

    /** True once {@code current} has reached zero. Always the exact opposite of {@link #isAlive()}. */
    public boolean isDead() {
        return !isAlive();
    }

    /**
     * Applies the damage in {@code damage} and returns the resulting health. {@code current}
     * is reduced by {@code damage.amount()} and floored at zero, so it can never go negative;
     * {@code max} is unchanged and {@code current} can never exceed it. Zero damage, or damage
     * to an already-dead pool, returns an equal value (the same instance). The receiver is
     * never modified.
     */
    public Health apply(DamageResult damage) {
        Objects.requireNonNull(damage, "damage");
        double amount = damage.amount();
        if (amount == 0 || current == 0) {
            return this;
        }
        return new Health(Math.max(current - amount, 0), max);
    }
}
