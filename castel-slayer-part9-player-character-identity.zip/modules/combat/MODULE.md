# combat

## Purpose

Damage resolution and (future) skills/abilities, server-authoritative combat rules
(see `PROJECT_MAP.md`). Gameplay Part 1 established the damage foundation:
`Attacker -> DamageRequest -> DamageCalculator -> DamageResult`. Gameplay Part 2 adds the
Health/HP value object and its integration with `DamageResult`:
`DamageResult -> Health.apply(...) -> Health`. Gameplay Part 3 adds the orchestration step
that applies a calculated `DamageResult` to a target's `Health`:
`DamageResult + Target Health -> DamageApplicationService.apply(...) -> New Health`.
Gameplay Part 4 adds the death transition/event: `DamageApplicationService.applyDetectingDeath(...)`
runs the same application and additionally detects the alive-to-dead transition, returning
a `DamageApplicationResult(Health, List<EntityDied>)` — `combat.events.EntityDied` is this
module's first published event.
Gameplay Part 5 adds the neutral Respawn foundation: `combat.contracts.RespawnPoint` (a platform-
neutral destination wrapping `core.domain.Location`), `IRespawnPointProvider` (the extension point
for "where does this entity respawn"), `RespawnRequest`/`RespawnDecision` (Granted/Denied), and
`combat.services.RespawnDecisionService`, a pure service answering "may this entity respawn, and
where" — `EntityDied -> RespawnRequest -> eligibility -> destination -> RespawnDecision`. Gameplay
Part 6 adds the lifecycle boundary: `combat.domain.RespawnLifecycleState`/`RespawnLifecycleStatus`
(an immutable five-state value: ALIVE, DEAD, RESPAWN_ELIGIBLE, RESPAWN_DECIDED,
RESPAWN_EXECUTION_REQUESTED) and `combat.services.RespawnLifecycleService`, which drives that state
through death, eligibility, destination, execution-request and execution-completion, each a
separate, retryable step. The actual "bring the entity back" step never happens in this module —
`combat.contracts.IRespawnExecutor` is the execution boundary, implemented outside the core (see
`RespawnExecutionRequest`/`RespawnExecutionResult`, `combat.events.EntityRespawned`). Gameplay Part
7 adds the persistence boundary for that lifecycle state: `combat.contracts.RespawnLifecycleSnapshot`
(the immutable, plain-data persistence model — schema version, optimistic-concurrency revision,
entity, status name, destination, timestamp), `combat.services.RespawnLifecycleSnapshotMapper`
(validated, non-repairing two-way mapping to/from `RespawnLifecycleState`), and
`combat.services.RespawnLifecycleStore` (this module's `IPersistenceGateway`-backed save/load/
discard, with optimistic revision checks and explicit failure/corruption reporting — see
"Gameplay Part 7 — Respawn Persistence" below for the full contract).

Everything else this module will eventually own (weapons, armor, crit, resistance, abilities, PvP
rules, target-health storage, healing/regeneration, respawn timers, penalties/rewards, and a real
`IRespawnPointProvider`/`IRespawnExecutor` implementation) is future Gameplay Parts.

## Responsibilities

- Naming the damage categories the game supports (`combat.domain.DamageType`).
- Modeling an attacker's request to deal damage before any calculation
  (`combat.domain.DamageRequest`): who dealt it, who it targets, what type, how much,
  validated at construction (finite, non-negative amount; non-null fields).
- Turning a validated request into a final, immutable damage amount, deterministically
  and without introducing randomness (`combat.services.DamageCalculator` ->
  `combat.domain.DamageResult`).
- Modeling a hit-point pool (`combat.domain.Health`): current HP, maximum HP, alive/dead, and
  `apply(DamageResult)` returning a new `Health`. Immutable; validated at construction
  (max finite and > 0, `0 <= current <= max`), so every instance is valid after every
  operation. HP is a `double` to match `DamageResult.amount()`. Dead iff `current == 0`.
- Orchestrating "apply this calculated `DamageResult` to this target's `Health`"
  (`combat.services.DamageApplicationService`): a stateless, deterministic
  `apply(DamageResult, Health) -> Health` that delegates to `Health.apply(...)` and adds
  null-safety at the boundary. Does not resolve, store, or persist a target's `Health` by
  identity — the caller supplies it and receives the result.
- Detecting the death transition and producing its event (`combat.services.DamageApplicationService
  .applyDetectingDeath(DamageResult, Health) -> DamageApplicationResult`): applies damage exactly as
  `apply` does, and additionally compares `targetHealth.isAlive()` before the call to the
  resulting `Health.isDead()` after it. Only an alive-to-dead transition produces a
  `combat.events.EntityDied` (`target`, `source`, `occurredAt`) in the returned
  `DamageApplicationResult.events()` — non-lethal damage, zero damage, and further damage to an
  already-dead target all produce none, so no duplicate death event is possible. Does not
  publish the event itself (no `core.contracts.IEventBus` dependency, no global mutable bus) —
  the caller receives it and decides how/whether to publish it, the same pattern
  `progression.services.LevelingService` uses for `CharacterLeveledUp`.

## Files

```
modules/combat/
├── MODULE.md                         (this file)
├── build.gradle.kts
├── public/
│   ├── contracts/
│   │   ├── RespawnPoint.java              destination wrapper around core.domain.Location
│   │   ├── IRespawnPointProvider.java     extension point: EntityRef -> Optional<RespawnPoint> (no impl here)
│   │   ├── RespawnDenialReason.java       ENTITY_ALIVE, KIND_NOT_RESPAWNABLE, NO_RESPAWN_POINT
│   │   ├── RespawnRequest.java            entity + requestedAt; RespawnRequest.from(EntityDied)
│   │   ├── RespawnDecision.java           sealed Granted(destination) / Denied(reason)
│   │   ├── RespawnExecutionRequest.java   the command across the execution boundary
│   │   ├── RespawnExecutionResult.java    sealed Succeeded(destination) / Failed(reason)
│   │   ├── IRespawnExecutor.java          execution-boundary extension point (no impl here)
│   │   ├── RespawnLifecycleSnapshot.java  persistence model: schemaVersion, revision, entity, status, destination, savedAt
│   │   └── HealthSnapshot.java            persistence model: schemaVersion, revision, entity, current, max, savedAt
│   └── events/
│       ├── EntityDied.java                target, source, occurredAt — published on the alive-to-dead transition
│       └── EntityRespawned.java           entity, destination, occurredAt — published on confirmed respawn
└── internal/
    ├── domain/
    │   ├── DamageType.java           Physical, Magical, Fire, Frost, Lightning, Poison, Shadow, Holy
    │   ├── DamageRequest.java        attacker's request: source, target, type, baseAmount
    │   ├── DamageResult.java         final, immutable damage amount (clamped >= 0)
    │   ├── Health.java               immutable HP pool: current, max, isAlive/isDead, apply(DamageResult)
    │   ├── RespawnEligibility.java   entity + optional RespawnDenialReason
    │   ├── RespawnLifecycleStatus.java   ALIVE, DEAD, RESPAWN_ELIGIBLE, RESPAWN_DECIDED, RESPAWN_EXECUTION_REQUESTED
    │   └── RespawnLifecycleState.java    immutable per-entity lifecycle value + its transition methods
    └── services/
        ├── DamageCalculator.java             pure, deterministic DamageRequest -> DamageResult
        ├── DamageApplicationService.java      orchestration: DamageResult + Health -> new Health,
        │                                       plus applyDetectingDeath(...) -> DamageApplicationResult
        ├── DamageApplicationResult.java       outcome record: Health + List<EntityDied>
        ├── RespawnDecisionService.java        eligibility + destination -> RespawnDecision
        ├── RespawnLifecycleService.java       drives RespawnLifecycleState through death/eligibility/
        │                                       destination/execution-request/execution-completion
        ├── RespawnLifecycleOutcome.java       APPLIED, DUPLICATE, DENIED, REJECTED, EXECUTION_FAILED
        ├── RespawnLifecycleResult.java        outcome record for every RespawnLifecycleService call
        ├── RespawnLifecycleSnapshotMapper.java  validated, non-repairing State <-> Snapshot mapping
        ├── RespawnRecoveryFailure.java        why a stored snapshot failed validation (closed set)
        ├── RespawnRecoveryResult.java          sealed Recovered(state, revision) / Rejected(reason, detail)
        ├── RespawnLifecycleStore.java          IPersistenceGateway-backed save/load/discard with revisions
        ├── RespawnLoadResult.java              sealed Loaded/NotFound/Corrupt/Failed
        ├── RespawnSaveResult.java              sealed Saved/VersionConflict/Blocked
        ├── HealthSnapshotMapper.java           validated, non-repairing Health <-> HealthSnapshot mapping
        ├── HealthRecoveryFailure.java          why a stored health snapshot failed validation (closed set)
        ├── HealthRecoveryResult.java           sealed Recovered(health, revision) / Rejected(reason, detail)
        ├── HealthStore.java                    IPersistenceGateway-backed save/load/discard with revisions, by EntityRef
        ├── HealthLoadResult.java               sealed Loaded/NotFound/Corrupt/Failed
        ├── HealthSaveResult.java               sealed Saved/VersionConflict/Blocked
        ├── HealthResolutionService.java        resolve(EntityRef) -> HealthResolutionResult; no silent default Health
        └── HealthResolutionResult.java         sealed Resolved/NotFound/Corrupt/Failed
```

Tests mirror this under `tests/modules/combat/{domain,services,events,contracts}/`.

## Dependencies

- `core.domain.EntityRef` (and transitively `EntityKind`, `PlayerId`) — `source`/`target`
  are `EntityRef`, not `PlayerId` or `character.contracts.CharacterId` directly, because a
  damage source or target can be a player, an NPC, or any other in-world entity, and
  `EntityRef` already exists in `core.domain` for exactly this "who dealt this damage"
  case. No dependency on `character`, `progression`, `inventory`, or any other module.
- `core.domain.Location` (Gameplay Part 5) — `RespawnPoint` wraps it; no Minecraft/Bukkit
  location type is used anywhere in this module.
- `core.contracts.IPersistenceGateway` (Gameplay Part 7) — see "Interfaces Consumed" below.
- No dependency on Bukkit/Paper/any Minecraft or third-party plugin API, or on
  `platform/*` — buildable/testable standalone.

## Public Interfaces Exposed

- `combat.events.EntityDied` (`public/events`) — published when a Damage Application
  transitions a target's `Health` from alive to dead. Carries only `target`, `source`
  (both `core.domain.EntityRef`) and `occurredAt`; no HP values, no `DamageType`, no
  `Health` snapshot. This module does not publish it itself — `DamageApplicationService
  .applyDetectingDeath` returns it to the caller, who publishes it through
  `core.contracts.IEventBus` (or not at all) at their discretion.

- `combat.events.EntityRespawned` (`public/events`) — published exactly once when a respawn
  execution is confirmed successful by `RespawnLifecycleService.completeExecution`. Carries
  `entity`, `destination`, `occurredAt`. Returned in `RespawnLifecycleResult.events()`, never
  published by this module itself — same "caller decides" pattern as `EntityDied`.
- `combat.contracts.RespawnPoint`, `RespawnRequest`, `RespawnDecision`, `RespawnDenialReason` —
  the Part 5 respawn-rules vocabulary; `RespawnDecision` is sealed (`Granted`/`Denied`).
- `combat.contracts.IRespawnPointProvider` — extension point ("where would this entity respawn").
  No implementation in this module; a real source (saved bed/checkpoint, world default, ...) is
  wired in at the composition root by whichever module/adapter owns that concept.
- `combat.contracts.IRespawnExecutor`, `RespawnExecutionRequest`, `RespawnExecutionResult` — the
  Part 6 execution boundary. `IRespawnExecutor` has no implementation in this module; a platform
  adapter implements it to actually teleport/revive. This module only ever produces the request and
  consumes the result.
- `combat.contracts.RespawnLifecycleSnapshot` — the Part 7 persistence model for
  `combat.domain.RespawnLifecycleState`. Other modules do not currently consume this module's
  lifecycle state, so nothing beyond the snapshot type itself is exposed for persistence purposes.

## Interfaces Consumed

- `core.contracts.IPersistenceGateway` (Gameplay Part 7) — `combat.services.RespawnLifecycleStore`
  is the only class in this module that depends on it. Reuses the existing interface unchanged;
  no new repository abstraction was introduced. The concrete gateway (in-memory today; a real
  database later, chosen by the `persistence` module) is invisible to everything else here.

## Configuration

None. No tunable values exist yet at this stage (no stat scaling, no resistance).

## External dependency check (Gameplay Part 1)

Checked for a mature public damage-model/combat-calculation library before
implementing (`DESIGN_PRINCIPLES.md` rule 5). Nothing suitable was found: available
options were either game projects rather than reusable libraries, in a different
language (e.g. a C# D&D-5e-SRD combat engine, Rust rule-set crates), or bring in far
more than this stage needs (attack rolls, saving throws, spellcasting) while being
tied to a specific ruleset this project doesn't use. Implemented internally; no new
`integrations/` adapter or decision record was needed as a result.

## Health/HP external dependency check (Gameplay Part 2)

Checked again before implementing `Health`. Nothing adopted:
- `Bernardo-MG/tabletop-stats-java` (Apache-2.0, archived 2017, Java 7/8) — derived stats /
  attributes for tabletop games, not an HP pool or damage integration; unmaintained.
- `HGS Rpg Stats` (`homy-game-studio/hgs-unity-rpg-stats`) — has a close `Vital` (current/max,
  decrease, empty/full events) idea, but it is C#/Unity, mutable and event-based.
- Bukkit plugins such as RPGHealth — Bukkit-coupled (forbidden in `core`/`modules`) and
  command/config oriented rather than a domain model.
- Assorted hobby RPG repos — applications, not reusable libraries.
No `integrations/` adapter or decision record was needed.

## Damage application external dependency check (Gameplay Part 3)

Checked again before implementing `DamageApplicationService` (`DESIGN_PRINCIPLES.md` rule 5).
Nothing adopted:
- General-purpose Java "orchestrator"/workflow libraries found on Maven Central and GitHub
  (e.g. `com.github.eriche39:orchestrator`) are infrastructure/process-orchestration tools
  (chaining remote/async steps, retries, sagas) with no notion of a combat damage model —
  adopting one to call a single pure method would add a dependency and a mental model far
  bigger than the problem.
- Full ECS/game-engine frameworks (e.g. `artemis-odb`) contain damage/health-adjacent systems,
  but as part of a whole entity-component-system runtime this project doesn't use — adopting one
  for a single orchestration method would be a large, unrelated architectural commitment
  (requirement 8: future-proof, not over-engineered).
- No standalone, license-clear Java library was found that does only "apply a calculated damage
  amount to a health pool and return the result" — this is a small enough operation, and specific
  enough to this project's `Health`/`DamageResult` types, that a library adds no real value over
  the few lines `DamageApplicationService` needs.
No `integrations/` adapter or decision record was needed as a result.

## Death event external dependency check (Gameplay Part 4)

Checked again before implementing the death transition/event (`DESIGN_PRINCIPLES.md` rule 5).
Nothing adopted:
- Bukkit/Paper `EntityDeathEvent` and Forge/NeoForge `LivingDeathEvent` (see e.g.
  `PaperMC/Paper` commit `4e30b91d4eabcf6738ed7881837968a4bdca6242`, the "Improve death events"
  Spigot-Server patch, and `henkelmax/corelib`'s `DeathEvents`) — real, mature death-event
  patterns, but Minecraft/Bukkit/Forge-coupled by construction (extend `EntityEvent`/post to a
  Forge `EVENT_BUS`); this module must not depend on Bukkit/Paper/Minecraft types
  (`DESIGN_PRINCIPLES.md` rule 3, and this Part's explicit "No Bukkit/Paper/Minecraft
  dependency" requirement) and could only ever be consumed from `platform/*`, not from `core`
  or `modules`.
- `tfredrich/Domain-Eventing` (Java, Apache-2.0) — a general-purpose
  DDD domain-event *bus* with an internal queue and asynchronous processing (optionally
  clustered via Akka/HazelCast). Adopting it would mean depending on a second, competing
  event-bus abstraction alongside this project's own `core.contracts.IEventBus`, plus internal
  queueing/async infrastructure this Part doesn't need — and this Part's requirement is
  explicitly "no global mutable event bus," which an internal-queue bus is closer to, not
  further from.
- `banq/jdonframework` (Apache-2.0) — a full DDD pub/sub framework (CQRS, event sourcing,
  distributed sagas, LMAX Disruptor) far beyond "detect an HP-to-zero transition and hand back
  an immutable event"; adopting it for that would be a large, unrelated architectural
  commitment (requirement 8: future-proof, not over-engineered), and it still doesn't replace
  this project's own `IEventBus`/`GameEvent` convention that every other module-owned event
  (`CharacterCreated`, `CharacterLeveledUp`, ...) already follows — consistency with that
  existing convention matters more here than any external library's feature set.
No standalone, license-clear, engine-agnostic Java library was found that does only "detect
an alive-to-dead HP transition and produce an immutable domain event for the caller to
publish" in a shape compatible with this project's existing `core.events.GameEvent`/
`IEventBus` conventions — this is a small enough operation, and specific enough to this
project's own `Health`/`DamageResult`/`GameEvent` types, that a library adds no real value
over the same pattern `progression.services.LevelingService`/`LevelingResult` already
established for `CharacterLeveledUp`. No `integrations/` adapter or decision record was
needed as a result.

## Tests

`tests/modules/combat/domain/DamageTypeTest.java` (1 method),
`tests/modules/combat/domain/DamageRequestTest.java` (9 methods),
`tests/modules/combat/domain/DamageResultTest.java` (6 methods),
`tests/modules/combat/services/DamageCalculatorTest.java` (8 methods),
`tests/modules/combat/domain/HealthTest.java` (22 methods),
`tests/modules/combat/services/DamageApplicationServiceTest.java` (37 methods: the original 13
covering `apply`, plus 24 new covering `applyDetectingDeath` — lethal/overkill/non-lethal/zero
damage, already-dead no-duplicate, exact-zero HP, one-HP-remaining non-death, immutability,
determinism, null inputs, a null `Clock`, and the complete
`DamageRequest -> DamageCalculator -> DamageResult -> DamageApplicationService -> Death
detection/event` path both with and without a kill),
`tests/modules/combat/services/DamageApplicationResultTest.java` (4 methods: null `health`/`events`
rejection, empty-events, one-event carry), `tests/modules/combat/events/EntityDiedTest.java`
(6 methods: `GameEvent` membership, field access, null rejection per field, value equality) —
using `tests/support`'s `@Test`/`Assertions`/`TestRunner` harness, the same harness every other
module's tests use.

## Gameplay Part 5 — Respawn Foundation (added)

Answers only "what does it mean for an entity to have a respawn point, and how does a dead entity
receive a destination decision" — nothing here teleports or revives anything.

- `combat.contracts.RespawnPoint(Location)` — the neutral respawn-destination concept. Not "bed",
  not "world spawn": just a validated `Location`. Invalid destinations (blank world, non-finite
  coordinates/rotation) are unrepresentable — `Location`'s own constructor rejects them.
- `combat.contracts.IRespawnPointProvider` — `EntityRef -> Optional<RespawnPoint>`. An interface
  with no implementation (per `DEVELOPMENT_RULES.md`); a real source is future work.
- `combat.contracts.RespawnRequest(entity, requestedAt)`, with `RespawnRequest.from(EntityDied)` —
  the bridge from the existing death pipeline: `Damage -> Health dead -> EntityDied ->
  RespawnRequest`.
- `combat.domain.RespawnEligibility` and `combat.contracts.RespawnDenialReason` (`ENTITY_ALIVE`,
  `KIND_NOT_RESPAWNABLE`, `NO_RESPAWN_POINT`) — whether an entity may respawn at all, kept separate
  from where.
- `combat.contracts.RespawnDecision` — sealed `Granted(entity, destination, decidedAt)` /
  `Denied(entity, reason, decidedAt)`. `decidedAt` is the request's timestamp, not a clock read
  here, so decisions are fully deterministic.
- `combat.services.RespawnDecisionService(IRespawnPointProvider, Set<EntityKind>)` — pure,
  stateless. `evaluateEligibility` checks `Health.isAlive()` (reused, not duplicated) then the
  injected respawnable-kinds set (no "player" assumption: any `EntityKind` set, including empty,
  is valid config); `resolveDestination` asks the provider; `decide` composes both, denying
  `NO_RESPAWN_POINT` when eligible but the provider has nothing. The provider is never consulted
  for an ineligible entity.

**Respawn external dependency check (Gameplay Part 5):** searched for a reusable respawn/spawn-point
domain library before implementing. Nothing suitable: `PlayerRespawnEvent`/`PlayerPostRespawnEvent`
(PaperMC/Paper, MIT/GPL-hybrid per-file, mostly public-domain-style Bukkit headers) are Bukkit
lifecycle *events*, not a respawn-rules domain model, and Minecraft-coupled (forbidden in
`core`/`modules`); no standalone, license-clear "eligibility + destination decision" library was
found. Implemented internally; no `integrations/` adapter or decision record needed.

## Gameplay Part 6 — Respawn Lifecycle Boundary (added)

Defines the application/domain-level lifecycle cleanly, per the task's five required distinctions,
and the explicit execution boundary Minecraft-specific code sits behind.

- `combat.domain.RespawnLifecycleStatus` — `ALIVE`, `DEAD`, `RESPAWN_ELIGIBLE`, `RESPAWN_DECIDED`,
  `RESPAWN_EXECUTION_REQUESTED`. Not a general state-machine framework — a five-value enum plus
  one immutable value type, matching the existing `Health`/`DamageResult` "immutable value +
  validated transitions" style rather than adding new machinery.
- `combat.domain.RespawnLifecycleState(entity, status, destination)` — the one state value per
  entity. Constructor-enforced invariant: a destination exists exactly in the two statuses that
  carry one. Transition methods (`died()`, `eligible()`, `decided(point)`, `executionRequested()`,
  `respawned()`, `executionFailed()`) each check their own required starting status and throw
  `IllegalStateException` otherwise — "a living entity cannot be respawned as if dead" is this:
  `eligible()`/`decided()`/`respawned()` are simply not callable from `ALIVE`.
- `combat.services.RespawnLifecycleService` — the five separate steps (`recordDeath`,
  `evaluateEligibility`, `decideDestination`, `requestExecution`, `completeExecution`, plus
  `execute` composing the last two around a synchronous `IRespawnExecutor`), each returning a
  `RespawnLifecycleResult` rather than throwing for an ordinary "can't proceed right now":
  - **Duplicates** (repeat `EntityDied`, repeat execution request, repeat success report) are
    `DUPLICATE`: state unchanged, `IRespawnExecutor` not called again, no second `EntityRespawned`.
    Handled per-step (not a single dedup flag) so a duplicate at any point in the pipeline is
    absorbed without rewinding later progress.
  - **Wrong entity / wrong state / inconsistent input** is `REJECTED`, state unchanged.
  - **Execution failure never mutates silently**: states are immutable, so a caller's pre-request
    value is untouched regardless of what the service returns; `completeExecution` on a reported
    failure returns to `RESPAWN_DECIDED` — equal to the state before the request — so a retry is
    just calling `requestExecution` again. An exception thrown by an `IRespawnExecutor`
    propagates unchanged and touches no state.
- `combat.contracts.IRespawnExecutor`, `RespawnExecutionRequest`, `RespawnExecutionResult`
  (sealed `Succeeded`/`Failed`) — the execution boundary. No Bukkit `Player`/`ServerPlayer`/
  `World`/`Location`(Minecraft)/`Chunk`/teleport/bed/respawn-screen/packet type appears anywhere
  in `combat`; the core only ever says "entity X may respawn at destination Y"
  (`RespawnExecutionRequest`) and receives back success-or-failure. No implementation of
  `IRespawnExecutor` exists in this module — a platform adapter is future work.
- `combat.events.EntityRespawned` — published (returned, not bus-published, same pattern as
  `EntityDied`) exactly once, only on a confirmed `Succeeded` result.
- No event bus dependency, no global mutable event bus, no hidden static state anywhere in this
  addition (verified — see Architecture Check below). `RespawnLifecycleService` is stateless
  except for an injectable `Clock`, used only to stamp `RespawnExecutionRequest.requestedAt()`.

**Respawn lifecycle external dependency check (Gameplay Part 6):** checked general-purpose Java
state-machine libraries (e.g. Spring Statemachine, Squirrel Foundation — both Apache-2.0) before
implementing. Neither adopted: both are full state-machine *frameworks* (states-as-configuration,
listeners, persisters, guards-as-objects) aimed at far more complex machines than five states and
one linear path with one retry loop; adopting one would add a runtime dependency and a new mental
model for what the existing `Health`/`DamageResult` immutable-value-with-transition-methods style
already expresses in a few small types, consistent with this module's Part 1-5 conventions. Also
re-checked Bukkit/Paper respawn events (see Part 5's check) — still Minecraft-coupled and still
events, not a lifecycle state model. Implemented internally; no `integrations/` adapter or
decision record needed.

## Gameplay Part 7 — Respawn Persistence (added)

Establishes the persistence/recovery boundary for `RespawnLifecycleState`, reusing the existing
`core.contracts.IPersistenceGateway` rather than inventing a second repository abstraction.

- `combat.contracts.RespawnLifecycleSnapshot(schemaVersion, revision, entity, status, destination,
  savedAt)` — the module's explicit persistence model (plain JDK/`core.domain` data only), the
  counterpart of `character.contracts.CharacterSnapshot`. Not the domain type: gameplay code never
  receives one, and a gateway never sees `RespawnLifecycleState`.
- `combat.services.RespawnLifecycleSnapshotMapper` — the only place that converts between them.
  `toSnapshot` cannot produce anything `restore` would refuse (revision >= 1, `savedAt` not before
  the epoch enforced at construction). `restore` validates, in order, schema version, revision,
  timestamp, status name (exact enum match — no trimming/case-folding), and destination-matches-
  status, returning a specific `RespawnRecoveryFailure` on the first problem found rather than
  repairing anything.
- `combat.services.RespawnLifecycleStore(IPersistenceGateway, Clock)` — `load`/`save`/`discard`,
  the module's persistence boundary (only class here touching `IPersistenceGateway`, exactly like
  `CharacterDirectoryService`/`CharacterRuntimeService`). Collection key: `"respawn-lifecycle"`;
  record key: `EntityKind:UUID`.
  - **Optimistic versioning:** every stored record carries a `revision` (1 on first save, +1 per
    later save). `save(state, expectedRevision)` writes only if the stored revision still equals
    `expectedRevision` (0 meaning "nothing stored yet"); otherwise `VersionConflict` and nothing is
    written. This is the smallest version contract that catches two callers advancing the same
    stale read (e.g. two respawn requests racing) — no distributed-transaction machinery was
    added. The check-then-write is `synchronized` (single-process, single-gateway-instance
    guarantee, matching `InMemoryPersistenceGateway`'s own `synchronized` policy); a true
    multi-process adapter needs a native compare-and-set on the gateway, noted as a future
    extension point, not built here.
  - **Failure vs. absence vs. corruption**, three-way, never conflated: `load` returns `NotFound`
    for nothing stored, `Failed` (cause preserved) for a `PersistenceException`, `Corrupt` for a
    record that failed validation. `save` lets a write-time `PersistenceException` propagate
    (state is *not* saved) and never overwrites a `Blocked` (corrupt/unreadable/identity-
    mismatched) existing record — `discard` is the explicit, separate way to clear one.
  - Recovery never "fixes" data: an unknown status string, a missing/extra destination, a future
    schema version, or a record stored under the wrong entity's key are all reported with a
    specific `RespawnRecoveryFailure`, never guessed at or silently coerced.
- What is persisted: entity identity, lifecycle status, the decided destination (while one
  exists), plus `schemaVersion`/`revision`/`savedAt` for consistency. What is deliberately *not*:
  `Health` (still owned entirely by `combat.domain.Health`/`DamageApplicationService`), the killer,
  `EntityDied`/`EntityRespawned` themselves, or anything platform-specific.

**Respawn persistence external dependency check (Gameplay Part 7):** checked Spring Data's
`@Version`/optimistic-locking pattern (`spring-projects/spring-data-commons`, Apache-2.0) as a
reference for the revision-check shape before implementing — confirmed the "compare stored version,
reject on mismatch" idea, but adopting Spring Data itself would pull in a full ORM-oriented
repository framework (dynamic query derivation, auditing, cross-store abstractions) for what this
module needs as roughly fifteen lines in `RespawnLifecycleStore.save`; not adopted. No standalone,
license-clear Java library was found that does only "validated snapshot mapping + optimistic-
revision save/load over an existing gateway interface" — implemented internally, reusing
`IPersistenceGateway`/`InMemoryPersistenceGateway` unchanged. No `integrations/` adapter or
decision record needed.

## Gameplay Part 8 — Entity Identity & Health State Boundary (added)

Establishes the technology-neutral boundary that resolves and persists `combat.domain.Health` by
stable entity identity, without implementing Player/Character persistence, Minecraft integration,
or any gameplay-specific player system. Foundation/boundary part, not a full player system.

- **Identity decision: no new identity type.** `core.domain.EntityRef` (wrapping `PlayerId`/
  `EntityId`) already satisfies every Part 8 requirement — immutable, value-based, deterministic
  equality/hashCode, UUID-based (never a display name), and already future-compatible with the
  `PlayerId`/`CharacterId`/display-name split (`EntityRef.ofPlayer(PlayerId)`). Introducing a
  second identity type would duplicate it for no gain, so none was added; `HealthSnapshot`,
  `HealthStore`, and `HealthResolutionService` all key off `EntityRef`, exactly like
  `RespawnLifecycleSnapshot`/`RespawnLifecycleStore` already do.
- `combat.contracts.HealthSnapshot(schemaVersion, revision, entity, current, max, savedAt)` — the
  persistence model (plain JDK/`core.domain` data only), the `Health` counterpart of
  `RespawnLifecycleSnapshot`. Not the domain type: gameplay code never receives one from storage
  without it passing through validated recovery, and a gateway never sees a live `Health`.
- `combat.services.HealthSnapshotMapper` — the only place that converts between `Health` and
  `HealthSnapshot`, same two-way/non-repairing shape as `RespawnLifecycleSnapshotMapper`.
  `restore` validates, in order: schema version, revision, timestamp, then the same
  `current`/`max` invariants `Health`'s own constructor enforces (finite, `max > 0`,
  `0 <= current <= max`) — checked explicitly rather than by constructing a `Health` and catching
  its exception, so recovery cannot crash on untrusted stored data.
- `combat.services.HealthStore(IPersistenceGateway, Clock)` — `load`/`save`/`discard`, the only
  class here touching `IPersistenceGateway` for health. Collection key: `"entity-health"`; record
  key: `EntityKind:UUID` (same key scheme as `RespawnLifecycleStore`). Same optimistic-revision
  contract as Part 7 (`save(entity, health, expectedRevision)`, `VersionConflict` on a stale or
  skipped revision, `synchronized` single-process guarantee), and the same three-way
  `NotFound`/`Failed`/`Corrupt` load split and `Saved`/`VersionConflict`/`Blocked` save split —
  no new persistence pattern was invented, the Part 7 one was reused.
- `combat.services.HealthResolutionService(HealthStore)` — the small application/domain service
  Part 8 asks for, resolving `Health` for an `EntityRef` as `HealthResolutionResult`
  (`Resolved`/`NotFound`/`Corrupt`/`Failed`, a thin 1:1 remap of `HealthLoadResult` with the
  revision dropped). **Never creates a default `Health` for `NotFound`** — that is an explicit,
  undecided gameplay rule (e.g. starting HP), not an identity/persistence concern, and is left as a
  documented future extension point (a `resolveOrDefault(EntityRef, Supplier<Health>)` overload)
  rather than guessed at here.
- What is persisted: entity identity, `current`/`max` HP, plus `schemaVersion`/`revision`/`savedAt`
  for consistency. What is deliberately *not*: alive/dead (derived, not stored), the respawn
  lifecycle (still `RespawnLifecycleStore`'s own collection/record, untouched by this addition),
  who last dealt damage, or anything platform-specific. `DamageApplicationService` is unchanged —
  it still receives `Health` from its caller and returns a new one; resolving/persisting *which*
  `Health` belongs to a given `DamageResult.target()` is exactly the gap this boundary closes for a
  future caller, not something wired into `DamageApplicationService` itself in this part.

**External dependency check (Gameplay Part 8):** the same "compare stored version, reject on
mismatch" question Part 7 already answered — re-checked whether anything had changed; it had not.
No UUID/value-object/persistence library was adopted for the same reasons documented under
"Respawn persistence external dependency check (Gameplay Part 7)" above; `HealthStore` reuses
`IPersistenceGateway`/`InMemoryPersistenceGateway` unchanged. No `integrations/` adapter or
decision record needed.

## Forbidden Responsibilities

- Healing/regeneration, respawn timers, and death penalties/rewards — none built yet. `Health`
  is still a plain value: it does not know its owner and does not publish anything itself.
  `HealthStore`/`HealthResolutionService` (Gameplay Part 8) resolve and persist `Health` by
  `EntityRef`, but `DamageApplicationService` itself still does not call them — a caller supplies
  `targetHealth` and receives the result (and any `EntityDied`/`EntityRespawned` event); wiring
  `DamageApplicationService`'s output through `HealthStore.save` is a future integration, not
  built in Part 8. No default/starting `Health` is ever created for an entity with no stored
  record (`HealthResolutionResult.NotFound` is explicit, never silently resolved to full/zero HP)
  — that gameplay rule is an intentional future extension point. Publishing domain events onto
  `core.contracts.IEventBus` — or acting on them in any way (loot, XP, despawn) — is the caller's
  job, not this module's.
- A concrete `IRespawnPointProvider` or `IRespawnExecutor` implementation — both remain
  interfaces with no implementation in this module; a platform/other-module adapter is future
  work, wired in at the composition root.
- Weapons, equipment, armor, stats/attributes — not read or modified by this module yet.
- Abilities/spells, critical hits, resistance/weakness, buffs/debuffs — future
  Gameplay Parts extend `DamageCalculator`; `DamageType` stays a plain tag until then.
- NPC AI, aggro, loot, XP, PvP rules, UI, Minecraft combat hooks, inventory restoration.
- A production database choice, a general repository/ORM framework, or automatic full-field
  persistence — Gameplay Part 7 persists exactly `RespawnLifecycleSnapshot`'s five fields, nothing
  more, through the existing `IPersistenceGateway`.
- Any randomness in damage calculation.
