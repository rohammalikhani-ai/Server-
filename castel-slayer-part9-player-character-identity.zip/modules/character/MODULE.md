# character

## Purpose

Owns the join point between a player account (`core.domain.PlayerId`) and
the named, playable character that account controls. This is the
foundation future systems — race, class, progression, guild,
reputation, profession, knowledge, housing, history — attach to; this
module intentionally does not implement any of them.

## Responsibilities

- Creating a new character for a player, with name validation
  (`character.services.CharacterFactory`).
- Owning the character's own lifecycle: active / retired
  (`character.domain.PlayerCharacter`, `character.domain.CharacterState`).
- Renaming a character's display name (Gameplay Part 9) — `CharacterId` and the owning
  `core.domain.PlayerId` are never affected by a rename (`character.domain.PlayerCharacter#rename`,
  `character.services.CharacterLifecycleService#rename`).
- Answering "what character(s) does this player have" and "what are
  this character's basic facts" for other modules, without leaking the
  internal `PlayerCharacter` aggregate (`character.contracts.ICharacterDirectory`,
  `character.contracts.CharacterSummary`).
- Persisting character state through `core.contracts.IPersistenceGateway`
  — this module never talks to a database directly
  (`character.services.CharacterDirectoryService`).
- Publishing lifecycle events (`CharacterCreated`, `CharacterRetired`, `CharacterRenamed`) so
  future modules can attach their own per-character state reactively.

## Files

```
modules/character/
├── MODULE.md                                   (this file)
├── public/
│   ├── contracts/
│   │   ├── CharacterId.java                     module-owned id, other modules hold this
│   │   ├── CharacterSummary.java                read-only projection: id, owner, name, active
│   │   ├── CharacterSnapshot.java                persistence model: id, ownerId, name, state, createdAt, updatedAt
│   │   ├── ICharacterDirectory.java             findById / findActiveForPlayer (read surface)
│   │   └── ICharacterLifecycle.java             create / retire / rename (write surface)
│   └── events/
│       ├── CharacterCreated.java
│       ├── CharacterRetired.java
│       └── CharacterRenamed.java                characterId, previousName, newName, occurredAt (Part 9)
└── internal/
    ├── domain/
    │   ├── PlayerCharacter.java                 the aggregate: identity + lifecycle + display name
    │   └── CharacterState.java                  ACTIVE / RETIRED
    └── services/
        ├── CharacterFactory.java                validated creation + CharacterCreated
        ├── CharacterNameRules.java               name validation (3–16 chars, alphanumeric) — shared by create and rename
        ├── CharacterDirectoryService.java        ICharacterDirectory impl, backed by IPersistenceGateway
        └── CharacterLifecycleService.java        ICharacterLifecycle impl: create / retire / rename
```

Tests mirror this under `tests/modules/character/{domain,services}/`.

## Dependencies

- `core.domain`: `PlayerId`.
- `core.events`: `GameEvent` (implemented by this module's own events).
- `core.contracts`: `IEventBus` (publishes `CharacterCreated`),
  `IPersistenceGateway` (all persistence, via `CharacterDirectoryService`).
- No dependency on any other module, and no dependency on any
  `platform/*` type.

## Public Interfaces Exposed

- `character.contracts.ICharacterDirectory` — synchronous read query,
  the only way another module should learn character facts.
- `character.contracts.ICharacterLifecycle` — create / retire / rename,
  the write surface; kept separate from `ICharacterDirectory` since most
  consumers should only ever read.
- `character.contracts.CharacterId`, `CharacterSummary` — the shared
  reference/DTO types that go with it.
- `character.events.CharacterCreated`, `CharacterRetired`,
  `CharacterRenamed` — subscribe via `IEventBus` to react to a
  character's lifecycle.

`character.services.CharacterFactory`, `CharacterDirectoryService`, and
`CharacterLifecycleService` are concrete classes, not contracts — they
are wired directly for now (no composition root exists yet; see
`CURRENT_STATE.md`). Once a composition root exists, only
`ICharacterDirectory`/`ICharacterLifecycle` should be handed to
consumers outside this module, per ARCHITECTURE.md.

## Interfaces Consumed

- `core.contracts.IEventBus` (publish only, for now).
- `core.contracts.IPersistenceGateway` (save/load/query, collection
  key `"characters"`).

## Configuration

None yet. Name-length bounds (3–16 characters) are hard-coded constants
in `CharacterNameRules` rather than `IConfigProvider` keys — they are
an invariant of what a valid character name *is*, not a tunable value,
so per `IConfigProvider.md`'s guidance this stays a constant unless a
future prompt decides otherwise. If it becomes configurable, the key
would be `character.nameMinLength` / `character.nameMaxLength`.

## Tests

`tests/modules/character/domain/PlayerCharacterTest.java` — creation,
state transitions (retire, double-retire rejection), rename (identity
stability across a rename, blank/null rejection, renaming a retired
character), reconstitution.
`tests/modules/character/services/CharacterFactoryTest.java` —
validated creation, event publication, name-rule rejections.
`tests/modules/character/services/CharacterDirectoryServiceTest.java`
— save/find round trip through `IPersistenceGateway`, retired
characters excluded from `findActiveForPlayer`, unknown-id lookup.
`tests/modules/character/services/CharacterDirectoryPersistenceModelTest.java`
— `CharacterSnapshot` structure/validation.
`tests/modules/character/services/CharacterLifecycleServiceTest.java`
— `create`/`retire`/`rename` end to end: persist-then-publish ordering,
one-active-character-per-player, invalid input persists and publishes
nothing, `CharacterRenamed` carries both names and leaves `CharacterId`/
owner untouched, renaming a retired character (Gameplay Part 9).

See `docs/decisions/0001-jvm-language-and-source-layout.md` for why
these run via a hand-rolled `tests/support` harness instead of JUnit.
Verified with `javac` 21 (via `java -m jdk.compiler/com.sun.tools.javac.Main`)
and `support.TestRunner` — see `CURRENT_STATE.md` for the latest run.

## Forbidden Responsibilities

This module must **not**:

- Implement race, class, stats, appearance, progression, guild,
  reputation, profession, knowledge, housing, or history — those are
  future modules/features that attach to a character by `CharacterId`.
- Know about combat, inventory, or quest state.
- Talk to a database directly (only through `IPersistenceGateway`) or
  to any `platform/*` type.
- Support more than one active character per player — not a prototype
  requirement; `findActiveForPlayer` returning a single `Optional` is a
  deliberate constraint, not an oversight.
