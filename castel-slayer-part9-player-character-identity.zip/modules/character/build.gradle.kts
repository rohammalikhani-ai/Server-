// :modules:character — depends on :core (core.domain.PlayerId, core.events.GameEvent, core.contracts.*).
// Source layout is unchanged: modules/character/internal/ and modules/character/public/ are the
// source roots (packages are declared per sub-folder, e.g. internal/domain -> `character.domain`),
// same approach as :core's build file. Tests live outside the module under tests/.

plugins {
    java
}

sourceSets {
    main {
        java {
            setSrcDirs(listOf("internal", "public"))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/modules/character"), rootProject.file("tests/support")))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    implementation(project(":core"))
}
