package character.domain;

/**
 * Internal lifecycle state of a {@link PlayerCharacter}. Not exposed outside the
 * module — see {@code character.contracts.CharacterSummary#active()}.
 */
public enum CharacterState {
    ACTIVE,
    RETIRED
}
