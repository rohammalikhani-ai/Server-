package character.domain;

import character.contracts.CharacterId;
import character.contracts.CharacterSnapshot;
import core.domain.PlayerId;
import java.time.Instant;
import java.util.Objects;

/**
 * The character module's own aggregate: the join point between a {@link PlayerId}
 * and a named, playable character. Intentionally thin — race, class, stats,
 * progression, guild, reputation, profession, knowledge, housing and history are all
 * future systems that attach to a character by {@link CharacterId}, not fields added
 * here (see {@code MODULE.md} "Forbidden Responsibilities").
 *
 * <p>Not a bare record: creation and retirement are the two state transitions this
 * prototype defines, and both have invariants worth enforcing in one place (e.g. a
 * retired character cannot be retired again).
 */
public final class PlayerCharacter {

    private final CharacterId id;
    private final PlayerId ownerId;
    private String name;
    private final Instant createdAt;
    private CharacterState state;
    private Instant updatedAt;

    private PlayerCharacter(CharacterId id, PlayerId ownerId, String name, Instant createdAt,
                             CharacterState state, Instant updatedAt) {
        this.id = id;
        this.ownerId = ownerId;
        this.name = name;
        this.createdAt = createdAt;
        this.state = state;
        this.updatedAt = updatedAt;
    }

    /** Creates a brand-new, active character. Name validity is the caller's responsibility — see {@code character.services.CharacterFactory}. */
    public static PlayerCharacter create(CharacterId id, PlayerId ownerId, String name, Instant createdAt) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(createdAt, "createdAt");
        return new PlayerCharacter(id, ownerId, name, createdAt, CharacterState.ACTIVE, createdAt);
    }

    /** Reconstructs a character from persisted state (e.g. loaded via IPersistenceGateway). Persisted data is trusted — only null-checked, not re-validated. */
    public static PlayerCharacter reconstitute(CharacterId id, PlayerId ownerId, String name, CharacterState state,
                                                Instant createdAt, Instant updatedAt) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(updatedAt, "updatedAt");
        return new PlayerCharacter(id, ownerId, name, createdAt, state, updatedAt);
    }

    /**
     * Reconstructs a character from its persistence model. Like {@link #reconstitute}, persisted
     * data is trusted for its content, but the state name must be a known {@link CharacterState}.
     *
     * @throws IllegalArgumentException the snapshot's state is not a known {@link CharacterState}
     */
    public static PlayerCharacter fromSnapshot(CharacterSnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        CharacterState state;
        try {
            state = CharacterState.valueOf(snapshot.state());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "Character " + snapshot.id() + " has unknown state '" + snapshot.state() + "'", e);
        }
        return reconstitute(snapshot.id(), snapshot.ownerId(), snapshot.name(), state,
                snapshot.createdAt(), snapshot.updatedAt());
    }

    /** The immutable persistence model of this character's current state. */
    public CharacterSnapshot toSnapshot() {
        return new CharacterSnapshot(id, ownerId, name, state.name(), createdAt, updatedAt);
    }

    public void retire(Instant at) {
        Objects.requireNonNull(at, "at");
        if (state == CharacterState.RETIRED) {
            throw new IllegalStateException("Character " + id + " is already retired");
        }
        this.state = CharacterState.RETIRED;
        this.updatedAt = at;
    }

    /**
     * Changes the character's display name. {@link CharacterId} and {@link #ownerId()} are
     * untouched — a rename is a presentation change only, never an identity change (Gameplay
     * Part 9). {@code validatedName} is trusted as already validated (length/character-set
     * rules live in {@code character.services.CharacterNameRules}, the same rules
     * {@code CharacterFactory} applies at creation, so both paths agree on what a valid name is);
     * this method only enforces the bare non-blank invariant every constructor here already
     * enforces, as a last defensive check against a caller that skipped validation.
     */
    public void rename(String validatedName, Instant at) {
        Objects.requireNonNull(validatedName, "validatedName");
        Objects.requireNonNull(at, "at");
        if (validatedName.isBlank()) {
            throw new IllegalArgumentException("validatedName must not be blank");
        }
        this.name = validatedName;
        this.updatedAt = at;
    }

    public boolean isActive() {
        return state == CharacterState.ACTIVE;
    }

    public CharacterId id() {
        return id;
    }

    public PlayerId ownerId() {
        return ownerId;
    }

    public String name() {
        return name;
    }

    public CharacterState state() {
        return state;
    }

    public Instant createdAt() {
        return createdAt;
    }

    public Instant updatedAt() {
        return updatedAt;
    }
}
