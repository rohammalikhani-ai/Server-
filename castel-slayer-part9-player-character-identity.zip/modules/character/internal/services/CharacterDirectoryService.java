package character.services;

import character.contracts.CharacterId;
import character.contracts.CharacterSnapshot;
import character.contracts.CharacterSummary;
import character.contracts.ICharacterDirectory;
import character.domain.CharacterState;
import character.domain.PlayerCharacter;
import core.contracts.IPersistenceGateway;
import core.domain.PlayerId;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * The module's own implementation of {@link ICharacterDirectory}, backed by
 * {@link IPersistenceGateway} — this is the only place in the module that touches
 * persistence, and it never sees a concrete database type, only the interface. This
 * is the module's explicit persistence boundary: everything else in
 * {@code character} either goes through this service or doesn't persist at all.
 *
 * <p>What is stored is a {@link CharacterSnapshot} (an immutable record), never the live
 * {@link PlayerCharacter} aggregate: {@link #save} converts on the way in and
 * {@link #loadCharacter} rebuilds a fresh aggregate on the way out, so no caller can mutate
 * stored state by mutating a loaded character.
 *
 * <p>Failure vs. absence follows {@link IPersistenceGateway}: an unknown id is
 * {@code Optional.empty()}; a gateway that cannot read/write throws
 * {@link core.contracts.PersistenceException}, which this service does not swallow.
 */
public final class CharacterDirectoryService implements ICharacterDirectory {

    private static final String COLLECTION = "characters";

    private final IPersistenceGateway persistence;

    public CharacterDirectoryService(IPersistenceGateway persistence) {
        this.persistence = Objects.requireNonNull(persistence, "persistence");
    }

    /** Persists a character (create or update). Not part of {@link ICharacterDirectory} — writes are not a query concern other modules need. */
    public void save(PlayerCharacter character) {
        Objects.requireNonNull(character, "character");
        persistence.save(COLLECTION, character.id().toString(), character.toSnapshot());
    }

    /**
     * Loads the full aggregate, for the module's own services (e.g. retiring). Other modules use
     * {@link #findById} and get a {@link CharacterSummary}.
     */
    public Optional<PlayerCharacter> loadCharacter(CharacterId id) {
        Objects.requireNonNull(id, "id");
        return persistence.load(COLLECTION, id.toString(), CharacterSnapshot.class)
                .map(PlayerCharacter::fromSnapshot);
    }

    @Override
    public Optional<CharacterSummary> findById(CharacterId id) {
        return loadCharacter(id).map(CharacterDirectoryService::toSummary);
    }

    @Override
    public Optional<CharacterSummary> findActiveForPlayer(PlayerId ownerId) {
        Objects.requireNonNull(ownerId, "ownerId");
        List<CharacterSnapshot> matches = persistence.query(
                COLLECTION,
                CharacterSnapshot.class,
                s -> s.ownerId().equals(ownerId) && CharacterState.ACTIVE.name().equals(s.state()));
        return matches.stream().findFirst().map(PlayerCharacter::fromSnapshot).map(CharacterDirectoryService::toSummary);
    }

    static CharacterSummary toSummary(PlayerCharacter character) {
        return new CharacterSummary(character.id(), character.ownerId(), character.name(), character.isActive());
    }
}
