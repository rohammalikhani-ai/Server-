package character.services;

import character.contracts.CharacterId;
import character.domain.PlayerCharacter;
import character.events.CharacterCreated;
import core.contracts.IEventBus;
import core.domain.PlayerId;
import java.time.Clock;
import java.util.Objects;

/**
 * Creates new characters, enforcing name validity and publishing
 * {@link CharacterCreated} so future modules (progression, inventory, ...) can react
 * without this module knowing they exist.
 */
public final class CharacterFactory {

    private final IEventBus eventBus;
    private final Clock clock;

    public CharacterFactory(IEventBus eventBus, Clock clock) {
        this.eventBus = Objects.requireNonNull(eventBus, "eventBus");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /**
     * Validates and constructs a new active character <em>without</em> publishing anything, so a
     * caller that persists characters (see {@link CharacterLifecycleService}) can save first and
     * only then {@link #announceCreated announce} it.
     */
    public PlayerCharacter build(PlayerId ownerId, String requestedName) {
        Objects.requireNonNull(ownerId, "ownerId");
        String name = CharacterNameRules.validate(requestedName);
        return PlayerCharacter.create(CharacterId.random(), ownerId, name, clock.instant());
    }

    /** Publishes {@link CharacterCreated} for a character produced by {@link #build}. */
    public void announceCreated(PlayerCharacter character) {
        Objects.requireNonNull(character, "character");
        eventBus.publish(new CharacterCreated(
                character.id(), character.ownerId(), character.name(), character.createdAt()));
    }

    /** {@link #build} then {@link #announceCreated}: the original one-step behaviour, unchanged. */
    public PlayerCharacter create(PlayerId ownerId, String requestedName) {
        PlayerCharacter character = build(ownerId, requestedName);
        announceCreated(character);
        return character;
    }
}
