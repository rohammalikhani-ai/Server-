package character.services;

/**
 * Validation rules for a character's display name, centralized so
 * {@link CharacterFactory} (and any future rename service) agree on one definition.
 */
final class CharacterNameRules {

    static final int MIN_LENGTH = 3;
    static final int MAX_LENGTH = 16;

    private CharacterNameRules() {
    }

    static String validate(String name) {
        if (name == null) {
            throw new IllegalArgumentException("name must not be null");
        }
        String trimmed = name.trim();
        if (trimmed.length() < MIN_LENGTH || trimmed.length() > MAX_LENGTH) {
            throw new IllegalArgumentException(
                    "name must be between " + MIN_LENGTH + " and " + MAX_LENGTH
                            + " characters, was " + trimmed.length());
        }
        for (int i = 0; i < trimmed.length(); i++) {
            if (!Character.isLetterOrDigit(trimmed.charAt(i))) {
                throw new IllegalArgumentException("name must be alphanumeric: " + name);
            }
        }
        return trimmed;
    }
}
