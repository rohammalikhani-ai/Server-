package character.services;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import character.contracts.ICharacterLifecycle;
import character.domain.PlayerCharacter;
import character.events.CharacterRenamed;
import character.events.CharacterRetired;
import core.contracts.IEventBus;
import core.domain.PlayerId;
import java.time.Clock;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/**
 * Creates and retires characters end to end: validate → mutate → <b>persist</b> →
 * <b>then</b> publish. {@link CharacterFactory} alone only builds an in-memory aggregate,
 * and {@link CharacterDirectoryService} alone only stores one; this is the small piece that
 * makes "a character was created/retired" true in the directory before anyone is told
 * (and that finally gives {@code CharacterRetired} a publisher — nothing published it before).
 *
 * <p>Not transactional: there is no unit-of-work abstraction over
 * {@link core.contracts.IPersistenceGateway}. If the save throws, nothing is published and
 * the exception propagates; if publishing were to fail (the bus never throws on a
 * subscriber's behalf), the change is already durable.
 */
public final class CharacterLifecycleService implements ICharacterLifecycle {

    private final CharacterDirectoryService directory;
    private final CharacterFactory factory;
    private final IEventBus eventBus;
    private final Clock clock;

    public CharacterLifecycleService(CharacterDirectoryService directory, CharacterFactory factory,
                                     IEventBus eventBus, Clock clock) {
        this.directory = Objects.requireNonNull(directory, "directory");
        this.factory = Objects.requireNonNull(factory, "factory");
        this.eventBus = Objects.requireNonNull(eventBus, "eventBus");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    @Override
    public CharacterSummary create(PlayerId ownerId, String requestedName) {
        Objects.requireNonNull(ownerId, "ownerId");
        // Validate the name first so a bad name is reported as such even for a player at the limit.
        PlayerCharacter character = factory.build(ownerId, requestedName);
        if (directory.findActiveForPlayer(ownerId).isPresent()) {
            throw new IllegalStateException(
                    "Player " + ownerId + " already has an active character; retire it before creating another");
        }
        directory.save(character);
        factory.announceCreated(character);
        return CharacterDirectoryService.toSummary(character);
    }

    @Override
    public Optional<CharacterSummary> retire(CharacterId id) {
        Objects.requireNonNull(id, "id");
        Optional<PlayerCharacter> loaded = directory.loadCharacter(id);
        if (loaded.isEmpty()) {
            return Optional.empty();
        }
        PlayerCharacter character = loaded.get();
        Instant now = clock.instant();
        character.retire(now);
        directory.save(character);
        eventBus.publish(new CharacterRetired(id, now));
        return Optional.of(CharacterDirectoryService.toSummary(character));
    }

    @Override
    public Optional<CharacterSummary> rename(CharacterId id, String requestedName) {
        Objects.requireNonNull(id, "id");
        // Validate first, same ordering CharacterFactory uses for create — a bad name is reported
        // as such even for a character that does not exist.
        String validatedName = CharacterNameRules.validate(requestedName);
        Optional<PlayerCharacter> loaded = directory.loadCharacter(id);
        if (loaded.isEmpty()) {
            return Optional.empty();
        }
        PlayerCharacter character = loaded.get();
        String previousName = character.name();
        Instant now = clock.instant();
        character.rename(validatedName, now);
        directory.save(character);
        eventBus.publish(new CharacterRenamed(id, previousName, validatedName, now));
        return Optional.of(CharacterDirectoryService.toSummary(character));
    }
}
