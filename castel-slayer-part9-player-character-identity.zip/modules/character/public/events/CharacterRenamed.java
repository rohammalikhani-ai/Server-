package character.events;

import character.contracts.CharacterId;
import core.events.GameEvent;
import java.time.Instant;
import java.util.Objects;

/**
 * Published when a character's display name changes (Gameplay Part 9). {@link #characterId()} is
 * unchanged by a rename — only the display name is — so subscribers that key their own state by
 * {@link CharacterId} need no migration when this fires. Carries both names, mirroring the
 * "old value / new value" shape a rename naturally has (unlike {@code CharacterCreated}/
 * {@code CharacterRetired}, which each describe a single state).
 */
public record CharacterRenamed(CharacterId characterId, String previousName, String newName, Instant occurredAt)
        implements GameEvent {
    public CharacterRenamed {
        Objects.requireNonNull(characterId, "characterId");
        Objects.requireNonNull(previousName, "previousName");
        Objects.requireNonNull(newName, "newName");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
