package character.events;

import character.contracts.CharacterId;
import core.domain.PlayerId;
import core.events.GameEvent;
import java.time.Instant;
import java.util.Objects;

/** Published once a new character has been created. Future modules (progression, inventory, ...) subscribe to initialize their own per-character state. */
public record CharacterCreated(CharacterId characterId, PlayerId ownerId, String name, Instant occurredAt) implements GameEvent {
    public CharacterCreated {
        Objects.requireNonNull(characterId, "characterId");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
