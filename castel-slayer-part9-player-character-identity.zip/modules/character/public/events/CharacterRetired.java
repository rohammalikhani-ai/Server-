package character.events;

import character.contracts.CharacterId;
import core.events.GameEvent;
import java.time.Instant;
import java.util.Objects;

/** Published when a character is retired (soft-deleted). It is no longer a player's active character. */
public record CharacterRetired(CharacterId characterId, Instant occurredAt) implements GameEvent {
    public CharacterRetired {
        Objects.requireNonNull(characterId, "characterId");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
