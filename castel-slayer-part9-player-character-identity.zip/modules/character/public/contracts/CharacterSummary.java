package character.contracts;

import core.domain.PlayerId;
import java.util.Objects;

/**
 * A minimal, read-only projection of a character for other modules to consume
 * through {@link ICharacterDirectory}. Deliberately does not expose the module's
 * internal {@code PlayerCharacter} type — see ARCHITECTURE.md's public/internal
 * split. Carries no race/class/progression fields; those belong to whichever future
 * module owns them, keyed by {@link CharacterId}.
 */
public record CharacterSummary(CharacterId id, PlayerId ownerId, String name, boolean active) {
    public CharacterSummary {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(name, "name");
        if (name.isBlank()) {
            throw new IllegalArgumentException("name must not be blank");
        }
    }
}
