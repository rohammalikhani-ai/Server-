package character.contracts;

import core.domain.PlayerId;
import java.time.Instant;
import java.util.Objects;

/**
 * The character module's explicit persistence model: an immutable, plain-data
 * description of everything needed to rebuild one character. This — not the module's
 * internal {@code PlayerCharacter} aggregate — is what crosses
 * {@code core.contracts.IPersistenceGateway}, so a concrete gateway (memory, JSON, SQL,
 * ...) only ever sees a small record of {@code core.domain}/JDK types and never a live,
 * mutable object graph (see {@code IPersistenceGateway}'s "immutable snapshots" rule).
 *
 * <p>Not a read projection for other modules — that is {@link CharacterSummary}. The
 * lifecycle state is carried as its name ({@code "ACTIVE"} / {@code "RETIRED"}) rather
 * than as the internal {@code CharacterState} enum, so the stored form does not depend
 * on an internal type and stays readable if the enum's implementation changes.
 *
 * @param id        the character's stable identity
 * @param ownerId   the player account that owns it (never used as a gameplay owner id — that is {@code id})
 * @param name      the validated display name
 * @param state     lifecycle state name, e.g. {@code "ACTIVE"}
 * @param createdAt when the character was created
 * @param updatedAt when its lifecycle state last changed
 */
public record CharacterSnapshot(CharacterId id, PlayerId ownerId, String name, String state,
                                Instant createdAt, Instant updatedAt) {

    public CharacterSnapshot {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(updatedAt, "updatedAt");
        if (name.isBlank()) {
            throw new IllegalArgumentException("name must not be blank");
        }
        if (state.isBlank()) {
            throw new IllegalArgumentException("state must not be blank");
        }
    }
}
