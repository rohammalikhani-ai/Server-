package character.contracts;

import core.domain.PlayerId;
import java.util.Optional;

/**
 * The character module's write surface for other modules/the application layer:
 * creating and retiring characters. Kept separate from the read-only
 * {@link ICharacterDirectory} on purpose — most consumers only ever need to look a
 * character up, and should not be handed the ability to create or retire one.
 *
 * <p>Both operations persist first and only then publish their event
 * ({@code CharacterCreated} / {@code CharacterRetired}), so a subscriber that reacts
 * by querying {@link ICharacterDirectory} always sees the change.
 */
public interface ICharacterLifecycle {

    /**
     * Creates, persists and announces a new active character for {@code ownerId}.
     *
     * @throws IllegalArgumentException the name is invalid (see {@code CharacterNameRules})
     * @throws IllegalStateException    {@code ownerId} already has an active character. This is the
     *                                  module's documented prototype-scope rule (one active
     *                                  character per player); retire the old one first.
     */
    CharacterSummary create(PlayerId ownerId, String requestedName);

    /**
     * Retires (soft-deletes) a character and announces it.
     *
     * @return the retired character, or empty if no character has that id
     * @throws IllegalStateException the character is already retired
     */
    Optional<CharacterSummary> retire(CharacterId id);

    /**
     * Changes a character's display name (Gameplay Part 9). {@link CharacterId} and the owning
     * {@code core.domain.PlayerId} are never affected — a rename is a presentation change only;
     * see {@code character.domain.PlayerCharacter#rename}.
     *
     * @return the renamed character, or empty if no character has that id
     * @throws IllegalArgumentException the name is invalid (see {@code CharacterNameRules})
     */
    Optional<CharacterSummary> rename(CharacterId id, String requestedName);
}
