package character.contracts;

import java.util.Objects;
import java.util.UUID;

/**
 * Identifies a character — the player-controlled avatar a {@code core.domain.PlayerId}
 * owns and plays as. Deliberately its own type, not reused from {@code core.domain}:
 * a player account and the character(s) it plays are different concepts (see
 * {@code MODULE.md}), and future multi-character-per-account support (if ever added)
 * should not require touching every module that already refers to a character by id.
 */
public record CharacterId(UUID value) {

    public CharacterId {
        Objects.requireNonNull(value, "value");
    }

    public static CharacterId random() {
        return new CharacterId(UUID.randomUUID());
    }

    public static CharacterId of(UUID value) {
        return new CharacterId(value);
    }

    @Override
    public String toString() {
        return value.toString();
    }
}
