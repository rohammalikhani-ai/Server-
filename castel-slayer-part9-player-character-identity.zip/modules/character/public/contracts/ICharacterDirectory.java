package character.contracts;

import core.domain.PlayerId;
import java.util.Optional;

/**
 * The character module's query surface for other modules/platform adapters. Nothing
 * outside {@code modules/character} may see the module's internal
 * {@code PlayerCharacter} type — this contract, plus {@link CharacterSummary} and
 * {@link CharacterId}, is the whole external read surface for character facts.
 */
public interface ICharacterDirectory {

    Optional<CharacterSummary> findById(CharacterId id);

    /** A player's single active character, if they have one. Multi-character-per-account is out of prototype scope. */
    Optional<CharacterSummary> findActiveForPlayer(PlayerId ownerId);
}
