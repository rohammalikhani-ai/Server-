package equipment.domain;

import inventory.contracts.ItemId;
import java.util.Objects;

/**
 * An immutable description of one kind of item: identity, name, category,
 * stack size, and — for equippable items — the one slot it goes in.
 *
 * <p>Always valid: every rule is checked in the canonical constructor and the
 * type is an immutable record. Rules:
 * <ul>
 *   <li>{@code name} is not blank; {@code category} is a declared category (not {@code null}).</li>
 *   <li>{@code maxStackSize} is at least 1.</li>
 *   <li>An item is equippable exactly when it has a {@code slot}
 *       ({@link #isEquippable()} is derived — there is no separate flag that
 *       could disagree with the slot).</li>
 *   <li>An equippable item has {@code maxStackSize == 1} — equipment holds a
 *       single item, not a stack.</li>
 * </ul>
 *
 * <p>This is not an item database or registry (out of scope); it is only the
 * value the Equipment domain needs. The {@link ItemId} is Inventory's public
 * identity contract ({@code inventory.contracts.ItemId}), so the same kind of
 * id identifies an item in both places. Inventory's own {@code Item} (id +
 * max stack size) is unchanged; a caller that needs one builds it from this
 * definition.
 *
 * <p>The C# reference's optional parameters ({@code maxStackSize = 1},
 * {@code slot = null}) become the convenience constructors below, since Java
 * has no default arguments.
 *
 * @param id           item identity (Inventory's public {@link ItemId}); must not be null
 * @param name         display/identity name; must not be null, empty, or blank
 * @param category     the item's category; must not be null
 * @param maxStackSize largest stack size; at least 1, and exactly 1 for equippable items
 * @param slot         the slot the item equips into, or {@code null} when the item cannot be equipped
 */
public record ItemDefinition(
        ItemId id,
        String name,
        ItemCategory category,
        int maxStackSize,
        EquipmentSlot slot) {

    /**
     * @throws NullPointerException     {@code id} or {@code name} is null
     * @throws IllegalArgumentException blank name; null category; {@code maxStackSize}
     *                                  below 1; or an equippable item whose
     *                                  {@code maxStackSize} is not 1
     */
    public ItemDefinition {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(name, "name");

        if (name.isBlank()) {
            throw new IllegalArgumentException("Item name cannot be empty or whitespace");
        }
        if (category == null) {
            throw new IllegalArgumentException("category must be a declared ItemCategory (was null)");
        }
        if (maxStackSize < 1) {
            throw new IllegalArgumentException("maxStackSize must be at least 1 (was " + maxStackSize + ")");
        }
        if (slot != null && maxStackSize != 1) {
            throw new IllegalArgumentException(
                    "An equippable item must have maxStackSize 1 (was " + maxStackSize + ")");
        }
    }

    /** A non-equippable item with {@code maxStackSize} 1. */
    public ItemDefinition(ItemId id, String name, ItemCategory category) {
        this(id, name, category, 1, null);
    }

    /** A non-equippable item with the given {@code maxStackSize}. */
    public ItemDefinition(ItemId id, String name, ItemCategory category, int maxStackSize) {
        this(id, name, category, maxStackSize, null);
    }

    /** An item equippable into {@code slot} (with {@code maxStackSize} 1), or non-equippable if {@code slot} is null. */
    public ItemDefinition(ItemId id, String name, ItemCategory category, EquipmentSlot slot) {
        this(id, name, category, 1, slot);
    }

    /** True exactly when {@link #slot()} is set. */
    public boolean isEquippable() {
        return slot != null;
    }
}
