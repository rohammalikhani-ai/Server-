package equipment.domain;

/**
 * A read-only view of one equipment slot: either empty ({@link #item()} is
 * {@code null}) or holding one {@link ItemDefinition}. A snapshot value —
 * holding one never lets a caller change the equipment; only
 * {@link ItemEquipment}'s own methods can.
 *
 * @param slot which slot this describes
 * @param item the equipped item, or {@code null} when the slot is empty
 */
public record EquipmentSlotState(EquipmentSlot slot, ItemDefinition item) {

    public boolean isEmpty() {
        return item == null;
    }
}
