package equipment.domain;

import java.util.Objects;

/**
 * Outcome of {@link ItemEquipment#unequip}. On success the removed item is
 * handed back in {@link #item()} — it is never discarded, so the caller (in
 * future, the Inventory ↔ Equipment transaction) must place it somewhere.
 * Refusals never change the equipment. Only {@link ItemEquipment} (via the
 * package-private {@link #create}) can create one — a final class rather than
 * a record, because a record's canonical constructor cannot be hidden.
 */
public final class UnequipResult {

    private final UnequipStatus status;
    private final EquipmentSlot requestedSlot;
    private final ItemDefinition item;

    private UnequipResult(UnequipStatus status, EquipmentSlot requestedSlot, ItemDefinition item) {
        this.status = status;
        this.requestedSlot = requestedSlot;
        this.item = item;
    }

    static UnequipResult create(UnequipStatus status, EquipmentSlot requestedSlot, ItemDefinition item) {
        return new UnequipResult(status, requestedSlot, item);
    }

    static UnequipResult create(UnequipStatus status, EquipmentSlot requestedSlot) {
        return new UnequipResult(status, requestedSlot, null);
    }

    public UnequipStatus status() {
        return status;
    }

    /**
     * The slot the caller asked about ({@code null} when {@link #status()} is
     * {@link UnequipStatus#INVALID_SLOT}, since that is how an undeclared slot
     * reaches Java).
     */
    public EquipmentSlot requestedSlot() {
        return requestedSlot;
    }

    /** The item that was removed; non-null exactly when {@link #isSuccess()}. */
    public ItemDefinition item() {
        return item;
    }

    public boolean isSuccess() {
        return status == UnequipStatus.SUCCESS;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UnequipResult that)) {
            return false;
        }
        return status == that.status
                && requestedSlot == that.requestedSlot
                && Objects.equals(item, that.item);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, requestedSlot, item);
    }

    @Override
    public String toString() {
        return "UnequipResult[status=" + status + ", requestedSlot=" + requestedSlot + ", item=" + item + "]";
    }
}
