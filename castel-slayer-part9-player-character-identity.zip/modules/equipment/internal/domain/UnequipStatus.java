package equipment.domain;

/** Why an unequip attempt succeeded or was refused. */
public enum UnequipStatus {

    /** The slot's item was removed and is returned in the result. */
    SUCCESS,

    /** The slot holds nothing. */
    SLOT_EMPTY,

    /** The slot is not a declared {@link EquipmentSlot} (in Java: it is {@code null}). */
    INVALID_SLOT
}
