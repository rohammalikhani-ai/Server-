package equipment.domain;

import character.contracts.CharacterId;
import equipment.contracts.EquipmentSnapshot;
import equipment.contracts.EquippedItemSnapshot;
import inventory.contracts.ItemId;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * What a character currently has equipped: at most one {@link ItemDefinition}
 * per {@link EquipmentSlot}. The only place equipped state changes — state is
 * private and callers see read-only {@link EquipmentSlotState} snapshots, so
 * nothing (client, AI, another module) can edit it directly.
 *
 * <p>Invariants, holding after every call (including refused ones):
 * <ul>
 *   <li>Every equipped item is equippable and sits in the slot its definition names.</li>
 *   <li>A slot holds at most one item.</li>
 *   <li>A given {@link ItemId} is equipped at most once.</li>
 * </ul>
 *
 * <p>Nothing here replaces or discards an item: equipping into an occupied
 * slot is refused, and unequipping hands the item back in the result. This
 * class does not touch {@code ItemInventory}; moving items between the two
 * (with all-or-nothing guarantees) is a later prompt's transaction. It also
 * knows nothing about Stats — a future integration reads {@link #slots()} and
 * applies modifiers on its side.
 *
 * <p>Every equipment set belongs to exactly one character: the owning
 * {@link CharacterId} is mandatory and fixed at construction, and no
 * operation can change it. The "one {@link ItemId} equipped at most once"
 * invariant is therefore per character — two characters may each wear an item
 * with the same id. The owner is never a {@code PlayerId} or a Bukkit UUID.
 *
 * <p>The module's persistence/runtime model is {@link EquipmentSnapshot}
 * ({@link #toSnapshot()} / {@link #fromSnapshot}); the internal map never leaves
 * this class, and a restore re-runs the normal domain rules.
 *
 * <p>Named {@code ItemEquipment} (not {@code Equipment}) to mirror
 * {@code inventory.domain.ItemInventory} and the C# reference's naming.
 * Not thread-safe; the caller (a future single-threaded authority) owns
 * synchronisation.
 *
 * <p>Gameplay refusals are result values; exceptions are for programmer
 * errors only. A {@code null} slot is Java's only "undeclared slot" (a Java
 * enum cannot hold any other invalid value), so {@code equip}/{@code unequip}
 * refuse it as {@code INVALID_SLOT} and the query methods throw
 * {@link IllegalArgumentException} for it — the same split the C# reference
 * makes for an undeclared slot value.
 */
public final class ItemEquipment {

    private final CharacterId ownerId;
    private final Map<EquipmentSlot, ItemDefinition> equipped = new EnumMap<>(EquipmentSlot.class);

    /** @param ownerId the character that owns this equipment; must not be null */
    public ItemEquipment(CharacterId ownerId) {
        this.ownerId = Objects.requireNonNull(ownerId, "ownerId");
    }

    /**
     * Rebuilds equipment from its persistence model by re-equipping each item through
     * {@link #equip}, so every invariant is checked again — a corrupt snapshot fails loudly
     * instead of producing an impossible state.
     *
     * @throws IllegalArgumentException an unknown category/slot name, an invalid item
     *                                  definition, or an item set that breaks an equipment invariant
     */
    public static ItemEquipment fromSnapshot(EquipmentSnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");

        ItemEquipment equipment = new ItemEquipment(snapshot.ownerId());
        for (EquippedItemSnapshot stored : snapshot.items()) {
            ItemCategory category = parse(ItemCategory.class, stored.category(), "category");
            EquipmentSlot slot = parse(EquipmentSlot.class, stored.slot(), "slot");
            ItemDefinition item = new ItemDefinition(stored.itemId(), stored.name(), category, stored.maxStackSize(), slot);
            EquipResult result = equipment.equip(item, slot);
            if (!result.isSuccess()) {
                throw new IllegalArgumentException(
                        "Cannot restore '" + stored.itemId() + "' into " + slot + ": " + result.status());
            }
        }
        return equipment;
    }

    /** The character that owns this equipment. Fixed for the equipment's lifetime. */
    public CharacterId ownerId() {
        return ownerId;
    }

    /** An immutable copy of the equipped items; later changes do not affect it. */
    public EquipmentSnapshot toSnapshot() {
        List<EquippedItemSnapshot> items = new ArrayList<>();
        for (Map.Entry<EquipmentSlot, ItemDefinition> entry : equipped.entrySet()) {
            ItemDefinition item = entry.getValue();
            items.add(new EquippedItemSnapshot(
                    item.id(), item.name(), item.category().name(), item.maxStackSize(), entry.getKey().name()));
        }
        return new EquipmentSnapshot(ownerId, items);
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String name, String what) {
        try {
            return Enum.valueOf(type, name);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Unknown " + what + " name '" + name + "' in stored equipment", e);
        }
    }

    /** Number of slots that currently hold an item. */
    public int equippedCount() {
        return equipped.size();
    }

    /**
     * Equips {@code item} into {@code slot}, or explains why not. Checks run
     * in this order and the first failure wins: not equippable → invalid slot
     * → incompatible slot → already equipped → slot occupied. Nothing changes
     * on any failure, and an occupied slot is never replaced.
     *
     * @throws NullPointerException {@code item} is null (a programming error, not a gameplay outcome)
     */
    public EquipResult equip(ItemDefinition item, EquipmentSlot slot) {
        Objects.requireNonNull(item, "item");

        if (!item.isEquippable()) {
            return EquipResult.create(EquipStatus.NOT_EQUIPPABLE, item, slot);
        }

        if (!EquipmentSlots.isValid(slot)) {
            return EquipResult.create(EquipStatus.INVALID_SLOT, item, slot);
        }

        if (item.slot() != slot) {
            return EquipResult.create(EquipStatus.INCOMPATIBLE_SLOT, item, slot);
        }

        for (ItemDefinition equippedItem : equipped.values()) {
            if (equippedItem.id().equals(item.id())) {
                return EquipResult.create(EquipStatus.ALREADY_EQUIPPED, item, slot, equippedItem);
            }
        }

        ItemDefinition occupant = equipped.get(slot);
        if (occupant != null) {
            return EquipResult.create(EquipStatus.SLOT_OCCUPIED, item, slot, occupant);
        }

        equipped.put(slot, item);
        return EquipResult.create(EquipStatus.SUCCESS, item, slot);
    }

    /** Removes and returns whatever is in {@code slot}, or explains why nothing was removed. */
    public UnequipResult unequip(EquipmentSlot slot) {
        if (!EquipmentSlots.isValid(slot)) {
            return UnequipResult.create(UnequipStatus.INVALID_SLOT, slot);
        }

        ItemDefinition removed = equipped.remove(slot);
        if (removed == null) {
            return UnequipResult.create(UnequipStatus.SLOT_EMPTY, slot);
        }

        return UnequipResult.create(UnequipStatus.SUCCESS, slot, removed);
    }

    /**
     * The item in {@code slot}, or {@code null} when it is empty.
     *
     * @throws IllegalArgumentException {@code slot} is not a declared slot (null)
     */
    public ItemDefinition getEquipped(EquipmentSlot slot) {
        requireValidSlot(slot);

        return equipped.get(slot);
    }

    /** @throws IllegalArgumentException {@code slot} is not a declared slot (null) */
    public boolean isSlotOccupied(EquipmentSlot slot) {
        requireValidSlot(slot);

        return equipped.containsKey(slot);
    }

    /** True if an item with this id is equipped in any slot. */
    public boolean isEquipped(ItemId itemId) {
        Objects.requireNonNull(itemId, "itemId");

        for (ItemDefinition equippedItem : equipped.values()) {
            if (equippedItem.id().equals(itemId)) {
                return true;
            }
        }

        return false;
    }

    /**
     * A read-only snapshot of every slot (empty ones included), in
     * {@link EquipmentSlots#ALL} order. Later changes to this equipment do
     * not alter a snapshot already handed out, and the list cannot be modified.
     */
    public List<EquipmentSlotState> slots() {
        List<EquipmentSlotState> snapshot = new ArrayList<>(EquipmentSlots.ALL.size());
        for (EquipmentSlot slot : EquipmentSlots.ALL) {
            snapshot.add(new EquipmentSlotState(slot, equipped.get(slot)));
        }

        return List.copyOf(snapshot);
    }

    private static void requireValidSlot(EquipmentSlot slot) {
        if (!EquipmentSlots.isValid(slot)) {
            throw new IllegalArgumentException("slot must be a declared EquipmentSlot (was null)");
        }
    }
}
