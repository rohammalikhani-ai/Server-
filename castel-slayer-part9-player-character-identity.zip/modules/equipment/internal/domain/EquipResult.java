package equipment.domain;

import java.util.Objects;

/**
 * Outcome of {@link ItemEquipment#equip}. A refused equip is a normal
 * gameplay outcome, reported here rather than thrown. Refusals never change
 * the equipment. Only {@link ItemEquipment} (via the package-private
 * {@link #create}) can create one — a final class rather than a record,
 * because a record's canonical constructor cannot be hidden.
 */
public final class EquipResult {

    private final EquipStatus status;
    private final ItemDefinition item;
    private final EquipmentSlot requestedSlot;
    private final ItemDefinition blockingItem;

    private EquipResult(EquipStatus status, ItemDefinition item, EquipmentSlot requestedSlot,
                        ItemDefinition blockingItem) {
        this.status = status;
        this.item = item;
        this.requestedSlot = requestedSlot;
        this.blockingItem = blockingItem;
    }

    static EquipResult create(EquipStatus status, ItemDefinition item, EquipmentSlot requestedSlot,
                              ItemDefinition blockingItem) {
        return new EquipResult(status, item, requestedSlot, blockingItem);
    }

    static EquipResult create(EquipStatus status, ItemDefinition item, EquipmentSlot requestedSlot) {
        return new EquipResult(status, item, requestedSlot, null);
    }

    public EquipStatus status() {
        return status;
    }

    /** The item the caller tried to equip. It is still the caller's on any refusal. */
    public ItemDefinition item() {
        return item;
    }

    /**
     * The slot the caller asked for ({@code null} when {@link #status()} is
     * {@link EquipStatus#INVALID_SLOT}, since that is how an undeclared slot
     * reaches Java).
     */
    public EquipmentSlot requestedSlot() {
        return requestedSlot;
    }

    /**
     * The item in the way: the current occupant for {@link EquipStatus#SLOT_OCCUPIED},
     * or the already-equipped copy for {@link EquipStatus#ALREADY_EQUIPPED}. {@code null} otherwise.
     */
    public ItemDefinition blockingItem() {
        return blockingItem;
    }

    public boolean isSuccess() {
        return status == EquipStatus.SUCCESS;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof EquipResult that)) {
            return false;
        }
        return status == that.status
                && Objects.equals(item, that.item)
                && requestedSlot == that.requestedSlot
                && Objects.equals(blockingItem, that.blockingItem);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, item, requestedSlot, blockingItem);
    }

    @Override
    public String toString() {
        return "EquipResult[status=" + status + ", item=" + item + ", requestedSlot=" + requestedSlot
                + ", blockingItem=" + blockingItem + "]";
    }
}
