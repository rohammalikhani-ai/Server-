package equipment.domain;

import java.util.List;

/** Helpers over the {@link EquipmentSlot} set. */
public final class EquipmentSlots {

    /** Every valid slot, in declaration order ({@code HEAD} first, {@code OFF_HAND} last). Immutable. */
    public static final List<EquipmentSlot> ALL = List.of(EquipmentSlot.values());

    private EquipmentSlots() {
    }

    /**
     * False for {@code null} — the only value a Java caller can pass that is
     * not a declared slot (the C# reference also rejected {@code default} and
     * integer casts, which a Java enum cannot represent).
     */
    public static boolean isValid(EquipmentSlot slot) {
        return slot != null;
    }
}
