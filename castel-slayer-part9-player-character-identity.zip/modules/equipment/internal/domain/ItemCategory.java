package equipment.domain;

/**
 * Coarse item category. Deliberately small: only what is needed to describe
 * an item today. A category does not by itself make an item equippable — see
 * {@link ItemDefinition#isEquippable()}.
 */
public enum ItemCategory {
    WEAPON,
    ARMOR,
    CONSUMABLE,
    MATERIAL,
    MISCELLANEOUS
}
