package equipment.domain;

/** Why an equip attempt succeeded or was refused. */
public enum EquipStatus {

    /** The item is now equipped in the requested slot. */
    SUCCESS,

    /** The item has no equipment slot, so it can never be equipped. */
    NOT_EQUIPPABLE,

    /** The requested slot is not a declared {@link EquipmentSlot} (in Java: it is {@code null}). */
    INVALID_SLOT,

    /** The item is equippable, but not in the requested slot. */
    INCOMPATIBLE_SLOT,

    /** The slot already holds a different item; nothing was replaced. */
    SLOT_OCCUPIED,

    /** An item with the same {@link inventory.contracts.ItemId} is already equipped; it can be equipped at most once. */
    ALREADY_EQUIPPED
}
