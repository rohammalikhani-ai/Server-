package equipment.domain;

/**
 * A place on a character where one item can be equipped. A domain-level
 * model — deliberately NOT Minecraft's {@code EquipmentSlot}; a future
 * platform adapter maps between the two.
 *
 * <p>Declaration order is the canonical slot order ({@link EquipmentSlots#ALL}
 * and {@link ItemEquipment#slots()} follow it: {@link #HEAD} first,
 * {@link #OFF_HAND} last). To add a slot (e.g. a ring or neck slot), append a
 * member at the end — {@code EquipmentSlots.ALL} and {@code ItemEquipment}
 * pick it up without further changes. Never reorder existing members.
 *
 * <p>Java enums cannot hold an "undeclared" value the way a C# enum can (via
 * {@code default} or an integer cast), so the only invalid slot a caller can
 * pass is {@code null}; see {@link EquipmentSlots#isValid}.
 */
public enum EquipmentSlot {
    HEAD,
    CHEST,
    LEGS,
    FEET,
    MAIN_HAND,
    OFF_HAND
}
