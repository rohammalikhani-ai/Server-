// :modules:equipment — depends on :modules:inventory (only its public inventory.contracts.ItemId)
// and :modules:character (only character.contracts.CharacterId, the owner identity). It must not
// import inventory.domain.* or any other Inventory internals; that is checked by the static audit.
// Source layout is unchanged: modules/equipment/internal/ and modules/equipment/public/ are the
// source roots (packages are declared per sub-folder, e.g. internal/domain -> `equipment.domain`),
// same approach as :core's build file. Tests live outside the module under tests/.

plugins {
    java
}

sourceSets {
    main {
        java {
            setSrcDirs(listOf("internal", "public"))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/modules/equipment"), rootProject.file("tests/support")))
            // tests/support's InMemoryEventBus / InMemoryPersistenceGateway implement
            // :core contracts, and this module's tests use neither. Leaving them out keeps
            // :core off this project's test classpath instead of adding a dependency that
            // only the shared test doubles would need.
            exclude("InMemoryEventBus.java", "InMemoryPersistenceGateway.java")
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    implementation(project(":modules:inventory"))
    implementation(project(":modules:character"))
}
