# equipment (Java)

## Purpose

Java migration of the Equipment Foundation: what a character has equipped,
as pure server-side domain state — one item per slot, with validated
equip/unequip. Nothing more; this is not the final equipment system. It is
the Java counterpart of the since-deprecated C# reference
(`dotnet-core/src/CastelSlayer.Modules.Equipment` — kept as reference only,
not modified by this migration; see
`docs/decisions/0002-java-as-sole-production-language.md` and
`dotnet-core/docs/decisions/0003-equipment-module-boundary.md`).

**Scope:** domain types, **character ownership**, and an explicit
persistence model. Since Master Phase 12–14 every `ItemEquipment` belongs to
exactly one character (`character.contracts.CharacterId`, mandatory and
immutable; "an item id is equipped at most once" is therefore *per character*),
and the module exposes `EquipmentSnapshot` / `EquippedItemSnapshot`
(category and slot stored by enum *name*) as its public persistence/runtime
model. `ItemEquipment.fromSnapshot` re-equips through the normal rules, so a
corrupt snapshot fails instead of producing an impossible state. Services and
events are still deliberately absent — see "Not Yet Migrated".

## Files

```
modules/equipment/
├── MODULE.md                          (this file)
├── public/contracts/                   EquipmentSnapshot, EquippedItemSnapshot (persistence model)
├── public/events/                      (.gitkeep placeholder only)
└── internal/
    ├── services/                       (.gitkeep placeholder only)
    └── domain/
        ├── EquipmentSlot.java          enum: HEAD, CHEST, LEGS, FEET, MAIN_HAND, OFF_HAND
        ├── EquipmentSlots.java         ALL (ordered, immutable) + isValid(slot)
        ├── ItemCategory.java           enum: WEAPON, ARMOR, CONSUMABLE, MATERIAL, MISCELLANEOUS
        ├── ItemDefinition.java         immutable, self-validating record
        ├── ItemEquipment.java          the aggregate: equip / unequip / getEquipped / isSlotOccupied / isEquipped / slots
        ├── EquipmentSlotState.java     read-only snapshot of one slot (slot + optional item)
        ├── EquipStatus.java            SUCCESS, NOT_EQUIPPABLE, INVALID_SLOT, INCOMPATIBLE_SLOT, SLOT_OCCUPIED, ALREADY_EQUIPPED
        ├── EquipResult.java            status + item + requested slot + blocking item
        ├── UnequipStatus.java          SUCCESS, SLOT_EMPTY, INVALID_SLOT
        └── UnequipResult.java          status + requested slot + removed item
```

Tests mirror this under `tests/modules/equipment/domain/`. The aggregate is
`ItemEquipment`, not `Equipment`, mirroring `inventory.domain.ItemInventory`
and the C# reference.

## Behavior (ported from the C# reference)

- **ItemDefinition:** `id`, `name`, `category`, `maxStackSize` (default 1),
  optional `slot`. `name` not blank; `category` declared; `maxStackSize >= 1`;
  **equippable ⇔ it has a slot** (`isEquippable()` is derived); an equippable
  item must have `maxStackSize == 1`. Validation order matches the C# constructor.
- **equip(item, slot)** — first failure wins, nothing changes on any failure:
  `NOT_EQUIPPABLE` → `INVALID_SLOT` → `INCOMPATIBLE_SLOT` → `ALREADY_EQUIPPED`
  (same `ItemId` already equipped, compared with `.equals()`) → `SLOT_OCCUPIED`
  (never replaces; `blockingItem()` names the occupant).
- **unequip(slot)** — `SUCCESS` (removed item returned in the result, never
  discarded), `SLOT_EMPTY`, or `INVALID_SLOT`.
- **Gameplay refusals are result values.** Exceptions are for programmer
  errors: null `item` in `equip`, null `ItemId` in `isEquipped`, and an
  invalid slot given to the query methods.
- **slots()** returns a fresh, unmodifiable snapshot of all six slots (empty
  ones included, in `EquipmentSlots.ALL` order); earlier snapshots never change.
- Invariants after every call: each equipped item is equippable and sits in
  the slot its definition names; a slot holds at most one item; an `ItemId`
  is equipped at most once (deliberate; revisit if dual-wielding two
  identical items is ever introduced).

## Differences From The C# Reference (noted, not hidden)

- **No "undeclared" enum values in Java.** A C# enum can hold `default` or an
  integer cast; a Java enum cannot. The only invalid slot/category a Java
  caller can pass is `null`, so `null` takes the place of C#'s undeclared
  value everywhere: `equip(item, null)` → `INVALID_SLOT` result;
  `unequip(null)` → `INVALID_SLOT` result; `getEquipped(null)` /
  `isSlotOccupied(null)` → `IllegalArgumentException`; `new ItemDefinition(...,
  category = null, ...)` → `IllegalArgumentException`. In the results,
  `requestedSlot()` is then `null`. (`ItemDefinition.slot() == null` still
  means "not equippable", exactly as in C#.)
- **Exception mapping** follows the Inventory module's convention:
  `ArgumentNullException` → `NullPointerException`;
  `ArgumentOutOfRangeException` / `ArgumentException` → `IllegalArgumentException`.
- **Numeric enum values dropped.** C# enums carry explicit values starting at 1
  (so `default` = 0 is never valid). Java has no such need; declaration order
  is the canonical slot order. Append new slots at the end, never reorder.
- **`EquipResult` / `UnequipResult` are final classes, not records.** C# hides
  their constructor (`private`, with an `internal` factory) so only
  `ItemEquipment` creates them; a Java record cannot hide its canonical
  constructor, so they use a private constructor plus package-private
  `create(...)` factories, with `equals`/`hashCode`/`toString` to keep value semantics.
- **Default parameters** (`maxStackSize = 1`, `slot = null`) become
  `ItemDefinition` convenience constructors.
- **`slots()` instead of `GetSlots()`**, matching `ItemInventory.slots()`;
  nullable returns (`getEquipped`, `slot()`, `item()`) follow `InventorySlot.stack()`.
- **Tests:** 49 methods vs. the C# reference's 50. `ItemDefinitionTests.UndeclaredSlotIsRejected`
  has no Java equivalent (an undeclared slot is unrepresentable; `null` slot is
  legitimately "not equippable"). Other "undeclared value" tests collapse to
  their `null` case. Everything else is a direct port.

## Dependencies

- `inventory.contracts.ItemId` — Inventory's public, canonical item identity.
  There is no exception to the "other modules' public surface only" rule any
  more: Equipment imports nothing from `inventory.domain` (main or tests; checked by
  the static audit). The cross-module check `EquipmentInventoryCompatibilityTest`
  lives with the application-layer tests, which may see both aggregates.
- `character.contracts.CharacterId` — the owner identity, nothing else from Character.
- No Progression or `core.*` reference. No Bukkit/Paper/Minecraft
  types — buildable/testable without a server.

## Not Yet Migrated (deliberately, this step)

- `equipment.services.*`, `equipment.contracts.*`, `equipment.events.*`.
- Item database/registry, loot, crafting, trading, shops, durability,
  enchantments, stat bonuses, class/race restrictions, persistence,
  networking, GUI, multi-slot items, automatic Inventory ↔ Equipment
  transactions, swap-on-equip — all also out of scope in the C# reference.

## Tests

`tests/modules/equipment/domain/`: `ItemDefinitionTest`, `EquipmentSlotTest`,
`ItemEquipmentTest`, `ItemEquipmentOwnershipTest` (ownership + snapshot round trip) —
run by `tests/support`'s `@Test`/`Assertions`/`TestRunner` harness.
`EquipmentInventoryCompatibilityTest` (5) moved to
`tests/application/runtime/` because it is the one test that needs both modules' aggregates.
