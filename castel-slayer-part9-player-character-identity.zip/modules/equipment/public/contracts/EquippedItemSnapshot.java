package equipment.contracts;

import inventory.contracts.ItemId;
import java.util.Objects;

/**
 * One equipped item in an {@link EquipmentSnapshot}: the item's identity and the full
 * description Equipment needs to rebuild it. Plain data with explicit, stable names — the
 * category and slot are stored as their enum <em>names</em> (e.g. {@code "ARMOR"},
 * {@code "MAIN_HAND"}), never as ordinals or as Equipment's internal types, so the stored form
 * survives enum reordering and needs nothing from {@code equipment.domain}.
 *
 * <p>Only shape is checked here (non-null/non-blank, {@code maxStackSize >= 1}); whether the
 * names are real categories/slots and whether the item is consistent (an equippable item has
 * stack size 1, sits in the slot it names) is checked when Equipment restores it, through the
 * normal domain rules.
 *
 * @param itemId       the item's canonical identity
 * @param name         display/identity name
 * @param category     {@code ItemCategory} name
 * @param maxStackSize the item definition's stack limit (1 for equippable items)
 * @param slot         {@code EquipmentSlot} name the item is equipped in
 */
public record EquippedItemSnapshot(ItemId itemId, String name, String category, int maxStackSize, String slot) {

    public EquippedItemSnapshot {
        Objects.requireNonNull(itemId, "itemId");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(category, "category");
        Objects.requireNonNull(slot, "slot");
        if (name.isBlank()) {
            throw new IllegalArgumentException("name must not be blank");
        }
        if (category.isBlank()) {
            throw new IllegalArgumentException("category must not be blank");
        }
        if (slot.isBlank()) {
            throw new IllegalArgumentException("slot must not be blank");
        }
        if (maxStackSize < 1) {
            throw new IllegalArgumentException("maxStackSize must be at least 1 (was " + maxStackSize + ")");
        }
    }
}
