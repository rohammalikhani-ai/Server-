package equipment.contracts;

import character.contracts.CharacterId;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Equipment's explicit persistence/runtime model: which character owns the equipment and what
 * is currently equipped. An immutable value — this, never the internal {@code ItemEquipment}
 * aggregate, is what crosses {@code IPersistenceGateway}.
 *
 * <p>Only occupied slots are listed. Items are normalised to slot-name order and each slot
 * may appear once, so equal equipment always yields equal snapshots.
 *
 * @param ownerId the {@link CharacterId} that owns the equipment; must not be null
 * @param items   the equipped items, at most one per slot
 */
public record EquipmentSnapshot(CharacterId ownerId, List<EquippedItemSnapshot> items) {

    public EquipmentSnapshot {
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(items, "items");
        Set<String> slots = new HashSet<>();
        for (EquippedItemSnapshot item : items) {
            Objects.requireNonNull(item, "items must not contain null");
            if (!slots.add(item.slot())) {
                throw new IllegalArgumentException("slot " + item.slot() + " holds more than one item");
            }
        }
        items = items.stream().sorted(Comparator.comparing(EquippedItemSnapshot::slot)).toList();
    }
}
