package progression.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * A character's base attribute values plus every currently active
 * {@link AttributeModifier}. Deliberately separate from
 * {@link CharacterStatsProfile} and {@link ProgressionState} (requirement 6:
 * separate base values, modifiers, and derived statistics) so each stays
 * small and independently testable instead of one aggregate growing into a
 * God Object.
 *
 * <p>{@link #addModifier} and {@link #removeModifier} are public because
 * Java has no assembly-scoped "internal" visibility, but per this module's
 * own boundary convention (see {@code MODULE.md}, ARCHITECTURE.md's
 * "enforced by convention and code review" rule) only
 * {@code progression.services.AttributeModifierService} is meant to call
 * them — validation/business rules belong in the service layer, not
 * scattered across callers.
 */
public final class CharacterAttributes {

    public static final int MIN_BASE_VALUE = 0;
    public static final int MAX_BASE_VALUE = 999;

    private final Map<AttributeType, Integer> base;
    private final Map<String, AttributeModifier> modifiers = new LinkedHashMap<>();

    public CharacterAttributes(Map<AttributeType, Integer> baseValues) {
        Objects.requireNonNull(baseValues, "baseValues");

        for (AttributeType type : AttributeType.values()) {
            Integer value = baseValues.get(type);
            if (value == null) {
                throw new IllegalArgumentException(
                        "Base attributes must specify a value for every AttributeType (missing " + type + ")");
            }
            if (value < MIN_BASE_VALUE || value > MAX_BASE_VALUE) {
                throw new IllegalArgumentException(
                        type + " base value must be between " + MIN_BASE_VALUE + " and " + MAX_BASE_VALUE
                                + " (was " + value + ")");
            }
        }

        this.base = new EnumMap<>(baseValues);
    }

    public int baseValue(AttributeType type) {
        return base.get(type);
    }

    public Collection<AttributeModifier> modifiers() {
        return Collections.unmodifiableCollection(modifiers.values());
    }

    /**
     * Registers a new modifier. Throws if a modifier with the same
     * {@link AttributeModifier#key()} (source + modifier id) is already
     * active — callers must remove the existing one first, so a source can
     * never silently double-apply (requirement 12: invalid-state protection).
     */
    public void addModifier(AttributeModifier modifier) {
        Objects.requireNonNull(modifier, "modifier");

        if (modifiers.putIfAbsent(modifier.key(), modifier) != null) {
            throw new IllegalStateException(
                    "A modifier with source '" + modifier.source() + "' and id '" + modifier.modifierId()
                            + "' is already active");
        }
    }

    /**
     * Removes a previously-applied modifier. Throws if no such modifier is
     * active, so callers cannot silently no-op on a mistaken source/id.
     */
    public void removeModifier(String source, String modifierId) {
        String key = source + ":" + modifierId;
        if (modifiers.remove(key) == null) {
            throw new IllegalStateException(
                    "No active modifier with source '" + source + "' and id '" + modifierId + "'");
        }
    }

    /**
     * The attribute value after every active modifier is applied: all
     * {@link ModifierOperation#FLAT} modifiers are added to the base value
     * first, then every {@link ModifierOperation#PERCENT_ADDITIVE} modifier
     * is summed and applied as a single percentage against that
     * flat-adjusted value. Result is floored to an integer and clamped to a
     * minimum of zero — deterministic and side-effect free.
     */
    public int effectiveValue(AttributeType type) {
        double value = baseValue(type);

        double flatSum = modifiers.values().stream()
                .filter(m -> m.attribute() == type && m.operation() == ModifierOperation.FLAT)
                .mapToDouble(AttributeModifier::value)
                .sum();
        value += flatSum;

        double percentSum = modifiers.values().stream()
                .filter(m -> m.attribute() == type && m.operation() == ModifierOperation.PERCENT_ADDITIVE)
                .mapToDouble(AttributeModifier::value)
                .sum();
        value *= 1.0 + percentSum / 100.0;

        int result = (int) Math.floor(value);
        return Math.max(result, 0);
    }
}
