package progression.domain;

/**
 * The minimum base attribute set a character has, independent of any future
 * race/class/equipment system. Race, class, equipment, buffs, etc. do not
 * add new members here — they contribute {@link AttributeModifier}s against
 * these same types (requirement 5: don't hardcode every future race/class
 * into the system).
 */
public enum AttributeType {
    STRENGTH,
    DEXTERITY,
    INTELLIGENCE,
    VITALITY,
    WISDOM,
    LUCK
}
