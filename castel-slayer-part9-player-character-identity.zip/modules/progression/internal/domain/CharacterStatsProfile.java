package progression.domain;

import character.contracts.CharacterId;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import progression.contracts.CharacterProgressionSnapshot;

/**
 * This module's aggregate root for one character: which
 * {@link CharacterId} it belongs to, its {@link CharacterAttributes}, and
 * its {@link ProgressionState}.
 *
 * <p>This is intentionally thin — it holds state and identity only. Every
 * piece of actual logic (levelling formulas, modifier validation, derived
 * stat formulas) lives in {@code progression.services.*}, so this class
 * cannot grow into a God Object as more systems (equipment, buffs, classes)
 * start contributing to a character's stats (requirement 2).
 *
 * <p>Mirrors the shape of {@code character.domain.PlayerCharacter} (identity
 * + state, logic delegated to services) rather than introducing a new
 * pattern.
 *
 * <p>{@link #replaceProgression} is public for the same reason
 * {@link CharacterAttributes#addModifier} is: Java has no assembly-scoped
 * visibility. Only {@code progression.services.LevelingService} is meant to
 * call it, by convention — see {@code MODULE.md}.
 */
public final class CharacterStatsProfile {

    private final CharacterId characterId;
    private final CharacterAttributes attributes;
    private ProgressionState progression;

    private CharacterStatsProfile(CharacterId characterId, CharacterAttributes attributes, ProgressionState progression) {
        this.characterId = Objects.requireNonNull(characterId, "characterId");
        this.attributes = Objects.requireNonNull(attributes, "attributes");
        this.progression = Objects.requireNonNull(progression, "progression");
    }

    /** Creates a brand-new profile for a freshly-created character: level 1, zero XP. */
    public static CharacterStatsProfile createNew(CharacterId characterId, CharacterAttributes attributes) {
        return new CharacterStatsProfile(characterId, attributes, ProgressionState.initial());
    }

    /**
     * Reconstitutes a profile from previously-persisted state (e.g. loaded
     * through {@code core.contracts.IPersistenceGateway} on the platform
     * side). Takes an explicit {@link ProgressionState} rather than starting
     * at level 1, unlike {@link #createNew}.
     */
    public static CharacterStatsProfile reconstitute(CharacterId characterId, CharacterAttributes attributes,
                                                       ProgressionState progression) {
        return new CharacterStatsProfile(characterId, attributes, progression);
    }

    /**
     * Rebuilds a profile from its persistence model. Attribute names are validated through the
     * normal domain rules, so an unknown, missing or out-of-range attribute is rejected. Modifiers
     * are never part of a snapshot — see {@link CharacterProgressionSnapshot}.
     *
     * @throws IllegalArgumentException unknown/missing/out-of-range attribute, or invalid level/XP
     */
    public static CharacterStatsProfile fromSnapshot(CharacterProgressionSnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");

        Map<AttributeType, Integer> base = new EnumMap<>(AttributeType.class);
        for (Map.Entry<String, Integer> entry : snapshot.baseAttributes().entrySet()) {
            try {
                base.put(AttributeType.valueOf(entry.getKey()), entry.getValue());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Unknown attribute name '" + entry.getKey() + "' in stored progression", e);
            }
        }
        return new CharacterStatsProfile(snapshot.characterId(), new CharacterAttributes(base),
                new ProgressionState(snapshot.level(), snapshot.totalXp()));
    }

    /** An immutable copy of the persistable state (level, XP, base attributes — not modifiers). */
    public CharacterProgressionSnapshot toSnapshot() {
        Map<String, Integer> base = new LinkedHashMap<>();
        for (AttributeType type : AttributeType.values()) {
            base.put(type.name(), attributes.baseValue(type));
        }
        return new CharacterProgressionSnapshot(characterId, progression.level(), progression.totalXp(), base);
    }

    /**
     * Replaces this profile's progression state. Only
     * {@code progression.services.LevelingService} should call this, after
     * validating and computing the new state itself.
     */
    public void replaceProgression(ProgressionState newState) {
        this.progression = Objects.requireNonNull(newState, "newState");
    }

    public CharacterId characterId() {
        return characterId;
    }

    public CharacterAttributes attributes() {
        return attributes;
    }

    public ProgressionState progression() {
        return progression;
    }
}
