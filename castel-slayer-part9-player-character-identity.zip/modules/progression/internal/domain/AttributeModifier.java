package progression.domain;

import java.util.Objects;

/**
 * A single contribution to one {@link AttributeType} from some source
 * outside this module — equipment, a buff, a class bonus, a profession
 * perk, etc. This module knows nothing about what a "source" is beyond this
 * opaque string; that is exactly the seam future modules (equipment, buffs,
 * classes, ...) attach through without this module depending on them
 * (requirement 6).
 *
 * @param modifierId unique, together with {@code source}, so the same source can
 *                    apply more than one distinct modifier and each can be
 *                    individually removed (e.g. a weapon granting both a
 *                    Strength and a Dexterity bonus)
 * @param source      opaque identifier for whatever granted this modifier, e.g.
 *                    {@code "equipment:iron-sword"}, {@code "buff:blessing-of-vigor"}.
 *                    Used only for lookup/removal — this module never interprets it
 */
public record AttributeModifier(
        String modifierId,
        String source,
        AttributeType attribute,
        ModifierOperation operation,
        double value) {

    public AttributeModifier {
        if (modifierId == null || modifierId.isBlank()) {
            throw new IllegalArgumentException("modifierId cannot be null or blank");
        }
        if (source == null || source.isBlank()) {
            throw new IllegalArgumentException("source cannot be null or blank");
        }
        Objects.requireNonNull(attribute, "attribute");
        Objects.requireNonNull(operation, "operation");
    }

    /** The compound key this modifier is stored/looked up under. */
    public String key() {
        return source + ":" + modifierId;
    }
}
