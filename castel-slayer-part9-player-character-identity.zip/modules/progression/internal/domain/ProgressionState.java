package progression.domain;

/**
 * A character's level/XP as of a point in time. Immutable — advancing it
 * always produces a new {@link ProgressionState} (via
 * {@code progression.services.LevelingService}), never a mutation in place,
 * so the progression formulas stay pure and unit-testable in isolation
 * (requirement 8: keep progression formulas isolated and unit-testable).
 *
 * @param level    1-based character level
 * @param totalXp  total XP accumulated over the character's lifetime (not "XP into this level")
 */
public record ProgressionState(int level, long totalXp) {

    public static final int MIN_LEVEL = 1;

    public ProgressionState {
        if (level < MIN_LEVEL) {
            throw new IllegalArgumentException("level must be >= " + MIN_LEVEL + " (was " + level + ")");
        }
        if (totalXp < 0) {
            throw new IllegalArgumentException("totalXp cannot be negative (was " + totalXp + ")");
        }
    }

    public static ProgressionState initial() {
        return new ProgressionState(MIN_LEVEL, 0);
    }
}
