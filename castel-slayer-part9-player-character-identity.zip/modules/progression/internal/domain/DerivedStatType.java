package progression.domain;

/**
 * Statistics computed from a character's effective attributes (base values
 * plus every active {@link AttributeModifier}), never stored or set
 * directly. See {@code progression.services.DerivedStatCalculator} for the
 * (prototype, tunable) formulas.
 */
public enum DerivedStatType {
    MAX_HEALTH,
    MAX_MANA,
    PHYSICAL_POWER,
    MAGIC_POWER,
    DEFENSE,
    SPEED
}
