package progression.domain;

/**
 * How an {@link AttributeModifier}'s value combines with a base attribute
 * value. Deliberately minimal for the prototype (requirement 8:
 * future-proof, not over-engineered) — additional operations can be added
 * to this enum without changing any modifier's shape.
 */
public enum ModifierOperation {

    /** Added directly to the base value before percent modifiers apply. */
    FLAT,

    /**
     * A percentage (e.g. 10 = +10%) applied to the base value after all flat
     * modifiers, and summed additively with any other percent modifiers on
     * the same attribute.
     */
    PERCENT_ADDITIVE
}
