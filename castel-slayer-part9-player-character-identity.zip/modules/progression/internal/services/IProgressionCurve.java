package progression.services;

import progression.domain.ProgressionState;

/**
 * Defines how much cumulative XP a level requires. Kept behind an interface
 * so the actual balancing formula can change (or become race/class/config-
 * driven later) without touching {@link LevelingService} — the leveling
 * algorithm itself (accumulate XP, cross thresholds, cap at max level) is
 * formula-agnostic.
 */
public interface IProgressionCurve {

    /** The highest level a character can reach; XP gained at this level is capped, not accumulated further. */
    int maxLevel();

    /**
     * The total (cumulative, lifetime) XP a character must have to be at
     * exactly {@code level}. Must be non-decreasing in {@code level}, and 0
     * for {@link ProgressionState#MIN_LEVEL}.
     */
    long totalXpRequiredForLevel(int level);
}
