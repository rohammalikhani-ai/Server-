package progression.services;

import java.util.Objects;
import progression.domain.AttributeModifier;
import progression.domain.CharacterStatsProfile;

/**
 * The entry point every future contributor (equipment, buffs, classes,
 * professions, races) is expected to go through to add or remove a stat
 * contribution — none of those systems should touch
 * {@code progression.domain.CharacterAttributes}'s mutation methods
 * directly, even though nothing stops them at compile time. Keeping the
 * call path here means validation/logging/future authority-checks have one
 * place to live, matching requirement 9 (server-authoritative, no scattered
 * mutation paths) applied to stat modifiers specifically.
 */
public final class AttributeModifierService {

    /** @throws IllegalStateException a modifier with the same source + modifier id is already active on this profile */
    public void applyModifier(CharacterStatsProfile profile, AttributeModifier modifier) {
        Objects.requireNonNull(profile, "profile");
        Objects.requireNonNull(modifier, "modifier");

        profile.attributes().addModifier(modifier);
    }

    /** @throws IllegalStateException no modifier with this source + modifier id is currently active */
    public void removeModifier(CharacterStatsProfile profile, String source, String modifierId) {
        Objects.requireNonNull(profile, "profile");

        profile.attributes().removeModifier(source, modifierId);
    }
}
