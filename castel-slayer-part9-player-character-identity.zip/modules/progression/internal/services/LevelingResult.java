package progression.services;

import java.util.List;
import progression.domain.ProgressionState;
import progression.events.CharacterLeveledUp;

/**
 * The outcome of one {@link LevelingService#gainXp} call. Carries the
 * events that occurred rather than publishing them directly, so
 * {@link LevelingService} stays a pure function with no
 * {@code core.contracts.IEventBus} dependency (requirement 8: isolated,
 * unit-testable formulas) — the caller decides how/whether to publish them.
 */
public record LevelingResult(ProgressionState newState, int levelsGained, List<CharacterLeveledUp> events) {
}
