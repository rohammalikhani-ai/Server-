package progression.services;

import progression.domain.ProgressionState;

/**
 * The prototype's default leveling curve: reaching level {@code L+1} from
 * level {@code L} costs {@code 100 * L} XP, so cumulative XP required for
 * level {@code L} is {@code 100 * (L - 1) * L / 2} (a triangular number).
 * Deliberately simple and easy to hand-verify; real balancing is future work
 * and can swap in a different {@link IProgressionCurve} without changing
 * {@link LevelingService}.
 */
public final class DefaultProgressionCurve implements IProgressionCurve {

    private static final long XP_PER_LEVEL_STEP = 100;
    private static final int DEFAULT_MAX_LEVEL = 60;

    private final int maxLevel;

    public DefaultProgressionCurve() {
        this(DEFAULT_MAX_LEVEL);
    }

    public DefaultProgressionCurve(int maxLevel) {
        if (maxLevel < ProgressionState.MIN_LEVEL) {
            throw new IllegalArgumentException(
                    "maxLevel must be >= " + ProgressionState.MIN_LEVEL + " (was " + maxLevel + ")");
        }
        this.maxLevel = maxLevel;
    }

    @Override
    public int maxLevel() {
        return maxLevel;
    }

    @Override
    public long totalXpRequiredForLevel(int level) {
        if (level < ProgressionState.MIN_LEVEL || level > maxLevel) {
            throw new IllegalArgumentException(
                    "level must be between " + ProgressionState.MIN_LEVEL + " and " + maxLevel + " (was " + level + ")");
        }

        long stepsCompleted = level - 1;
        return XP_PER_LEVEL_STEP * stepsCompleted * (stepsCompleted + 1) / 2;
    }
}
