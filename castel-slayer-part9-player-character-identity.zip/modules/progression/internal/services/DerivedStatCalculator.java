package progression.services;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import progression.domain.AttributeType;
import progression.domain.CharacterAttributes;
import progression.domain.DerivedStatType;

/**
 * Computes {@link DerivedStatType} values from a character's effective
 * attributes. Pure and deterministic — same attributes always produce the
 * same derived stats, no hidden state, no randomness.
 *
 * <p>The formulas below are prototype placeholders (requirement 8: do not
 * over-engineer; real balancing is future work) but are wired through a
 * single method so a future prompt can retune them without touching
 * anything that calls {@link #calculate}.
 */
public final class DerivedStatCalculator {

    public Map<DerivedStatType, Integer> calculate(CharacterAttributes attributes) {
        Objects.requireNonNull(attributes, "attributes");

        int strength = attributes.effectiveValue(AttributeType.STRENGTH);
        int dexterity = attributes.effectiveValue(AttributeType.DEXTERITY);
        int intelligence = attributes.effectiveValue(AttributeType.INTELLIGENCE);
        int vitality = attributes.effectiveValue(AttributeType.VITALITY);
        int wisdom = attributes.effectiveValue(AttributeType.WISDOM);
        int luck = attributes.effectiveValue(AttributeType.LUCK);

        Map<DerivedStatType, Integer> derived = new EnumMap<>(DerivedStatType.class);
        derived.put(DerivedStatType.MAX_HEALTH, 50 + vitality * 10 + strength * 2);
        derived.put(DerivedStatType.MAX_MANA, 20 + intelligence * 8 + wisdom * 4);
        derived.put(DerivedStatType.PHYSICAL_POWER, strength * 2 + dexterity);
        derived.put(DerivedStatType.MAGIC_POWER, intelligence * 2 + wisdom);
        derived.put(DerivedStatType.DEFENSE, vitality + strength / 2);
        derived.put(DerivedStatType.SPEED, dexterity + luck / 2);
        return derived;
    }
}
