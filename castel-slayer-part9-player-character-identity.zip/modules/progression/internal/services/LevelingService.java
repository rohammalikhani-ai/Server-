package progression.services;

import java.time.Clock;
import java.util.List;
import java.util.Objects;
import progression.domain.CharacterStatsProfile;
import progression.domain.ProgressionState;
import progression.events.CharacterLeveledUp;

/**
 * The single, authoritative place XP is accumulated and levels are crossed
 * (requirement 8: do not spread level/XP calculations across multiple
 * modules). Only ever called with server-side amounts computed by other
 * core systems (e.g. combat's kill-reward calculation) — this service, and
 * everything that calls it, must never accept an XP/level value supplied
 * directly by a client (requirement 7).
 *
 * <p>Takes a {@link Clock} (mirroring {@code character.services.CharacterFactory})
 * only to timestamp the {@link CharacterLeveledUp} events it returns — Java's
 * {@code core.events.GameEvent} requires an {@code occurredAt()}, unlike the
 * C# reference implementation's marker-only event interface.
 */
public final class LevelingService {

    private final IProgressionCurve curve;
    private final Clock clock;

    public LevelingService(IProgressionCurve curve, Clock clock) {
        this.curve = Objects.requireNonNull(curve, "curve");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /**
     * Applies an XP gain to {@code profile}, advancing zero or more levels,
     * and returns the result. Mutates {@code profile}'s progression state as
     * a side effect (via its {@code replaceProgression}) — {@code profile}
     * is the one piece of mutable state this service owns changing;
     * everything else here is pure computation.
     *
     * @throws IllegalArgumentException {@code amount} is not positive. XP gains must be a
     *                                  positive amount; use a dedicated correction path (not this
     *                                  method) for any future admin/debug adjustment
     */
    public LevelingResult gainXp(CharacterStatsProfile profile, long amount) {
        Objects.requireNonNull(profile, "profile");

        if (amount <= 0) {
            throw new IllegalArgumentException("XP gained must be a positive amount (was " + amount + ")");
        }

        ProgressionState state = profile.progression();

        if (state.level() >= curve.maxLevel()) {
            // Already at the level cap: XP has nothing left to buy. Discard
            // rather than accumulating unbounded totalXp past what any level
            // will ever require.
            return new LevelingResult(state, 0, List.of());
        }

        long newTotalXp = state.totalXp() + amount;
        int newLevel = state.level();

        while (newLevel < curve.maxLevel() && newTotalXp >= curve.totalXpRequiredForLevel(newLevel + 1)) {
            newLevel++;
        }

        if (newLevel == curve.maxLevel()) {
            // Cap accumulated XP at exactly what the max level requires, so
            // totalXp never carries an unbounded, meaningless overflow once
            // there is nowhere left to spend it.
            long capXp = curve.totalXpRequiredForLevel(curve.maxLevel());
            if (newTotalXp > capXp) {
                newTotalXp = capXp;
            }
        }

        ProgressionState newState = new ProgressionState(newLevel, newTotalXp);
        profile.replaceProgression(newState);

        int levelsGained = newLevel - state.level();
        List<CharacterLeveledUp> events = levelsGained > 0
                ? List.of(new CharacterLeveledUp(profile.characterId(), state.level(), newLevel, clock.instant()))
                : List.of();

        return new LevelingResult(newState, levelsGained, events);
    }
}
