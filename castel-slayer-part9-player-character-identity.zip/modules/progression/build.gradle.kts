// :modules:progression — depends on :modules:character (character.contracts.CharacterId) and :core (core.events.GameEvent).
// Source layout is unchanged: modules/progression/internal/ and modules/progression/public/ are the
// source roots (packages are declared per sub-folder, e.g. internal/domain -> `progression.domain`),
// same approach as :core's build file. Tests live outside the module under tests/.

plugins {
    java
}

sourceSets {
    main {
        java {
            setSrcDirs(listOf("internal", "public"))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/modules/progression"), rootProject.file("tests/support")))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    implementation(project(":core"))
    implementation(project(":modules:character"))
}
