package progression.contracts;

import character.contracts.CharacterId;
import java.util.Map;
import java.util.Objects;

/**
 * Progression's explicit persistence/runtime model for one character: level, lifetime XP and
 * base attribute values. An immutable value — this, never the internal
 * {@code CharacterStatsProfile} aggregate, is what crosses {@code IPersistenceGateway}.
 *
 * <p>Base attributes are keyed by {@code AttributeType} <em>name</em> (e.g.
 * {@code "STRENGTH"}), not by the internal enum, so the stored form depends on no internal type.
 * Whether every attribute is present and in range is checked when Progression restores it.
 *
 * <p><b>Deliberately not included: attribute modifiers.</b> A modifier is contributed by an
 * outside source (equipment, a buff, a class) and identified by that source; the source is
 * responsible for re-applying it when the character becomes active. Persisting them here as
 * well would make a restored profile double-apply them the moment such an integration exists.
 * No modifier source exists yet, so nothing is lost today; see this module's {@code MODULE.md}.
 *
 * @param characterId    the owning character; must not be null
 * @param level          1-based level; at least 1
 * @param totalXp        lifetime XP; not negative
 * @param baseAttributes base value per {@code AttributeType} name
 */
public record CharacterProgressionSnapshot(CharacterId characterId, int level, long totalXp,
                                           Map<String, Integer> baseAttributes) {

    public CharacterProgressionSnapshot {
        Objects.requireNonNull(characterId, "characterId");
        Objects.requireNonNull(baseAttributes, "baseAttributes");
        if (level < 1) {
            throw new IllegalArgumentException("level must be at least 1 (was " + level + ")");
        }
        if (totalXp < 0) {
            throw new IllegalArgumentException("totalXp cannot be negative (was " + totalXp + ")");
        }
        baseAttributes = Map.copyOf(baseAttributes);
    }
}
