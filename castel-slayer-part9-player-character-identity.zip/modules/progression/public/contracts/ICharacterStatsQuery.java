package progression.contracts;

import character.contracts.CharacterId;
import java.util.Optional;
import progression.domain.DerivedStatType;

/**
 * The read-only surface other modules (combat, equipment, quest, ...) are
 * meant to depend on once they need a character's level or derived stats —
 * never {@code progression.domain.CharacterStatsProfile} or any other
 * internal type directly (ARCHITECTURE.md → module public/internal split).
 *
 * <p>This is an extension point only for now: no implementation exists yet.
 * Per DEVELOPMENT_RULES.md ("never create a manager/service/class for a
 * feature that isn't being built yet"), a concrete persistence-/registry-
 * backed implementation is deliberately deferred to whichever future prompt
 * actually needs another module to query stats (requirement 10: only the
 * extension points required are created now, not the systems that would
 * consume them).
 */
public interface ICharacterStatsQuery {

    /** The current level, if {@code characterId} has a stats profile. */
    Optional<Integer> findLevel(CharacterId characterId);

    /** The current derived value, if {@code characterId} has a stats profile. */
    Optional<Integer> findDerivedStat(CharacterId characterId, DerivedStatType stat);
}
