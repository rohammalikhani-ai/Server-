package progression.events;

import character.contracts.CharacterId;
import core.events.GameEvent;
import java.time.Instant;
import java.util.Objects;

/**
 * Published when a character's level increases (by one or more levels in a
 * single XP gain). Other systems (combat unlocking a skill slot, quest
 * tracking a "reach level N" objective, etc.) observe level-ups through this
 * event instead of coupling directly to this module (requirement 9).
 *
 * @param characterId the character that leveled up
 * @param fromLevel   level before this XP gain
 * @param toLevel     level after this XP gain (may be more than one level higher)
 * @param occurredAt  when this level-up occurred, server time
 */
public record CharacterLeveledUp(CharacterId characterId, int fromLevel, int toLevel, Instant occurredAt)
        implements GameEvent {

    public CharacterLeveledUp {
        Objects.requireNonNull(characterId, "characterId");
        Objects.requireNonNull(occurredAt, "occurredAt");
    }
}
