# progression

## Purpose

Owns a character's base attributes, active stat modifiers, derived
combat/support statistics, and level/XP progression. This is the Java
migration of the reference implementation built under the since-reversed
Prompt 05 C#-first decision (`dotnet-core/src/CastelSlayer.Modules.Progression`
— kept as reference only, not modified by this migration; see
`docs/decisions/0002-java-as-sole-production-language.md`).

## Responsibilities

- Storing each `AttributeType`'s base value and every currently active
  `AttributeModifier` from any source (equipment, buffs, classes, ...)
  (`progression.domain.CharacterAttributes`).
- Computing an attribute's effective value (base + flat modifiers, then
  summed percent-additive modifiers), and `DerivedStatType` values from
  those effective attributes (`progression.services.DerivedStatCalculator`).
- Server-authoritative level/XP progression via a pluggable curve
  (`progression.domain.ProgressionState`, `progression.services.IProgressionCurve`
  / `DefaultProgressionCurve`, `progression.services.LevelingService`),
  observable through `progression.events.CharacterLeveledUp`.
- Validated apply/remove of stat modifiers through one entry point
  (`progression.services.AttributeModifierService`) rather than every future
  contributor mutating `CharacterAttributes` directly.

## Files

```
modules/progression/
├── MODULE.md                                   (this file)
├── public/
│   ├── contracts/
│   │   └── ICharacterStatsQuery.java            declared extension point, no implementation yet
│   └── events/
│       └── CharacterLeveledUp.java
└── internal/
    ├── domain/
    │   ├── AttributeType.java                   Strength, Dexterity, Intelligence, Vitality, Wisdom, Luck
    │   ├── DerivedStatType.java                 MaxHealth, MaxMana, PhysicalPower, MagicPower, Defense, Speed
    │   ├── ModifierOperation.java                Flat, PercentAdditive
    │   ├── AttributeModifier.java
    │   ├── CharacterAttributes.java              base values + modifiers + effective-value calculation
    │   ├── ProgressionState.java                 immutable Level/TotalXp
    │   └── CharacterStatsProfile.java             aggregate root: CharacterId + CharacterAttributes + ProgressionState
    └── services/
        ├── IProgressionCurve.java / DefaultProgressionCurve.java   triangular-number XP curve, 100 XP per level-step, default max level 60
        ├── DerivedStatCalculator.java             pure formulas
        ├── AttributeModifierService.java          validated apply/remove
        ├── LevelingResult.java
        └── LevelingService.java                    the sole authoritative XP-gain/level-up path
```

Tests mirror this under `tests/modules/progression/{domain,services}/`.

## Persistence model

`CharacterStatsProfile.toSnapshot()` / `fromSnapshot(CharacterProgressionSnapshot)` — the
public, immutable persistence model (`progression.contracts.CharacterProgressionSnapshot`:
owner, level, lifetime XP, base attributes keyed by attribute *name*). Attribute
**modifiers are deliberately not stored**: their source (equipment, buffs, ...) re-applies them
when the character becomes active, otherwise a restore would double-apply them.
`CharacterLeveledUp` events are still returned by `LevelingService`, not published by it.

## Dependencies

- `character.contracts.CharacterId` — every profile is keyed by the
  existing character module's id, mirroring how the deprecated C#
  reference attached to `CastelSlayer.Core.Domain.CharacterId`.
- `core.events.GameEvent` — implemented by `CharacterLeveledUp`. Unlike the
  C# reference's marker-only `IGameEvent`, Java's `GameEvent` requires an
  `occurredAt()`, so `LevelingService` takes a `java.time.Clock` (mirroring
  `character.services.CharacterFactory`) purely to timestamp the events it
  returns.
- No dependency on `core.contracts.IEventBus` — like the C# reference,
  `LevelingService` stays a pure function that returns events; the caller
  is responsible for publishing them.
- No dependency on any other module, on Bukkit/Paper/any Minecraft or
  third-party plugin API, or on `platform/*` — buildable/testable
  standalone (requirement 11).

## Public Interfaces Exposed

- `progression.contracts.ICharacterStatsQuery` — declared as the future
  read surface for other modules, **no implementation yet** (deliberately
  — nothing consumes it in this migration, matching the C# reference).
- `progression.events.CharacterLeveledUp` — subscribe via `IEventBus` (once
  a caller wires `LevelingService`'s returned events to one) to react to a
  character's level-ups.

`progression.services.LevelingService`, `AttributeModifierService`, and
`DerivedStatCalculator` are concrete classes, not contracts — wired
directly for now, consistent with `character.services.CharacterFactory`
(no composition root exists yet; see `CURRENT_STATE.md`).

## Interfaces Consumed

- `character.contracts.CharacterId`.

## Configuration

None yet. `DefaultProgressionCurve`'s max level (default 60) and XP-per-
level-step (100) are constructor/constant values, not read through
`core.contracts.IConfigProvider` — matching the C# reference's scope.

## Tests

`tests/modules/progression/domain/CharacterAttributesTest.java` (10
methods), `tests/modules/progression/domain/CharacterStatsProfileTest.java`
(4 methods), `tests/modules/progression/services/DerivedStatCalculatorTest.java`
(3 methods), `tests/modules/progression/services/LevelingServiceTest.java`
(9 methods) — migrated from the C# reference's equivalent test classes,
adapted to this module's Java types and to `tests/support`'s
`@Test`/`Assertions`/`TestRunner` harness (same harness `character`'s tests
use, for the same reason: no network access to fetch JUnit here).

One behavioral divergence from the C# reference, noted rather than hidden:
`CharacterStatsProfileTests.EmptyCharacterIdIsRejected` exercised C#'s
`Guid.Empty` rejection. The existing Java `character.contracts.CharacterId`
has no reserved "empty" UUID sentinel — its only rejection case is a null
value — so the migrated test (`emptyCharacterIdIsRejected`) asserts that
instead. This is a difference in the id type this module was told to reuse,
not a design choice made during this migration.

## Forbidden Responsibilities

- Race, class, equipment, buffs, professions, guild, reputation, knowledge,
  housing, history — future systems that attach via `AttributeModifier`s,
  not fields added here.
- Persistence, networking, GUI, Bukkit/Paper/Minecraft integration of any
  kind.
- Publishing events itself — `LevelingService` returns events; it does not
  depend on `core.contracts.IEventBus`.
- Inventory or Equipment logic — untouched by this migration.
