package inventory.contracts;

import java.util.Objects;

/**
 * One occupied slot of an {@link InventorySnapshot}: which slot, which item type, that
 * type's stack limit, and how many are held. Plain data — the persistence-facing twin of
 * Inventory's internal {@code ItemStack} + slot index, without exposing those types.
 *
 * @param slotIndex    zero-based slot position; must be non-negative
 * @param itemId       which item type; must not be null
 * @param maxStackSize the item type's largest stack size; at least 1
 * @param quantity     how many are held; between 1 and {@code maxStackSize}
 */
public record InventoryStackSnapshot(int slotIndex, ItemId itemId, int maxStackSize, int quantity) {

    public InventoryStackSnapshot {
        Objects.requireNonNull(itemId, "itemId");
        if (slotIndex < 0) {
            throw new IllegalArgumentException("slotIndex must be non-negative (was " + slotIndex + ")");
        }
        if (maxStackSize < 1) {
            throw new IllegalArgumentException("maxStackSize must be at least 1 (was " + maxStackSize + ")");
        }
        if (quantity < 1 || quantity > maxStackSize) {
            throw new IllegalArgumentException(
                    "quantity must be between 1 and maxStackSize " + maxStackSize + " (was " + quantity + ")");
        }
    }
}
