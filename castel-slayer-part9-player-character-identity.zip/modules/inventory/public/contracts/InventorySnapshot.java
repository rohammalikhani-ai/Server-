package inventory.contracts;

import character.contracts.CharacterId;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Inventory's explicit persistence/runtime model: who owns the inventory, how many slots
 * it has, and which slots are occupied by what. An immutable value — this, never the internal
 * {@code ItemInventory} aggregate, is what crosses {@code IPersistenceGateway}.
 *
 * <p>Only occupied slots are listed; every other slot is empty. The list is normalised to
 * ascending slot order, so two inventories with the same contents always produce equal
 * snapshots regardless of how they were built.
 *
 * @param ownerId  the {@link CharacterId} that owns the inventory; must not be null
 * @param capacity total slot count; at least 1
 * @param stacks   the occupied slots; each index within {@code [0, capacity)}, none repeated
 */
public record InventorySnapshot(CharacterId ownerId, int capacity, List<InventoryStackSnapshot> stacks) {

    public InventorySnapshot {
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(stacks, "stacks");
        if (capacity < 1) {
            throw new IllegalArgumentException("capacity must be at least 1 (was " + capacity + ")");
        }
        Set<Integer> seen = new HashSet<>();
        for (InventoryStackSnapshot stack : stacks) {
            Objects.requireNonNull(stack, "stacks must not contain null");
            if (stack.slotIndex() >= capacity) {
                throw new IllegalArgumentException(
                        "slotIndex " + stack.slotIndex() + " is outside capacity " + capacity);
            }
            if (!seen.add(stack.slotIndex())) {
                throw new IllegalArgumentException("slotIndex " + stack.slotIndex() + " appears more than once");
            }
        }
        stacks = stacks.stream()
                .sorted(Comparator.comparingInt(InventoryStackSnapshot::slotIndex))
                .toList();
    }
}
