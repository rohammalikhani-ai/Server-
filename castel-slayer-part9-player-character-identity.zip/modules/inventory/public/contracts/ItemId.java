package inventory.contracts;

import java.util.Objects;

/**
 * Stable identifier of an item type (e.g. {@code "health_potion"}) — the single,
 * canonical item identity of the codebase. Inventory's domain, Equipment's
 * definitions and every snapshot use this one type; there is deliberately no
 * internal twin and no converter.
 *
 * <p>Only an identifier: no item database or registry sits behind it. Two stacks
 * hold "the same item" when their {@code ItemId}s are equal.
 *
 * @param value the identifier text; must not be null, empty, or blank
 */
public record ItemId(String value) {

    public ItemId {
        Objects.requireNonNull(value, "value");
        if (value.isBlank()) {
            throw new IllegalArgumentException("ItemId cannot be empty or whitespace");
        }
    }

    @Override
    public String toString() {
        return value;
    }
}
