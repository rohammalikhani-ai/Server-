// :modules:inventory — depends on :modules:character, and only for character.contracts.CharacterId
// (every inventory is owned by a character). Nothing under this module may import
// character.internal-only types, and it must never depend on :modules:equipment.
// Source layout is unchanged: modules/inventory/internal/ and modules/inventory/public/ are the
// source roots (packages are declared per sub-folder, e.g. internal/domain -> `inventory.domain`),
// same approach as :core's build file. Tests live outside the module under tests/.

plugins {
    java
}

sourceSets {
    main {
        java {
            setSrcDirs(listOf("internal", "public"))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/modules/inventory"), rootProject.file("tests/support")))
            // tests/support's InMemoryEventBus / InMemoryPersistenceGateway implement
            // :core contracts, and this module's tests use neither. Leaving them out keeps
            // :core off this project's test classpath instead of adding a dependency that
            // only the shared test doubles would need.
            exclude("InMemoryEventBus.java", "InMemoryPersistenceGateway.java")
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    implementation(project(":modules:character"))
}
