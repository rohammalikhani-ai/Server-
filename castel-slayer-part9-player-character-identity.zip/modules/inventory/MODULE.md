# inventory (Java)

## Purpose

Java migration of the Inventory Foundation: a small, server-authoritative,
slot-based item container. Nothing more — this is not the final game
inventory. This is the Java counterpart of the since-deprecated C#
reference built under the reversed Prompt 05 decision
(`dotnet-core/src/CastelSlayer.Modules.Inventory` — kept as reference
only, not modified by this migration; see
`docs/decisions/0002-java-as-sole-production-language.md`).

**Scope:** domain/value objects, **character ownership**, and an explicit
persistence model. Since Master Phase 12–14 every `ItemInventory` belongs to
exactly one character (`character.contracts.CharacterId`, mandatory and
immutable), and the module exposes `InventorySnapshot` /
`InventoryStackSnapshot` as its public persistence/runtime model. Services,
events and a query interface are still deliberately absent — see "Not Yet
Migrated" below.

## Responsibilities

- Identifying an item type (`inventory.contracts.ItemId` — the codebase's
  single canonical item identity, also used by Equipment) and its minimal
  definition — identity plus stack-size limit, nothing else
  (`inventory.domain.Item`).
- Holding a validated, always-in-range quantity of one item
  (`inventory.domain.ItemStack`: `1 <= quantity <= item.maxStackSize()`,
  enforced in the compact constructor).
- A fixed-capacity, slot-based container with add/remove/has/count
  operations, all server-authoritative (`inventory.domain.ItemInventory`).
- Read-only slot snapshots so callers can observe state without ever
  mutating it directly (`inventory.domain.InventorySlot`).
- Being owned by exactly one character: `ItemInventory(CharacterId ownerId, int capacity)`,
  `ownerId()` never changes and is never a `PlayerId` or Bukkit UUID.
- Converting to/from an immutable persistence model
  (`toSnapshot()` / `ItemInventory.fromSnapshot(InventorySnapshot)`) so nothing
  persists the internal slot array; a restore re-validates (e.g. conflicting item definitions).
- Reporting exactly how much of a request was fulfilled versus left over,
  so nothing is ever silently gained or lost
  (`inventory.domain.AddItemResult`, `inventory.domain.RemoveItemResult`).

## Files

```
modules/inventory/
├── MODULE.md                          (this file)
├── public/contracts/
│   ├── ItemId.java                     the canonical non-blank string item id
│   ├── InventorySnapshot.java          owner + capacity + occupied slots (persistence model)
│   └── InventoryStackSnapshot.java     one occupied slot: index, ItemId, max stack, quantity
└── internal/
    └── domain/
        ├── Item.java                   ItemId + maxStackSize (>= 1) — minimal, not an item definition
        ├── ItemStack.java              Item + quantity, always 1..maxStackSize
        ├── InventorySlot.java          read-only snapshot: index + optional stack
        ├── ItemInventory.java          fixed-capacity slots; addItem / removeItem / hasItem / countOf
        ├── AddItemResult.java          requested / added / remaining
        └── RemoveItemResult.java       requested / removed / shortfall
```

Tests mirror this under `tests/modules/inventory/domain/`
(`ItemInventoryOwnershipTest` covers ownership and the snapshot round trip).

The aggregate is named `ItemInventory`, not `Inventory`, carrying over the
C# reference's own naming rationale (a type named `Inventory` inside a
module/package named `inventory` reads ambiguously, even though Java does
not raise the compiler diagnostic — CS0118 — that motivated it in C#).

## Behavior

Ported behaviorally from the C# reference (`ItemInventory.cs`), verified
line-by-line against it:

- **addItem(item, qty):** tops up existing stacks of the same item (slot
  order), then fills empty slots. Whatever does not fit comes back in
  `AddItemResult.remainingQuantity()`; the caller still holds it, nothing
  is lost.
- **removeItem(itemId, qty):** removes only what is present (lowest slot
  first) and reports `shortfallQuantity()` for the rest. Emptied slots
  become empty — a zero-quantity stack never exists. Callers that need
  all-or-nothing check `hasItem` first or test `isFullyRemoved()`.
- **hasItem(itemId, qty)** (default `qty = 1`, via overload since Java has
  no default parameters): true if total held across stacks >= qty.
- **Invalid input** (qty < 1, null arguments, bad slot index, capacity < 1)
  throws and leaves the inventory unchanged. Adding an item whose `ItemId`
  is already held with a different `maxStackSize` throws (two conflicting
  definitions).

## Behavioral Divergences From The C# Reference (noted, not hidden)

- **Value equality via `.equals()`, not `==`.** C# `record` types overload
  `==`/`!=` to mean value equality; Java records only override `.equals()`
  — `==` stays reference equality. Every comparison the C# source made
  with `==`/`!=` on `Item`/`ItemId` (e.g. `stack.Item != item` when
  topping up a stack, `stack.Item.Id == item.Id` when checking for a
  conflicting definition) is translated to `.equals()` in the Java port.
  This preserves the original value-equality behavior; using Java's `==`
  in the same spots would have silently changed the semantics.
- **Invalid slot index throws `IllegalArgumentException`, not
  `IndexOutOfBoundsException`.** The C# reference throws
  `ArgumentOutOfRangeException`. This codebase's established Java
  convention (see e.g. `progression.domain.CharacterAttributes`,
  `core.domain.Location`) validates every argument — including indices —
  with `IllegalArgumentException` rather than reaching for
  `IndexOutOfBoundsException`; this migration follows that local
  convention rather than introducing a new exception type for one method.
- **No `hasItem(itemId, qty = 1)` default parameter.** Java has no
  default arguments; `hasItem(ItemId)` is a one-line overload delegating
  to `hasItem(ItemId, int)` with `1`.

## Dependencies

`:modules:character`, **only** for `character.contracts.CharacterId` (the owner
identity). No Equipment reference, no `core.*` reference, no Minecraft/Bukkit/Paper types —
buildable/testable without a server.

## Not Yet Migrated (deliberately, this step)

- `inventory.services.*` — the add/remove orchestration lives on
  `ItemInventory` itself for now (as it does in the C# reference); no
  separate service layer exists yet on either side.
- A `public/contracts` *query* interface beyond `ItemId` and the snapshot records
  — add one only when a second module actually needs it.
- Events, a persistence *engine* (the snapshot is only the model), item database/registry, item effects, durability,
  enchantments, equipment integration, trading, shop, crafting, GUI —
  all out of scope for the C# reference this migrates and therefore out
  of scope here too.

## Tests

`tests/modules/inventory/domain/ItemStackTest.java` (8 methods) and
`tests/modules/inventory/domain/ItemInventoryTest.java` (19 methods) —
migrated from the C# reference's `ItemStackTests` (8) and
`ItemInventoryTests` (19), adapted to this module's Java types and to
`tests/support`'s `@Test`/`Assertions`/`TestRunner` harness (the same
harness `progression` and `character`'s tests use, for the same reason:
no network access to fetch a real test framework here).

No test coverage was added, removed, or altered beyond this direct port —
same 27 cases, same intent, same edge cases (zero/negative quantities,
null arguments, out-of-range index, conflicting item definitions, partial
add/remove, overflow/shortfall accounting, multi-slot fill).

## Forbidden Responsibilities

- Equipment, loot, trading, shop, crafting, persistence, item database,
  item effects, durability, enchantments, GUI, race/class integration,
  networking, inventory ownership/`CharacterId` binding, events — none of
  these are added here; they belong to future modules or later prompts.
- Bukkit/Paper/Minecraft integration of any kind.
