package inventory.domain;

/**
 * A read-only view of one slot: either empty ({@link #stack()} is
 * {@code null}) or holding one {@link ItemStack}. It is a snapshot value —
 * holding one never lets a caller change the inventory; only
 * {@link ItemInventory}'s own methods can (server authority over item
 * ownership).
 *
 * @param index zero-based position of the slot within its inventory
 * @param stack the stack in the slot, or {@code null} when the slot is empty
 */
public record InventorySlot(int index, ItemStack stack) {

    public boolean isEmpty() {
        return stack == null;
    }
}
