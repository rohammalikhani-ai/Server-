package inventory.domain;

import java.util.Objects;

/**
 * A quantity of one {@link Item}. Immutable, and always valid:
 * {@code 1 <= quantity <= item.maxStackSize()}. An empty stack is
 * represented by the absence of a stack (an empty {@link InventorySlot}),
 * never by a zero-quantity stack.
 *
 * @param item     the item type held
 * @param quantity how many; must be between 1 and {@code item.maxStackSize()} inclusive
 */
public record ItemStack(Item item, int quantity) {

    public ItemStack {
        Objects.requireNonNull(item, "item");
        if (quantity < 1) {
            throw new IllegalArgumentException("quantity must be at least 1 (was " + quantity + ")");
        }
        if (quantity > item.maxStackSize()) {
            throw new IllegalArgumentException(
                    "quantity cannot exceed the item's maxStackSize (" + item.maxStackSize()
                            + ") (was " + quantity + ")");
        }
    }

    /** How many more of the item this stack can still take. */
    public int freeSpace() {
        return item.maxStackSize() - quantity;
    }

    /** Returns a copy of this stack with a different (still validated) quantity. */
    public ItemStack withQuantity(int newQuantity) {
        return new ItemStack(item, newQuantity);
    }
}
