package inventory.domain;

/**
 * Outcome of {@link ItemInventory#addItem}. Whatever did not fit is
 * reported in {@link #remainingQuantity()} — the caller still owns it;
 * the inventory never silently discards items.
 *
 * @param requestedQuantity how much was asked to be added; must be at least 1
 * @param addedQuantity     how much was actually added; must be between 0 and {@code requestedQuantity}
 */
public record AddItemResult(int requestedQuantity, int addedQuantity) {

    public AddItemResult {
        if (requestedQuantity < 1) {
            throw new IllegalArgumentException(
                    "requestedQuantity must be at least 1 (was " + requestedQuantity + ")");
        }
        if (addedQuantity < 0 || addedQuantity > requestedQuantity) {
            throw new IllegalArgumentException(
                    "addedQuantity must be between 0 and requestedQuantity (was " + addedQuantity + ")");
        }
    }

    /** The part of the request that did NOT fit and is still with the caller. */
    public int remainingQuantity() {
        return requestedQuantity - addedQuantity;
    }

    public boolean isFullyAdded() {
        return remainingQuantity() == 0;
    }
}
