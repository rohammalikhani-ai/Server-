package inventory.domain;

import character.contracts.CharacterId;
import inventory.contracts.InventorySnapshot;
import inventory.contracts.InventoryStackSnapshot;
import inventory.contracts.ItemId;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A fixed number of slots, each empty or holding one {@link ItemStack}.
 * This is the only place item quantities change: slots are private and
 * exposed only as read-only {@link InventorySlot} snapshots, so no caller
 * (client, AI, other module) can edit ownership directly — they must go
 * through {@link #addItem} / {@link #removeItem}.
 *
 * <p>Named {@code ItemInventory} rather than {@code Inventory}, carrying
 * over the C# reference's own naming rationale: a type named
 * {@code Inventory} inside a package/module named {@code inventory} reads
 * ambiguously to anyone skimming imports, even though Java (unlike C#) does
 * not actually raise a compiler diagnostic (CS0118) over it.
 *
 * <p>Every inventory belongs to exactly one character: the owning
 * {@link CharacterId} is mandatory and fixed at construction, and no operation
 * can change it. Ownership is identity only — this class holds no character
 * behaviour, and the owner is never a {@code PlayerId} or a Bukkit UUID.
 *
 * <p>The module's persistence/runtime model is {@link InventorySnapshot}
 * ({@link #toSnapshot()} / {@link #fromSnapshot}); the internal slot array
 * never leaves this class.
 *
 * <p>Item identity is the module's single public {@link ItemId}
 * ({@code inventory.contracts.ItemId}); there is no second, internal id type.
 *
 * <p>No Minecraft/Bukkit/Paper, persistence-engine, or networking
 * dependency lives here. Not thread-safe; the caller (a future
 * single-threaded authority) owns synchronization.
 */
public final class ItemInventory {

    private final CharacterId ownerId;
    private final ItemStack[] slots;

    /**
     * @param ownerId  the character that owns this inventory; must not be null
     * @param capacity number of slots; must be at least 1
     */
    public ItemInventory(CharacterId ownerId, int capacity) {
        this.ownerId = Objects.requireNonNull(ownerId, "ownerId");
        if (capacity < 1) {
            throw new IllegalArgumentException("capacity must be at least 1 (was " + capacity + ")");
        }
        this.slots = new ItemStack[capacity];
    }

    /**
     * Rebuilds an inventory from its persistence model, keeping the exact slot layout
     * (gaps included). The result shares nothing with the snapshot or any other inventory.
     *
     * @throws IllegalArgumentException the snapshot holds two conflicting definitions of one item
     */
    public static ItemInventory fromSnapshot(InventorySnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");

        ItemInventory inventory = new ItemInventory(snapshot.ownerId(), snapshot.capacity());
        for (InventoryStackSnapshot stack : snapshot.stacks()) {
            Item item = new Item(stack.itemId(), stack.maxStackSize());
            inventory.ensureNoConflictingDefinition(item);
            inventory.slots[stack.slotIndex()] = new ItemStack(item, stack.quantity());
        }
        return inventory;
    }

    /** The character that owns this inventory. Fixed for the inventory's lifetime. */
    public CharacterId ownerId() {
        return ownerId;
    }

    /** An immutable copy of this inventory's persistable state; later changes do not affect it. */
    public InventorySnapshot toSnapshot() {
        List<InventoryStackSnapshot> stacks = new ArrayList<>();
        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = slots[i];
            if (stack != null) {
                stacks.add(new InventoryStackSnapshot(i, stack.item().id(), stack.item().maxStackSize(), stack.quantity()));
            }
        }
        return new InventorySnapshot(ownerId, slots.length, stacks);
    }

    public int capacity() {
        return slots.length;
    }

    /**
     * @throws IllegalArgumentException {@code index} is negative or {@code >= capacity()}.
     * Uses {@code IllegalArgumentException} rather than
     * {@code IndexOutOfBoundsException} to match this codebase's established
     * convention of validating every argument with {@code IllegalArgumentException}
     * (see e.g. {@code progression.domain.CharacterAttributes}), rather than the
     * C# reference's {@code ArgumentOutOfRangeException}, which has no single
     * direct Java equivalent.
     */
    public InventorySlot slot(int index) {
        if (index < 0 || index >= slots.length) {
            throw new IllegalArgumentException(
                    "index must be between 0 and " + (slots.length - 1) + " (was " + index + ")");
        }
        return new InventorySlot(index, slots[index]);
    }

    /** A snapshot of every slot, in index order. */
    public List<InventorySlot> slots() {
        List<InventorySlot> snapshot = new ArrayList<>(slots.length);
        for (int i = 0; i < slots.length; i++) {
            snapshot.add(new InventorySlot(i, slots[i]));
        }
        return snapshot;
    }

    /** Total quantity of the given item across all slots (0 if none). */
    public long countOf(ItemId itemId) {
        Objects.requireNonNull(itemId, "itemId");

        long total = 0;
        for (ItemStack stack : slots) {
            if (stack != null && stack.item().id().equals(itemId)) {
                total += stack.quantity();
            }
        }
        return total;
    }

    /** True if the inventory holds at least 1 of the item. Equivalent to {@code hasItem(itemId, 1)}. */
    public boolean hasItem(ItemId itemId) {
        return hasItem(itemId, 1);
    }

    /**
     * True if the inventory holds at least {@code quantity} of the item.
     *
     * @throws IllegalArgumentException {@code quantity} is less than 1
     */
    public boolean hasItem(ItemId itemId, int quantity) {
        Objects.requireNonNull(itemId, "itemId");
        requireValidQuantity(quantity);

        return countOf(itemId) >= quantity;
    }

    /**
     * Adds as much of the request as fits: first tops up existing stacks of the
     * same item (in slot order), then fills empty slots (in slot order). What
     * does not fit is returned in {@link AddItemResult#remainingQuantity()}
     * and is not lost — the caller still holds it.
     *
     * @throws IllegalArgumentException {@code quantity} is less than 1, or the
     *         inventory already holds the same {@link ItemId} with a
     *         different {@link Item#maxStackSize()} (two conflicting
     *         definitions of one item)
     */
    public AddItemResult addItem(Item item, int quantity) {
        Objects.requireNonNull(item, "item");
        requireValidQuantity(quantity);
        ensureNoConflictingDefinition(item);

        int remaining = quantity;

        // Pass 1: top up existing stacks of this item.
        for (int i = 0; i < slots.length && remaining > 0; i++) {
            ItemStack stack = slots[i];
            if (stack == null || !stack.item().equals(item) || stack.freeSpace() == 0) {
                continue;
            }

            int toAdd = Math.min(stack.freeSpace(), remaining);
            slots[i] = stack.withQuantity(stack.quantity() + toAdd);
            remaining -= toAdd;
        }

        // Pass 2: open new stacks in empty slots.
        for (int i = 0; i < slots.length && remaining > 0; i++) {
            if (slots[i] != null) {
                continue;
            }

            int toAdd = Math.min(item.maxStackSize(), remaining);
            slots[i] = new ItemStack(item, toAdd);
            remaining -= toAdd;
        }

        return new AddItemResult(quantity, quantity - remaining);
    }

    /**
     * Removes up to {@code quantity} of the item, taking from the lowest
     * slot index first and emptying any slot that reaches zero. If less
     * than requested is present, only what is present is removed and the
     * difference is reported in {@link RemoveItemResult#shortfallQuantity()}.
     *
     * @throws IllegalArgumentException {@code quantity} is less than 1
     */
    public RemoveItemResult removeItem(ItemId itemId, int quantity) {
        Objects.requireNonNull(itemId, "itemId");
        requireValidQuantity(quantity);

        int remaining = quantity;

        for (int i = 0; i < slots.length && remaining > 0; i++) {
            ItemStack stack = slots[i];
            if (stack == null || !stack.item().id().equals(itemId)) {
                continue;
            }

            if (stack.quantity() > remaining) {
                slots[i] = stack.withQuantity(stack.quantity() - remaining);
                remaining = 0;
            } else {
                remaining -= stack.quantity();
                slots[i] = null;
            }
        }

        return new RemoveItemResult(quantity, quantity - remaining);
    }

    private static void requireValidQuantity(int quantity) {
        if (quantity < 1) {
            throw new IllegalArgumentException("quantity must be at least 1 (was " + quantity + ")");
        }
    }

    private void ensureNoConflictingDefinition(Item item) {
        for (ItemStack stack : slots) {
            if (stack != null && stack.item().id().equals(item.id()) && !stack.item().equals(item)) {
                throw new IllegalArgumentException(
                        "Item '" + item.id() + "' conflicts with the definition already in this inventory"
                                + " (different maxStackSize)");
            }
        }
    }
}
