package inventory.domain;

/**
 * Outcome of {@link ItemInventory#removeItem}. Removal takes only what is
 * actually present; anything asked for beyond that is reported in
 * {@link #shortfallQuantity()} and never drives a stack negative.
 *
 * @param requestedQuantity how much was asked to be removed; must be at least 1
 * @param removedQuantity   how much was actually removed; must be between 0 and {@code requestedQuantity}
 */
public record RemoveItemResult(int requestedQuantity, int removedQuantity) {

    public RemoveItemResult {
        if (requestedQuantity < 1) {
            throw new IllegalArgumentException(
                    "requestedQuantity must be at least 1 (was " + requestedQuantity + ")");
        }
        if (removedQuantity < 0 || removedQuantity > requestedQuantity) {
            throw new IllegalArgumentException(
                    "removedQuantity must be between 0 and requestedQuantity (was " + removedQuantity + ")");
        }
    }

    /** How much of the request could not be removed because it was not in the inventory. */
    public int shortfallQuantity() {
        return requestedQuantity - removedQuantity;
    }

    public boolean isFullyRemoved() {
        return shortfallQuantity() == 0;
    }
}
