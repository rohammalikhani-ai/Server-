package inventory.domain;

import inventory.contracts.ItemId;
import java.util.Objects;

/**
 * The minimal item model the Inventory domain needs: an identity and how
 * many of it fit in one stack. Not an item definition — no name, category,
 * effects, durability, etc. (all explicitly out of scope here, matching the
 * C# reference this migrates).
 *
 * @param id           which item type this is
 * @param maxStackSize largest quantity allowed in a single stack; must be at least 1
 */
public record Item(ItemId id, int maxStackSize) {

    public Item {
        Objects.requireNonNull(id, "id");
        if (maxStackSize < 1) {
            throw new IllegalArgumentException("maxStackSize must be at least 1 (was " + maxStackSize + ")");
        }
    }
}
