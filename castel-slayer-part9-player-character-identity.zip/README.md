# CASTEL SLAYER

A fantasy MMORPG that uses **Minecraft as its runtime/platform** — not as
the game design itself. Minecraft supplies rendering, movement, base
networking, audio/video, and server execution. Castel Slayer owns the
actual game: races, classes, stats, combat, quests, dungeons, economy,
professions, factions, world memory, and long-term progression.

> **Status:** Architecture & Foundation phase (Prompt 01). No gameplay
> systems are implemented yet. This repository is a skeleton with
> defined module boundaries, contracts, and documentation for future
> prompts to build on.

## Start Here

If you are an AI assistant or a developer picking this project up,
read in this order:

1. [`PROJECT_MAP.md`](./PROJECT_MAP.md) — what every directory/module does
2. [`ARCHITECTURE.md`](./ARCHITECTURE.md) — layering, boundaries, contracts
3. [`DESIGN_PRINCIPLES.md`](./DESIGN_PRINCIPLES.md) — non-negotiable rules
4. [`DEVELOPMENT_RULES.md`](./DEVELOPMENT_RULES.md) — the AI/dev workflow
5. [`CURRENT_STATE.md`](./CURRENT_STATE.md) — what exists right now
6. [`CHANGELOG.md`](./CHANGELOG.md) — history of changes

Then read only the `MODULE.md` files relevant to the task at hand —
never the whole codebase at once.

## Current Prototype Scope (1–3 months)

A small playable vertical slice: one small city + nearby areas, a
preset race/class system, stats & progression, basic combat, a
handful of NPCs and quests, enemies with loot, inventory/equipment,
basic economy, one dungeon with one boss, and multiplayer
persistence — enough to feel like the beginning of a real world, not
a tech demo.

## Long-Term Vision (not built now, but not blocked by today's design)

Guilds, Parties, Professions, Crafting, Trading, Market/Auction,
Reputation, Factions, Politics, Kingdoms, Crime & Justice,
Academy/Education, Player Knowledge, player-created items/spells,
Housing, Mounts, Pets, Contracts, Mail, World Events, World Memory,
a Living World, Dynamic Economy, Player Governance, a Grand Archive,
large regions/cities, raids, PvP, AI-assisted NPCs/events,
localization, and live operations.

See `/docs/master-architecture-100-sections.md` for the full long-term
specification this project is descended from (originally written for
a Unity + ASP.NET Core stack, now being re-scoped section by section
for Minecraft — see that doc's header for status per section).
