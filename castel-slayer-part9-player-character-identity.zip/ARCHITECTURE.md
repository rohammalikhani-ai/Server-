# ARCHITECTURE

## Java-Only Production (Prompt 08; supersedes the Prompt 05 C# split)

As of Prompt 08, **Java is the sole production language.** All
authoritative gameplay logic is built in Java under `core/` +
`modules/<name>/public|internal`, per
`docs/decisions/0001-jvm-language-and-source-layout.md`.

Prompt 05 had previously moved authoritative gameplay logic to a new C#
tree (`dotnet-core/`), with Java/Fabric reduced to the Minecraft
integration/platform layer. That split is reversed — see
`docs/decisions/0002-java-as-sole-production-language.md` for the full
reasoning. In short:

- `dotnet-core/` is **deprecated and reference-only**. It is not deleted
  and not extended with new modules; it is not on any build or ship path.
  See `dotnet-core/README.md` for its deprecation notice.
- No C#↔Java bridge/integration mechanism is built — the one Prompt 05
  deferred is now moot for production purposes.
- No migration of the C# `Progression`/`Inventory`/`Equipment` modules
  into Java has happened yet. Those systems currently have **no
  authoritative production implementation** until a future prompt rebuilds
  them in Java under `modules/`.
- The layering rules, dependency direction matrix, module public/internal
  split, and communication rules on this page apply to the Java tree only,
  as they did before Prompt 05.

## Layering

```
┌──────────────────────────────────────────────────────────┐
│  platform/  (Java client adapter | Bedrock client adapter) │  ← untrusted input, presentation only
├──────────────────────────────────────────────────────────┤
│  modules/   (character, combat, inventory, quest, ...)     │  ← feature logic, one responsibility each
├──────────────────────────────────────────────────────────┤
│  core/      (domain models, services, events, contracts)   │  ← engine-agnostic rules, source of truth
├──────────────────────────────────────────────────────────┤
│  integrations/  (adapters around external mods/libraries)  │  ← isolate 3rd-party dependencies
├──────────────────────────────────────────────────────────┤
│  database/  (persistence, once chosen)                     │
└──────────────────────────────────────────────────────────┘
```

Dependencies point downward only. This section is the **development
contract**: it says exactly what each layer is allowed to depend on,
so it's always obvious where a new system belongs.

## Dependency Direction Matrix

| Layer | May depend on | May NOT depend on |
|---|---|---|
| `core/domain` | nothing (pure data/value objects) | everything else |
| `core/services`, `core/events`, `core/contracts` | `core/domain` only | `modules`, `platform`, `integrations`, `database`, any external library type |
| `modules/<name>/internal` | `core/*`, its own module's `public/*`, and other modules' `public/contracts` + `public/events` | any other module's `internal/*`; `platform/*`; `integrations/*` directly (only through a `core/contracts` or a module's `public/contracts` interface) |
| `modules/<name>/public` | `core/*` only | any module's `internal/*` (its own included — public code must not leak internal types); `platform/*` |
| `application/runtime` | `core/*`; the four feature modules (`character`, `progression`, `inventory`, `equipment`) | `platform/*`; Bukkit/Paper; gameplay rules of its own (each module keeps its own) |
| `platform/java`, `platform/bedrock` | `core/*`; any module's `public/*`; `application/*` | any module's `internal/*` (the composition root is the one documented exception: it constructs concrete services); each other (`java` and `bedrock` never import from each other — shared logic goes in `platform/shared`) |
| `platform/shared` | `core/*`; any module's `public/*` | `platform/java`, `platform/bedrock` (specific editions depend on `shared`, not the reverse) |
| `integrations/<tool>` | `core/contracts` (what it implements); the external library it wraps | `modules/*`, `platform/*` (integrations are consumed *through* a contract, they don't reach upward) |
| `database/` | nothing in this repo (it's schema/migrations) | everything — only the `persistence` module's `internal` may talk to it, via its own adapter |
| `tests/<mirror path>` | whatever it is testing, at the same visibility rules below | — |

Rule of thumb: **if you're not sure where a dependency is allowed to
point, it points at an interface in `core/contracts` or a module's
`public/contracts`, never at a concrete implementation in another
branch of the tree.**

## Module Internal Structure — Public vs. Private

Every module (`modules/<name>/`) is split into exactly two halves:

```
modules/<name>/
├── MODULE.md
├── public/
│   ├── contracts/   ← interfaces OTHER modules/platform may depend on
│   └── events/      ← event types this module publishes, importable by anyone
└── internal/
    ├── domain/      ← this module's own data models
    └── services/    ← this module's actual logic/implementation
```

- **`public/`** is the module's entire external surface. Nothing else
  is exposed. If another module or a platform adapter needs something
  from this module, it must exist here as a contract or an event —
  it cannot be added "just this once" by importing something from
  `internal/`.
- **`internal/`** is private. No file outside `modules/<name>/` may
  import from `modules/<name>/internal/`, including generated code,
  tests for a *different* module, and platform adapters. Only
  `tests/modules/<name>/` (that module's own tests) and the module's
  own `public/` layer may see into `internal/`.
- This is enforced by convention and code review now; if the chosen
  toolchain later supports compiler-level module boundaries
  (e.g. Java module system, package-private visibility, internal
  keyword), turn this into a hard build error rather than leaving it
  as a convention. Record that as a decision when it happens.
- `core/contracts` holds only the small set of foundational,
  engine-wide interfaces every module needs (currently `IEventBus`,
  `IPersistenceGateway`, `IPlatformPresenter`, `IContentValidator`,
  `IVisibilityProvider`, `IConfigProvider`). Anything narrower —
  "can economy ask inventory if a player owns item X" — belongs in
  that module's own `public/contracts`, not in `core/contracts`.
  `core/contracts` should stay small; if it starts accumulating
  module-specific interfaces, that's a signal they belong in a
  module's `public/` instead.

## Communication Between Modules

Modules do not call each other's internals directly. Two allowed
channels:

1. **Events** (via `core/contracts/IEventBus`, event types declared in
   `modules/<name>/public/events/` or, for truly cross-cutting events
   used by core services regardless of module, in `core/events`) —
   the default. A module publishes a domain event (e.g.
   `PlayerDefeatedEnemy`); any interested module subscribes. See
   `## Event Conventions` in `DEVELOPMENT_RULES.md` for naming and
   shape rules.
2. **Contracts** (`core/contracts` or a module's `public/contracts`)
   — when a synchronous answer is needed (e.g. inventory asking
   economy "can this player afford this?"), the caller depends on the
   interface, not the concrete module. The concrete implementation is
   wired to the interface at startup by a **composition root** (see
   below) — never by a module instantiating another module's concrete
   type itself.

Hard-coded cross-module method calls or shared mutable state are not
allowed (rule 10).

## Composition Root

Somewhere at startup, concrete implementations get wired to the
interfaces that consume them (e.g. the concrete event bus gets handed
to every module that depends on `IEventBus`; the concrete persistence
adapter gets handed to whatever implements `IPersistenceGateway`).
This wiring code is the **only** place in the codebase allowed to
know about concrete types across module boundaries — it is not itself
a module, and no module or platform file may replicate its job by
constructing another module's concrete services directly.

**Resolved (Prompt 09/10):** the composition root lives in
`platform/java`'s `bootstrap` package
(`castelslayer.platform.paper.bootstrap.CompositionRoot`), constructed
once in the Paper plugin's `onEnable` and discarded in `onDisable`.
See `docs/decisions/0003-paper-platform-and-composition-root.md` for
the full reasoning, including why it isn't a separate
`core/bootstrap` yet (only one loader/platform exists so far).

As of Master Phase 12–14 it also assembles the character runtime: event bus, in-memory
persistence gateway, character directory/lifecycle, `CharacterRuntimeService`, `SessionManager`,
`PlayerSessionService` and the event subscription (`PlayerSessionLifecycle`). It contains no logic.

### Character runtime (Master Phase 12–14)

`CharacterId` is the ownership identity of all gameplay state; `PlayerId` only identifies the
connected Minecraft account. `application/runtime` (`:application:runtime`, Paper-free — see
`docs/decisions/0004-application-runtime-layer.md`) composes one active character's module state:

```
Paper player ─► PlayerId ─► PlayerSession ─► CharacterRuntime ─┬─ CharacterSummary (character)
                                                               ├─ CharacterStatsProfile (progression)
                                                               ├─ ItemInventory  (owner = CharacterId)
                                                               └─ ItemEquipment  (owner = CharacterId)
```

- **Join:** `PlayerJoinedWorld` → `PlayerSessionLifecycle` → `PlayerSessionService.join`
  (`CharacterSelector` picks the `CharacterId`, `CharacterRuntimeService.load` builds the runtime,
  `SessionManager.register` makes it active).
- **Quit:** `PlayerLeftWorld` → `PlayerSessionService.quit` (session released, then saved).
- **Persistence:** `CharacterRuntimeService` saves one immutable `CharacterRuntimeSnapshot`
  (the modules' public snapshots) through `IPersistenceGateway`; the dev implementation is
  `core.services.InMemoryPersistenceGateway`. Load results distinguish not-found, retired and failed.

## Server Authority

`core/services` is where cross-cutting authority checks live. Nothing
in `platform/` (client input) can directly mutate Gold, Items,
Ownership, Trades, Permissions, Damage, or Progression — those always
go through a `core` service that validates the action server-side
first (rule 9). The same applies to AI-generated content: the
`ai-director` module only *proposes*; `IContentValidator`
approves/rejects/repairs against game rules, schema, economy impact,
and lore before anything is committed.

## Dual-Client Presentation

One authoritative game state, two presentation adapters
(`platform/java`, `platform/bedrock`). They may render different
UI/models/animations/effects for the same state (rule 6). Contracts
in `core/contracts` define what data a platform adapter receives —
never Minecraft-specific types crossing back into `core` or
`modules`. Logic genuinely shared by both editions (but still
presentation-layer, not game rules) lives in `platform/shared` and is
depended on by both — see the Dependency Direction Matrix above.

## Story Phasing / Personal Visibility

Handled by the `world-state` module: it computes, per player, which
entities/objects/states are visible based on quest/faction/reputation/
event conditions, and exposes that through `IVisibilityProvider`,
which platform adapters query before sending anything to a client
(rule 7).

## Configuration Strategy

All tunable values are read through `core/contracts/IConfigProvider`
— no module or platform file reads a raw config file, environment
variable, or plugin-config object directly. Config keys are
namespaced by owning module (`<module-name>.<key>`, e.g.
`economy.startingGold`); cross-cutting keys not owned by one module
use `core.<key>`. Each module documents the keys it depends on and
their defaults in its own `MODULE.md` once implemented, rather than
one global schema file. See `core/contracts/IConfigProvider.md` for
the interface and open questions (concrete config source is not yet
chosen).

## External Dependencies

External mods/plugins/libraries/frameworks are wrapped in
`integrations/<tool-name>/`, each implementing a `core/contracts` or
module `public/contracts` interface. No module, `core`, or `platform`
file imports an external library's types directly — only the
integration adapter may. See `## External Dependency Wrapping` in
`DEVELOPMENT_RULES.md` for the exact rules and what each integration
folder must contain.

## Extension Points Defined Now

These interfaces exist in `core/contracts` from the start so future
systems (rule 8: future-proof, not over-engineered — these are empty
extension points, not fake implementations) can be added without
reshaping the core:

- `IEventBus` — publish/subscribe contract used by all modules.
- `IPersistenceGateway` — how any module saves/loads state, without
  knowing which database is behind it.
- `IPlatformPresenter` — what a platform adapter must implement to
  receive core state and forward client input back.
- `IContentValidator` — what any AI-proposed or externally-sourced
  content (quest, dialogue, encounter) must pass through before it
  can affect authoritative state.
- `IVisibilityProvider` — how world-state answers "what can this
  player see right now."
- `IConfigProvider` — how any module or platform adapter reads
  configuration without knowing the config source (added Prompt 02).

See `core/contracts/` for the actual interface stubs. Module-specific
contracts (e.g. an inventory query interface economy depends on) are
*not* listed here — they live in that module's own `public/contracts`
and get documented in its `MODULE.md` instead, per the "keep
`core/contracts` small" rule above.

## Documentation Rule

Every module gets a `MODULE.md` (created when work on that module
begins) covering: purpose, responsibilities, files, dependencies,
public interfaces exposed (its `public/contracts` and
`public/events`), interfaces consumed, configuration keys, tests, and
forbidden responsibilities (what this module must *not* do, to keep
boundaries honest). `PROJECT_MAP.md` stays the index of what every
directory/module does.
