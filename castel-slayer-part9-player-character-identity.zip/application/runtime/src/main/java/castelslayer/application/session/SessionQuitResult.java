package castelslayer.application.session;

import core.domain.PlayerId;
import java.util.Objects;

/**
 * The outcome of {@link PlayerSessionService#quit}. In every case the session is released and the
 * runtime is no longer active; what differs is whether its state reached the store.
 */
public sealed interface SessionQuitResult {

    /** The session was released and the character's state saved. */
    record Saved(PlayerSession session) implements SessionQuitResult {
        public Saved {
            Objects.requireNonNull(session, "session");
        }
    }

    /** The player had no active session (e.g. they never had a character). Nothing to save. */
    record NoSession(PlayerId playerId) implements SessionQuitResult {
        public NoSession {
            Objects.requireNonNull(playerId, "playerId");
        }
    }

    /**
     * The session was released but the save failed. The unsaved session is returned so the caller
     * can report it or retry {@code CharacterRuntimeService.save} — state is never silently dropped.
     */
    record SaveFailed(PlayerSession session, Throwable cause) implements SessionQuitResult {
        public SaveFailed {
            Objects.requireNonNull(session, "session");
            Objects.requireNonNull(cause, "cause");
        }
    }
}
