package castelslayer.application.session;

import castelslayer.application.runtime.CharacterLoadResult;
import castelslayer.application.runtime.CharacterRuntimeService;
import character.contracts.CharacterId;
import core.domain.PlayerId;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * The application-level join/quit flow, with no Paper and no gameplay rules:
 *
 * <pre>
 *   join:  PlayerId ─► CharacterSelector ─► CharacterId ─► CharacterRuntimeService.load ─► SessionManager.register
 *   quit:  SessionManager.remove ─► CharacterRuntimeService.save
 * </pre>
 *
 * It orchestrates the pieces and decides nothing about inventory, equipment or progression. Outcomes
 * are explicit result types; only genuine programming errors throw.
 */
public final class PlayerSessionService {

    private final SessionManager sessions;
    private final CharacterSelector selector;
    private final CharacterRuntimeService runtimes;

    public PlayerSessionService(SessionManager sessions, CharacterSelector selector, CharacterRuntimeService runtimes) {
        this.sessions = Objects.requireNonNull(sessions, "sessions");
        this.selector = Objects.requireNonNull(selector, "selector");
        this.runtimes = Objects.requireNonNull(runtimes, "runtimes");
    }

    /** Resolves the player's character, loads its runtime and registers the session. */
    public SessionJoinResult join(PlayerId playerId) {
        Objects.requireNonNull(playerId, "playerId");

        Optional<PlayerSession> existing = sessions.find(playerId);
        if (existing.isPresent()) {
            return new SessionJoinResult.AlreadyActive(existing.get());
        }

        Optional<CharacterId> selected = selector.select(playerId);
        if (selected.isEmpty()) {
            return new SessionJoinResult.NoCharacter(playerId);
        }
        CharacterId characterId = selected.get();

        Optional<PlayerSession> holder = sessions.findByCharacter(characterId);
        if (holder.isPresent()) {
            return new SessionJoinResult.CharacterInUse(playerId, characterId, holder.get().playerId());
        }

        CharacterLoadResult loaded = runtimes.load(characterId);
        if (!(loaded instanceof CharacterLoadResult.Loaded ok)) {
            return new SessionJoinResult.LoadRejected(playerId, loaded);
        }

        // Ownership guard: never trust the selector. A player may only play a character they own.
        PlayerId ownerId = ok.runtime().character().ownerId();
        if (!playerId.equals(ownerId)) {
            String reason = "character " + characterId + " is owned by player " + ownerId
                    + " and cannot be played by player " + playerId;
            return new SessionJoinResult.LoadRejected(playerId,
                    new CharacterLoadResult.Failed(characterId, reason, new IllegalStateException(reason)));
        }

        PlayerSession session = new PlayerSession(playerId, ok.runtime());
        try {
            sessions.register(session);
        } catch (IllegalStateException e) {
            // Another join for this player registered between our "already active?" check and here.
            // The registry kept exactly one session; report it instead of throwing.
            Optional<PlayerSession> winner = sessions.find(playerId);
            if (winner.isPresent()) {
                return new SessionJoinResult.AlreadyActive(winner.get());
            }
            throw e;
        }
        return new SessionJoinResult.Joined(session);
    }

    /** Releases the player's session and saves its state. See {@link SessionQuitResult}. */
    public SessionQuitResult quit(PlayerId playerId) {
        Objects.requireNonNull(playerId, "playerId");

        Optional<PlayerSession> removed = sessions.remove(playerId);
        if (removed.isEmpty()) {
            return new SessionQuitResult.NoSession(playerId);
        }
        PlayerSession session = removed.get();
        try {
            runtimes.save(session.runtime());
        } catch (RuntimeException e) {
            // Deliberate: an application boundary. Whatever went wrong (store outage, ...), the caller
            // gets the unsaved session back instead of an exception that an event bus would swallow.
            return new SessionQuitResult.SaveFailed(session, e);
        }
        return new SessionQuitResult.Saved(session);
    }

    /** Quits every active session (server shutdown): each is released and saved independently. */
    public List<SessionQuitResult> quitAll() {
        List<SessionQuitResult> results = new ArrayList<>();
        for (PlayerSession session : sessions.activeSessions()) {
            results.add(quit(session.playerId()));
        }
        return results;
    }
}
