package castelslayer.application.session;

import character.contracts.CharacterId;
import core.domain.PlayerId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * The in-memory registry of currently active {@link PlayerSession}s — nothing more. It does not
 * load, save or create anything and holds no gameplay logic; it only answers "who is playing
 * which character right now" and refuses to let one player, or one character, be active twice.
 *
 * <p>Instance state only (no statics), so every composition root gets its own independent
 * registry. Methods are synchronized so the two lookup maps can never disagree; that is the
 * whole concurrency story on purpose.
 */
public final class SessionManager {

    private final Map<PlayerId, PlayerSession> byPlayer = new HashMap<>();
    private final Map<CharacterId, PlayerSession> byCharacter = new HashMap<>();

    /**
     * Registers an active session.
     *
     * @throws IllegalStateException the player already has an active session, or the character is
     *                               already active for another player (nothing is registered)
     */
    public synchronized void register(PlayerSession session) {
        Objects.requireNonNull(session, "session");
        if (byPlayer.containsKey(session.playerId())) {
            throw new IllegalStateException("Player " + session.playerId() + " already has an active session");
        }
        if (byCharacter.containsKey(session.characterId())) {
            throw new IllegalStateException("Character " + session.characterId() + " is already active for player "
                    + byCharacter.get(session.characterId()).playerId());
        }
        byPlayer.put(session.playerId(), session);
        byCharacter.put(session.characterId(), session);
    }

    public synchronized Optional<PlayerSession> find(PlayerId playerId) {
        Objects.requireNonNull(playerId, "playerId");
        return Optional.ofNullable(byPlayer.get(playerId));
    }

    public synchronized Optional<PlayerSession> findByCharacter(CharacterId characterId) {
        Objects.requireNonNull(characterId, "characterId");
        return Optional.ofNullable(byCharacter.get(characterId));
    }

    /** Removes and returns the player's session, or empty if they have none. */
    public synchronized Optional<PlayerSession> remove(PlayerId playerId) {
        Objects.requireNonNull(playerId, "playerId");
        PlayerSession removed = byPlayer.remove(playerId);
        if (removed == null) {
            return Optional.empty();
        }
        byCharacter.remove(removed.characterId());
        return Optional.of(removed);
    }

    /** A snapshot copy of the active sessions; changing it does not affect the registry. */
    public synchronized List<PlayerSession> activeSessions() {
        return List.copyOf(byPlayer.values());
    }

    public synchronized int size() {
        return byPlayer.size();
    }
}
