package castelslayer.application.runtime;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import equipment.domain.ItemEquipment;
import inventory.domain.ItemInventory;
import java.util.Objects;
import progression.domain.CharacterStatsProfile;

/**
 * "These module-owned states currently belong to this active character." That is the whole job
 * of this class: it groups one character's {@link CharacterSummary} with the Progression,
 * Inventory and Equipment state that character owns while it is active. It is a runtime
 * composition object, <b>not</b> a domain aggregate — it has no gameplay rules of its own, and
 * each module still owns and enforces its own state.
 *
 * <p>Fail-fast ownership: the constructor rejects any part that belongs to a different
 * {@link CharacterId}, so a runtime that mixes "Character A" with "Inventory B" cannot exist.
 * There is no way to swap a part afterwards (all fields are final, no setters).
 *
 * <p>Instances are created per active character by {@link CharacterRuntimeFactory}; nothing here
 * is static or shared, so two runtimes can never see each other's state.
 */
public final class CharacterRuntime {

    private final CharacterSummary character;
    private final CharacterStatsProfile progression;
    private final ItemInventory inventory;
    private final ItemEquipment equipment;

    /**
     * @throws NullPointerException     any argument is null
     * @throws IllegalArgumentException a part is owned by a character other than {@code character}
     */
    public CharacterRuntime(CharacterSummary character, CharacterStatsProfile progression,
                            ItemInventory inventory, ItemEquipment equipment) {
        this.character = Objects.requireNonNull(character, "character");
        this.progression = Objects.requireNonNull(progression, "progression");
        this.inventory = Objects.requireNonNull(inventory, "inventory");
        this.equipment = Objects.requireNonNull(equipment, "equipment");

        CharacterId id = character.id();
        requireOwnedBy(id, "progression", progression.characterId());
        requireOwnedBy(id, "inventory", inventory.ownerId());
        requireOwnedBy(id, "equipment", equipment.ownerId());
    }

    private static void requireOwnedBy(CharacterId expected, String part, CharacterId actual) {
        if (!expected.equals(actual)) {
            throw new IllegalArgumentException("Character " + expected + " cannot be assembled with " + part
                    + " owned by character " + actual);
        }
    }

    public CharacterId characterId() {
        return character.id();
    }

    public CharacterSummary character() {
        return character;
    }

    public CharacterStatsProfile progression() {
        return progression;
    }

    public ItemInventory inventory() {
        return inventory;
    }

    public ItemEquipment equipment() {
        return equipment;
    }
}
