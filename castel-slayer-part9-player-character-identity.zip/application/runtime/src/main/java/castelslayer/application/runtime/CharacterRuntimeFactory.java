package castelslayer.application.runtime;

import character.contracts.CharacterSummary;
import equipment.domain.ItemEquipment;
import inventory.domain.ItemInventory;
import java.util.EnumMap;
import java.util.Objects;
import progression.domain.AttributeType;
import progression.domain.CharacterAttributes;
import progression.domain.CharacterStatsProfile;

/**
 * Assembles a {@link CharacterRuntime} from a character plus its module state — pure
 * plain-Java composition, no I/O, no framework, no Paper. Two ways in, one out:
 *
 * <ul>
 *   <li>{@link #createNew} — the character has no saved state yet: build each module's initial
 *       state from {@link CharacterRuntimeDefaults};</li>
 *   <li>{@link #restore} — rebuild each module's state from its snapshot;</li>
 *   <li>{@link #snapshotOf} — the reverse, for saving.</li>
 * </ul>
 *
 * Both entry points verify that every piece belongs to the character (the
 * {@link CharacterRuntime} constructor is the last line of defence and throws on any mismatch).
 * Fetching the snapshot from storage is {@link CharacterRuntimeService}'s job, not this class's —
 * which is what keeps this one trivially testable.
 */
public final class CharacterRuntimeFactory {

    private final CharacterRuntimeDefaults defaults;

    public CharacterRuntimeFactory(CharacterRuntimeDefaults defaults) {
        this.defaults = Objects.requireNonNull(defaults, "defaults");
    }

    /** A runtime with freshly-initialised module state for a character that has none saved. */
    public CharacterRuntime createNew(CharacterSummary character) {
        Objects.requireNonNull(character, "character");
        var id = character.id();
        CharacterAttributes attributes = new CharacterAttributes(new EnumMap<AttributeType, Integer>(defaults.baseAttributes()));
        return new CharacterRuntime(
                character,
                CharacterStatsProfile.createNew(id, attributes),
                new ItemInventory(id, defaults.inventoryCapacity()),
                new ItemEquipment(id));
    }

    /**
     * A runtime rebuilt from saved state.
     *
     * @throws IllegalArgumentException the snapshot is for a different character, or one of its
     *                                  parts is not a valid state for its module
     */
    public CharacterRuntime restore(CharacterSummary character, CharacterRuntimeSnapshot snapshot) {
        Objects.requireNonNull(character, "character");
        Objects.requireNonNull(snapshot, "snapshot");
        if (!character.id().equals(snapshot.characterId())) {
            throw new IllegalArgumentException("Snapshot for character " + snapshot.characterId()
                    + " cannot be restored for character " + character.id());
        }
        return new CharacterRuntime(
                character,
                CharacterStatsProfile.fromSnapshot(snapshot.progression()),
                ItemInventory.fromSnapshot(snapshot.inventory()),
                ItemEquipment.fromSnapshot(snapshot.equipment()));
    }

    /** An immutable copy of the runtime's current persistable state. */
    public CharacterRuntimeSnapshot snapshotOf(CharacterRuntime runtime) {
        Objects.requireNonNull(runtime, "runtime");
        return new CharacterRuntimeSnapshot(
                runtime.characterId(),
                runtime.progression().toSnapshot(),
                runtime.inventory().toSnapshot(),
                runtime.equipment().toSnapshot());
    }
}
