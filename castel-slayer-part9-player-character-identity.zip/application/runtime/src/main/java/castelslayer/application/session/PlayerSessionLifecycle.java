package castelslayer.application.session;

import core.contracts.IEventBus;
import core.contracts.Subscription;
import core.events.PlayerJoinedWorld;
import core.events.PlayerLeftWorld;
import java.util.List;
import java.util.Objects;

/**
 * Connects the two lifecycle events to {@link PlayerSessionService}:
 *
 * <pre>
 *   PlayerJoinedWorld ─► join  (resolve character, load runtime, session becomes active)
 *   PlayerLeftWorld   ─► quit  (session released, state saved)
 * </pre>
 *
 * The bus only <em>triggers</em>; the flow and every rule live in the service. Outcomes go to the
 * {@link SessionOutcomeListener} because the bus swallows handler failures. {@link #close()}
 * unsubscribes, so the wiring is explicit and reversible.
 */
public final class PlayerSessionLifecycle implements AutoCloseable {

    private final IEventBus eventBus;
    private final List<Subscription> subscriptions;

    public PlayerSessionLifecycle(IEventBus eventBus, PlayerSessionService service, SessionOutcomeListener listener) {
        this.eventBus = Objects.requireNonNull(eventBus, "eventBus");
        Objects.requireNonNull(service, "service");
        Objects.requireNonNull(listener, "listener");

        this.subscriptions = List.of(
                eventBus.subscribe(PlayerJoinedWorld.class,
                        e -> listener.onJoin(e.playerId(), service.join(e.playerId()))),
                eventBus.subscribe(PlayerLeftWorld.class,
                        e -> listener.onQuit(e.playerId(), service.quit(e.playerId()))));
    }

    @Override
    public void close() {
        subscriptions.forEach(eventBus::unsubscribe);
    }
}
