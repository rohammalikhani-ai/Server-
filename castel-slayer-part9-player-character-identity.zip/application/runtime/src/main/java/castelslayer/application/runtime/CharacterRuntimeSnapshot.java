package castelslayer.application.runtime;

import character.contracts.CharacterId;
import equipment.contracts.EquipmentSnapshot;
import inventory.contracts.InventorySnapshot;
import java.util.Objects;
import progression.contracts.CharacterProgressionSnapshot;

/**
 * Everything persisted about one active character's runtime, as a single immutable record:
 * the three modules' own public snapshot models side by side. This is what
 * {@link CharacterRuntimeService} hands to {@code IPersistenceGateway}.
 *
 * <p>One record, saved under one key, on purpose: {@code IPersistenceGateway} has no
 * transactions, so three separate saves could leave a crash between them with, say, a sword gone
 * from the inventory but not yet recorded as equipped. One key is one write — all or nothing on any
 * reasonable store. (The character's own record — name, owner, lifecycle — stays in the character
 * module's directory; it does not change during a session.)
 *
 * <p>An envelope, not a domain type: each part is defined and validated by the module that owns
 * it. The only thing checked here is the cross-module invariant this layer is responsible for —
 * every part belongs to {@code characterId}.
 *
 * @throws IllegalArgumentException (from the constructor) a part belongs to a different character
 */
public record CharacterRuntimeSnapshot(CharacterId characterId, CharacterProgressionSnapshot progression,
                                       InventorySnapshot inventory, EquipmentSnapshot equipment) {

    public CharacterRuntimeSnapshot {
        Objects.requireNonNull(characterId, "characterId");
        Objects.requireNonNull(progression, "progression");
        Objects.requireNonNull(inventory, "inventory");
        Objects.requireNonNull(equipment, "equipment");
        requireOwnedBy(characterId, "progression", progression.characterId());
        requireOwnedBy(characterId, "inventory", inventory.ownerId());
        requireOwnedBy(characterId, "equipment", equipment.ownerId());
    }

    private static void requireOwnedBy(CharacterId expected, String what, CharacterId actual) {
        if (!expected.equals(actual)) {
            throw new IllegalArgumentException("Runtime snapshot for character " + expected + " contains " + what
                    + " state owned by character " + actual);
        }
    }
}
