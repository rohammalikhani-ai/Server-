package castelslayer.application.session;

import core.domain.PlayerId;

/**
 * Receives the outcome of an event-driven join/quit. The event bus deliberately swallows
 * subscriber failures, and {@code core} has no logging abstraction, so without this hook a failed
 * load or save triggered by an event would be invisible. The platform layer supplies an
 * implementation that logs; {@link #NONE} ignores everything (tests, or when nobody cares).
 */
public interface SessionOutcomeListener {

    SessionOutcomeListener NONE = new SessionOutcomeListener() {
    };

    default void onJoin(PlayerId playerId, SessionJoinResult result) {
    }

    default void onQuit(PlayerId playerId, SessionQuitResult result) {
    }
}
