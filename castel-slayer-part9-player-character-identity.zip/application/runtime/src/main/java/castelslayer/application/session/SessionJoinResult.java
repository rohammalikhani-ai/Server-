package castelslayer.application.session;

import castelslayer.application.runtime.CharacterLoadResult;
import character.contracts.CharacterId;
import core.domain.PlayerId;
import java.util.Objects;

/** The outcome of {@link PlayerSessionService#join}. Every non-success case is distinct — nothing is reported as {@code null}. */
public sealed interface SessionJoinResult {

    /** A runtime was loaded and the player's session is now active. */
    record Joined(PlayerSession session) implements SessionJoinResult {
        public Joined {
            Objects.requireNonNull(session, "session");
        }
    }

    /** The player already had an active session; nothing was loaded or changed. */
    record AlreadyActive(PlayerSession session) implements SessionJoinResult {
        public AlreadyActive {
            Objects.requireNonNull(session, "session");
        }
    }

    /** The player has no character to play (e.g. none created yet). */
    record NoCharacter(PlayerId playerId) implements SessionJoinResult {
        public NoCharacter {
            Objects.requireNonNull(playerId, "playerId");
        }
    }

    /** The selected character is already active for another player; nothing was loaded. */
    record CharacterInUse(PlayerId playerId, CharacterId characterId, PlayerId activeFor) implements SessionJoinResult {
        public CharacterInUse {
            Objects.requireNonNull(playerId, "playerId");
            Objects.requireNonNull(characterId, "characterId");
            Objects.requireNonNull(activeFor, "activeFor");
        }
    }

    /**
     * The character could not be made active: not found, retired, or a failure while reading it
     * ({@code reason} keeps those apart — see {@link CharacterLoadResult}).
     */
    record LoadRejected(PlayerId playerId, CharacterLoadResult reason) implements SessionJoinResult {
        public LoadRejected {
            Objects.requireNonNull(playerId, "playerId");
            Objects.requireNonNull(reason, "reason");
        }
    }
}
