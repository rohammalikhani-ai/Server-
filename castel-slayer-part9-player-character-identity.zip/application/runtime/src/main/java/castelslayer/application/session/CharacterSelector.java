package castelslayer.application.session;

import character.contracts.CharacterId;
import core.domain.PlayerId;
import java.util.Optional;

/**
 * Decides which character a joining player plays: {@code PlayerId → CharacterId}. This is the
 * seam where a real character-selection flow will plug in later (a menu, a command, a stored
 * "last played" choice). Until then {@link DirectoryCharacterSelector} answers deterministically
 * from the character directory — no selection UI is faked here.
 */
@FunctionalInterface
public interface CharacterSelector {

    /** The character {@code playerId} should play now, or empty if they have none to play. */
    Optional<CharacterId> select(PlayerId playerId);
}
