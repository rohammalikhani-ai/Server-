package castelslayer.application.session;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import character.contracts.ICharacterDirectory;
import core.domain.PlayerId;
import java.util.Objects;
import java.util.Optional;

/**
 * The development/test {@link CharacterSelector}: a player plays their single active character,
 * as reported by {@link ICharacterDirectory#findActiveForPlayer}. Deterministic and stateless.
 * The directory's one-active-character-per-player rule is a documented prototype limit of the
 * character module, not an assumption of this application layer — replace this selector, not the
 * session code, when multi-character selection arrives.
 */
public final class DirectoryCharacterSelector implements CharacterSelector {

    private final ICharacterDirectory directory;

    public DirectoryCharacterSelector(ICharacterDirectory directory) {
        this.directory = Objects.requireNonNull(directory, "directory");
    }

    @Override
    public Optional<CharacterId> select(PlayerId playerId) {
        Objects.requireNonNull(playerId, "playerId");
        return directory.findActiveForPlayer(playerId).map(CharacterSummary::id);
    }
}
