package castelslayer.application.runtime;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import progression.domain.AttributeType;
import progression.domain.CharacterAttributes;

/**
 * The starting module state a character gets the first time it becomes active (nothing saved
 * yet): base attribute values and inventory size. Deliberately a plain value passed in by the
 * composition root rather than constants buried in the factory, so these numbers have exactly one
 * place to change — and, once a production {@code IConfigProvider} exists, one place to be read
 * from.
 *
 * <p>{@link #standard()} is a <b>development placeholder</b>, not game design: it exists so a
 * fresh character is valid and testable, in the same spirit as {@code DefaultProgressionCurve}.
 *
 * @param baseAttributes  a base value for every {@link AttributeType}; validated by {@link CharacterAttributes}
 * @param inventoryCapacity number of inventory slots; at least 1
 */
public record CharacterRuntimeDefaults(Map<AttributeType, Integer> baseAttributes, int inventoryCapacity) {

    private static final int DEVELOPMENT_ATTRIBUTE_VALUE = 5;
    private static final int DEVELOPMENT_INVENTORY_CAPACITY = 20;

    public CharacterRuntimeDefaults {
        Objects.requireNonNull(baseAttributes, "baseAttributes");
        if (inventoryCapacity < 1) {
            throw new IllegalArgumentException("inventoryCapacity must be at least 1 (was " + inventoryCapacity + ")");
        }
        Map<AttributeType, Integer> copy = new EnumMap<>(AttributeType.class);
        copy.putAll(baseAttributes);
        new CharacterAttributes(copy); // throws unless every attribute is present and in range
        baseAttributes = Map.copyOf(copy);
    }

    /** Development placeholder defaults: every attribute 5, a 20-slot inventory. */
    public static CharacterRuntimeDefaults standard() {
        Map<AttributeType, Integer> values = new EnumMap<>(AttributeType.class);
        for (AttributeType type : AttributeType.values()) {
            values.put(type, DEVELOPMENT_ATTRIBUTE_VALUE);
        }
        return new CharacterRuntimeDefaults(values, DEVELOPMENT_INVENTORY_CAPACITY);
    }
}
