package castelslayer.application.session;

import castelslayer.application.runtime.CharacterRuntime;
import character.contracts.CharacterId;
import core.domain.PlayerId;
import java.util.Objects;

/**
 * Associates one connected player with the character runtime they are currently playing.
 *
 * <p>The two identities stay distinct on purpose: {@link #playerId()} identifies the connected
 * Minecraft account, {@link #characterId()} identifies the gameplay character (and is what owns
 * progression, inventory and equipment). Nothing derives one from the other, and a player may
 * eventually own several characters — this record only says which one is active right now.
 */
public record PlayerSession(PlayerId playerId, CharacterRuntime runtime) {

    public PlayerSession {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(runtime, "runtime");
    }

    public CharacterId characterId() {
        return runtime.characterId();
    }
}
