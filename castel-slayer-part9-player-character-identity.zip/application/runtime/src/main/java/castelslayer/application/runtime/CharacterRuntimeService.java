package castelslayer.application.runtime;

import character.contracts.CharacterId;
import character.contracts.CharacterSummary;
import character.contracts.ICharacterDirectory;
import core.contracts.IPersistenceGateway;
import java.util.Objects;
import java.util.Optional;

/**
 * Loads and saves {@link CharacterRuntime}s. This is the application layer's persistence
 * boundary — the counterpart of {@code CharacterDirectoryService} in the character module: it is
 * the only class here that touches {@link IPersistenceGateway}, and it never sees a concrete store,
 * only the interface, so whether the data lives in memory, a file or a database is invisible to it.
 *
 * <pre>
 *   load:  ICharacterDirectory ──► character          (exists? active?)
 *          IPersistenceGateway ──► CharacterRuntimeSnapshot   (saved before? else fresh defaults)
 *          CharacterRuntimeFactory ──► CharacterRuntime
 *   save:  CharacterRuntime ──► CharacterRuntimeSnapshot ──► IPersistenceGateway
 * </pre>
 *
 * <p>Errors are explicit, not swallowed and not null: {@link #load} returns a
 * {@link CharacterLoadResult} that separates "not found", "retired" and "failed to load", and
 * {@link #save} lets a {@link core.contracts.PersistenceException} propagate so the caller knows the
 * state was not durably stored. A module with no saved state yet is <em>not</em> an error — a
 * character that has never been active simply starts from {@link CharacterRuntimeDefaults}.
 */
public final class CharacterRuntimeService {

    static final String COLLECTION = "character-runtime";

    private final ICharacterDirectory directory;
    private final IPersistenceGateway persistence;
    private final CharacterRuntimeFactory factory;

    public CharacterRuntimeService(ICharacterDirectory directory, IPersistenceGateway persistence,
                                   CharacterRuntimeFactory factory) {
        this.directory = Objects.requireNonNull(directory, "directory");
        this.persistence = Objects.requireNonNull(persistence, "persistence");
        this.factory = Objects.requireNonNull(factory, "factory");
    }

    /**
     * Resolves a character id to a ready-to-activate runtime. Never returns null and never throws for
     * a data/storage problem — those are {@link CharacterLoadResult.Failed}. A {@link CharacterLoadResult.Loaded}
     * runtime always belongs to the requested {@code id}: if the directory answers with a different
     * character, that is a {@code Failed}, never a runtime for the wrong character. (Catching
     * {@code RuntimeException} here is deliberate: this is an application boundary that must turn any
     * load-time failure — a gateway outage, a corrupt snapshot — into a reportable result; the
     * original exception is preserved in {@code Failed#cause}.)
     */
    public CharacterLoadResult load(CharacterId id) {
        Objects.requireNonNull(id, "id");
        try {
            Optional<CharacterSummary> found = directory.findById(id);
            if (found.isEmpty()) {
                return new CharacterLoadResult.NotFound(id);
            }
            CharacterSummary character = found.get();
            if (!id.equals(character.id())) {
                // Ownership guard: whatever the directory answered, the runtime must be for the
                // character that was asked for. Anything else would silently hand A's session B's state.
                throw new IllegalStateException("directory answered a request for character " + id
                        + " with character " + character.id());
            }
            if (!character.active()) {
                return new CharacterLoadResult.NotActive(id);
            }
            Optional<CharacterRuntimeSnapshot> saved =
                    persistence.load(COLLECTION, id.toString(), CharacterRuntimeSnapshot.class);
            CharacterRuntime runtime = saved.isPresent()
                    ? factory.restore(character, saved.get())
                    : factory.createNew(character);
            return new CharacterLoadResult.Loaded(runtime);
        } catch (RuntimeException e) {
            return new CharacterLoadResult.Failed(id, "could not load character " + id + ": " + e.getMessage(), e);
        }
    }

    /**
     * Persists the runtime's current module state.
     *
     * @throws core.contracts.PersistenceException the store could not be written; the state is NOT saved
     */
    public void save(CharacterRuntime runtime) {
        Objects.requireNonNull(runtime, "runtime");
        persistence.save(COLLECTION, runtime.characterId().toString(), factory.snapshotOf(runtime));
    }
}
