package castelslayer.application.runtime;

import character.contracts.CharacterId;
import java.util.Objects;

/**
 * The outcome of {@link CharacterRuntimeService#load}. Three different non-success cases are kept
 * apart on purpose, because callers must be able to tell them apart:
 *
 * <ul>
 *   <li>{@link NotFound} — no character has that id (a normal answer);</li>
 *   <li>{@link NotActive} — it exists but is retired, so it cannot be played;</li>
 *   <li>{@link Failed} — something went wrong reading it (storage failure, corrupt saved state).
 *       Never confused with {@link NotFound}: "I could not read it" must not be reported as "it
 *       does not exist", or a transient outage would look like data loss.</li>
 * </ul>
 */
public sealed interface CharacterLoadResult {

    /** The runtime was assembled and is ready to become active. */
    record Loaded(CharacterRuntime runtime) implements CharacterLoadResult {
        public Loaded {
            Objects.requireNonNull(runtime, "runtime");
        }
    }

    /** No character has this id. */
    record NotFound(CharacterId characterId) implements CharacterLoadResult {
        public NotFound {
            Objects.requireNonNull(characterId, "characterId");
        }
    }

    /** The character exists but is retired. */
    record NotActive(CharacterId characterId) implements CharacterLoadResult {
        public NotActive {
            Objects.requireNonNull(characterId, "characterId");
        }
    }

    /** Loading was attempted and failed; {@code cause} says why. */
    record Failed(CharacterId characterId, String reason, Throwable cause) implements CharacterLoadResult {
        public Failed {
            Objects.requireNonNull(characterId, "characterId");
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(cause, "cause");
        }
    }
}
