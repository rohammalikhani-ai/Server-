// :application:runtime — the Paper-free application layer that sits between platform/java and the
// feature modules (see docs/decisions/0004-application-runtime-layer.md). It composes ONE active
// character's module-owned state (CharacterRuntime), associates a connected player with it
// (PlayerSession / SessionManager) and drives the join -> load -> quit -> save lifecycle. It holds
// no gameplay rules: each module still owns its own state and rules.
//
// Why a new Gradle module instead of an existing one: composing Character + Progression +
// Inventory + Equipment needs a dependency on all four, and none of them may depend on each other
// (character must not know inventory/equipment; equipment must not depend on inventory internals),
// nor may the domain depend on the platform. platform/java would work mechanically but would put
// application logic in the Paper layer and make it depend on every domain module.
//
// It uses java-library's `api` on purpose: CharacterRuntime's public API exposes the four modules'
// aggregate/state types, so consumers need them on their compile classpath. Only THIS module is
// meant to touch the modules' aggregates; platform/java talks to core + this module only.
// Source layout follows platform/java (standard src/main/java); tests live under tests/application/runtime.

plugins {
    `java-library`
}

sourceSets {
    test {
        java {
            setSrcDirs(listOf(rootProject.file("tests/application/runtime"), rootProject.file("tests/support")))
        }
        resources {
            setSrcDirs(emptyList<String>())
        }
    }
}

dependencies {
    api(project(":core"))
    api(project(":modules:character"))
    api(project(":modules:progression"))
    api(project(":modules:inventory"))
    api(project(":modules:equipment"))
}
